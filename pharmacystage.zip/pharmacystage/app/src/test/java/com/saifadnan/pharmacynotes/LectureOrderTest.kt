package com.saifadnan.pharmacynotes

import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.util.LectureOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class LectureOrderTest {

    private var nextId = 1L

    private fun lec(title: String, semester: Int = 1, ts: Long = 0, subject: String = "S") =
        LectureEntity(
            id = nextId++,
            title = title,
            subject = subject,
            semester = semester,
            fileUrl = "u",
            uploadTimestamp = ts
        )

    private fun List<LectureEntity>.inFolder() = sortedWith(LectureOrder.inFolder).map { it.title }

    @Test
    fun numbersAreSortedNumericallyNotAlphabetically() {
        val list = listOf(lec("محاضرة 10"), lec("محاضرة 2"), lec("محاضرة 1"), lec("محاضرة 11"), lec("محاضرة 3"))
        assertEquals(listOf("محاضرة 1", "محاضرة 2", "محاضرة 3", "محاضرة 10", "محاضرة 11"), list.inFolder())
    }

    @Test
    fun uploadOrderDoesNotMatter() {
        val list = listOf(lec("Lecture 3", ts = 1), lec("Lecture 2", ts = 2), lec("Lecture 1", ts = 3))
        assertEquals(listOf("Lecture 1", "Lecture 2", "Lecture 3"), list.inFolder())
    }

    @Test
    fun arabicIndicDigitsAreUnderstood() {
        val list = listOf(lec("المحاضرة ١٠"), lec("المحاضرة ٢"), lec("المحاضرة ١"))
        assertEquals(listOf("المحاضرة ١", "المحاضرة ٢", "المحاضرة ١٠"), list.inFolder())
    }

    @Test
    fun yearInTitleIsNotALectureNumber() {
        val list = listOf(lec("2024 Lecture 5"), lec("2024 Lecture 4"), lec("2024 Lecture 12"))
        assertEquals(listOf("2024 Lecture 4", "2024 Lecture 5", "2024 Lecture 12"), list.inFolder())
    }

    @Test
    fun unnumberedTitlesComeLastOldestFirst() {
        val list = listOf(lec("مراجعة", ts = 5), lec("مقدمة", ts = 3), lec("محاضرة 2"), lec("محاضرة 1"))
        assertEquals(listOf("محاضرة 1", "محاضرة 2", "مقدمة", "مراجعة"), list.inFolder())
    }

    @Test
    fun firstSemesterBeforeSecondWhenNumberingRestarts() {
        val list = listOf(lec("Lec 1", semester = 2), lec("Lec 2", semester = 1), lec("Lec 2", semester = 2), lec("Lec 1", semester = 1))
        val sorted = list.sortedWith(LectureOrder.inFolder).map { "${it.semester}:${it.title}" }
        assertEquals(listOf("1:Lec 1", "1:Lec 2", "2:Lec 1", "2:Lec 2"), sorted)
    }

    @Test
    fun partsOfTheSameLectureAreNaturallySorted() {
        val list = listOf(lec("Lec 3 part 10"), lec("Lec 3 part 2"), lec("Lec 3 part 1"))
        assertEquals(listOf("Lec 3 part 1", "Lec 3 part 2", "Lec 3 part 10"), list.inFolder())
    }

    @Test
    fun searchResultsAreGroupedBySubject() {
        val list = listOf(lec("Lec 2", subject = "B"), lec("Lec 1", subject = "B"), lec("Lec 3", subject = "A"), lec("Lec 1", subject = "A"))
        val sorted = list.sortedWith(LectureOrder.inSearchResults).map { "${it.subject}${it.title.last()}" }
        assertEquals(listOf("A1", "A3", "B1", "B2"), sorted)
    }

    @Test
    fun comparatorIsConsistentSoSortingNeverThrows() {
        val rnd = java.util.Random(42)
        val pieces = listOf("محاضرة ", "Lec ", "L", " ", "1", "2", "٣", "10", "0", "a", "ا", "-", "(", "2024")
        repeat(300) {
            val list = (0 until 80).map {
                lec(
                    title = (0 until rnd.nextInt(6)).joinToString("") { pieces[rnd.nextInt(pieces.size)] },
                    semester = 1 + rnd.nextInt(2),
                    ts = rnd.nextInt(5).toLong()
                )
            }
            list.sortedWith(LectureOrder.inFolder)
        }
    }
}
