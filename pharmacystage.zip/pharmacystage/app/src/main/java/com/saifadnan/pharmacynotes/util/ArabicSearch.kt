package com.saifadnan.pharmacynotes.util

object ArabicSearch {

    private val diacriticsRange = 0x064B..0x0652

    fun normalize(text: String): String {
        if (text.isEmpty()) return text
        val sb = StringBuilder(text.length)
        for (ch in text) {
            if (ch.code in diacriticsRange) continue
            val mapped = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                else -> ch
            }
            sb.append(mapped)
        }
        return sb.toString().lowercase().trim()
    }

    fun matches(haystack: String, needle: String): Boolean {
        if (needle.isBlank()) return true
        return normalize(haystack).contains(normalize(needle))
    }
}
