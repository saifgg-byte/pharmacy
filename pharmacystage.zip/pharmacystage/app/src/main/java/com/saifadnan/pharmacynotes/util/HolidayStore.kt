package com.saifadnan.pharmacynotes.util

import android.content.Context
import android.util.Log
import com.saifadnan.pharmacynotes.data.ResilientDns
import com.saifadnan.pharmacynotes.data.ServerConfig
import com.saifadnan.pharmacynotes.data.Stages
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object HolidayStore {
    private const val TAG = "HolidayStore"
    private const val PREFS = "holidays_cache"
    private const val KEY_JSON = "holidays_json"
    private const val KEY_LAST_REFRESH = "last_refresh"

    private val client by lazy {
        OkHttpClient.Builder()
            .dns(ResilientDns)
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(3, TimeUnit.SECONDS)
            .callTimeout(5, TimeUnit.SECONDS)
            .build()
    }

    fun refreshBlocking(context: Context): Boolean {
        return try {
            val request = Request.Builder()
                .url(ServerConfig.BASE_URL.trimEnd('/') + "/holidays")
                .header("X-Stage", Stages.current.toString())
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    false
                } else {
                    val body = response.body?.string().orEmpty()
                    JSONArray(body)
                    context.applicationContext
                        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit()
                        .putString(KEY_JSON, body)
                        .putLong(KEY_LAST_REFRESH, System.currentTimeMillis())
                        .apply()
                    true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "holiday refresh failed: ${e.message}")
            false
        }
    }

    fun refreshIfStale(context: Context, maxAgeMs: Long = 30 * 60 * 1000L) {
        val last = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_LAST_REFRESH, 0L)
        if (System.currentTimeMillis() - last >= maxAgeMs) refreshBlocking(context)
    }

    fun isHolidayToday(context: Context, now: Date = Date()): Boolean {

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val json = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_JSON, null) ?: return false
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).any { i ->
                val o = arr.getJSONObject(i)
                val start = o.optString("startDate")
                val end = o.optString("endDate")
                start.isNotEmpty() && end.isNotEmpty() && today >= start && today <= end
            }
        } catch (e: Exception) {
            false
        }
    }
}
