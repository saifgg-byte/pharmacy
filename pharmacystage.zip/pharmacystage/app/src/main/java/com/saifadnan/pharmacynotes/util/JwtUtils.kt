package com.saifadnan.pharmacynotes.util

import android.util.Base64
import org.json.JSONObject

object JwtUtils {
    private fun payload(token: String?): JSONObject? {
        if (token.isNullOrBlank()) return null
        val parts = token.split('.')
        if (parts.size < 2) return null
        return try {
            val bytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            JSONObject(String(bytes, Charsets.UTF_8))
        } catch (e: Exception) {
            null
        }
    }

    fun email(token: String?): String? =
        payload(token)?.optString("email")?.takeIf { it.isNotBlank() }

    fun role(token: String?): String? =
        payload(token)?.optString("role")?.takeIf { it.isNotBlank() }

    fun expiryMs(token: String?): Long {
        val exp = payload(token)?.optLong("exp", 0L) ?: 0L
        return if (exp > 0) exp * 1000L else 0L
    }
}
