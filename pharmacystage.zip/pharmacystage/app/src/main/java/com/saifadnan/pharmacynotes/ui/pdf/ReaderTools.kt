package com.saifadnan.pharmacynotes.ui.pdf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.FormatColorReset
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.material.icons.filled.Translate
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import kotlinx.coroutines.delay

class MarkedItem(val page: Int, val starred: Boolean, val hasHighlight: Boolean, val note: String?)

@Composable
fun PageNoteDialog(
    pageNumber: Int,
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ملاحظتي على صفحة $pageNumber", style = MaterialTheme.typography.titleMedium) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(1000) },
                minLines = 4,
                maxLines = 8,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }) { Text("حفظ", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                if (initial.isNotBlank()) {
                    TextButton(onClick = { onSave("") }) {
                        Text("حذف", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        }
    )
}

@Composable
fun MarkedPagesDialog(
    items: List<MarkedItem>,
    onJump: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الصفحات المميّزة", style = MaterialTheme.typography.titleMedium) },
        text = {
            if (items.isEmpty()) {
                Text(
                    "لا توجد صفحات مميّزة بعد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(items, key = { it.page }) { item ->
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onJump(item.page) }
                                    .padding(horizontal = 6.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        "صفحة ${item.page + 1}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (!item.note.isNullOrBlank()) {
                                        Text(
                                            item.note,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (item.starred) {
                                    Icon(Icons.Default.Star, contentDescription = "معلّمة", tint = Amber, modifier = Modifier.size(18.dp))
                                }
                                if (item.hasHighlight) {
                                    Icon(Icons.Default.Brush, contentDescription = "تظليل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                                if (!item.note.isNullOrBlank()) {
                                    Icon(Icons.Default.EditNote, contentDescription = "ملاحظة", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                }
                            }
                            HorizontalDivider(color = CardBorder)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
fun LectureSearchDialog(
    lectureId: Long,
    onJump: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SupabaseClient.LectureSearch?>(null) }
    var searched by remember { mutableStateOf("") }

    LaunchedEffect(query) {
        val q = query.trim()
        if (q.length < 2) {
            result = null
            loading = false
            return@LaunchedEffect
        }
        delay(450)
        loading = true
        val r = SupabaseClient.searchLecture(lectureId, q)
        result = r
        searched = q
        loading = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بحث في المحاضرة", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it.take(80) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                val r = result
                Box(modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp, max = 340.dp)) {
                    when {
                        loading -> CircularProgressIndicator(
                            modifier = Modifier.size(26.dp).align(Alignment.Center),
                            strokeWidth = 2.5.dp
                        )
                        r == null -> Text(
                            "اكتب كلمة أو جملة للبحث في نص المحاضرة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                        )
                        r.error != null -> Text(
                            r.error,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                        )
                        !r.available -> Text(
                            "البحث غير متاح لهذه المحاضرة، وقد يكون الملف صوراً ممسوحة ضوئياً.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                        )
                        r.hits.isEmpty() -> Text(
                            "لا توجد نتائج لـ \"$searched\".",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                        )
                        else -> LazyColumn {
                            items(r.hits, key = { it.page }) { hit ->
                                Column {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onJump(hit.page - 1) }
                                            .padding(horizontal = 6.dp, vertical = 10.dp),
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text(
                                            text = if (hit.count > 1) "صفحة ${hit.page} · ${hit.count} نتائج" else "صفحة ${hit.page}",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = hit.snippet,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    HorizontalDivider(color = CardBorder)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
private fun SelectionAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

@Composable
fun SelectionActionBar(
    onCopy: () -> Unit,
    onHighlight: () -> Unit,
    onAsk: () -> Unit,
    onTranslate: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    showRemoveHighlight: Boolean = false,
    onRemoveHighlight: () -> Unit = {}
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(1.dp, CardBorder, RoundedCornerShape(22.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        SelectionAction(Icons.Default.ContentCopy, "نسخ", onCopy)
        SelectionAction(Icons.Default.Highlight, "تظليل", onHighlight)
        AnimatedVisibility(
            visible = showRemoveHighlight,
            enter = fadeIn() + expandHorizontally(),
            exit = fadeOut() + shrinkHorizontally()
        ) {
            SelectionAction(Icons.Default.FormatColorReset, "إزالة التظليل", onRemoveHighlight)
        }
        SelectionAction(Icons.Default.AutoAwesome, "اسأل المساعد", onAsk)
        SelectionAction(Icons.Default.Translate, "ترجمة", onTranslate)
        Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "إلغاء التحديد",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .clickable(onClick = onClose)
                .padding(7.dp)
        )
    }
}
