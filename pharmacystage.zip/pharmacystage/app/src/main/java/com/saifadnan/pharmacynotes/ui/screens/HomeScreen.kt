package com.saifadnan.pharmacynotes.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import com.saifadnan.pharmacynotes.ui.theme.rememberAdaptive
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Image
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.ImeAction
import com.saifadnan.pharmacynotes.data.Category
import com.saifadnan.pharmacynotes.data.Course
import com.saifadnan.pharmacynotes.data.Section
import com.saifadnan.pharmacynotes.ui.components.CategoryTabs
import com.saifadnan.pharmacynotes.ui.components.SectionSwitcher
import com.saifadnan.pharmacynotes.ui.components.GlassSortChip
import com.saifadnan.pharmacynotes.ui.components.WorksheetActionRow
import com.saifadnan.pharmacynotes.ui.components.WorksheetViewerDialog
import com.saifadnan.pharmacynotes.ui.components.YoutubeLinkButton
import com.saifadnan.pharmacynotes.util.PdfHelper
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.data.SubjectEntity
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.HomeTabSkeleton
import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.LazyListPrefetchHandler
import com.saifadnan.pharmacynotes.ui.components.MedicalEmptyFolderState
import com.saifadnan.pharmacynotes.ui.components.MedicalEmptyLectureState
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.SectionLabel
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.components.shimmerEffect
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.TelegramAccent
import com.saifadnan.pharmacynotes.ui.theme.glass
import com.saifadnan.pharmacynotes.ui.viewmodel.SortOrder
import com.saifadnan.pharmacynotes.util.ArabicSearch

private data class HomeHeaderState(val title: String, val subtitle: String, val showBack: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    subjects: List<SubjectEntity>,
    examPinnedSubjects: List<SubjectEntity>,
    lectures: List<LectureEntity>,
    totalLecturesCount: Int = 0,
    allLectures: List<LectureEntity> = emptyList(),
    selectedSection: String = Section.THEORY,
    onSectionSelect: (String) -> Unit = {},
    selectedCategory: String = Category.OFFICIAL,
    onCategorySelect: (String) -> Unit = {},
    categoryCounts: Map<String, Int> = emptyMap(),
    selectedSubject: String?,
    searchQuery: String,
    selectedSemester: Int,
    onlyDownloaded: Boolean,
    onlyBookmarked: Boolean = false,
    sortOrder: SortOrder,
    onSubjectSelect: (String?) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSemesterSelect: (Int) -> Unit,
    onToggleOnlyDownloaded: () -> Unit,
    onToggleOnlyBookmarked: () -> Unit = {},
    onSortOrderChange: (SortOrder) -> Unit,
    onLectureClick: (LectureEntity) -> Unit,
    onToggleBookmark: (LectureEntity) -> Unit,
    onToggleDownload: (LectureEntity) -> Unit,
    downloadProgress: Map<Long, Int> = emptyMap(),
    isRefreshing: Boolean = false,
    isTabLoading: Boolean = false,
    onReloadClick: () -> Unit = {},
    isDarkMode: Boolean = false,
    onThemeToggle: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val pullToRefreshState = rememberPullToRefreshState()

    val inFolderView = selectedSubject != null || onlyBookmarked || onlyDownloaded
    val inLectureView = inFolderView || searchQuery.isNotEmpty()

    val goBack: () -> Unit = {
        when {
            selectedSubject != null -> onSubjectSelect(null)
            onlyBookmarked -> onToggleOnlyBookmarked()
            onlyDownloaded -> onToggleOnlyDownloaded()
            searchQuery.isNotBlank() -> onSearchQueryChange("")
        }
    }

    BackHandler(enabled = selectedSubject != null || searchQuery.isNotBlank() || onlyDownloaded || onlyBookmarked) {
        goBack()
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onReloadClick,
        state = pullToRefreshState,
        indicator = {
            PullToRefreshDefaults.Indicator(
                state = pullToRefreshState,
                isRefreshing = isRefreshing,
                modifier = Modifier.align(Alignment.TopCenter),
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        modifier = modifier.fillMaxSize()
    ) {
        if (isTabLoading) {
            HomeTabSkeleton(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            )
        } else {
            val listState = rememberLazyListState()
            LazyListPrefetchHandler(lazyListState = listState, bufferItems = 3) {

            }

            val countsBySubject = remember(allLectures, selectedSection, selectedSemester) {
                allLectures.filter { it.section == selectedSection && it.semester == selectedSemester }
                    .groupBy { it.subject }
                    .mapValues { (_, list) -> list.groupingBy { it.category }.eachCount() }
            }
            var worksheetLecture by remember { mutableStateOf<LectureEntity?>(null) }
            val worksheetContext = LocalContext.current
            worksheetLecture?.let { l ->
                WorksheetViewerDialog(
                    imageUrl = l.worksheetUrl,
                    title = l.title,
                    type = l.worksheetType,
                    onDismiss = { worksheetLecture = null }
                )
            }
            val adaptive = rememberAdaptive()
            BoxWithConstraints(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            val columns = adaptive.columnsFor(maxWidth)
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(
                    start = adaptive.horizontalPadding,
                    end = adaptive.horizontalPadding,
                    top = 8.dp,
                    bottom = 28.dp
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.widthIn(max = adaptive.gridMaxWidth).fillMaxSize()
            ) {

                item(key = "home_header") {
                    val header = when {
                        selectedSubject != null -> HomeHeaderState(
                            selectedSubject,
                            "${Section.label(selectedSection)} · ${Course.label(selectedSemester)} · ${lectures.size} ${if (selectedCategory == Category.OFFICIAL) "محاضرة" else "ملزمة"}",
                            true
                        )
                        onlyBookmarked -> HomeHeaderState("المفضلة", "${lectures.size} محاضرة", true)
                        onlyDownloaded -> HomeHeaderState("المحملة", "${lectures.size} محاضرة", true)
                        searchQuery.isNotEmpty() -> HomeHeaderState("نتائج البحث", "${lectures.size} محاضرة", false)
                        else -> HomeHeaderState("ملازم", "${com.saifadnan.pharmacynotes.data.Stages.label(com.saifadnan.pharmacynotes.data.Stages.current)} · ${Course.label(selectedSemester)}", false)
                    }
                    Crossfade(targetState = header, animationSpec = tween(220), label = "HomeHeader") { h ->
                        ScreenHeader(
                            title = h.title,
                            subtitle = h.subtitle,
                            leading = if (h.showBack) {
                                {
                                    GlassIconButton(
                                        onClick = goBack,
                                        modifier = Modifier.testTag("back_to_all_folders_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                            contentDescription = "رجوع",
                                            tint = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            } else null,
                            trailing = if (!h.showBack) {
                                {
                                    GlassIconButton(
                                        onClick = onThemeToggle,
                                        modifier = Modifier.testTag("theme_mode_toggle")
                                    ) {
                                        Crossfade(targetState = isDarkMode, animationSpec = tween(260), label = "ThemeIcon") { dark ->
                                            Icon(
                                                imageVector = if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                                contentDescription = "تبديل المظهر",
                                                tint = MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                }
                            } else null
                        )
                    }
                }

                item(key = "search_and_filters_bar") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        GlassSearchField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChange
                        )

                        when {

                            selectedSubject != null && searchQuery.isBlank() -> CategoryTabs(
                                section = selectedSection,
                                selected = selectedCategory,
                                counts = categoryCounts,
                                onSelect = onCategorySelect
                            )

                            !inFolderView && searchQuery.isBlank() -> SectionSwitcher(
                                selected = selectedSection,
                                onSelect = onSectionSelect
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlassChip(
                                text = "المفضلة",
                                selected = onlyBookmarked,
                                onClick = onToggleOnlyBookmarked,
                                icon = if (onlyBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                modifier = Modifier.testTag("filter_only_bookmarked")
                            )
                            GlassChip(
                                text = "المحملة",
                                selected = onlyDownloaded,
                                onClick = onToggleOnlyDownloaded,
                                icon = if (onlyDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                                modifier = Modifier.testTag("filter_only_downloaded")
                            )
                            if (inLectureView) {
                                val sortLabel = when (sortOrder) {
                                    SortOrder.OLDEST_FIRST -> "الأقدم"
                                    SortOrder.NEWEST_FIRST -> "الأحدث"
                                    SortOrder.ALPHABETICAL -> "أبجدي"
                                }
                                GlassSortChip(
                                    text = sortLabel,
                                    onClick = {
                                        val next = when (sortOrder) {
                                            SortOrder.NEWEST_FIRST -> SortOrder.OLDEST_FIRST
                                            SortOrder.OLDEST_FIRST -> SortOrder.ALPHABETICAL
                                            SortOrder.ALPHABETICAL -> SortOrder.NEWEST_FIRST
                                        }
                                        onSortOrderChange(next)
                                    },
                                    icon = Icons.Default.Sort,
                                    modifier = Modifier.testTag("sort_button")
                                )
                            }
                        }
                    }
                }

                if (!inFolderView) {
                    val displaySubjects = if (searchQuery.isBlank()) subjects else subjects.filter { ArabicSearch.matches(it.name, searchQuery) }

                    if (displaySubjects.isNotEmpty() || searchQuery.isBlank()) {
                        item(key = "subjects_label") {
                            SectionLabel(
                                text = if (selectedSection == Section.PRACTICAL) "مواد العملي" else "المواد الدراسية",
                                trailing = "${displaySubjects.size} مادة",
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    if (displaySubjects.isEmpty() && isRefreshing && searchQuery.isBlank()) {

                        items(3, key = { "subject_placeholder_$it" }) {
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Box(Modifier.size(48.dp).clip(CircleShape).shimmerEffect())
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(Modifier.width(140.dp).height(14.dp).clip(CircleShape).shimmerEffect())
                                        Box(Modifier.width(80.dp).height(10.dp).clip(CircleShape).shimmerEffect())
                                    }
                                }
                            }
                        }
                    } else if (displaySubjects.isEmpty()) {
                        item(key = "subjects_empty") {
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    MedicalEmptyFolderState(
                                        message = if (searchQuery.isNotBlank()) "لا يوجد تطابق" else "لا توجد مجلدات في ${Course.label(selectedSemester)} حالياً",
                                        subtitle = if (searchQuery.isNotBlank()) "تأكد من كتابة اسم المادة بشكل صحيح أو جرب كلمة ثانية" else "ستظهر المواد هنا فور إضافتها"
                                    )
                                    if (searchQuery.isNotBlank()) {
                                        PillButton(
                                            text = "مسح البحث",
                                            onClick = { onSearchQueryChange("") },
                                            height = 44.dp,
                                            modifier = Modifier.padding(bottom = 20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    itemsIndexed(
                        displaySubjects.chunked(columns),
                        key = { _, row -> "subject_row_${row.first().name}" }
                    ) { rowIndex, rowSubjects ->
                        Row(
                            modifier = Modifier.fillMaxWidth().animateItem(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            rowSubjects.forEachIndexed { colIndex, subj ->
                                val index = rowIndex * columns + colIndex
                                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        val counts = countsBySubject[subj.name].orEmpty()
                        val summary = buildList {
                            counts[Category.OFFICIAL]?.takeIf { it > 0 }?.let { add("$it محاضرة") }
                            counts[Category.GHRADI]?.takeIf { it > 0 }?.let { add("$it غراضي") }
                            counts[Category.REEYUS]?.takeIf { it > 0 }?.let { add("$it ريوس") }
                        }.joinToString(" · ").ifBlank { "لا توجد ملفات بعد" }
                        GlassCard(
                            onClick = { onSubjectSelect(subj.name) },
                            modifier = Modifier
                                .fillMaxSize()
                                .animateItemEntrance(index = index)
                                .testTag("subject_folder_card_${subj.name}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                com.saifadnan.pharmacynotes.ui.components.SubjectIconTile(icon = subj.icon, size = 48.dp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = if (searchQuery.isBlank()) AnnotatedString(subj.name) else highlightMatch(subj.name, searchQuery),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (subj.isExamPinned) {
                                            Icon(
                                                Icons.Default.PushPin,
                                                contentDescription = "مادة الامتحان",
                                                tint = Amber,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = summary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ChevronLeft,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                                }
                            }
                            repeat(columns - rowSubjects.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                if (inLectureView) {
                    if (lectures.isEmpty()) {
                        item(key = "lectures_empty_state") {
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                MedicalEmptyLectureState(
                                    message = when {
                                        onlyBookmarked && selectedSubject == null && searchQuery.isBlank() -> "لا توجد محاضرات مفضلة بعد"
                                        onlyDownloaded && selectedSubject == null && searchQuery.isBlank() -> "لا توجد محاضرات محملة بعد"
                                        searchQuery.isNotBlank() -> "لا توجد نتائج"
                                        selectedCategory == Category.GHRADI -> "لا توجد ملازم غراضي هنا"
                                        selectedCategory == Category.REEYUS -> "لا توجد ملازم ريوس هنا"
                                        else -> "لا توجد محاضرات هنا"
                                    },
                                    subtitle = when {
                                        onlyBookmarked && selectedSubject == null && searchQuery.isBlank() ->
                                            "اضغط على علامة الحفظ داخل أي محاضرة لتجدها هنا"
                                        onlyDownloaded && selectedSubject == null && searchQuery.isBlank() ->
                                            "نزّل أي محاضرة لتقرأها بدون إنترنت"
                                        searchQuery.isNotBlank() -> "جرب كلمة ثانية أو اسم الدكتور"
                                        else -> "ستظهر الملفات هنا فور رفعها"
                                    }
                                )
                            }
                        }
                    } else {
                        itemsIndexed(
                            lectures.chunked(columns),
                            key = { _, row -> "lecture_row_${row.first().id}" }
                        ) { rowIndex, rowLectures ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItem(fadeInSpec = null, fadeOutSpec = tween(160)),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                rowLectures.forEachIndexed { colIndex, lecture ->
                                    val index = rowIndex * columns + colIndex
                                    Box(modifier = Modifier.weight(1f)) {
                            LectureItemCard(
                                lecture = lecture,
                                index = index,
                                showSubject = selectedSubject == null,
                                showTags = selectedSubject == null,
                                highlightQuery = searchQuery,
                                onOpenWorksheet = if (lecture.worksheetUrl.isNotBlank()) {
                                    {
                                        if (PdfHelper.isPdfUrl(lecture.worksheetUrl)) {
                                            onLectureClick(
                                                PdfHelper.worksheetEntity(
                                                    lecture,
                                                    PdfHelper.isWorksheetSaved(worksheetContext, lecture)
                                                )
                                            )
                                        } else {
                                            worksheetLecture = lecture
                                        }
                                    }
                                } else null,
                                modifier = Modifier.fillMaxHeight(),
                                onLectureClick = { onLectureClick(lecture) },
                                onToggleBookmark = { onToggleBookmark(lecture) },
                                onToggleDownload = { onToggleDownload(lecture) },
                                downloadProgress = downloadProgress[lecture.id]
                            )
                                    }
                                }
                                repeat(columns - rowLectures.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                item(key = "telegram_support_footer") {
                    val context = LocalContext.current
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                        com.saifadnan.pharmacynotes.ui.components.TelegramSupportButton(modifier = Modifier.testTag("telegram_footer_button"))
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun GlassSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = MaterialTheme.glass
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }

    val borderColor by animateColorAsState(
        targetValue = if (focused) MaterialTheme.colorScheme.secondary else glass.border,
        animationSpec = tween(200),
        label = "SearchBorder"
    )
    val borderWidth by animateDpAsState(
        targetValue = if (focused) 1.6.dp else 1.dp,
        animationSpec = tween(200),
        label = "SearchBorderWidth"
    )
    val iconTint by animateColorAsState(
        targetValue = if (focused) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(200),
        label = "SearchIcon"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(CircleShape)
            .background(if (focused) glass.fillTop else glass.fillBottom)
            .border(borderWidth, borderColor, CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                focusRequester.requestFocus()
            }
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            Icons.Default.Search,
            contentDescription = "بحث",
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) {
                Text(
                    text = "ابحث باسم المحاضرة أو المادة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.secondary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester)
                    .onFocusChanged { focused = it.isFocused }
                    .testTag("search_lectures_input")
            )
        }
        AnimatedVisibility(
            visible = value.isNotEmpty(),
            enter = fadeIn(tween(140)) + scaleIn(tween(160), initialScale = 0.6f),
            exit = fadeOut(tween(100)) + scaleOut(tween(100), targetScale = 0.6f)
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .iconInteractiveClick(behavior = IconClickBehavior.ROTATE_SPIN, onClick = { onValueChange("") })
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Clear,
                    contentDescription = "مسح البحث",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun highlightMatch(text: String, query: String): AnnotatedString {
    val q = ArabicSearch.normalize(query)
    val nt = ArabicSearch.normalize(text)
    if (q.isEmpty() || nt.length != text.length) return AnnotatedString(text)
    val start = nt.indexOf(q)
    if (start < 0) return AnnotatedString(text)
    val bg = MaterialTheme.colorScheme.secondary.copy(alpha = 0.22f)
    return buildAnnotatedString {
        append(text)
        addStyle(SpanStyle(background = bg, fontWeight = FontWeight.Bold), start, start + q.length)
    }
}

@Composable
fun LectureItemCard(
    lecture: LectureEntity,
    onLectureClick: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleDownload: () -> Unit,
    downloadProgress: Int? = null,
    index: Int = 0,
    showSubject: Boolean = true,
    showTags: Boolean = false,
    highlightQuery: String = "",
    onOpenWorksheet: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isFresh = remember(lecture.id, lecture.uploadTimestamp) {
        System.currentTimeMillis() - lecture.uploadTimestamp < 3L * 24 * 60 * 60 * 1000
    }
    val accent = MaterialTheme.colorScheme.secondary

    GlassCard(
        onClick = onLectureClick,
        modifier = modifier
            .fillMaxWidth()
            .animateItemEntrance(index = index)
            .testTag("lecture_card_${lecture.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (showSubject || isFresh) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (showSubject) {
                                Text(
                                    text = lecture.subject,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                            }
                            if (isFresh) {
                                Text(
                                    text = "جديدة",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = accent,
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(accent.copy(alpha = 0.14f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (highlightQuery.isBlank()) AnnotatedString(lecture.title) else highlightMatch(lecture.title, highlightQuery),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (lecture.doctorName.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = lecture.doctorName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .iconInteractiveClick(
                            behavior = IconClickBehavior.HEART_PULSE,
                            onClick = onToggleBookmark
                        )
                        .clip(CircleShape)
                        .background(
                            if (lecture.isBookmarked) Amber.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                        )
                        .testTag("bookmark_button_${lecture.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (lecture.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "حفظ في المفضلة",
                        tint = if (lecture.isBookmarked) Amber else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showTags && lecture.section == Section.PRACTICAL) InfoPill(Section.label(Section.PRACTICAL))
                if (showTags && lecture.category != Category.OFFICIAL) InfoPill(Category.label(lecture.category))
                InfoPill("الكورس ${lecture.semester}")
                InfoPill("${lecture.pageCount} صفحة")
                if (lecture.fileSize.isNotBlank()) InfoPill(lecture.fileSize)
            }

            if (onOpenWorksheet != null) {
                WorksheetActionRow(lecture = lecture, onOpen = onOpenWorksheet)
            }

            if (lecture.youtubeUrl.isNotBlank()) {
                YoutubeLinkButton(url = lecture.youtubeUrl)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .iconInteractiveClick(
                            behavior = IconClickBehavior.SPRING_BOUNCE,
                            scaleDown = 0.97f,
                            onClick = onLectureClick
                        )
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.09f))
                        .testTag("open_lecture_button_${lecture.id}"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قراءة المحاضرة",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Default.ChevronLeft,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                }

                com.saifadnan.pharmacynotes.ui.components.DownloadPinButton(
                    isDownloaded = lecture.isDownloaded,
                    progress = downloadProgress,
                    onClick = onToggleDownload,
                    modifier = Modifier.testTag("download_lecture_button_${lecture.id}")
                )
            }
        }
    }
}

@Composable
private fun InfoPill(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    )
}