package com.saifadnan.pharmacynotes.data

import com.saifadnan.pharmacynotes.util.AdminConfig
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        LectureEntity::class,
        BroadcastNotificationEntity::class,
        SubjectEntity::class,
        UserEntity::class,
        ScheduleEntity::class,
        ExamEntity::class
    ],
    version = 13,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lectureDao(): LectureDao
    abstract fun subjectDao(): SubjectDao
    abstract fun broadcastNotificationDao(): BroadcastNotificationDao
    abstract fun userDao(): UserDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun examDao(): ExamDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE subjects ADD COLUMN addedAt INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE users ADD COLUMN groupName TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `class_schedule` (
                        `id` TEXT NOT NULL,
                        `groupName` TEXT NOT NULL,
                        `subject` TEXT NOT NULL,
                        `sessionType` TEXT NOT NULL,
                        `dayOfWeek` INTEGER NOT NULL,
                        `startHour` INTEGER NOT NULL,
                        `startMinute` INTEGER NOT NULL,
                        `endHour` INTEGER NOT NULL,
                        `endMinute` INTEGER NOT NULL,
                        `room` TEXT NOT NULL,
                        `doctorName` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE lectures ADD COLUMN section TEXT NOT NULL DEFAULT 'THEORY'")
                db.execSQL("ALTER TABLE lectures ADD COLUMN category TEXT NOT NULL DEFAULT 'OFFICIAL'")
                db.execSQL("ALTER TABLE lectures ADD COLUMN worksheetUrl TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE lectures ADD COLUMN worksheetType TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `subjects_new` (`name` TEXT NOT NULL, `section` TEXT NOT NULL, " +
                        "`isExamPinned` INTEGER NOT NULL, `addedAt` INTEGER NOT NULL, PRIMARY KEY(`name`, `section`))"
                )
                db.execSQL(
                    "INSERT INTO subjects_new(name, section, isExamPinned, addedAt) " +
                        "SELECT name, 'THEORY', isExamPinned, addedAt FROM subjects"
                )
                db.execSQL("DROP TABLE subjects")
                db.execSQL("ALTER TABLE subjects_new RENAME TO subjects")
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE lectures ADD COLUMN youtubeUrl TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `subjects_new` (`name` TEXT NOT NULL, `section` TEXT NOT NULL, " +
                        "`semester` INTEGER NOT NULL, `isExamPinned` INTEGER NOT NULL, `addedAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`name`, `section`, `semester`))"
                )
                db.execSQL(
                    "INSERT OR IGNORE INTO subjects_new(name, section, semester, isExamPinned, addedAt) " +
                        "SELECT s.name, s.section, 1, s.isExamPinned, s.addedAt FROM subjects s " +
                        "WHERE EXISTS(SELECT 1 FROM lectures l WHERE l.subject = s.name AND l.section = s.section AND l.semester <> 2) " +
                        "OR NOT EXISTS(SELECT 1 FROM lectures l WHERE l.subject = s.name AND l.section = s.section)"
                )
                db.execSQL(
                    "INSERT OR IGNORE INTO subjects_new(name, section, semester, isExamPinned, addedAt) " +
                        "SELECT s.name, s.section, 2, s.isExamPinned, s.addedAt FROM subjects s " +
                        "WHERE EXISTS(SELECT 1 FROM lectures l WHERE l.subject = s.name AND l.section = s.section AND l.semester = 2)"
                )
                db.execSQL("DROP TABLE subjects")
                db.execSQL("ALTER TABLE subjects_new RENAME TO subjects")
            }
        }

        private val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `exam_schedule` (`id` TEXT NOT NULL, `subject` TEXT NOT NULL, " +
                        "`examDate` TEXT NOT NULL, `startHour` INTEGER NOT NULL, `startMinute` INTEGER NOT NULL, " +
                        "`durationMin` INTEGER NOT NULL, `examType` TEXT NOT NULL, `groupName` TEXT NOT NULL, " +
                        "`hall` TEXT NOT NULL, `notes` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("ALTER TABLE subjects ADD COLUMN icon TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE broadcast_notifications ADD COLUMN style TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pharmacy_clean_v6_db"
                )
                .addMigrations(MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13)
                .fallbackToDestructiveMigration()
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            val userDao = db.userDao()

            userDao.insertUser(
                UserEntity(
                    email = AdminConfig.ADMIN_EMAIL,
                    fullName = "سيف عدنان",
                    studentId = "ADMIN-01",
                    role = "ADMIN"
                )
            )
        }
    }
}
