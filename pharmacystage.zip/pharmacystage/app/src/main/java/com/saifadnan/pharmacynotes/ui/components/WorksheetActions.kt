package com.saifadnan.pharmacynotes.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.data.WorksheetType
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.util.PdfHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun WorksheetActionRow(
    lecture: LectureEntity,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val accent = MaterialTheme.colorScheme.secondary
    var saving by remember { mutableStateOf(false) }
    var saved by remember(lecture.id, lecture.worksheetUrl) { mutableStateOf(PdfHelper.isWorksheetSaved(context, lecture)) }
    val downloadable = PdfHelper.isPdfUrl(lecture.worksheetUrl)

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .iconInteractiveClick(
                    behavior = IconClickBehavior.SPRING_BOUNCE,
                    scaleDown = 0.97f,
                    onClick = onOpen
                )
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.12f))
                .testTag("worksheet_button_${lecture.id}"),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = WorksheetType.label(lecture.worksheetType),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }

        if (downloadable) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .iconInteractiveClick(
                        behavior = IconClickBehavior.SPRING_BOUNCE,
                        onClick = {
                            if (!saving) {
                                saving = true
                                scope.launch {
                                    try {
                                        val path = PdfHelper.saveWorksheetToDevice(context, lecture)
                                        saved = true
                                        Toast.makeText(context, PdfHelper.worksheetSavedMessage(path), Toast.LENGTH_LONG).show()
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        Toast.makeText(
                                            context,
                                            (e as? PdfHelper.LectureFileException)?.message ?: "تعذر تنزيل الملف",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    } finally {
                                        saving = false
                                    }
                                }
                            }
                        }
                    )
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.12f))
                    .testTag("worksheet_download_${lecture.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (saving) {
                    CircularProgressIndicator(color = accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else {
                    Icon(
                        imageVector = if (saved) Icons.Default.CheckCircle else Icons.Default.Download,
                        contentDescription = if (saved) "تم التنزيل" else "تنزيل",
                        tint = if (saved) SuccessGreen else accent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
