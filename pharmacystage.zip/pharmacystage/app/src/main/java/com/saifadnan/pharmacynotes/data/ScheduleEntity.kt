package com.saifadnan.pharmacynotes.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "class_schedule")
data class ScheduleEntity(
    @PrimaryKey
    val id: String,
    val groupName: String,
    val subject: String,
    val sessionType: String,
    val dayOfWeek: Int,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val room: String = "",
    val doctorName: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
