package com.saifadnan.pharmacynotes.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

data class StageInfo(val id: Int, val name: String)

object Stages {
    const val DEFAULT = 2
    const val AUTO = 0
    const val NEED_GROUP = "need_group"

    private val ORDINALS = mapOf(
        1 to "الأولى",
        2 to "الثانية",
        3 to "الثالثة",
        4 to "الرابعة",
        5 to "الخامسة"
    )

    val ALL: List<StageInfo> = ORDINALS.keys.sorted().map { StageInfo(it, "المرحلة ${ORDINALS.getValue(it)}") }

    var current by mutableIntStateOf(DEFAULT)

    fun isValid(id: Int): Boolean = ORDINALS.containsKey(id)

    fun short(id: Int): String = ORDINALS[id] ?: id.toString()

    fun label(id: Int): String = "المرحلة ${short(id)}"
}
