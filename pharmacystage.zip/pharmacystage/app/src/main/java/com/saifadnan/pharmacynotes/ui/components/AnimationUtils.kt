package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs

enum class IconClickBehavior {
    SPRING_BOUNCE,
    BELL_SHAKE,
    HEART_PULSE,
    ROTATE_SPIN,
    TILT_SHIFT
}

private const val PRESS_IN_MS = 70
private const val PRESSED_ALPHA = 0.88f

fun Modifier.iconInteractiveClick(
    behavior: IconClickBehavior = IconClickBehavior.SPRING_BOUNCE,
    scaleDown: Float = 0.86f,
    onClick: (() -> Unit)? = null
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressedState by interactionSource.collectIsPressedAsState()
    var isPointerPressed by remember { mutableStateOf(false) }
    val isPressed = isPressedState || isPointerPressed
    val haptic = LocalHapticFeedback.current

    val scale = remember { Animatable(1f) }
    val rotation = remember { Animatable(0f) }
    val dim = remember { Animatable(1f) }
    val wasPressed = remember { booleanArrayOf(false) }

    val pressedScale = if (behavior == IconClickBehavior.HEART_PULSE) 1.22f else scaleDown

    LaunchedEffect(isPressed) {
        if (isPressed) {
            wasPressed[0] = true
            coroutineScope {
                launch { scale.animateTo(pressedScale, animationSpec = tween(PRESS_IN_MS, easing = FastOutSlowInEasing)) }
                launch {
                    dim.animateTo(
                        if (behavior == IconClickBehavior.HEART_PULSE) 1f else PRESSED_ALPHA,
                        animationSpec = tween(PRESS_IN_MS)
                    )
                }
                when (behavior) {
                    IconClickBehavior.BELL_SHAKE -> launch {
                        rotation.animateTo(-12f, animationSpec = tween(40))
                        rotation.animateTo(12f, animationSpec = tween(40))
                        rotation.animateTo(-6f, animationSpec = tween(30))
                        rotation.animateTo(6f, animationSpec = tween(30))
                        rotation.animateTo(0f, animationSpec = MotionSpecs.IconSpring)
                    }
                    IconClickBehavior.ROTATE_SPIN -> launch { rotation.animateTo(90f, animationSpec = MotionSpecs.SoftSpring) }
                    IconClickBehavior.TILT_SHIFT -> launch { rotation.animateTo(10f, animationSpec = MotionSpecs.IconSpring) }
                    else -> Unit
                }
            }
        } else if (wasPressed[0]) {

            val full = pressedScale - 1f
            val progress = if (full == 0f) 1f else (scale.value - 1f) / full
            if (progress < 0.6f) {
                scale.animateTo(pressedScale, animationSpec = tween(PRESS_IN_MS / 2, easing = FastOutSlowInEasing))
            }
            coroutineScope {
                launch { scale.animateTo(1f, animationSpec = MotionSpecs.IconSpring) }
                launch { dim.animateTo(1f, animationSpec = tween(160)) }
                launch { rotation.animateTo(0f, animationSpec = MotionSpecs.IconSpring) }
            }
        }
    }

    this
        .graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
            rotationZ = rotation.value
            alpha = dim.value
        }
        .then(
            if (onClick != null) {
                Modifier.clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    }
                )
            } else {
                Modifier.pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            isPointerPressed = true
                            try {
                                awaitRelease()
                            } finally {
                                isPointerPressed = false
                            }
                        }
                    )
                }
            }
        )
}

fun Modifier.bounceClick(
    scaleDown: Float = 0.97f,
    interactionSource: MutableInteractionSource? = null,
    onClick: (() -> Unit)? = null
): Modifier = composed {
    val actualInteractionSource = interactionSource ?: remember { MutableInteractionSource() }
    val isPressedState by actualInteractionSource.collectIsPressedAsState()
    var isPointerPressed by remember { mutableStateOf(false) }
    val isPressed = isPressedState || isPointerPressed
    val haptic = LocalHapticFeedback.current

    val scale = remember { Animatable(1f) }
    val wasPressed = remember { booleanArrayOf(false) }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            wasPressed[0] = true
            scale.animateTo(scaleDown, animationSpec = tween(PRESS_IN_MS + 20, easing = FastOutSlowInEasing))
        } else if (wasPressed[0]) {
            if (scale.value > scaleDown + (1f - scaleDown) * 0.4f) {
                scale.animateTo(scaleDown, animationSpec = tween(PRESS_IN_MS / 2, easing = FastOutSlowInEasing))
            }
            scale.animateTo(1f, animationSpec = MotionSpecs.CardBounceSpring)
        }
    }

    this
        .graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
        .then(
            if (onClick != null) {
                Modifier.clickable(
                    interactionSource = actualInteractionSource,
                    indication = null,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    }
                )
            } else if (interactionSource != null) {
                Modifier
            } else {
                Modifier.pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            isPointerPressed = true
                            try {
                                awaitRelease()
                            } finally {
                                isPointerPressed = false
                            }
                        }
                    )
                }
            }
        )
}

@Composable
fun AnimatedThemeToggleButton(
    isDarkMode: Boolean,
    onThemeToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rotation by animateFloatAsState(
        targetValue = if (isDarkMode) 360f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "ThemeRotation"
    )

    val scale by animateFloatAsState(
        targetValue = if (isDarkMode) 1.1f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "ThemeScale"
    )

    IconButton(
        onClick = onThemeToggle,
        modifier = modifier
            .bounceClick()
            .graphicsLayer {
                rotationZ = rotation
                scaleX = scale
                scaleY = scale
            }
    ) {
        Crossfade(
            targetState = isDarkMode,
            animationSpec = tween(durationMillis = 300),
            label = "ThemeCrossfade"
        ) { dark ->
            Icon(
                imageVector = if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                contentDescription = "Toggle Theme",
                tint = if (dark) Amber else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun AnimatedFolderIcon(
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    iconSize: Dp = 24.dp,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(12.dp),
    isAnimated: Boolean = false
) {
    if (isAnimated) {
        val infiniteTransition = rememberInfiniteTransition(label = "FolderFloatTransition")
        val floatAnim by infiniteTransition.animateFloat(
            initialValue = -2f,
            targetValue = 2f,
            animationSpec = infiniteRepeatable(
                animation = tween(1600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "FolderFloat"
        )
        val scaleAnim by infiniteTransition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(1600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "FolderScale"
        )

        Box(
            modifier = modifier
                .size(size)
                .clip(shape)
                .background(containerColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = "Folder",
                tint = iconTint,
                modifier = Modifier
                    .size(iconSize)
                    .graphicsLayer {
                        translationY = floatAnim
                        scaleX = scaleAnim
                        scaleY = scaleAnim
                    }
            )
        }
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(shape)
                .background(containerColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = "Folder",
                tint = iconTint,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}

@Composable
fun AnimatedBellIcon(
    hasUnread: Boolean,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier,
    iconSize: Dp = 20.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "BellRingTransition")
    val rotationAnim by infiniteTransition.animateFloat(
        initialValue = if (hasUnread) -12f else 0f,
        targetValue = if (hasUnread) 12f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(250, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BellRotation"
    )

    Icon(
        imageVector = Icons.Default.Notifications,
        contentDescription = "Notifications",
        tint = tint,
        modifier = modifier
            .size(iconSize)
            .graphicsLayer {
                rotationZ = if (hasUnread) rotationAnim else 0f
            }
    )
}

@Composable
fun AnimatedIconBadge(
    icon: ImageVector,
    contentDescription: String,
    isSelected: Boolean = false,
    tint: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    iconSize: Dp = 22.dp
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.18f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "BadgeScale"
    )

    Icon(
        imageVector = icon,
        contentDescription = contentDescription,
        tint = tint,
        modifier = modifier
            .size(iconSize)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    )
}

fun Modifier.shimmerEffect(): Modifier = composed {
    val transition = rememberInfiniteTransition(label = "ShimmerTransition")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerProgress"
    )

    val base = MaterialTheme.colorScheme.onSurface
    val shimmerColors = listOf(
        base.copy(alpha = 0.06f),
        base.copy(alpha = 0.14f),
        base.copy(alpha = 0.06f)
    )

    this.drawBehind {
        val width = size.width
        val height = size.height
        val totalDistance = width + height + 800f
        val currentOffset = progress * totalDistance - 400f

        val brush = Brush.linearGradient(
            colors = shimmerColors,
            start = Offset(x = currentOffset - 400f, y = currentOffset - 400f),
            end = Offset(x = currentOffset, y = currentOffset)
        )

        drawRect(brush = brush)
    }
}

fun Modifier.softGlow(
    color: Color = Color(0xFF0288D1),
    glowAlpha: Float = 0.18f,
    spreadFactor: Float = 1.35f
): Modifier = composed {
    this.drawBehind {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radiusPx = (maxOf(size.width, size.height) / 2f) * spreadFactor
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    color.copy(alpha = glowAlpha),
                    color.copy(alpha = glowAlpha * 0.4f),
                    Color.Transparent
                ),
                center = center,
                radius = radiusPx
            ),
            radius = radiusPx,
            center = center
        )
    }
}

fun Modifier.pulsatingGlow(
    color: Color = Color(0xFF0288D1),
    durationMs: Int = 2000
): Modifier = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "PulsatingGlowTransition")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.10f,
        targetValue = 0.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AlphaPulsate"
    )
    val scaleAnim by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScalePulsate"
    )

    this.drawBehind {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radiusPx = (maxOf(size.width, size.height) / 2f) * 1.4f * scaleAnim
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    color.copy(alpha = alphaAnim),
                    color.copy(alpha = alphaAnim * 0.35f),
                    Color.Transparent
                ),
                center = center,
                radius = radiusPx
            ),
            radius = radiusPx,
            center = center
        )
    }
}

fun Modifier.animateItemEntrance(
    index: Int = 0,
    delayPerItemMs: Int = 25,
    slideDistanceDp: Float = 16f,
    maxAnimatedIndex: Int = 8
): Modifier {
    if (index >= maxAnimatedIndex) return this

    return composed {
        var hasAnimated by rememberSaveable { mutableStateOf(false) }

        val alpha = remember { Animatable(if (hasAnimated) 1f else 0f) }
        val offsetY = remember { Animatable(if (hasAnimated) 0f else slideDistanceDp) }

        LaunchedEffect(Unit) {
            if (!hasAnimated) {
                val delayMs = (index * delayPerItemMs).coerceAtMost(200)
                if (delayMs > 0) {
                    kotlinx.coroutines.delay(delayMs.toLong())
                }
                coroutineScope {
                    launch {
                        alpha.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing)
                        )
                    }
                    launch {
                        offsetY.animateTo(
                            targetValue = 0f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )
                    }
                }
                hasAnimated = true
            }
        }

        if (hasAnimated && alpha.value == 1f && offsetY.value == 0f) {
            this
        } else {
            this.graphicsLayer {
                this.alpha = alpha.value
                translationY = offsetY.value
            }
        }
    }
}

@Composable
fun LazyCoilImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    fallbackIcon: @Composable () -> Unit = {}
) {
    val context = LocalContext.current
    val imageRequest = remember(model) {
        ImageRequest.Builder(context)
            .data(model)
            .crossfade(true)
            .crossfade(300)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .build()
    }

    SubcomposeAsyncImage(
        model = imageRequest,
        contentDescription = contentDescription,
        modifier = modifier,
        contentScale = contentScale,
        loading = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .shimmerEffect()
            )
        },
        error = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                fallbackIcon()
            }
        }
    )
}

@Composable
fun LazyListPrefetchHandler(
    lazyListState: LazyListState,
    bufferItems: Int = 3,
    onPrefetch: () -> Unit
) {
    val shouldPrefetch by remember {
        derivedStateOf {
            val totalItems = lazyListState.layoutInfo.totalItemsCount
            val lastVisibleIndex = lazyListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleIndex >= (totalItems - bufferItems)
        }
    }

    LaunchedEffect(shouldPrefetch) {
        if (shouldPrefetch) {
            onPrefetch()
        }
    }
}
