package com.saifadnan.pharmacynotes.ui.pdf

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import com.saifadnan.pharmacynotes.data.SupabaseClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.toArgb
import java.util.concurrent.Executors
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object InkTool {
    const val LEGACY = -1
    const val HAND = 0
    const val PEN = 1
    const val BRUSH = 2
    const val HIGHLIGHTER = 3
    const val ERASER = 4
    const val LASER = 5
    const val TEXT = 6
}

class HStroke(
    val color: Int,
    val points: List<Offset>,
    val rects: List<Rect>? = null,
    val tool: Int = InkTool.LEGACY,
    val argb: Int = 0,
    val width: Float = 0f,
    val opacity: Float = 1f
) {
    fun withRects(r: List<Rect>?) = HStroke(color, points, r, tool, argb, width, opacity)
}

@Immutable
data class InkStyle(val argb: Int, val size: Float, val opacity: Float)

@Immutable
data class TextLook(val argb: Int, val size: Float, val opacity: Float, val bold: Boolean, val bg: Boolean, val bgArgb: Int = 0)

@Immutable
data class TextItem(
    val id: Long,
    val page: Int,
    val x: Float,
    val y: Float,
    val text: String,
    val argb: Int,
    val size: Float,
    val opacity: Float,
    val bold: Boolean,
    val bg: Boolean,
    val bgArgb: Int = 0
)

class TextRequest(val id: Long, val page: Int, val x: Float, val y: Float, val initial: String)

class LaserPoint(val x: Float, val y: Float, val t: Long, val brk: Boolean)

internal val InkPalette: List<Int> = listOf(
    0xFF111827, 0xFF475569, 0xFF4A7BA6, 0xFF2563EB, 0xFF14B8A6, 0xFF16A34A, 0xFF84CC16,
    0xFFF59E0B, 0xFFF97316, 0xFFDC2626, 0xFFEC4899, 0xFF9333EA, 0xFF78350F, 0xFFFFFFFF
).map { it.toInt() }

internal val HighlightPalette: List<Int> = listOf(
    0xFFFFE23D, 0xFF7BE495, 0xFFFF8FB8, 0xFF8FD3FF, 0xFFFFB86B, 0xFFC4A7FF, 0xFF5EEAD4, 0xFFFF6B6B
).map { it.toInt() }

internal val TextBgPalette: List<Int> = listOf(
    0xFFFFFFFF, 0xFF111827, 0xFFFFF3A3, 0xFFB8F0C8, 0xFFFFC8DC, 0xFFBFE6FF,
    0xFFFFD7A8, 0xFFDCCBFF, 0xFF99F6E4, 0xFF2563EB, 0xFFDC2626, 0xFF16A34A
).map { it.toInt() }

internal val LaserPalette: List<Int> = listOf(
    0xFFFF2D2D, 0xFF22E58B, 0xFF38BDF8, 0xFFFFD43B, 0xFFFF4FD8, 0xFFFFFFFF
).map { it.toInt() }

internal val DefaultStyles: Map<Int, InkStyle> = mapOf(
    InkTool.PEN to InkStyle(0xFF2563EB.toInt(), 3f, 1f),
    InkTool.BRUSH to InkStyle(0xFF14B8A6.toInt(), 10f, 0.9f),
    InkTool.HIGHLIGHTER to InkStyle(0xFFFFE23D.toInt(), 22f, 0.4f),
    InkTool.ERASER to InkStyle(0xFF000000.toInt(), 24f, 1f),
    InkTool.LASER to InkStyle(0xFFFF2D2D.toInt(), 7f, 1f)
)

internal val DefaultTextLook = TextLook(0xFF111827.toInt(), 45f, 1f, false, false)

internal fun sizeRange(tool: Int): ClosedFloatingPointRange<Float> = when (tool) {
    InkTool.PEN -> 1f..20f
    InkTool.BRUSH -> 2f..48f
    InkTool.HIGHLIGHTER -> 8f..64f
    InkTool.ERASER -> 6f..90f
    InkTool.LASER -> 3f..22f
    else -> 20f..140f
}

private val InkToolSet = setOf(InkTool.PEN, InkTool.BRUSH, InkTool.HIGHLIGHTER, InkTool.ERASER)

private class Op(val undo: () -> Unit, val redo: () -> Unit)

val HighlightColors = listOf(Color(0xFFFFE23D), Color(0xFF7BE495), Color(0xFFFF8FB8))

@Stable
class ReaderAnnotations(
    context: Context,
    private val key: String,
    val lectureId: Long = 0L,
    fileTag: String = ""
) {
    private val tag = fileTag.replace(Regex("[^A-Za-z0-9]"), "")
    private val prefs = context.applicationContext.getSharedPreferences("reader_annotations", Context.MODE_PRIVATE)

    private val drawPrefs = context.applicationContext.getSharedPreferences("reader_draw_prefs", Context.MODE_PRIVATE)

    val strokes = mutableStateMapOf<Int, List<HStroke>>()
    val notes = mutableStateMapOf<Int, String>()
    val texts = mutableStateListOf<TextItem>()

    var drawMode by mutableStateOf(false)
    var penColor by mutableIntStateOf(0)

    var tool by mutableIntStateOf(InkTool.PEN)
        private set
    val capturing: Boolean get() = drawMode && tool != InkTool.HAND

    val styles = mutableStateMapOf<Int, InkStyle>()
    var textLook by mutableStateOf(DefaultTextLook)
        private set
    var laserSeconds by mutableIntStateOf(3)
        private set

    val livePts = mutableStateListOf<Offset>()
    var livePage by mutableIntStateOf(-1)
        private set

    val laserPts = mutableStateListOf<LaserPoint>()
    var laserPage by mutableIntStateOf(-1)
        private set
    var laserDown by mutableStateOf(false)
        private set
    var laserHead by mutableStateOf(Offset.Zero)
        private set
    var laserClock by mutableLongStateOf(0L)
        private set

    var selectedTextId by mutableLongStateOf(-1L)
        private set
    var textRequest by mutableStateOf<TextRequest?>(null)
        private set
    @Volatile var unitW: Float = 1f
    @Volatile var unitH: Float = 1f
    private var styleSnap: TextItem? = null

    private val undoMap = HashMap<Int, ArrayList<Op>>()
    private val redoMap = HashMap<Int, ArrayList<Op>>()
    private var historyTick by mutableIntStateOf(0)

    init {
        try {
            prefs.getString("hl_$key", null)?.let { raw ->
                val o = JSONObject(raw)
                for (k in o.keys()) {
                    val page = k.toIntOrNull() ?: continue
                    val arr = o.getJSONArray(k)
                    val list = ArrayList<HStroke>()
                    for (i in 0 until arr.length()) {
                        val s = arr.getJSONObject(i)
                        val pts = ArrayList<Offset>()
                        for (pair in s.optString("p").split(';')) {
                            val xy = pair.split(',')
                            if (xy.size != 2) continue
                            val x = xy[0].toFloatOrNull() ?: continue
                            val y = xy[1].toFloatOrNull() ?: continue
                            pts.add(Offset(x, y))
                        }
                        val rs = s.optString("r")
                        val rectList = ArrayList<Rect>()
                        if (rs.isNotEmpty()) {
                            for (q in rs.split(';')) {
                                val v = q.split(',').mapNotNull { it.toFloatOrNull() }
                                if (v.size == 4) rectList.add(Rect(v[0], v[1], v[2], v[3]))
                            }
                        }
                        if (pts.size >= 2 || rectList.isNotEmpty()) {
                            list.add(
                                HStroke(
                                    s.optInt("c"), pts, rectList.takeIf { it.isNotEmpty() },
                                    s.optInt("k", InkTool.LEGACY), s.optInt("a"),
                                    s.optDouble("w", 0.0).toFloat(), s.optDouble("o", 1.0).toFloat()
                                )
                            )
                        }
                    }
                    if (list.isNotEmpty()) strokes[page] = list
                }
            }
            prefs.getString("nt_$key", null)?.let { raw ->
                val o = JSONObject(raw)
                for (k in o.keys()) {
                    val page = k.toIntOrNull() ?: continue
                    val t = o.optString(k)
                    if (t.isNotBlank()) notes[page] = t
                }
            }
            prefs.getString("tx_$key", null)?.let { raw ->
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val txt = o.optString("t")
                    if (txt.isBlank()) continue
                    texts.add(
                        TextItem(
                            o.optLong("i", i.toLong()), o.optInt("p"),
                            o.optDouble("x").toFloat(), o.optDouble("y").toFloat(), txt,
                            o.optInt("c", DefaultTextLook.argb), o.optDouble("s", 0.045).toFloat().let { if (it < 0.02f) 0.045f else it.coerceAtMost(0.14f) },
                            o.optDouble("o", 1.0).toFloat(), o.optBoolean("b"), o.optBoolean("g"), o.optInt("k", 0)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        loadDrawPrefs()
    }

    private fun loadDrawPrefs() {
        try {
            for (t in DefaultStyles.keys) {
                val raw = drawPrefs.getString("ds_$t", null) ?: continue
                val v = raw.split('|')
                if (v.size != 3) continue
                val def = DefaultStyles.getValue(t)
                val r = sizeRange(t)
                styles[t] = InkStyle(
                    v[0].toIntOrNull() ?: def.argb,
                    (v[1].toFloatOrNull() ?: def.size).coerceIn(r.start, r.endInclusive),
                    (v[2].toFloatOrNull() ?: def.opacity).coerceIn(0.1f, 1f)
                )
            }
            drawPrefs.getString("text_look", null)?.split('|')?.let { v ->
                if (v.size == 5 || v.size == 6) {
                    textLook = TextLook(
                        v[0].toIntOrNull() ?: DefaultTextLook.argb,
                        (v[1].toFloatOrNull() ?: 45f).coerceIn(20f, 140f),
                        (v[2].toFloatOrNull() ?: 1f).coerceIn(0.1f, 1f),
                        v[3] == "1", v[4] == "1",
                        if (v.size == 6) (v[5].toIntOrNull() ?: 0) else 0
                    )
                }
            }
            laserSeconds = drawPrefs.getInt("laser_sec", 3).coerceIn(1, 7)
            tool = drawPrefs.getInt("last_tool", InkTool.PEN).coerceIn(InkTool.PEN, InkTool.TEXT)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun style(t: Int): InkStyle = styles[t] ?: DefaultStyles[t] ?: DefaultStyles.getValue(InkTool.PEN)

    fun setStyle(t: Int, s: InkStyle) {
        styles[t] = s
        drawPrefs.edit().putString("ds_$t", "${s.argb}|${s.size}|${s.opacity}").apply()
    }

    fun changeLaserSeconds(v: Int) {
        laserSeconds = v.coerceIn(1, 7)
        drawPrefs.edit().putInt("laser_sec", laserSeconds).apply()
    }

    fun openTools(initial: Int = tool) {
        drawMode = true
        selectTool(if (initial == InkTool.HAND) InkTool.PEN else initial)
    }

    fun closeTools() {
        liveCancel()
        laserPts.clear()
        laserDown = false
        selectedTextId = -1L
        textRequest = null
        drawMode = false
    }

    fun selectTool(t: Int) {
        if (t == tool) return
        liveCancel()
        laserPts.clear()
        laserDown = false
        if (t != InkTool.TEXT) selectedTextId = -1L
        tool = t
        if (t != InkTool.HAND) drawPrefs.edit().putInt("last_tool", t).apply()
    }

    fun onPageChanged() {
        liveCancel()
        laserPts.clear()
        laserDown = false
        selectedTextId = -1L
    }

    private fun push(page: Int, op: Op) {
        val list = undoMap.getOrPut(page) { ArrayList() }
        list.add(op)
        if (list.size > 120) list.removeAt(0)
        redoMap[page]?.clear()
        historyTick++
    }

    fun canUndo(page: Int): Boolean { historyTick; return undoMap[page]?.isNotEmpty() == true }
    fun canRedo(page: Int): Boolean { historyTick; return redoMap[page]?.isNotEmpty() == true }

    fun undo(page: Int) {
        val op = undoMap[page]?.removeLastOrNull() ?: return
        op.undo()
        redoMap.getOrPut(page) { ArrayList() }.add(op)
        historyTick++
    }

    fun redo(page: Int) {
        val op = redoMap[page]?.removeLastOrNull() ?: return
        op.redo()
        undoMap.getOrPut(page) { ArrayList() }.add(op)
        historyTick++
    }

    fun hasContent(page: Int): Boolean = !strokes[page].isNullOrEmpty() || texts.any { it.page == page }

    fun annotatedPages(): List<Int> = (strokes.keys + texts.map { it.page }).distinct().sorted()

    private fun saveStrokes() {
        val snap = strokes.toMap()
        saver.execute {
            try {
                val o = JSONObject()
                for ((page, list) in snap) {
                    val arr = JSONArray()
                    for (st in list) {
                        val obj = JSONObject()
                            .put("c", st.color)
                            .put("p", st.points.joinToString(";") { String.format(Locale.US, "%.4f,%.4f", it.x, it.y) })
                        if (st.tool != InkTool.LEGACY) {
                            obj.put("k", st.tool).put("a", st.argb)
                                .put("w", st.width.toDouble()).put("o", st.opacity.toDouble())
                        }
                        val rs = st.rects
                        if (rs != null) {
                            obj.put("r", rs.joinToString(";") {
                                String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", it.left, it.top, it.right, it.bottom)
                            })
                        }
                        arr.put(obj)
                    }
                    o.put(page.toString(), arr)
                }
                prefs.edit().putString("hl_$key", o.toString()).apply()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun saveTexts() {
        val arr = JSONArray()
        for (t in texts.toList()) {
            arr.put(
                JSONObject().put("i", t.id).put("p", t.page)
                    .put("x", t.x.toDouble()).put("y", t.y.toDouble()).put("t", t.text)
                    .put("c", t.argb).put("s", t.size.toDouble()).put("o", t.opacity.toDouble())
                    .put("b", t.bold).put("g", t.bg).put("k", t.bgArgb)
            )
        }
        prefs.edit().putString("tx_$key", arr.toString()).apply()
    }

    private fun saveLook() {
        val l = textLook
        drawPrefs.edit().putString(
            "text_look", "${l.argb}|${l.size}|${l.opacity}|${if (l.bold) 1 else 0}|${if (l.bg) 1 else 0}|${l.bgArgb}"
        ).apply()
    }

    private fun saveNotes() {
        val o = JSONObject()
        for ((page, text) in notes) o.put(page.toString(), text)
        prefs.edit().putString("nt_$key", o.toString()).apply()
    }

    private fun setStrokes(page: Int, list: List<HStroke>) {
        if (list.isEmpty()) strokes.remove(page) else strokes[page] = list
        saveStrokes()
    }

    fun addStroke(page: Int, stroke: HStroke) {
        if (stroke.points.isEmpty() && stroke.rects.isNullOrEmpty()) return
        val before = strokes[page].orEmpty()
        val after = before + stroke
        setStrokes(page, after)
        push(page, Op({ setStrokes(page, before) }, { setStrokes(page, after) }))
    }

    fun clearPage(page: Int) {
        val sb = strokes[page].orEmpty()
        val tb = texts.filter { it.page == page }
        if (sb.isEmpty() && tb.isEmpty()) return
        setStrokes(page, emptyList())
        texts.removeAll { it.page == page }
        selectedTextId = -1L
        saveTexts()
        push(page, Op(
            undo = {
                setStrokes(page, sb)
                texts.addAll(tb)
                saveTexts()
            },
            redo = {
                setStrokes(page, emptyList())
                texts.removeAll { it.page == page }
                selectedTextId = -1L
                saveTexts()
            }
        ))
    }

    fun liveBegin(page: Int, p: Offset) {
        livePts.clear()
        livePts.add(p)
        livePage = page
    }

    fun liveAdd(p: Offset) {
        val l = livePts.lastOrNull() ?: return
        if ((p - l).getDistance() > 0.0008f) livePts.add(p)
    }

    fun liveCancel() {
        livePts.clear()
        livePage = -1
    }

    fun liveCommit() {
        if (livePage < 0 || livePts.isEmpty()) { liveCancel(); return }
        val page = livePage
        val pts = ArrayList(livePts.toList())
        liveCancel()
        if (pts.size == 1) pts.add(Offset(pts[0].x + 0.0001f, pts[0].y))
        addStroke(page, makeStroke(pts))
    }

    private fun makeStroke(pts: List<Offset>): HStroke {
        val st = style(tool)
        return HStroke(0, pts, null, tool, st.argb, st.size / 1000f, st.opacity)
    }

    fun liveStroke(page: Int): HStroke? {
        if (livePage != page || livePts.isEmpty() || tool !in InkToolSet) return null
        val pts = livePts.toList()
        return makeStroke(if (pts.size == 1) listOf(pts[0], Offset(pts[0].x + 0.0001f, pts[0].y)) else pts)
    }

    fun laserBegin(page: Int, p: Offset) {
        if (laserPage != page) laserPts.clear()
        laserPage = page
        laserDown = true
        laserHead = p
        val now = System.nanoTime()
        laserClock = now
        laserPts.add(LaserPoint(p.x, p.y, now, true))
    }

    fun laserAdd(p: Offset) {
        laserHead = p
        val l = laserPts.lastOrNull()
        if (l != null && kotlin.math.abs(l.x - p.x) + kotlin.math.abs(l.y - p.y) < 0.0016f) return
        laserPts.add(LaserPoint(p.x, p.y, System.nanoTime(), false))
        if (laserPts.size > 900) laserPts.removeAt(0)
    }

    fun laserEnd() {
        laserDown = false
    }

    fun tickLaser(now: Long) {
        laserClock = now
        val life = laserSeconds * 1_000_000_000L
        while (laserPts.isNotEmpty() && now - laserPts[0].t > life) laserPts.removeAt(0)
    }

    private fun nextTextId(): Long = (texts.maxOfOrNull { it.id } ?: 0L) + 1L

    fun textById(id: Long): TextItem? = texts.firstOrNull { it.id == id }

    private fun setText(item: TextItem) {
        val i = texts.indexOfFirst { it.id == item.id }
        if (i >= 0) texts[i] = item
    }

    private fun clampText(t: TextItem): TextItem {
        val b = InkRenderer.textBox(t, unitW, unitH)
        val bw = (b.right - b.left) / unitW
        val bh = (b.bottom - b.top) / unitH
        return t.copy(
            x = t.x.coerceIn(0f, kotlin.math.max(0f, 1f - bw)),
            y = t.y.coerceIn(0f, kotlin.math.max(0f, 1f - bh))
        )
    }

    fun textBoundsN(t: TextItem): Rect {
        val r = InkRenderer.textBox(t, unitW, unitH)
        return Rect(r.left / unitW, r.top / unitH, r.right / unitW, r.bottom / unitH)
    }

    fun hitText(page: Int, p: Offset): Long {
        for (i in texts.indices.reversed()) {
            val t = texts[i]
            if (t.page != page) continue
            val b = textBoundsN(t)
            if (p.x >= b.left - 0.015f && p.x <= b.right + 0.015f && p.y >= b.top - 0.015f && p.y <= b.bottom + 0.015f) return t.id
        }
        return -1L
    }

    fun selectText(id: Long) {
        selectedTextId = id
        if (id >= 0) textById(id)?.let { textLook = TextLook(it.argb, (it.size * 1000f).coerceIn(20f, 140f), it.opacity, it.bold, it.bg, it.bgArgb) }
    }

    fun requestNewText(page: Int, p: Offset) {
        textRequest = TextRequest(-1L, page, p.x, p.y, "")
    }

    fun requestEditSelected() {
        textById(selectedTextId)?.let { textRequest = TextRequest(it.id, it.page, it.x, it.y, it.text) }
    }

    fun cancelTextRequest() {
        textRequest = null
    }

    fun submitText(raw: String) {
        val req = textRequest ?: return
        textRequest = null
        val t = raw.trim()
        if (req.id < 0) {
            if (t.isEmpty()) return
            val l = textLook
            val item = clampText(
                TextItem(nextTextId(), req.page, req.x, req.y, t, l.argb, l.size / 1000f, l.opacity, l.bold, l.bg, l.bgArgb)
            )
            texts.add(item)
            saveTexts()
            selectedTextId = item.id
            push(req.page, Op(
                undo = { texts.removeAll { it.id == item.id }; if (selectedTextId == item.id) selectedTextId = -1L; saveTexts() },
                redo = { texts.add(item); saveTexts() }
            ))
        } else {
            val old = textById(req.id) ?: return
            if (t.isEmpty()) { deleteText(old.id); return }
            if (t == old.text) return
            val upd = clampText(old.copy(text = t))
            setText(upd)
            saveTexts()
            push(old.page, Op({ setText(old); saveTexts() }, { setText(upd); saveTexts() }))
        }
    }

    fun deleteText(id: Long) {
        val old = textById(id) ?: return
        val idx = texts.indexOfFirst { it.id == id }
        texts.removeAt(idx)
        if (selectedTextId == id) selectedTextId = -1L
        saveTexts()
        push(old.page, Op(
            undo = { texts.add(idx.coerceAtMost(texts.size), old); saveTexts() },
            redo = { texts.removeAll { it.id == id }; if (selectedTextId == id) selectedTextId = -1L; saveTexts() }
        ))
    }

    fun duplicateSelected() {
        val old = textById(selectedTextId) ?: return
        val copy = clampText(old.copy(id = nextTextId(), x = old.x + 0.03f, y = old.y + 0.03f))
        texts.add(copy)
        saveTexts()
        selectedTextId = copy.id
        push(copy.page, Op(
            undo = { texts.removeAll { it.id == copy.id }; if (selectedTextId == copy.id) selectedTextId = -1L; saveTexts() },
            redo = { texts.add(copy); saveTexts() }
        ))
    }

    fun moveTextLive(id: Long, x: Float, y: Float) {
        val t = textById(id) ?: return
        setText(clampText(t.copy(x = x, y = y)))
    }

    fun restoreText(before: TextItem) = setText(before)

    fun commitMove(before: TextItem) {
        val now = textById(before.id) ?: return
        if (now.x == before.x && now.y == before.y) return
        saveTexts()
        push(now.page, Op({ setText(before); saveTexts() }, { setText(now); saveTexts() }))
    }

    fun updateTextLook(look: TextLook, commit: Boolean = true) {
        textLook = look
        saveLook()
        val cur = textById(selectedTextId) ?: return
        if (styleSnap == null) styleSnap = cur
        setText(clampText(cur.copy(argb = look.argb, size = (look.size / 1000f).coerceIn(0.02f, 0.14f), opacity = look.opacity, bold = look.bold, bg = look.bg, bgArgb = look.bgArgb)))
        if (commit) commitStyle()
    }

    fun commitStyle() {
        val snap = styleSnap ?: return
        styleSnap = null
        val now = textById(snap.id) ?: return
        if (now == snap) return
        saveTexts()
        push(now.page, Op({ setText(snap); saveTexts() }, { setText(now); saveTexts() }))
    }

    fun setNote(page: Int, text: String) {
        val t = text.trim()
        if (t.isEmpty()) notes.remove(page) else notes[page] = t
        saveNotes()
    }

    fun markedPages(): List<Int> = (strokes.keys + notes.keys + texts.map { it.page }).distinct().sorted()

    private val wordCache = HashMap<Int, List<SupabaseClient.PageWord>>()
    private val noText = HashSet<Int>()
    private val wordsDir = File(context.applicationContext.cacheDir, "reader_words").apply { mkdirs() }

    var selPage by mutableIntStateOf(-1)
        private set
    var selStart by mutableIntStateOf(-1)
        private set
    var selEnd by mutableIntStateOf(-1)
        private set
    var selStartOff by mutableIntStateOf(0)
        private set
    var selEndOff by mutableIntStateOf(0)
        private set
    private var selList: List<SupabaseClient.PageWord> = emptyList()

    val hasSelection: Boolean get() = selPage >= 0 && selStart >= 0 && selEnd >= selStart

    suspend fun words(page: Int): List<SupabaseClient.PageWord>? {
        wordCache[page]?.let { return it }
        if (page in noText) return emptyList()
        val f = File(wordsDir, "w_${lectureId}_${tag}_$page.json")
        val cached = withContext(Dispatchers.IO) { readWords(f) }
        if (cached != null) {
            wordCache[page] = cached
            return cached
        }
        val r = SupabaseClient.getPageWords(lectureId, page + 1)
        if (r.failed) return null
        if (!r.available || r.words.isEmpty()) {
            noText.add(page)
            return emptyList()
        }
        wordCache[page] = r.words
        withContext(Dispatchers.IO) { writeWords(f, r.words) }
        return r.words
    }

    private fun readWords(f: File): List<SupabaseClient.PageWord>? {
        if (!f.exists()) return null
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).mapNotNull { i ->
                val x = a.optJSONArray(i) ?: return@mapNotNull null
                if (x.length() < 6) return@mapNotNull null
                SupabaseClient.PageWord(
                    x.optDouble(0).toFloat(), x.optDouble(1).toFloat(),
                    x.optDouble(2).toFloat(), x.optDouble(3).toFloat(),
                    x.optString(4), x.optInt(5)
                )
            }.takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            null
        }
    }

    private fun writeWords(f: File, list: List<SupabaseClient.PageWord>) {
        try {
            val a = JSONArray()
            for (w in list) {
                a.put(JSONArray().put(w.l.toDouble()).put(w.t.toDouble()).put(w.r.toDouble()).put(w.b.toDouble()).put(w.text).put(w.line))
            }
            f.writeText(a.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSelection(page: Int, list: List<SupabaseClient.PageWord>, a: Int, aOff: Int, b: Int, bOff: Int) {
        var si = a; var so = aOff; var ei = b; var eo = bOff
        if (si > ei || (si == ei && so > eo)) {
            val ti = si; val to = so
            si = ei; so = eo; ei = ti; eo = to
        }
        fun len(i: Int) = list.getOrNull(i)?.text?.length ?: 0
        so = so.coerceIn(0, len(si)); eo = eo.coerceIn(0, len(ei))
        while (si < ei && so >= len(si)) { si++; so = 0 }
        while (ei > si && eo <= 0) { ei--; eo = len(ei) }
        if (si == ei && so == eo) {
            if (eo < len(ei)) eo++ else if (so > 0) so--
        }
        selList = list
        selPage = page
        selStart = si
        selEnd = ei
        selStartOff = so
        selEndOff = eo
    }

    fun selectWholeWord(page: Int, list: List<SupabaseClient.PageWord>, index: Int) {
        val n = list.getOrNull(index)?.text?.length ?: return
        setSelection(page, list, index, 0, index, n)
    }

    fun selWord(index: Int): SupabaseClient.PageWord? = selList.getOrNull(index)

    fun clearSelection() {
        selPage = -1
        selStart = -1
        selEnd = -1
        selStartOff = 0
        selEndOff = 0
        selList = emptyList()
    }

    private fun partOf(i: Int, w: SupabaseClient.PageWord): IntRange? {
        val from = if (i == selStart) selStartOff else 0
        val to = if (i == selEnd) selEndOff else w.text.length
        return if (to > from) from until to else null
    }

    fun selectedText(): String {
        if (!hasSelection) return ""
        val sb = StringBuilder()
        for (i in selStart..selEnd) {
            val w = selList.getOrNull(i) ?: continue
            val part = partOf(i, w) ?: continue
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(w.text.substring(part.first, part.last + 1))
        }
        return sb.toString().trim()
    }

    fun selectedRects(): List<Rect> {
        if (!hasSelection) return emptyList()
        val out = ArrayList<Rect>()
        var curLine = Int.MIN_VALUE
        var l = 0f
        var t = 0f
        var r = 0f
        var b = 0f
        for (i in selStart..selEnd) {
            val w = selList.getOrNull(i) ?: continue
            val part = partOf(i, w) ?: continue
            val x1 = caretX(w, part.first)
            val x2 = caretX(w, part.last + 1)
            val wl = minOf(x1, x2)
            val wr = maxOf(x1, x2)
            if (w.line != curLine) {
                if (curLine != Int.MIN_VALUE) out.add(Rect(l, t, r, b))
                curLine = w.line
                l = wl; t = w.t; r = wr; b = w.b
            } else {
                l = minOf(l, wl); t = minOf(t, w.t); r = maxOf(r, wr); b = maxOf(b, w.b)
            }
        }
        if (curLine != Int.MIN_VALUE) out.add(Rect(l, t, r, b))
        return out
    }

    private fun sameLine(a: Rect, b: Rect): Boolean {
        val ov = minOf(a.bottom, b.bottom) - maxOf(a.top, b.top)
        val minH = minOf(a.bottom - a.top, b.bottom - b.top)
        return minH > 0f && ov > minH * 0.4f
    }

    private fun hOverlap(a: Rect, b: Rect): Float = minOf(a.right, b.right) - maxOf(a.left, b.left)

    private fun cutRect(p: Rect, s: Rect): List<Rect> {
        if (!sameLine(p, s) || hOverlap(p, s) <= 0.0015f) return listOf(p)
        val out = ArrayList<Rect>(2)
        if (s.left - p.left > 0.004f) out.add(Rect(p.left, p.top, s.left, p.bottom))
        if (p.right - s.right > 0.004f) out.add(Rect(s.right, p.top, p.right, p.bottom))
        return out
    }

    fun selectionHasHighlight(): Boolean {
        if (!hasSelection) return false
        val list = strokes[selPage] ?: return false
        val sel = selectedRects()
        return list.any { st ->
            st.rects?.any { r -> sel.any { s -> sameLine(r, s) && hOverlap(r, s) > 0.0015f } } == true
        }
    }

    fun removeHighlightInSelection(): Boolean {
        if (!hasSelection) return false
        val page = selPage
        val list = strokes[page] ?: return false
        val sel = selectedRects()
        var changed = false
        val out = ArrayList<HStroke>()
        for (st in list) {
            val rs = st.rects
            if (rs == null) { out.add(st); continue }
            val kept = ArrayList<Rect>()
            for (r in rs) {
                var pieces = listOf(r)
                for (s in sel) pieces = pieces.flatMap { cutRect(it, s) }
                if (pieces.size != 1 || pieces[0] != r) changed = true
                kept.addAll(pieces)
            }
            if (kept.isNotEmpty() || st.points.size >= 2) out.add(st.withRects(kept.takeIf { it.isNotEmpty() }))
        }
        if (!changed) return false
        if (out.isEmpty()) strokes.remove(page) else strokes[page] = out
        saveStrokes()
        return true
    }

    fun highlightSelection() {
        if (!hasSelection) return
        val rects = selectedRects()
        if (rects.isEmpty()) return
        val st = style(InkTool.HIGHLIGHTER)
        addStroke(selPage, HStroke(0, emptyList(), rects, InkTool.HIGHLIGHTER, st.argb, 0f, st.opacity))
    }

    companion object {
        private val saver = Executors.newSingleThreadExecutor()
    }
}

internal fun toPage(o: Offset, w: Float, h: Float, rotated: Boolean): Offset {
    if (w <= 0f || h <= 0f) return Offset.Zero
    val x = (o.x / w).coerceIn(0f, 1f)
    val y = (o.y / h).coerceIn(0f, 1f)
    return if (!rotated) Offset(x, y) else Offset(y, 1f - x)
}

private fun hitWord(words: List<SupabaseClient.PageWord>, p: Offset): Int {
    var best = -1
    var bestD = Float.MAX_VALUE
    for (i in words.indices) {
        val w = words[i]
        val dx = when {
            p.x < w.l -> w.l - p.x
            p.x > w.r -> p.x - w.r
            else -> 0f
        }
        val dy = when {
            p.y < w.t -> w.t - p.y
            p.y > w.b -> p.y - w.b
            else -> 0f
        }
        val d = dx * dx + dy * dy
        if (d < bestD) {
            bestD = d
            best = i
            if (d == 0f) break
        }
    }
    return if (best >= 0 && bestD <= 0.035f * 0.035f) best else -1
}

private val SelectionBlue = Color(0xFF4F7CFF)

private class LineBand(val first: Int, val last: Int, val top: Float, val bottom: Float)

private fun buildBands(words: List<SupabaseClient.PageWord>): List<LineBand> {
    val out = ArrayList<LineBand>()
    var i = 0
    while (i < words.size) {
        var j = i
        var top = words[i].t
        var bottom = words[i].b
        while (j + 1 < words.size && words[j + 1].line == words[i].line) {
            j++
            top = minOf(top, words[j].t)
            bottom = maxOf(bottom, words[j].b)
        }
        out.add(LineBand(i, j, top, bottom))
        i = j + 1
    }
    return out
}

private fun nearestWord(words: List<SupabaseClient.PageWord>, bands: List<LineBand>, p: Offset): Int {
    if (words.isEmpty() || bands.isEmpty()) return -1
    var best: LineBand? = null
    var bestScore = Float.MAX_VALUE
    for (band in bands) {
        val dy = when {
            p.y < band.top -> band.top - p.y
            p.y > band.bottom -> p.y - band.bottom
            else -> 0f
        }
        val score = dy * 1000f + kotlin.math.abs(p.y - (band.top + band.bottom) / 2f)
        if (score < bestScore) {
            bestScore = score
            best = band
        }
    }
    val line = best ?: return -1
    var bestIdx = line.first
    var bestDx = Float.MAX_VALUE
    for (i in line.first..line.last) {
        val w = words[i]
        val dx = when {
            p.x < w.l -> w.l - p.x
            p.x > w.r -> p.x - w.r
            else -> 0f
        }
        if (dx < bestDx) {
            bestDx = dx
            bestIdx = i
            if (dx == 0f) break
        }
    }
    return bestIdx
}

private fun isRtlText(s: String): Boolean {
    for (c in s) {
        val d = Character.getDirectionality(c)
        if (d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC) return true
        if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false
    }
    return false
}

private fun charWeight(c: Char): Float = when {
    c == ' ' -> 0.4f
    c in "iljI.,;:'|!()[]{}`" -> 0.42f
    c in "mwMW@%" -> 1.45f
    c.isUpperCase() -> 1.15f
    else -> 1f
}

private fun wordBoundaries(text: String): FloatArray {
    val n = text.length
    val out = FloatArray(n + 1)
    var total = 0f
    for (i in 0 until n) {
        total += charWeight(text[i])
        out[i + 1] = total
    }
    if (total > 0f) for (i in 0..n) out[i] /= total
    return out
}

private fun caretX(w: SupabaseClient.PageWord, off: Int): Float {
    val n = w.text.length
    val rtl = isRtlText(w.text)
    if (n == 0) return if (rtl) w.r else w.l
    val f = wordBoundaries(w.text)[off.coerceIn(0, n)]
    return if (rtl) w.r - (w.r - w.l) * f else w.l + (w.r - w.l) * f
}

private fun caretOffsetAt(w: SupabaseClient.PageWord, x: Float): Int {
    val n = w.text.length
    val width = w.r - w.l
    if (n == 0 || width <= 0f) return 0
    val frac = (if (isRtlText(w.text)) w.r - x else x - w.l) / width
    val b = wordBoundaries(w.text)
    var best = 0
    var bd = Float.MAX_VALUE
    for (i in 0..n) {
        val d = kotlin.math.abs(b[i] - frac)
        if (d < bd) { bd = d; best = i }
    }
    return best
}

private class Caret(val idx: Int, val off: Int) {
    val key: Long get() = idx.toLong() * 100000L + off
}

private fun nearestCaret(words: List<SupabaseClient.PageWord>, bands: List<LineBand>, p: Offset): Caret? {
    val idx = nearestWord(words, bands, p)
    if (idx < 0) return null
    return Caret(idx, caretOffsetAt(words[idx], p.x))
}

private class HandlePts(
    val startTop: Offset,
    val startBottom: Offset,
    val endTop: Offset,
    val endBottom: Offset
)

private fun handlePts(a: ReaderAnnotations): HandlePts? {
    if (!a.hasSelection) return null
    val first = a.selWord(a.selStart) ?: return null
    val last = a.selWord(a.selEnd) ?: return null
    val sx = caretX(first, a.selStartOff)
    val ex = caretX(last, a.selEndOff)
    return HandlePts(Offset(sx, first.t), Offset(sx, first.b), Offset(ex, last.t), Offset(ex, last.b))
}

internal fun pageToPx(o: Offset, w: Float, h: Float, rotated: Boolean): Offset =
    if (!rotated) Offset(o.x * w, o.y * h) else Offset((1f - o.y) * w, o.x * h)

private fun grabberCenter(top: Offset, bottom: Offset, atTop: Boolean, r: Float): Offset {
    val dx = top.x - bottom.x
    val dy = top.y - bottom.y
    val len = kotlin.math.sqrt(dx * dx + dy * dy)
    val ux = if (len > 0.001f) dx / len else 0f
    val uy = if (len > 0.001f) dy / len else -1f
    return if (atTop) Offset(top.x + ux * r, top.y + uy * r) else Offset(bottom.x - ux * r, bottom.y - uy * r)
}

private fun DrawScope.drawGrabber(
    top: Offset,
    bottom: Offset,
    atTop: Boolean,
    r: Float,
    ring: Float,
    stem: Float,
    color: Color
) {
    val c = grabberCenter(top, bottom, atTop, r)
    drawLine(color = color, start = top, end = bottom, strokeWidth = stem, cap = StrokeCap.Round)
    drawCircle(color = Color.Black.copy(alpha = 0.18f), radius = r + ring, center = Offset(c.x, c.y + ring * 0.7f))
    drawCircle(color = Color.White, radius = r + ring * 0.7f, center = c)
    drawCircle(color = color, radius = r, center = c)
}

@Composable
fun SelectionLayer(
    pageIndex: Int,
    annotations: ReaderAnnotations,
    rotated: Boolean,
    dispW: Float,
    dispH: Float,
    zoom: ReaderZoomState
) {
    val density = LocalDensity.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val isOwner = zoom.ownerPage == pageIndex
    var words by remember(pageIndex) { mutableStateOf<List<SupabaseClient.PageWord>>(emptyList()) }
    LaunchedEffect(pageIndex, isOwner) {
        if (isOwner && words.isEmpty()) {
            annotations.words(pageIndex)?.let { words = it }
        }
    }
    val bands = remember(words) { buildBands(words) }
    val warned = remember(pageIndex) { BooleanArray(1) }

    val longPressInput = if (!annotations.drawMode) {
        Modifier.pointerInput(pageIndex, rotated, words, bands) {
            var anchor = -1
            var lastKey = -1L
            detectDragGesturesAfterLongPress(
                onDragStart = { o ->
                    if (words.isEmpty()) {
                        anchor = -1
                        if (!warned[0]) {
                            warned[0] = true
                            Toast.makeText(context, "تحديد النص غير متاح في هذه الصفحة", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        val p = toPage(o, size.width.toFloat(), size.height.toFloat(), rotated)
                        anchor = hitWord(words, p)
                        lastKey = -1L
                        if (anchor >= 0) {
                            annotations.selectWholeWord(pageIndex, words, anchor)
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                    }
                },
                onDrag = { change, _ ->
                    if (anchor >= 0) {
                        change.consume()
                        val c = nearestCaret(words, bands, toPage(change.position, size.width.toFloat(), size.height.toFloat(), rotated))
                        if (c != null && c.key != lastKey) {
                            lastKey = c.key
                            val aLen = words[anchor].text.length
                            when {
                                c.idx == anchor -> annotations.selectWholeWord(pageIndex, words, anchor)
                                c.idx > anchor -> annotations.setSelection(pageIndex, words, anchor, 0, c.idx, c.off)
                                else -> annotations.setSelection(pageIndex, words, c.idx, c.off, anchor, aLen)
                            }
                        }
                    }
                },
                onDragEnd = {},
                onDragCancel = {}
            )
        }
    } else {
        Modifier
    }

    val handleInput = if (!annotations.drawMode) {
        Modifier.pointerInput(pageIndex, rotated, words, bands) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                if (words.isEmpty() || annotations.selPage != pageIndex || !annotations.hasSelection) return@awaitEachGesture
                val pts = handlePts(annotations) ?: return@awaitEachGesture
                val w = size.width.toFloat()
                val h = size.height.toFloat()
                if (w <= 0f || h <= 0f) return@awaitEachGesture

                val sc = if (zoom.ownerPage == pageIndex) zoom.scale.coerceAtLeast(1f) else 1f
                val k = 1f / sc
                val r = 8.dp.toPx() * k
                val hitR = 28.dp.toPx() * k
                val sTop = pageToPx(pts.startTop, w, h, rotated)
                val sBot = pageToPx(pts.startBottom, w, h, rotated)
                val eTop = pageToPx(pts.endTop, w, h, rotated)
                val eBot = pageToPx(pts.endBottom, w, h, rotated)
                val cs = grabberCenter(sTop, sBot, true, r)
                val ce = grabberCenter(eTop, eBot, false, r)
                val ds = (down.position - cs).getDistance()
                val de = (down.position - ce).getDistance()
                val dragStart = ds <= hitR && ds <= de
                val dragEnd = !dragStart && de <= hitR
                if (!dragStart && !dragEnd) return@awaitEachGesture

                down.consume()
                val fixedIdx = if (dragStart) annotations.selEnd else annotations.selStart
                val fixedOff = if (dragStart) annotations.selEndOff else annotations.selStartOff
                var lastKey = if (dragStart) {
                    annotations.selStart.toLong() * 100000L + annotations.selStartOff
                } else {
                    annotations.selEnd.toLong() * 100000L + annotations.selEndOff
                }
                val grabCenter = if (dragStart) cs else ce
                val toward = if (dragStart) sBot - sTop else eTop - eBot
                val lineLen = toward.getDistance()
                val dir = if (lineLen > 0.001f) Offset(toward.x / lineLen, toward.y / lineLen) else Offset(0f, if (dragStart) 1f else -1f)
                val reach = r + lineLen / 2f
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)

                while (true) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                    change.consume()
                    if (!change.pressed) break
                    val grabbed = grabCenter + (change.position - down.position)
                    val target = grabbed + dir * reach
                    val c = nearestCaret(words, bands, toPage(target, w, h, rotated))
                    if (c != null && c.key != lastKey) {
                        lastKey = c.key
                        annotations.setSelection(pageIndex, words, fixedIdx, fixedOff, c.idx, c.off)
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
            }
        }
    } else {
        Modifier
    }

    Canvas(
        modifier = Modifier
            .requiredSize(with(density) { dispW.toDp() }, with(density) { dispH.toDp() })
            .graphicsLayer {
                if (zoom.ownerPage == pageIndex) {
                    scaleX = zoom.scale
                    scaleY = zoom.scale
                    translationX = zoom.offset.x
                    translationY = zoom.offset.y
                }
            }
            .then(longPressInput)
            .then(handleInput)
    ) {
        if (annotations.selPage == pageIndex && annotations.hasSelection) {
            val w = size.width
            val h = size.height
            val corner = 2.dp.toPx()
            for (rc in annotations.selectedRects()) {
                val a = pageToPx(Offset(rc.left, rc.top), w, h, rotated)
                val d = pageToPx(Offset(rc.right, rc.bottom), w, h, rotated)
                drawRoundRect(
                    color = SelectionBlue.copy(alpha = 0.28f),
                    topLeft = Offset(minOf(a.x, d.x), minOf(a.y, d.y)),
                    size = Size(kotlin.math.abs(a.x - d.x), kotlin.math.abs(a.y - d.y)),
                    cornerRadius = CornerRadius(corner, corner)
                )
            }
            val pts = handlePts(annotations)
            if (pts != null) {
                val sc = if (zoom.ownerPage == pageIndex) zoom.scale.coerceAtLeast(1f) else 1f
                val k = 1f / sc
                val r = 8.dp.toPx() * k
                val ring = 2.dp.toPx() * k
                val stem = 2.dp.toPx() * k
                drawGrabber(
                    pageToPx(pts.startTop, w, h, rotated), pageToPx(pts.startBottom, w, h, rotated),
                    true, r, ring, stem, SelectionBlue
                )
                drawGrabber(
                    pageToPx(pts.endTop, w, h, rotated), pageToPx(pts.endBottom, w, h, rotated),
                    false, r, ring, stem, SelectionBlue
                )
            }
        }
    }
}