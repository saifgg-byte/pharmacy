package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

@Composable
fun RichMessageEditor(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "التفاصيل",
    placeholder: String = "",
    shape: Shape = RoundedCornerShape(14.dp)
) {
    var tfv by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    var preview by remember { mutableStateOf(false) }

    // إذا الشاشة فرّغت الحقل (بعد الإرسال) نزامنه
    LaunchedEffect(value) {
        if (value != tfv.text) tfv = TextFieldValue(value, TextRange(value.length))
    }

    fun update(new: TextFieldValue) {
        tfv = new
        if (new.text != value) onValueChange(new.text)
    }

    fun wrap(marker: String) {
        val t = tfv.text
        val s = tfv.selection.min
        val e = tfv.selection.max
        if (s == e) {
            val out = t.substring(0, s) + marker + marker + t.substring(e)
            update(TextFieldValue(out, TextRange(s + marker.length)))
        } else {
            val out = t.substring(0, s) + marker + t.substring(s, e) + marker + t.substring(e)
            update(TextFieldValue(out, TextRange(s + marker.length, e + marker.length)))
        }
    }

    fun lineStart(t: String, pos: Int): Int = t.lastIndexOf('\n', (pos - 1).coerceAtLeast(0)).let {
        if (pos == 0) 0 else it + 1
    }

    fun cycleHeader() {
        val t = tfv.text
        val pos = tfv.selection.min
        val ls = lineStart(t, pos)
        val le = t.indexOf('\n', ls).let { if (it < 0) t.length else it }
        val line = t.substring(ls, le)
        val m = Regex("^(#{1,3})\\s+").find(line)
        val body = if (m != null) line.substring(m.range.last + 1) else line
        val next = when (m?.groupValues?.get(1)?.length ?: 0) {
            0 -> "# "
            1 -> "## "
            2 -> "### "
            else -> ""
        }
        val newLine = next + body
        val out = t.substring(0, ls) + newLine + t.substring(le)
        val delta = newLine.length - line.length
        update(TextFieldValue(out, TextRange((pos + delta).coerceAtLeast(ls))))
    }

    fun toggleBullet() {
        val t = tfv.text
        val pos = tfv.selection.min
        val ls = lineStart(t, pos)
        val has = t.startsWith("• ", ls)
        val out = if (has) t.removeRange(ls, ls + 2) else t.substring(0, ls) + "• " + t.substring(ls)
        val delta = if (has) -2 else 2
        update(TextFieldValue(out, TextRange((pos + delta).coerceAtLeast(ls))))
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FormatButton(Icons.Default.Title, "عنوان (اضغط مرة ثانية لتغيير الحجم)") { cycleHeader() }
            FormatButton(Icons.Default.FormatBold, "غامق") { wrap("**") }
            FormatButton(Icons.Default.FormatItalic, "مائل") { wrap("*") }
            FormatButton(Icons.Default.FormatListBulleted, "نقطة") { toggleBullet() }
            Box(modifier = Modifier.weight(1f))
            FormatButton(
                icon = if (preview) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                desc = "معاينة",
                active = preview
            ) { preview = !preview }
        }

        OutlinedTextField(
            value = tfv,
            onValueChange = { update(it) },
            label = { Text(label) },
            placeholder = { if (placeholder.isNotEmpty()) Text(placeholder) },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
            maxLines = 12,
            shape = shape
        )

        AnimatedVisibility(
            visible = preview,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(
                        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "المعاينة (هكذا يظهر للطلاب)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (tfv.text.isBlank()) {
                    Text(
                        text = "لا يوجد نص بعد",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    RichText(
                        text = tfv.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        headerColor = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun FormatButton(
    icon: ImageVector,
    desc: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(shape)
            .border(BorderStroke(1.dp, cs.outlineVariant), shape)
            .then(
                if (active) Modifier.border(BorderStroke(1.5.dp, cs.onSurface), shape) else Modifier
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = desc,
            tint = cs.onSurface,
            modifier = Modifier.size(21.dp)
        )
    }
}
