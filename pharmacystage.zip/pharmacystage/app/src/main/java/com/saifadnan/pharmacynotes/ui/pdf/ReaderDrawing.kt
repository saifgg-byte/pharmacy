@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package com.saifadnan.pharmacynotes.ui.pdf

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.max
import androidx.compose.animation.Crossfade
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.semantics.selected
import kotlinx.coroutines.launch
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun HighlightLayer(
    pageIndex: Int,
    annotations: ReaderAnnotations,
    rotated: Boolean,
    dispW: Float,
    dispH: Float,
    zoom: ReaderZoomState
) {
    val density = LocalDensity.current
    val primary = MaterialTheme.colorScheme.primary
    val saved = annotations.strokes[pageIndex].orEmpty()
    val pageTexts = annotations.texts.filter { it.page == pageIndex }
    val laserActive = annotations.laserPage == pageIndex && (annotations.laserPts.isNotEmpty() || annotations.laserDown)

    LaunchedEffect(laserActive) {
        if (laserActive) {
            while (true) {
                withFrameNanos { annotations.tickLaser(System.nanoTime()) }
                if (annotations.laserPts.isEmpty() && !annotations.laserDown) break
            }
        }
    }

    Canvas(
        modifier = Modifier
            .requiredSize(with(density) { dispW.toDp() }, with(density) { dispH.toDp() })
            .graphicsLayer {
                if (zoom.ownerPage == pageIndex) {
                    scaleX = zoom.scale
                    scaleY = zoom.scale
                    translationX = zoom.offset.x
                    translationY = zoom.offset.y
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val unitW = if (rotated) h else w
        val unitH = if (rotated) w else h
        val scale = if (zoom.ownerPage == pageIndex) zoom.scale.coerceAtLeast(1f) else 1f
        val k = 1f / scale

        val live = annotations.liveStroke(pageIndex)
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            val cp = nc.save()
            if (rotated) {
                nc.translate(w, 0f)
                nc.rotate(90f)
            }
            InkRenderer.drawPage(nc, unitW, unitH, saved, pageTexts, live)
            nc.restoreToCount(cp)
        }

        val selId = annotations.selectedTextId
        if (selId >= 0 && annotations.tool == InkTool.TEXT) {
            pageTexts.firstOrNull { it.id == selId }?.let { item ->
                val b = InkRenderer.textBox(item, unitW, unitH)
                val a = pageToPx(Offset(b.left / unitW, b.top / unitH), w, h, rotated)
                val d = pageToPx(Offset(b.right / unitW, b.bottom / unitH), w, h, rotated)
                val tl = Offset(minOf(a.x, d.x), minOf(a.y, d.y))
                val sz = Size(kotlin.math.abs(a.x - d.x), kotlin.math.abs(a.y - d.y))
                drawRoundRect(
                    color = primary,
                    topLeft = tl,
                    size = sz,
                    cornerRadius = CornerRadius(6.dp.toPx() * k, 6.dp.toPx() * k),
                    style = Stroke(
                        width = 1.6.dp.toPx() * k,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx() * k, 6.dp.toPx() * k))
                    )
                )
                val corners = listOf(tl, Offset(tl.x + sz.width, tl.y), Offset(tl.x, tl.y + sz.height), Offset(tl.x + sz.width, tl.y + sz.height))
                for (p in corners) {
                    drawCircle(Color.White, 5.dp.toPx() * k, p)
                    drawCircle(primary, 3.4.dp.toPx() * k, p)
                }
            }
        }

        if (annotations.tool == InkTool.ERASER && annotations.livePage == pageIndex) {
            annotations.livePts.lastOrNull()?.let { p ->
                val ctr = pageToPx(p, w, h, rotated)
                val r = annotations.style(InkTool.ERASER).size / 1000f * unitW / 2f
                drawCircle(Color.White.copy(alpha = 0.22f), r, ctr)
                drawCircle(Color(0xCC111827), r, ctr, style = Stroke(width = 1.2.dp.toPx() * k))
            }
        }

        drawLaser(annotations, pageIndex, rotated, unitW)
    }
}

private inline fun DrawScope.layerAlpha(alpha: Float, block: () -> Unit) {
    val paint = Paint().apply { this.alpha = alpha }
    drawContext.canvas.saveLayer(Rect(0f, 0f, size.width, size.height), paint)
    block()
    drawContext.canvas.restore()
}

private fun DrawScope.drawTrail(pts: List<Offset>, e: List<Float>, brk: List<Boolean>, color: Color, baseW: Float) {
    val n = pts.size
    if (n < 2) return
    fun pass(mul: Float, c: Color) {
        for (i in 1 until n) {
            if (brk[i]) continue
            val ee = e[i]
            if (ee <= 0.02f) continue
            drawLine(c, pts[i - 1], pts[i], strokeWidth = baseW * mul * (0.05f + 0.95f * ee), cap = StrokeCap.Round)
        }
    }
    layerAlpha(0.20f) { pass(3.2f, color) }
    layerAlpha(0.45f) { pass(1.9f, color) }
    pass(1f, color)
    pass(0.38f, Color.White)
}

private fun DrawScope.drawLaser(a: ReaderAnnotations, page: Int, rotated: Boolean, unitW: Float) {
    if (a.laserPage != page) return
    val now = a.laserClock
    val life = a.laserSeconds * 1_000_000_000f
    val st = a.style(InkTool.LASER)
    val color = Color(st.argb)
    val baseW = (st.size / 1000f * unitW).coerceAtLeast(2f)
    val w = size.width
    val h = size.height
    val src = a.laserPts
    val n = src.size
    if (n >= 2) {
        val pts = ArrayList<Offset>(n)
        val es = ArrayList<Float>(n)
        val brk = ArrayList<Boolean>(n)
        for (i in 0 until n) {
            val p = src[i]
            pts.add(pageToPx(Offset(p.x, p.y), w, h, rotated))
            val f = (1f - (now - p.t) / life).coerceIn(0f, 1f)
            es.add(f * f * (3f - 2f * f))
            brk.add(p.brk)
        }
        drawTrail(pts, es, brk, color, baseW)
    }
    if (a.laserDown) {
        val c = pageToPx(a.laserHead, w, h, rotated)
        val r = baseW * 0.9f
        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = 0.55f), color.copy(alpha = 0f)), center = c, radius = r * 3.4f),
            radius = r * 3.4f,
            center = c
        )
        drawCircle(color, r, c)
        drawCircle(Color.White.copy(alpha = 0.95f), r * 0.5f, c)
    }
}

internal fun Modifier.inkGestures(
    pageIndex: Int,
    annotations: ReaderAnnotations,
    zoom: ReaderZoomState,
    rotated: Boolean,
    dispW: Float,
    dispH: Float
): Modifier = pointerInput(pageIndex, annotations, zoom, rotated, dispW, dispH) {
    val touchSlop = viewConfiguration.touchSlop
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (zoom.ownerPage != pageIndex) return@awaitEachGesture
        val tool = annotations.tool
        if (tool == InkTool.HAND) return@awaitEachGesture
        zoom.cancelAnimation()
        val center = Offset(size.width / 2f, size.height / 2f)

        val toPageN: (Offset) -> Offset = { p ->
            val s = zoom.scale
            val o = zoom.offset
            val local = Offset((p.x - center.x - o.x) / s + dispW / 2f, (p.y - center.y - o.y) / s + dispH / 2f)
            toPage(local, dispW, dispH, rotated)
        }
        val pinch: (PointerEvent) -> Unit = { event ->
            val zoomChange = event.calculateZoom()
            val panChange = event.calculatePan()
            if (zoomChange != 1f || panChange != Offset.Zero) {
                val old = zoom.scale
                val ns = (old * zoomChange).coerceIn(1f, ReaderZoomState.MAX_SCALE)
                val p = event.calculateCentroid(useCurrent = false) - center
                val raw = p - (p - zoom.offset) * (ns / old) + panChange
                zoom.scale = ns
                zoom.offset = if (ns <= 1f) Offset.Zero else zoom.clamp(raw, ns)
                event.changes.forEach { if (it.positionChanged()) it.consume() }
            }
        }

        when (tool) {
            InkTool.PEN, InkTool.BRUSH, InkTool.HIGHLIGHTER, InkTool.ERASER -> trackInk(
                down, toPageN, pinch,
                begin = { annotations.liveBegin(pageIndex, it) },
                add = { annotations.liveAdd(it) },
                end = { annotations.liveCommit() },
                cancel = { annotations.liveCancel() },
                cancelOnPinch = true
            )
            InkTool.LASER -> trackInk(
                down, toPageN, pinch,
                begin = { annotations.laserBegin(pageIndex, it) },
                add = { annotations.laserAdd(it) },
                end = { annotations.laserEnd() },
                cancel = { annotations.laserEnd() },
                cancelOnPinch = false
            )
            InkTool.TEXT -> trackText(down, pageIndex, annotations, toPageN, pinch, touchSlop)
        }
    }
}

private suspend fun AwaitPointerEventScope.trackInk(
    down: PointerInputChange,
    toPageN: (Offset) -> Offset,
    pinch: (PointerEvent) -> Unit,
    begin: (Offset) -> Unit,
    add: (Offset) -> Unit,
    end: () -> Unit,
    cancel: () -> Unit,
    cancelOnPinch: Boolean
) {
    val stylus = down.type == PointerType.Stylus || down.type == PointerType.Eraser
    down.consume()
    begin(toPageN(down.position))
    var multi = false
    while (true) {
        val event = awaitPointerEvent()
        val pressed = event.changes.count { it.pressed }
        if (!stylus && (multi || pressed >= 2)) {
            if (!multi) {
                multi = true
                if (cancelOnPinch) cancel() else end()
            }
            pinch(event)
            if (pressed == 0) break
            continue
        }
        val ch = event.changes.firstOrNull { it.id == down.id } ?: break
        if (stylus) event.changes.forEach { it.consume() }
        if (!ch.pressed) {
            ch.consume()
            break
        }
        for (hist in ch.historical) add(toPageN(hist.position))
        add(toPageN(ch.position))
        ch.consume()
    }
    if (!multi) end()
}

private suspend fun AwaitPointerEventScope.trackText(
    down: PointerInputChange,
    pageIndex: Int,
    annotations: ReaderAnnotations,
    toPageN: (Offset) -> Offset,
    pinch: (PointerEvent) -> Unit,
    touchSlop: Float
) {
    val start = toPageN(down.position)
    val hit = annotations.hitText(pageIndex, start)
    if (hit >= 0L) {
        down.consume()
        val wasSelected = annotations.selectedTextId == hit
        annotations.selectText(hit)
        val before = annotations.textById(hit) ?: return
        var moved = false
        var multi = false
        while (true) {
            val event = awaitPointerEvent()
            val pressed = event.changes.count { it.pressed }
            if (multi || pressed >= 2) {
                if (!multi) {
                    multi = true
                    annotations.restoreText(before)
                }
                pinch(event)
                if (pressed == 0) break
                continue
            }
            val ch = event.changes.firstOrNull { it.id == down.id } ?: break
            if (!ch.pressed) {
                ch.consume()
                break
            }
            if (!moved && (ch.position - down.position).getDistance() > touchSlop) moved = true
            if (moved) {
                val cur = toPageN(ch.position)
                annotations.moveTextLive(hit, before.x + (cur.x - start.x), before.y + (cur.y - start.y))
            }
            ch.consume()
        }
        if (!multi) {
            if (moved) annotations.commitMove(before)
            else if (wasSelected) annotations.requestEditSelected()
        }
    } else {
        val t0 = down.uptimeMillis
        var moved = false
        var multi = false
        var upAt = t0
        while (true) {
            val event = awaitPointerEvent()
            if (event.changes.count { it.pressed } >= 2) multi = true
            val ch = event.changes.firstOrNull { it.id == down.id }
            if (ch != null) {
                if ((ch.position - down.position).getDistance() > touchSlop) moved = true
                if (!ch.pressed) upAt = ch.uptimeMillis
            }
            if (event.changes.none { it.pressed }) break
        }
        if (!moved && !multi && upAt - t0 < 450L) {
            if (annotations.selectedTextId >= 0L) annotations.selectText(-1L)
            else annotations.requestNewText(pageIndex, start)
        }
    }
}

private val ToolOrder = listOf(
    InkTool.HAND, InkTool.PEN, InkTool.BRUSH, InkTool.HIGHLIGHTER, InkTool.ERASER, InkTool.LASER, InkTool.TEXT
)

private const val GLYPH_AI = 100
private const val GLYPH_UNDO = 101
private const val GLYPH_REDO = 102
private const val GLYPH_TRASH = 103
private const val GLYPH_PREV = 104
private const val GLYPH_NEXT = 105
private const val GLYPH_DOWN = 106
private const val GLYPH_CHECK = 107
private const val GLYPH_BOLD = 108
private const val GLYPH_BG = 109
private const val GLYPH_COPY = 110
private const val GLYPH_EDIT = 111
private const val GLYPH_PLUS = 112

private fun toolLabel(t: Int): String = when (t) {
    InkTool.HAND -> "تنقّل"
    InkTool.PEN -> "قلم"
    InkTool.BRUSH -> "فرشاة"
    InkTool.HIGHLIGHTER -> "تظليل"
    InkTool.ERASER -> "ممحاة"
    InkTool.LASER -> "ليزر"
    GLYPH_AI -> "AI"
    else -> "نص"
}

private const val GlyphMotionMs = 620
private const val GW = 2.0f

private fun <T> inkSpring() = spring<T>(dampingRatio = 0.74f, stiffness = Spring.StiffnessMediumLow * 1.6f)

private fun easeOutCubic(t: Float): Float {
    val x = 1f - t.coerceIn(0f, 1f)
    return 1f - x * x * x
}

private fun wiggle(t: Float): Float = sin(t * 2.5f * PI.toFloat()) * (1f - t)

private fun bump(t: Float): Float = sin(t * PI.toFloat())

private suspend fun Animatable<Float, AnimationVector1D>.playGlyph() {
    snapTo(0f)
    animateTo(1f, tween(GlyphMotionMs, easing = LinearEasing))
}

private class GStroke(val path: Path, val width: Float, val group: Int = 0) {
    val length: Float = PathMeasure().also { it.setPath(path, false) }.length
}

private class GFill(val cx: Float, val cy: Float, val r: Float, val alpha: Float = 1f, val group: Int = 0)

private class Glyph(val strokes: List<GStroke>, val fills: List<GFill> = emptyList()) {
    val total: Float = strokes.sumOf { it.length.toDouble() }.toFloat()
}

private class Mx(
    val rot: Float = 0f,
    val px: Float = 12f,
    val py: Float = 12f,
    val dx: Float = 0f,
    val dy: Float = 0f,
    val s: Float = 1f
)

private fun gp(block: Path.() -> Unit): Path = Path().apply(block)

private fun gpl(vararg v: Float): Path = gp {
    moveTo(v[0], v[1])
    var i = 2
    while (i < v.size - 1) {
        lineTo(v[i], v[i + 1])
        i += 2
    }
}

private fun gStar(cx: Float, cy: Float, r: Float, k: Float): Path = gp {
    moveTo(cx, cy - r)
    cubicTo(cx + k, cy - k, cx + k, cy - k, cx + r, cy)
    cubicTo(cx + k, cy + k, cx + k, cy + k, cx, cy + r)
    cubicTo(cx - k, cy + k, cx - k, cy + k, cx - r, cy)
    cubicTo(cx - k, cy - k, cx - k, cy - k, cx, cy - r)
    close()
}

private fun buildGlyph(tool: Int): Glyph = when (tool) {
    InkTool.HAND -> Glyph(
        listOf(
            GStroke(gpl(13.9f, 3.5f, 12.9f, 2.7f, 11.9f, 2.7f, 11.2f, 2.8f, 10.8f, 3.2f, 10.3f, 3.7f, 10.3f, 5.7f, 10.3f, 10.4f), GW, 0),
            GStroke(gpl(13.9f, 10.4f, 13.9f, 3.4f, 15.5f, 3.4f, 16.7f, 3.4f, 17.4f, 4.2f, 17.4f, 6.3f, 17.5f, 8.9f, 17.5f, 10.4f), GW, 0),
            GStroke(gpl(17.6f, 6.2f, 18.9f, 6.2f, 20.0f, 6.2f, 20.5f, 6.7f, 20.9f, 7.2f, 20.9f, 8.1f, 20.9f, 15.3f, 20.6f, 17.2f, 19.8f, 18.8f, 18.5f, 20.2f, 17.3f, 21.1f, 16.1f, 21.5f, 14.5f, 21.9f, 12.2f, 21.9f, 10.4f, 21.5f, 8.5f, 20.5f, 5.3f, 17.4f, 3.9f, 15.9f, 3.6f, 15.3f, 3.6f, 14.5f, 3.6f, 13.6f, 4.0f, 13.3f, 4.6f, 12.9f, 6.6f, 12.9f, 6.6f, 11.9f, 6.6f, 7.8f, 7.0f, 6.4f, 7.8f, 5.6f, 8.9f, 5.6f, 10.1f, 5.6f), GW, 0)
        )
    )
    InkTool.PEN -> Glyph(
        listOf(
            GStroke(gpl(15.1f, 6.2f, 18.0f, 9.1f, 19.3f, 8.4f, 21.3f, 6.3f, 21.3f, 5.2f, 21.4f, 4.6f, 21.1f, 3.8f, 20.7f, 3.3f, 20.3f, 2.9f, 19.4f, 2.9f, 17.8f, 2.9f, 15.8f, 4.7f, 15.1f, 6.2f), GW, 0),
            GStroke(gpl(15.1f, 6.2f, 13.6f, 6.9f, 4.9f, 15.6f, 4.6f, 16.1f, 4.0f, 17.6f, 5.3f, 18.3f, 6.0f, 19.1f, 6.3f, 19.7f, 6.6f, 20.1f, 7.4f, 19.9f, 8.4f, 19.4f, 17.4f, 10.4f, 18.0f, 9.1f), GW, 0),
            GStroke(gpl(6.6f, 20.1f, 5.8f, 20.8f, 3.0f, 21.2f, 3.3f, 18.7f, 3.5f, 18.0f, 4.0f, 17.7f), GW, 0)
        )
    )
    InkTool.BRUSH -> Glyph(
        listOf(
            GStroke(gpl(10.7f, 10.5f, 11.3f, 9.4f, 18.1f, 2.5f, 19.2f, 2.5f, 20.2f, 2.5f, 20.9f, 2.9f, 21.5f, 3.5f, 21.5f, 4.6f, 21.5f, 5.3f, 21.0f, 6.1f, 14.2f, 12.9f, 12.8f, 13.4f, 11.9f, 13.4f, 11.3f, 11.8f, 10.7f, 10.7f), GW, 0),
            GStroke(gpl(3.7f, 21.3f, 4.7f, 18.6f, 5.2f, 15.9f, 6.1f, 14.7f, 7.2f, 13.9f, 7.9f, 13.6f, 9.0f, 13.6f, 10.7f, 13.6f, 11.4f, 13.7f, 12.1f, 17.3f, 11.7f, 19.2f, 10.8f, 20.3f, 9.4f, 21.2f, 7.5f, 21.8f, 5.7f, 21.8f, 4.6f, 21.8f, 4.0f, 21.7f, 3.7f, 21.5f, 2.8f, 21.5f), GW, 0)
        )
    )
    InkTool.HIGHLIGHTER -> Glyph(
        listOf(
            GStroke(gpl(6.4f, 12.3f, 5.5f, 12.8f, 5.0f, 13.8f, 4.0f, 15.9f, 3.6f, 17.9f, 6.1f, 17.9f, 8.0f, 17.5f), GW, 0),
            GStroke(gpl(12.0f, 17.1f, 13.0f, 16.6f, 20.8f, 8.8f, 21.1f, 8.1f, 21.1f, 7.6f, 20.8f, 6.9f, 16.7f, 2.9f, 15.7f, 2.5f, 14.8f, 2.9f, 7.0f, 10.6f, 6.4f, 12.3f, 7.3f, 13.0f, 11.0f, 16.6f, 12.0f, 17.1f), GW, 0),
            GStroke(gpl(10.5f, 22.4f, 2.8f, 22.4f), GW, 0)
        )
    )
    InkTool.ERASER -> Glyph(
        listOf(
            GStroke(gpl(8.7f, 10.2f, 7.5f, 10.6f, 5.1f, 12.9f, 3.5f, 13.5f, 3.1f, 14.2f, 3.7f, 16.0f, 7.7f, 19.9f, 8.7f, 20.3f, 12.9f, 20.3f, 13.6f, 18.8f, 14.6f, 17.7f, 15.2f, 16.7f, 8.7f, 10.1f, 9.0f, 9.2f, 9.3f, 8.7f, 13.7f, 4.3f, 14.2f, 3.9f, 15.0f, 3.9f, 15.7f, 3.9f, 16.7f, 3.9f, 20.7f, 7.9f, 21.3f, 8.7f, 21.4f, 9.4f, 21.4f, 10.5f, 21.0f, 11.3f, 16.4f, 15.9f, 15.2f, 16.7f), GW, 0),
            GStroke(gpl(13.0f, 20.4f, 13.4f, 20.7f, 21.2f, 20.7f), GW, 0)
        )
    )
    GLYPH_UNDO -> Glyph(
        listOf(
            GStroke(gpl(8.4f, 3.5f, 5.0f, 6.9f, 4.3f, 8.8f, 16.2f, 8.8f, 18.4f, 9.6f, 19.5f, 10.4f, 20.4f, 11.3f, 21.1f, 12.7f, 21.4f, 13.9f, 21.4f, 15.2f, 21.0f, 17.1f, 19.8f, 18.9f, 18.5f, 19.9f, 16.8f, 20.7f, 12.3f, 20.7f), GW, 0),
            GStroke(gpl(8.4f, 14.2f, 5.0f, 10.8f, 4.3f, 8.9f), GW, 0)
        )
    )
    GLYPH_REDO -> Glyph(
        listOf(
            GStroke(gpl(15.9f, 3.5f, 19.2f, 6.9f, 19.8f, 8.8f, 8.0f, 8.8f, 6.9f, 9.1f, 5.5f, 9.7f, 4.4f, 10.7f, 3.6f, 11.7f, 2.8f, 13.1f, 2.8f, 14.1f, 2.8f, 15.5f, 3.3f, 17.4f, 4.3f, 18.8f, 5.8f, 19.9f, 7.5f, 20.7f, 12.0f, 20.7f), GW, 0),
            GStroke(gpl(15.8f, 14.2f, 19.2f, 10.8f, 19.9f, 8.8f, 21.2f, 8.8f), GW, 0)
        )
    )
    GLYPH_TRASH -> Glyph(
        listOf(
            GStroke(gpl(3.5f, 6.2f, 5.6f, 6.2f, 5.6f, 8.7f, 6.5f, 20.3f, 6.9f, 21.4f, 8.0f, 21.5f, 16.2f, 21.5f, 17.1f, 21.5f, 17.4f, 21.1f, 17.8f, 19.5f, 18.5f, 6.3f, 18.1f, 6.1f, 15.1f, 6.1f), GW, 0),
            GStroke(gpl(18.5f, 6.3f, 19.1f, 6.2f, 20.8f, 6.2f), GW, 1),
            GStroke(gpl(14.5f, 11.3f, 14.5f, 17.1f), GW, 0),
            GStroke(gpl(9.7f, 17.1f, 9.7f, 11.3f), GW, 0),
            GStroke(gpl(9.2f, 6.0f, 9.2f, 4.3f, 9.2f, 3.2f, 9.8f, 2.6f, 11.0f, 2.7f, 13.3f, 2.7f, 14.7f, 2.7f, 15.0f, 3.9f, 15.0f, 6.1f, 9.2f, 6.1f, 5.8f, 6.1f), GW, 1)
        )
    )
    GLYPH_BOLD -> Glyph(
        listOf(
            GStroke(gpl(6.0f, 11.9f, 5.8f, 12.4f, 5.8f, 19.9f, 6.1f, 20.5f, 6.5f, 20.7f, 14.5f, 20.7f, 16.3f, 20.2f, 17.6f, 19.1f, 18.4f, 17.9f, 18.4f, 16.5f, 18.4f, 14.8f, 17.8f, 13.7f, 16.9f, 12.7f, 16.0f, 12.2f, 15.6f, 11.7f), GW, 0),
            GStroke(gpl(15.5f, 11.7f, 12.8f, 11.7f, 6.1f, 11.7f, 5.8f, 11.3f, 5.8f, 4.3f, 6.1f, 3.7f, 6.7f, 3.5f, 13.5f, 3.5f, 15.0f, 4.0f, 15.8f, 4.6f, 16.6f, 5.6f, 17.1f, 6.8f, 17.1f, 7.8f, 16.7f, 9.4f, 15.9f, 10.7f, 15.6f, 11.6f), GW, 0)
        )
    )
    GLYPH_BG -> Glyph(
        listOf(
            GStroke(gpl(2.7f, 5.6f, 3.5f, 4.8f, 4.3f, 4.3f, 5.5f, 3.8f, 6.7f, 3.8f, 17.6f, 3.8f, 19.1f, 3.8f, 20.3f, 4.5f, 21.2f, 5.5f, 21.7f, 6.1f, 22.2f, 7.9f, 22.2f, 16.5f, 21.9f, 17.7f, 21.4f, 18.7f, 21.0f, 19.2f, 20.1f, 19.9f, 18.2f, 20.3f, 6.1f, 20.3f, 4.9f, 20.3f, 3.9f, 19.6f, 3.0f, 18.8f, 2.5f, 18.0f, 2.1f, 17.2f, 2.1f, 15.6f, 2.1f, 7.5f, 2.4f, 6.2f, 2.7f, 5.6f), GW, 0),
            GStroke(gpl(10.1f, 13.1f, 10.4f, 13.3f, 13.8f, 13.3f, 14.1f, 13.0f, 13.7f, 11.3f, 13.1f, 9.8f, 12.0f, 9.3f, 11.1f, 9.9f, 10.5f, 11.2f, 10.1f, 13.1f, 9.3f, 13.6f, 8.0f, 16.1f), GW, 0),
            GStroke(gpl(14.2f, 13.1f, 14.9f, 13.6f, 16.2f, 16.2f), GW, 0)
        )
    )
    GLYPH_COPY -> Glyph(
        listOf(
            GStroke(gpl(16.2f, 7.8f, 16.2f, 5.6f, 16.2f, 4.7f, 15.5f, 3.8f, 14.7f, 3.3f, 13.3f, 3.3f, 6.1f, 3.3f, 4.6f, 3.3f, 3.7f, 4.0f, 3.3f, 4.8f, 3.3f, 6.1f, 3.3f, 13.3f, 3.3f, 14.8f, 4.0f, 15.6f, 4.7f, 16.2f, 5.6f, 16.2f, 7.9f, 16.2f, 7.9f, 10.7f, 8.4f, 9.5f, 8.9f, 8.8f, 9.8f, 8.0f, 10.7f, 8.0f, 16.2f, 8.0f), GW, 0),
            GStroke(gpl(16.3f, 7.9f, 18.6f, 7.9f, 19.4f, 8.4f, 20.3f, 9.2f, 20.9f, 10.0f, 20.9f, 11.0f, 20.9f, 18.0f, 20.9f, 19.2f, 20.2f, 20.1f, 19.4f, 20.8f, 18.0f, 20.9f, 11.0f, 20.9f, 10.0f, 20.9f, 9.2f, 20.4f, 8.3f, 19.3f, 7.9f, 18.2f, 7.9f, 16.3f), GW, 1)
        )
    )
    GLYPH_EDIT -> Glyph(
        listOf(
            GStroke(gpl(15.1f, 6.2f, 18.0f, 9.1f, 19.3f, 8.4f, 21.3f, 6.3f, 21.3f, 5.2f, 21.4f, 4.6f, 21.1f, 3.8f, 20.7f, 3.3f, 20.3f, 2.9f, 19.4f, 2.9f, 17.8f, 2.9f, 15.8f, 4.7f, 15.1f, 6.2f), GW, 0),
            GStroke(gpl(15.1f, 6.2f, 13.6f, 6.9f, 4.3f, 16.2f, 3.6f, 17.5f, 3.2f, 19.0f, 3.2f, 21.3f, 5.3f, 21.0f, 7.0f, 20.4f, 7.5f, 20.1f, 17.4f, 10.4f, 18.0f, 9.1f), GW, 0)
        )
    )
    GLYPH_PREV -> Glyph(listOf(GStroke(gpl(15.9f, 4.4f, 8.6f, 12.0f, 15.9f, 19.6f), GW)))
    GLYPH_NEXT -> Glyph(listOf(GStroke(gpl(8.2f, 4.4f, 15.4f, 12.0f, 8.2f, 19.6f), GW)))
    GLYPH_DOWN -> Glyph(listOf(GStroke(gpl(5.0f, 8.6f, 12.1f, 15.2f, 19.2f, 8.6f), GW)))
    GLYPH_CHECK -> Glyph(listOf(GStroke(gpl(3.8f, 12.4f, 9.2f, 17.6f, 20.4f, 6.5f), GW)))
    GLYPH_PLUS -> Glyph(
        listOf(
            GStroke(gpl(12.0f, 5.0f, 12.0f, 19.0f), GW),
            GStroke(gpl(5.0f, 12.0f, 19.0f, 12.0f), GW)
        )
    )
    InkTool.TEXT -> Glyph(
        listOf(
            GStroke(gpl(4.4f, 5.9f, 4.4f, 4.4f, 4.9f, 3.8f, 19.3f, 3.8f, 19.8f, 4.4f, 19.8f, 5.9f), GW),
            GStroke(gpl(12.1f, 3.8f, 12.1f, 20.4f), GW),
            GStroke(gpl(8.9f, 20.4f, 15.3f, 20.4f), GW)
        )
    )
    InkTool.LASER -> Glyph(
        strokes = listOf(
            GStroke(gpl(1.8f, 22.7f, 14.5f, 9.8f), GW, 0),
            GStroke(gpl(21.4f, 7.7f, 22.3f, 7.7f), GW, 1),
            GStroke(gpl(20.0f, 11.2f, 20.6f, 11.8f), GW, 1),
            GStroke(gpl(16.5f, 12.6f, 16.5f, 13.5f), GW, 1),
            GStroke(gpl(13.0f, 11.2f, 12.4f, 11.8f), GW, 1),
            GStroke(gpl(11.6f, 7.7f, 10.7f, 7.7f), GW, 1),
            GStroke(gpl(13.0f, 4.2f, 12.4f, 3.6f), GW, 1),
            GStroke(gpl(16.5f, 2.8f, 16.5f, 1.9f), GW, 1),
            GStroke(gpl(20.0f, 4.2f, 20.6f, 3.6f), GW, 1)
        ),
        fills = listOf(GFill(16.5f, 7.7f, 2.9f, 1f, 1))
    )
    GLYPH_AI -> Glyph(
        strokes = listOf(
            GStroke(gStar(10.5f, 13.5f, 8.4f, 1.7f), GW, 0),
            GStroke(gStar(19.0f, 5.2f, 3.2f, 0.7f), GW, 1)
        ),
        fills = listOf(GFill(20.4f, 19.2f, 1.15f, 1f, 2))
    )
    else -> Glyph(listOf(GStroke(gpl(4.0f, 12.0f, 20.0f, 12.0f), GW)))
}

private val GlyphCache = HashMap<Int, Glyph>()

private fun glyphFor(tool: Int): Glyph = GlyphCache.getOrPut(tool) { buildGlyph(tool) }

private fun glyphMotion(tool: Int, group: Int, t: Float): Mx {
    val w = wiggle(t)
    val b = bump(t)
    val e = easeOutCubic(t)
    return when (tool) {
        InkTool.HAND -> Mx(rot = 14f * w, px = 12f, py = 21f)
        InkTool.PEN -> Mx(rot = -9f * w, px = 4f, py = 20f, dx = 1.2f * w)
        GLYPH_EDIT -> Mx(rot = -9f * w, px = 4f, py = 20f, dx = 1.2f * w)
        InkTool.BRUSH -> Mx(rot = 13f * w, px = 4f, py = 20f)
        InkTool.HIGHLIGHTER -> Mx(rot = -9f * w, px = 5f, py = 20f, dx = 1.0f * w)
        InkTool.ERASER -> Mx(dx = 2.0f * w, dy = -0.8f * w)
        InkTool.LASER -> if (group == 0) Mx(rot = 8f * w, px = 3f, py = 21f) else Mx(px = 16.5f, py = 7.7f, s = 1f + 0.22f * b, rot = 45f * e)
        InkTool.TEXT -> Mx(dy = -2.2f * b)
        GLYPH_AI -> when (group) {
            0 -> Mx(rot = 90f * e, px = 10.5f, py = 13.5f, s = 1f + 0.12f * b)
            1 -> Mx(rot = -90f * e, px = 19f, py = 5.2f, s = 1f + 0.4f * b)
            else -> Mx(px = 20.4f, py = 19.2f, s = 1f + 0.9f * b)
        }
        GLYPH_UNDO -> Mx(rot = -38f * b)
        GLYPH_REDO -> Mx(rot = 38f * b)
        GLYPH_TRASH -> if (group == 1) Mx(rot = -16f * b, px = 4f, py = 6f, dy = -1.2f * b) else Mx(dx = 0.5f * w)
        GLYPH_PREV -> Mx(dx = -2.6f * b)
        GLYPH_NEXT -> Mx(dx = 2.6f * b)
        GLYPH_DOWN -> Mx(dy = 2.4f * b)
        GLYPH_CHECK -> Mx(s = 1f + 0.28f * b, px = 10f, py = 15f)
        GLYPH_PLUS -> Mx(rot = 90f * e, s = 1f + 0.12f * b)
        GLYPH_BOLD -> Mx(s = 1f + 0.2f * b)
        GLYPH_BG -> Mx(s = 1f + 0.12f * b, rot = 6f * w)
        GLYPH_COPY -> if (group == 1) Mx(dx = 1.4f * b, dy = 1.4f * b) else Mx(dx = -0.9f * b, dy = -0.9f * b)
        else -> Mx(dy = -2.2f * b)
    }
}

private fun DrawScope.drawGlyph(g: Glyph, tool: Int, tint: Color, t: Float, retrace: Boolean, seg: Path, pm: PathMeasure) {
    val unit = size.minDimension / 24f
    val full = t >= 0.999f
    val trim = if (full || !retrace) 1f else easeOutCubic((t / 0.58f).coerceIn(0f, 1f))
    val fillA = if (full || !retrace) 1f else ((t - 0.42f) / 0.3f).coerceIn(0f, 1f)
    withTransform({ scale(scaleX = unit, scaleY = unit, pivot = Offset.Zero) }) {
        var consumed = 0f
        for (s in g.strokes) {
            val len = s.length.coerceAtLeast(0.001f)
            val frac = if (trim >= 1f) 1f else ((g.total * trim - consumed) / len).coerceIn(0f, 1f)
            consumed += s.length
            if (frac <= 0f) continue
            val mx = if (full) null else glyphMotion(tool, s.group, t)
            withTransform({
                if (mx != null) {
                    translate(mx.dx, mx.dy)
                    rotate(mx.rot, Offset(mx.px, mx.py))
                    scale(mx.s, mx.s, Offset(mx.px, mx.py))
                }
            }) {
                val style = Stroke(width = s.width, cap = StrokeCap.Round, join = StrokeJoin.Round)
                if (frac >= 0.999f) {
                    drawPath(s.path, tint, style = style)
                } else {
                    pm.setPath(s.path, false)
                    seg.rewind()
                    pm.getSegment(0f, s.length * frac, seg, true)
                    drawPath(seg, tint, style = style)
                }
            }
        }
        if (fillA > 0f) {
            for (f in g.fills) {
                val mx = if (full) null else glyphMotion(tool, f.group, t)
                withTransform({
                    if (mx != null) {
                        translate(mx.dx, mx.dy)
                        rotate(mx.rot, Offset(mx.px, mx.py))
                        scale(mx.s, mx.s, Offset(mx.px, mx.py))
                    }
                }) {
                    drawCircle(tint.copy(alpha = (tint.alpha * f.alpha * fillA).coerceIn(0f, 1f)), f.r, Offset(f.cx, f.cy))
                }
            }
        }
    }
}

@Composable
private fun GlyphIcon(
    id: Int,
    tint: Color,
    modifier: Modifier = Modifier,
    retrace: Boolean = false,
    pulse: () -> Float = { 1f }
) {
    val glyph = remember(id) { glyphFor(id) }
    val seg = remember { Path() }
    val pm = remember { PathMeasure() }
    Canvas(modifier) { drawGlyph(glyph, id, tint, pulse(), retrace, seg, pm) }
}

private fun dotFor(a: ReaderAnnotations, t: Int): Color? = when (t) {
    InkTool.PEN, InkTool.BRUSH, InkTool.HIGHLIGHTER, InkTool.LASER -> Color(a.style(t).argb)
    InkTool.TEXT -> Color(a.textLook.argb)
    else -> null
}

private val PreviewSize = Modifier.size(width = 84.dp, height = 62.dp)

@Composable
fun InkToolbar(
    annotations: ReaderAnnotations,
    page: Int,
    pageLabel: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    aiOpen: Boolean = false,
    onAi: (() -> Unit)? = null
) {
    val busy = annotations.livePage >= 0 || annotations.laserDown
    val fade by animateFloatAsState(if (busy) 0.62f else 1f, tween(MotionSpecs.DurationQuick), label = "ink_busy")

    BoxWithConstraints(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
        val tabletWidth = maxWidth >= 600.dp
        val wide = maxWidth >= 800.dp
        var expanded by remember(tabletWidth) { mutableStateOf(!tabletWidth) }
        val shape = RoundedCornerShape(if (tabletWidth) 22.dp else 26.dp)
        Column(
            modifier = Modifier
                .padding(horizontal = 10.dp)
                .widthIn(max = if (wide) 980.dp else if (tabletWidth) 720.dp else 460.dp)
                .fillMaxWidth()
                .graphicsLayer { alpha = fade }
                .shadow(14.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.28f), spotColor = Color.Black.copy(alpha = 0.28f))
                .clip(shape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.97f))
                .border(1.dp, CardBorder, shape)
                .pointerInput(Unit) { detectTapGestures { } }
        ) {
            if (!wide) {
                if (annotations.tool != InkTool.HAND) {
                    GrabHandle(expanded) { expanded = !expanded }
                } else {
                    Spacer(Modifier.height(6.dp))
                }
            }
            AnimatedVisibility(
                visible = expanded && annotations.tool != InkTool.HAND,
                enter = fadeIn(tween(MotionSpecs.DurationMedium)) + expandVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)),
                exit = fadeOut(tween(MotionSpecs.DurationQuick)) + shrinkVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing))
            ) {
                ToolSettings(annotations, wide)
            }
            if (wide) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ToolButtons(annotations, Modifier, wide = true, aiOpen = aiOpen, onAi = onAi) { expanded = !expanded }
                        SettingsToggle(expanded) { expanded = !expanded }
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 10.dp)
                                .width(1.dp)
                                .height(32.dp)
                                .background(CardBorder)
                        )
                        ActionCluster(annotations, page, pageLabel, onPrev, onNext, onDone, spread = false)
                    }
                }
            } else {
                ToolButtons(
                    annotations,
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    wide = false,
                    aiOpen = aiOpen,
                    onAi = onAi
                ) { expanded = !expanded }
                HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = CardBorder)
                ActionCluster(
                    annotations, page, pageLabel, onPrev, onNext, onDone, spread = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}


@Composable
private fun SettingsToggle(expanded: Boolean, onClick: () -> Unit) {
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing),
        label = "drawing_settings_toggle"
    )
    val shape = RoundedCornerShape(13.dp)
    val toggleTint = if (expanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        modifier = Modifier
            .padding(start = 2.dp)
            .size(width = 36.dp, height = 42.dp)
            .clip(shape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = if (expanded) 0.14f else 0.06f))
            .border(1.dp, CardBorder, shape)
            .semantics { contentDescription = if (expanded) "إخفاء إعدادات الرسم" else "إظهار إعدادات الرسم" }
            .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.92f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(GLYPH_DOWN, toggleTint, Modifier.size(22.dp).graphicsLayer { rotationZ = rotation })
    }
}

@Composable
private fun GrabHandle(expanded: Boolean, onClick: () -> Unit) {
    val handleTint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
    val rot by animateFloatAsState(
        if (expanded) 0f else 180f,
        tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing),
        label = "handle_rot"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .semantics { contentDescription = "طي / فتح الإعدادات" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(GLYPH_DOWN, handleTint, Modifier.size(22.dp).graphicsLayer { rotationZ = rot })
    }
}

@Composable
private fun ToolButtons(
    a: ReaderAnnotations,
    modifier: Modifier,
    wide: Boolean,
    aiOpen: Boolean,
    onAi: (() -> Unit)?,
    onReselect: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val primary = MaterialTheme.colorScheme.primary
    val hasAi = onAi != null
    val idx = ToolOrder.indexOf(a.tool).coerceAtLeast(0)
    val shape = RoundedCornerShape(if (wide) 15.dp else 14.dp)
    val btnH = if (wide) 48.dp else 54.dp
    val gap = if (wide) 4.dp else 2.dp
    val n = ToolOrder.size + if (hasAi) 1 else 0
    val gaps = if (hasAi) n else n - 1
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(modifier = modifier) {
            val slot = if (wide) 48.dp else (maxWidth - gap * gaps - (if (hasAi) 1.dp else 0.dp)) / n
            val indicatorX by animateDpAsState(
                targetValue = (slot + gap) * idx,
                animationSpec = inkSpring(),
                label = "tool_indicator"
            )
            Box(
                modifier = Modifier
                    .offset(x = indicatorX)
                    .size(width = slot, height = btnH)
                    .clip(shape)
                    .background(primary.copy(alpha = 0.13f))
                    .border(1.dp, primary.copy(alpha = 0.32f), shape)
            )
            Row(
                modifier = if (wide) Modifier else Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(gap),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for ((i, t) in ToolOrder.withIndex()) {
                    val bm = if (wide) Modifier.width(48.dp) else Modifier.weight(1f)
                    ToolButton(
                        tool = t,
                        index = i,
                        selected = a.tool == t,
                        wide = wide,
                        dot = dotFor(a, t),
                        chip = false,
                        replayOnClick = false,
                        modifier = bm,
                        onClick = {
                            if (a.tool == t) {
                                if (t != InkTool.HAND) onReselect()
                            } else {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                a.selectTool(t)
                            }
                        }
                    )
                }
                if (hasAi) {
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(26.dp)
                            .background(CardBorder)
                    )
                    val bm = if (wide) Modifier.width(48.dp) else Modifier.weight(1f)
                    ToolButton(
                        tool = GLYPH_AI,
                        index = ToolOrder.size,
                        selected = aiOpen,
                        wide = wide,
                        dot = null,
                        chip = true,
                        replayOnClick = true,
                        modifier = bm,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onAi?.invoke()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolButton(
    tool: Int,
    index: Int,
    selected: Boolean,
    wide: Boolean,
    dot: Color?,
    chip: Boolean,
    replayOnClick: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surfaceContainerHigh
    val progress by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMediumLow * 1.45f),
        label = "tool_select"
    )
    val pulse = remember { Animatable(1f) }
    val appear = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val firstRun = remember { booleanArrayOf(true) }
    val seg = remember { Path() }
    val pm = remember { PathMeasure() }
    val glyph = remember(tool) { glyphFor(tool) }

    LaunchedEffect(Unit) {
        delay(index * 32L)
        appear.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow))
    }
    LaunchedEffect(selected) {
        if (selected && !firstRun[0]) {
            pulse.snapTo(0f)
            pulse.animateTo(1f, tween(GlyphMotionMs, easing = LinearEasing))
        }
        firstRun[0] = false
    }

    val idle = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.76f)
    val tint = androidx.compose.ui.graphics.lerp(idle, primary, progress)
    val shape = RoundedCornerShape(if (wide) 15.dp else 14.dp)
    Column(
        modifier = modifier
            .height(if (wide) 48.dp else 54.dp)
            .graphicsLayer {
                val a = appear.value
                alpha = a.coerceIn(0f, 1f)
                val s = 0.6f + 0.4f * a
                scaleX = s
                scaleY = s
            }
            .clip(shape)
            .then(
                if (chip) Modifier
                    .background(primary.copy(alpha = 0.13f * progress))
                    .border(1.dp, primary.copy(alpha = 0.32f * progress), shape)
                else Modifier
            )
            .drawBehind {
                val t = pulse.value
                if (t < 0.999f) {
                    drawCircle(
                        color = primary.copy(alpha = 0.22f * (1f - t)),
                        radius = size.maxDimension * 0.8f * easeOutCubic(t),
                        center = center
                    )
                }
            }
            .semantics(mergeDescendants = true) {
                contentDescription = toolLabel(tool)
                this.selected = selected
            }
            .iconInteractiveClick(
                behavior = IconClickBehavior.SPRING_BOUNCE,
                scaleDown = 0.92f,
                onClick = {
                    if (replayOnClick) {
                        scope.launch {
                            pulse.snapTo(0f)
                            pulse.animateTo(1f, tween(GlyphMotionMs, easing = LinearEasing))
                        }
                    }
                    onClick()
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(if (wide) 25.dp else 22.dp)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val s = 1f + 0.075f * progress
                        scaleX = s
                        scaleY = s
                    }
            ) { drawGlyph(glyph, tool, tint, pulse.value, true, seg, pm) }
            if (dot != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 4.dp, y = 4.dp)
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(dot)
                        .border(1.5.dp, surface, CircleShape)
                )
            }
        }
        if (!wide) {
            Spacer(Modifier.height(3.dp))
            Text(
                text = toolLabel(tool),
                fontSize = 9.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = tint,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ActionCluster(
    a: ReaderAnnotations,
    page: Int,
    pageLabel: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onDone: () -> Unit,
    spread: Boolean,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        IconAction(GLYPH_UNDO, "تراجع", a.canUndo(page)) { a.undo(page) }
        IconAction(GLYPH_REDO, "إعادة", a.canRedo(page)) { a.redo(page) }
        IconAction(GLYPH_TRASH, "مسح الصفحة", a.hasContent(page)) { a.clearPage(page) }
        Spacer(if (spread) Modifier.weight(1f) else Modifier.width(12.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconAction(GLYPH_PREV, "الصفحة السابقة", true, onPrev)
                AnimatedContent(
                    targetState = pageLabel,
                    transitionSpec = {
                        val from = initialState.substringBefore('/').trim().toIntOrNull() ?: 0
                        val to = targetState.substringBefore('/').trim().toIntOrNull() ?: 0
                        val dir = if (to >= from) 1 else -1
                        (slideInVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)) { dir * it / 2 } +
                            fadeIn(tween(MotionSpecs.DurationQuick))) togetherWith
                            (slideOutVertically(tween(MotionSpecs.DurationQuick)) { -dir * it / 2 } +
                                fadeOut(tween(MotionSpecs.DurationQuick)))
                    },
                    contentAlignment = Alignment.Center,
                    label = "ink_page_label"
                ) { label ->
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.widthIn(min = 44.dp)
                    )
                }
                IconAction(GLYPH_NEXT, "الصفحة التالية", true, onNext)
            }
        }
        Spacer(if (spread) Modifier.weight(1f) else Modifier.width(12.dp))
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.93f, onClick = onDone)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val doneTint = MaterialTheme.colorScheme.onPrimary
            GlyphIcon(GLYPH_CHECK, doneTint, Modifier.size(16.dp))
            Text(
                "تم",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}

@Composable
private fun IconAction(glyph: Int, desc: String, enabled: Boolean, onClick: () -> Unit) {
    val alpha by animateFloatAsState(if (enabled) 1f else 0.32f, tween(MotionSpecs.DurationQuick), label = "act_alpha")
    val tint = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha)
    val pulse = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .then(
                if (enabled) Modifier.iconInteractiveClick(
                    behavior = IconClickBehavior.SPRING_BOUNCE,
                    scaleDown = 0.9f,
                    onClick = {
                        scope.launch { pulse.playGlyph() }
                        onClick()
                    }
                ) else Modifier
            )
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, tint, Modifier.size(22.dp), pulse = { pulse.value })
    }
}

@Composable
private fun ToolSettings(a: ReaderAnnotations, wide: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing))
    ) {
        AnimatedContent(
            targetState = a.tool,
            transitionSpec = {
                val dir = if (ToolOrder.indexOf(targetState) >= ToolOrder.indexOf(initialState)) 1 else -1
                ((fadeIn(tween(MotionSpecs.DurationMedium, delayMillis = 60)) +
                    slideInHorizontally(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)) { dir * it / 8 }) togetherWith
                    (fadeOut(tween(MotionSpecs.DurationQuick)) +
                        slideOutHorizontally(tween(MotionSpecs.DurationQuick)) { -dir * it / 8 })) using
                    SizeTransform(clip = false) { _, _ -> snap() }
            },
            label = "ink_settings"
        ) { t ->
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (t) {
                    InkTool.PEN, InkTool.BRUSH, InkTool.HIGHLIGHTER -> InkStyleSection(a, t, wide)
                    InkTool.ERASER -> EraserSection(a, wide)
                    InkTool.LASER -> LaserSection(a, wide)
                    InkTool.TEXT -> TextSection(a, wide)
                    else -> Spacer(Modifier.height(1.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = CardBorder)
    }
}

@Composable
private fun SectionRow(
    wide: Boolean,
    preview: @Composable () -> Unit,
    sliders: @Composable ColumnScope.() -> Unit,
    colors: (@Composable () -> Unit)? = null
) {
    if (wide) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            preview()
            Column(modifier = Modifier.weight(1f), content = sliders)
            if (colors != null) Box(modifier = Modifier.weight(1.1f)) { colors() }
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            preview()
            Column(modifier = Modifier.weight(1f), content = sliders)
        }
        if (colors != null) colors()
    }
}

@Composable
private fun InkStyleSection(a: ReaderAnnotations, t: Int, wide: Boolean) {
    val st = a.style(t)
    val acc = accentFor(st.argb, MaterialTheme.colorScheme.onSurface)
    SectionRow(
        wide = wide,
        preview = { StrokePreview(t, st, PreviewSize) },
        sliders = {
            InkSliderRow("الحجم", "${st.size.roundToInt()}", st.size, sizeRange(t), acc, { a.setStyle(t, st.copy(size = it)) })
            InkSliderRow("الشفافية", "${(st.opacity * 100f).roundToInt()}%", st.opacity, 0.1f..1f, acc, { a.setStyle(t, st.copy(opacity = it)) })
        },
        colors = {
            ColorPalette(if (t == InkTool.HIGHLIGHTER) HighlightPalette else InkPalette, st.argb, wide) {
                a.setStyle(t, st.copy(argb = it))
            }
        }
    )
}

@Composable
private fun EraserSection(a: ReaderAnnotations, wide: Boolean) {
    val st = a.style(InkTool.ERASER)
    val acc = MaterialTheme.colorScheme.onSurface
    SectionRow(
        wide = wide,
        preview = { StrokePreview(InkTool.ERASER, st, PreviewSize) },
        sliders = {
            InkSliderRow("الحجم", "${st.size.roundToInt()}", st.size, sizeRange(InkTool.ERASER), acc, { a.setStyle(InkTool.ERASER, st.copy(size = it)) })
        }
    )
}

@Composable
private fun LaserSection(a: ReaderAnnotations, wide: Boolean) {
    val st = a.style(InkTool.LASER)
    val acc = accentFor(st.argb, MaterialTheme.colorScheme.onSurface)
    SectionRow(
        wide = wide,
        preview = { StrokePreview(InkTool.LASER, st, PreviewSize) },
        sliders = {
            InkSliderRow(
                label = "المدة",
                valueText = "${a.laserSeconds} ث",
                value = a.laserSeconds.toFloat(),
                range = 1f..7f,
                accent = acc,
                onChange = { a.changeLaserSeconds(it.roundToInt()) },
                steps = 5
            )
            InkSliderRow("الحجم", "${st.size.roundToInt()}", st.size, sizeRange(InkTool.LASER), acc, { a.setStyle(InkTool.LASER, st.copy(size = it)) })
        },
        colors = { ColorPalette(LaserPalette, st.argb, wide) { a.setStyle(InkTool.LASER, st.copy(argb = it)) } }
    )
}

@Composable
private fun TextSection(a: ReaderAnnotations, wide: Boolean) {
    val look = a.textLook
    val hasSel = a.selectedTextId >= 0L
    val acc = accentFor(look.argb, MaterialTheme.colorScheme.onSurface)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ToggleChip(GLYPH_BOLD, "عريض", look.bold) { a.updateTextLook(look.copy(bold = !look.bold)) }
        ToggleChip(GLYPH_BG, "خلفية", look.bg) { a.updateTextLook(look.copy(bg = !look.bg)) }
        if (hasSel) {
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(22.dp)
                    .background(CardBorder)
            )
            SmallIconButton(GLYPH_EDIT, "تعديل", MaterialTheme.colorScheme.onSurface) { a.requestEditSelected() }
            SmallIconButton(GLYPH_COPY, "تكرار", MaterialTheme.colorScheme.onSurface) { a.duplicateSelected() }
            SmallIconButton(GLYPH_TRASH, "حذف", MaterialTheme.colorScheme.error) { a.deleteText(a.selectedTextId) }
        } else {
            Text(
                text = "اضغط على السلايد لإضافة نص",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
    SectionRow(
        wide = wide,
        preview = { TextPreview(look, PreviewSize) },
        sliders = {
            InkSliderRow(
                "حجم الخط", "${look.size.roundToInt()}", look.size, sizeRange(InkTool.TEXT), acc,
                onChange = { a.updateTextLook(look.copy(size = it), commit = false) },
                onFinished = { a.commitStyle() }
            )
            InkSliderRow(
                "الشفافية", "${(look.opacity * 100f).roundToInt()}%", look.opacity, 0.1f..1f, acc,
                onChange = { a.updateTextLook(look.copy(opacity = it), commit = false) },
                onFinished = { a.commitStyle() }
            )
        },
        colors = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ColorPalette(InkPalette, look.argb, wide) { a.updateTextLook(look.copy(argb = it)) }
                AnimatedVisibility(
                    visible = look.bg,
                    enter = expandVertically(tween(MotionSpecs.DurationQuick)) + fadeIn(tween(MotionSpecs.DurationQuick)),
                    exit = shrinkVertically(tween(MotionSpecs.DurationQuick)) + fadeOut(tween(MotionSpecs.DurationQuick))
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "لون الخلفية",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = if (wide) 0.dp else 14.dp)
                        )
                        ColorPalette(
                            palette = TextBgPalette,
                            selected = look.bgArgb,
                            wide = wide,
                            autoSelected = look.bgArgb == 0,
                            onAuto = { a.updateTextLook(look.copy(bgArgb = 0)) }
                        ) { a.updateTextLook(look.copy(bgArgb = it)) }
                    }
                }
            }
        }
    )
}

@Composable
private fun TextPreview(look: TextLook, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFFF7F8FA))
            .border(1.dp, CardBorder, shape),
        contentAlignment = Alignment.Center
    ) {
        val c = Color(look.argb)
        Text(
            text = "أبج Aa",
            fontSize = (look.size * 0.3f).coerceIn(10f, 28f).sp,
            fontWeight = if (look.bold) FontWeight.Bold else FontWeight.Normal,
            color = c.copy(alpha = look.opacity),
            modifier = Modifier
                .then(
                    if (look.bg) Modifier.background(
                        textBgFor(c, look.bgArgb),
                        RoundedCornerShape(6.dp)
                    ) else Modifier
                )
                .padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}

private fun textBgFor(text: Color, bgArgb: Int): Color =
    if (bgArgb != 0) Color(bgArgb).copy(alpha = 0.9f)
    else if (text.luminance() > 0.6f) Color(0xE6111827) else Color(0xE6FFFFFF)

private fun accentFor(argb: Int, fallback: Color): Color {
    val c = Color(argb)
    return if (c.luminance() > 0.82f) fallback else c
}

@Composable
private fun SmallIconButton(glyph: Int, desc: String, tint: Color, onClick: () -> Unit) {
    val pulse = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .semantics { contentDescription = desc }
            .iconInteractiveClick(
                behavior = IconClickBehavior.SPRING_BOUNCE,
                scaleDown = 0.88f,
                onClick = {
                    scope.launch { pulse.playGlyph() }
                    onClick()
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, tint, Modifier.size(18.dp), pulse = { pulse.value })
    }
}

@Composable
private fun ToggleChip(glyph: Int, label: String, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val bg by animateColorAsState(
        if (selected) primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f),
        tween(MotionSpecs.DurationQuick + 60), label = "chip_bg"
    )
    val fg by animateColorAsState(
        if (selected) primary else MaterialTheme.colorScheme.onSurface,
        tween(MotionSpecs.DurationQuick + 60), label = "chip_fg"
    )
    val pulse = remember { Animatable(1f) }
    val firstRun = remember { booleanArrayOf(true) }
    LaunchedEffect(selected) {
        if (!firstRun[0]) pulse.playGlyph()
        firstRun[0] = false
    }
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, if (selected) primary.copy(alpha = 0.5f) else Color.Transparent, CircleShape)
            .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.93f, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        GlyphIcon(glyph, fg, Modifier.size(18.dp), retrace = selected, pulse = { pulse.value })
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
    }
}

@Composable
private fun InkSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: Color,
    onChange: (Float) -> Unit,
    steps: Int = 0,
    onFinished: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            modifier = Modifier.width(58.dp)
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            InkSliderBar(value, range, steps, accent, onChange, onFinished, Modifier.weight(1f))
        }
        Text(
            text = valueText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.End,
            maxLines = 1,
            modifier = Modifier.width(40.dp)
        )
    }
}

@Composable
private fun InkSliderBar(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    accent: Color,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val onChangeState by rememberUpdatedState(onChange)
    val onFinishedState by rememberUpdatedState(onFinished)
    var dragging by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (dragging) 1.22f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "thumb_scale"
    )
    val haptic = LocalHapticFeedback.current
    val inactive = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f)
    val span = range.endInclusive - range.start
    val frac = if (span <= 0f) 0f else ((value - range.start) / span).coerceIn(0f, 1f)

    Canvas(
        modifier = modifier
            .height(30.dp)
            .pointerInput(range, steps) {
                val r = 11.dp.toPx()
                awaitEachGesture {
                    val d = awaitFirstDown()
                    var lastSnap = -1f
                    fun upd(x: Float) {
                        val f = ((x - r) / (size.width - 2f * r).coerceAtLeast(1f)).coerceIn(0f, 1f)
                        val snapped = if (steps > 0) {
                            val n = steps + 1
                            (f * n).roundToInt() / n.toFloat()
                        } else f
                        if (steps > 0 && snapped != lastSnap) {
                            if (lastSnap >= 0f) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            lastSnap = snapped
                        }
                        onChangeState(range.start + snapped * span)
                    }
                    dragging = true
                    upd(d.position.x)
                    d.consume()
                    do {
                        val e = awaitPointerEvent()
                        val c = e.changes.firstOrNull() ?: break
                        if (c.pressed) {
                            upd(c.position.x)
                            c.consume()
                        }
                    } while (e.changes.any { it.pressed })
                    dragging = false
                    onFinishedState()
                }
            }
    ) {
        val r = 11.dp.toPx()
        val cy = size.height / 2f
        val trackH = 6.dp.toPx()
        val x0 = r
        val x1 = size.width - r
        val tx = x0 + (x1 - x0) * frac
        val corner = CornerRadius(trackH / 2f, trackH / 2f)
        drawRoundRect(inactive, Offset(x0, cy - trackH / 2f), Size(x1 - x0, trackH), corner)
        drawRoundRect(accent, Offset(x0, cy - trackH / 2f), Size(max(tx - x0, 0f), trackH), corner)
        if (steps > 0) {
            for (i in 0..steps + 1) {
                val x = x0 + (x1 - x0) * i / (steps + 1f)
                drawCircle(
                    if (x <= tx) Color.White.copy(alpha = 0.75f) else inactive,
                    1.6.dp.toPx(), Offset(x, cy)
                )
            }
        }
        val tr = r * 0.82f * scale
        drawCircle(Color.Black.copy(alpha = 0.16f), tr + 1.dp.toPx(), Offset(tx, cy + 1.5.dp.toPx()))
        drawCircle(Color.White, tr, Offset(tx, cy))
        drawCircle(accent, tr, Offset(tx, cy), style = Stroke(2.5.dp.toPx()))
    }
}

@Composable
private fun ColorPalette(
    palette: List<Int>,
    selected: Int,
    wide: Boolean,
    autoSelected: Boolean? = null,
    onAuto: (() -> Unit)? = null,
    onPick: (Int) -> Unit
) {
    var showPicker by remember { mutableStateOf(false) }
    val inPalette = palette.contains(selected) || autoSelected == true
    if (wide) {
        val cells: List<Int?> = palette + listOf<Int?>(null)
        val autoCell = onAuto != null
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((rowIdx, rowItems) in cells.chunked(8).withIndex()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (autoCell && rowIdx == 0) AutoColorDot(autoSelected == true) { onAuto?.invoke() }
                    for (c in rowItems) {
                        if (c == null) CustomColorDot(if (inPalette) null else selected) { showPicker = true }
                        else ColorDot(c, c == selected) { onPick(c) }
                    }
                }
            }
        }
    } else {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onAuto != null) item { AutoColorDot(autoSelected == true) { onAuto() } }
            items(palette) { c -> ColorDot(c, c == selected && autoSelected != true) { onPick(c) } }
            item { CustomColorDot(if (inPalette) null else selected) { showPicker = true } }
        }
    }
    if (showPicker) {
        ColorPickerDialog(
            initial = if (selected == 0) 0xFFFFFFFF.toInt() else selected,
            onPick = {
                showPicker = false
                onPick(it)
            },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
private fun ColorDot(color: Int, selected: Boolean, onClick: () -> Unit) {
    val c = Color(color)
    val scale by animateFloatAsState(
        if (selected) 1.1f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "dot_scale"
    )
    val ring by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f),
        tween(MotionSpecs.DurationQuick), label = "dot_ring"
    )
    Box(
        modifier = Modifier
            .size(30.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(c)
            .border(if (selected) 2.5.dp else 1.dp, ring, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            GlyphIcon(
                GLYPH_CHECK,
                if (c.luminance() > 0.6f) Color.Black else Color.White,
                Modifier.size(15.dp)
            )
        }
    }
}

@Composable
private fun AutoColorDot(selected: Boolean, onClick: () -> Unit) {
    val scale by animateFloatAsState(
        if (selected) 1.1f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "auto_dot_scale"
    )
    val ring by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f),
        tween(MotionSpecs.DurationQuick), label = "auto_dot_ring"
    )
    val split = remember {
        Brush.linearGradient(
            colorStops = arrayOf(0f to Color.White, 0.5f to Color.White, 0.5f to Color(0xFF111827), 1f to Color(0xFF111827)),
            start = Offset(0f, 0f),
            end = Offset(100f, 100f)
        )
    }
    Box(
        modifier = Modifier
            .size(30.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(split)
            .border(if (selected) 2.5.dp else 1.dp, ring, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) GlyphIcon(GLYPH_CHECK, Color(0xFF6B7280), Modifier.size(15.dp))
    }
}

@Composable
private fun CustomColorDot(active: Int?, onClick: () -> Unit) {
    val rainbow = remember {
        Brush.sweepGradient(
            listOf(Color(0xFFFF4D4D), Color(0xFFFFD43B), Color(0xFF4ADE80), Color(0xFF38BDF8), Color(0xFF6366F1), Color(0xFFEC4899), Color(0xFFFF4D4D))
        )
    }
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(rainbow)
            .border(
                if (active != null) 2.5.dp else 1.dp,
                if (active != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f),
                CircleShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (active != null) {
            Box(
                modifier = Modifier
                    .size(17.dp)
                    .clip(CircleShape)
                    .background(Color(active))
                    .border(1.5.dp, Color.White, CircleShape)
            )
        } else {
            GlyphIcon(GLYPH_PLUS, Color.White, Modifier.size(16.dp))
        }
    }
}

@Composable
internal fun InkDialog(
    title: String,
    onDismiss: () -> Unit,
    actions: @Composable RowScope.() -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        val enter by animateFloatAsState(
            targetValue = if (shown) 1f else 0f,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow * 1.4f),
            label = "ink_dialog_enter"
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 400.dp)
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = enter.coerceIn(0f, 1f)
                        val sc = 0.92f + 0.08f * enter
                        scaleX = sc
                        scaleY = sc
                        translationY = (1f - enter) * 24.dp.toPx()
                    }
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .border(1.dp, CardBorder, shape)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                content()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), content = actions)
            }
        }
    }
}

@Composable
internal fun DialogButton(text: String, filled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(CircleShape)
            .then(
                if (filled) Modifier.background(primary)
                else Modifier
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    .border(1.dp, CardBorder, CircleShape)
            )
            .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.95f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

@Composable
fun ColorPickerDialog(initial: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var hue by remember { mutableFloatStateOf(init[0]) }
    var sat by remember { mutableFloatStateOf(init[1]) }
    var value by remember { mutableFloatStateOf(init[2]) }
    val current = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))

    InkDialog(
        title = "لون مخصص",
        onDismiss = onDismiss,
        actions = {
            DialogButton("إلغاء", false, Modifier.weight(1f), onDismiss)
            DialogButton("اختيار", true, Modifier.weight(1f)) { onPick(current.toArgb()) }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(168.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val d = awaitFirstDown()
                        fun upd(p: Offset) {
                            sat = (p.x / size.width).coerceIn(0f, 1f)
                            value = 1f - (p.y / size.height).coerceIn(0f, 1f)
                        }
                        upd(d.position)
                        d.consume()
                        do {
                            val e = awaitPointerEvent()
                            val c = e.changes.firstOrNull() ?: break
                            if (c.pressed) {
                                upd(c.position)
                                c.consume()
                            }
                        } while (e.changes.any { it.pressed })
                    }
                }
        ) {
            Canvas(Modifier.matchParentSize()) {
                drawRect(Brush.horizontalGradient(listOf(Color.White, Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f))))
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                val p = Offset(sat * size.width, (1f - value) * size.height)
                drawCircle(Color.White, 11.dp.toPx(), p)
                drawCircle(current, 8.dp.toPx(), p)
                drawCircle(Color.Black.copy(alpha = 0.35f), 11.dp.toPx(), p, style = Stroke(1.dp.toPx()))
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(26.dp)
                .clip(CircleShape)
                .border(1.dp, CardBorder, CircleShape)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val d = awaitFirstDown()
                        fun upd(p: Offset) {
                            hue = (p.x / size.width).coerceIn(0f, 1f) * 360f
                        }
                        upd(d.position)
                        d.consume()
                        do {
                            val e = awaitPointerEvent()
                            val c = e.changes.firstOrNull() ?: break
                            if (c.pressed) {
                                upd(c.position)
                                c.consume()
                            }
                        } while (e.changes.any { it.pressed })
                    }
                }
        ) {
            Canvas(Modifier.matchParentSize()) {
                val stops = (0..6).map { Color.hsv((it * 60f).coerceAtMost(359.9f), 1f, 1f) }
                drawRect(Brush.horizontalGradient(stops))
                val x = hue.coerceIn(0f, 360f) / 360f * size.width
                drawCircle(Color.White, 12.dp.toPx(), Offset(x, size.height / 2f))
                drawCircle(Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f), 9.dp.toPx(), Offset(x, size.height / 2f))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(current)
                    .border(1.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f), CircleShape)
            )
            Text(
                text = String.format(java.util.Locale.US, "#%06X", current.toArgb() and 0xFFFFFF),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun StrokePreview(tool: Int, style: InkStyle, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Canvas(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFFF7F8FA))
            .border(1.dp, CardBorder, shape)
            .clipToBounds()
    ) {
        val cw = size.width
        val ch = size.height
        when (tool) {
            InkTool.ERASER -> {
                val r = (style.size / 1000f * 360.dp.toPx() / 2f).coerceAtMost(ch / 2f - 4.dp.toPx())
                drawCircle(Color(0xFF111827).copy(alpha = 0.10f), r, Offset(cw / 2f, ch / 2f))
                drawCircle(Color(0xFF111827).copy(alpha = 0.65f), r, Offset(cw / 2f, ch / 2f), style = Stroke(1.6.dp.toPx()))
            }
            InkTool.LASER -> {
                val col = Color(style.argb)
                val wd = (style.size / 1000f * 360.dp.toPx()).coerceAtMost(ch * 0.30f)
                val n = 30
                val pts = ArrayList<Offset>(n)
                val es = ArrayList<Float>(n)
                for (i in 0 until n) {
                    val t = i / (n - 1f)
                    pts.add(Offset(cw * (0.10f + 0.74f * t), ch * (0.70f - 0.36f * sin(t * PI.toFloat() * 0.9f))))
                    es.add(t * t * (3f - 2f * t))
                }
                drawTrail(pts, es, List(n) { false }, col, wd)
                val head = pts.last()
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.55f), col.copy(alpha = 0f)), center = head, radius = wd * 2.6f), wd * 2.6f, head)
                drawCircle(col, wd * 0.8f, head)
                drawCircle(Color.White, wd * 0.4f, head)
            }
            else -> {
                val pageW = 360.dp.toPx()
                val pts = (0..24).map { i ->
                    val t = i / 24f
                    Offset((0.03f + (cw / pageW - 0.06f) * t), 0.5f + 0.26f * sin(t * 2f * PI.toFloat()))
                }
                val stroke = HStroke(0, pts, null, tool, style.argb, style.size / 1000f, style.opacity)
                drawIntoCanvas { c -> InkRenderer.drawPage(c.nativeCanvas, pageW, ch, listOf(stroke), emptyList()) }
            }
        }
    }
}

@Composable
fun TextEditDialog(
    request: TextRequest,
    look: TextLook,
    onSubmit: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember(request) { mutableStateOf(request.initial) }
    val focus = remember { FocusRequester() }
    val editing = request.id >= 0L
    LaunchedEffect(request) {
        delay(160)
        runCatching { focus.requestFocus() }
    }
    InkDialog(
        title = if (editing) "تعديل النص" else "إضافة نص",
        onDismiss = onDismiss,
        actions = {
            if (editing) {
                Box(
                    modifier = Modifier
                        .height(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f))
                        .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.92f, onClick = { onSubmit("") })
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    GlyphIcon(GLYPH_TRASH, MaterialTheme.colorScheme.error, Modifier.size(20.dp))
                }
            }
            DialogButton("إلغاء", false, Modifier.weight(1f), onDismiss)
            DialogButton(if (editing) "حفظ" else "إضافة", true, Modifier.weight(1f)) { onSubmit(text) }
        }
    ) {
        val c = Color(look.argb)
        val paper = RoundedCornerShape(16.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 76.dp)
                .clip(paper)
                .background(Color(0xFFF7F8FA))
                .border(1.dp, CardBorder, paper)
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text.ifBlank { "معاينة النص" },
                fontSize = (look.size * 0.45f).coerceIn(14f, 34f).sp,
                fontWeight = if (look.bold) FontWeight.Bold else FontWeight.Normal,
                color = c.copy(alpha = if (text.isBlank()) 0.35f else look.opacity),
                textAlign = TextAlign.Center,
                maxLines = 4,
                modifier = Modifier
                    .then(
                        if (look.bg && text.isNotBlank()) Modifier.background(
                            textBgFor(c, look.bgArgb),
                            RoundedCornerShape(8.dp)
                        ) else Modifier
                    )
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(500) },
            minLines = 2,
            maxLines = 5,
            placeholder = { Text("اكتب ملاحظتك على السلايد...") },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focus)
        )
    }
}