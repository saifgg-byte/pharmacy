package com.saifadnan.pharmacynotes.ui.pdf

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageScrubber(
    currentPage: Int,
    totalPages: Int,
    onJump: (page: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (totalPages < 2) return
    val haptics = LocalHapticFeedback.current
    var drag by remember { mutableStateOf<Float?>(null) }

    var pending by remember { mutableStateOf<Int?>(null) }
    val lastNotified = remember { intArrayOf(-1) }

    LaunchedEffect(currentPage) { if (pending == currentPage - 1) pending = null }
    LaunchedEffect(pending) {
        if (pending != null) {
            delay(700)
            pending = null
        }
    }

    val value = drag ?: pending?.toFloat() ?: (currentPage - 1).toFloat()
    val shown = value.roundToInt().coerceIn(0, totalPages - 1)

    LaunchedEffect(shown) {
        if (drag != null) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    Box(modifier = modifier.fillMaxWidth()) {
        GlassCard(shape = CircleShape, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "1",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = value,
                    onValueChange = { raw ->
                        drag = raw
                        val target = raw.roundToInt().coerceIn(0, totalPages - 1)
                        if (target != lastNotified[0]) {
                            lastNotified[0] = target
                            onJump(target)
                        }
                    },
                    onValueChangeFinished = {
                        val target = drag?.roundToInt()?.coerceIn(0, totalPages - 1)
                        drag = null
                        lastNotified[0] = -1
                        if (target != null) {
                            pending = target
                            onJump(target)
                        }
                    },
                    valueRange = 0f..(totalPages - 1).toFloat(),
                    thumb = {
                        Box(
                            modifier = Modifier
                                .size(if (drag != null) 26.dp else 22.dp)
                                .shadow(4.dp, CircleShape)
                                .background(MaterialTheme.colorScheme.onSurface, CircleShape)
                        )
                    },
                    track = { state ->
                        val range = state.valueRange.endInclusive - state.valueRange.start
                        val fraction = if (range > 0f) ((state.value - state.valueRange.start) / range).coerceIn(0f, 1f) else 0f
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(fraction)
                                    .height(4.dp)
                                    .background(MaterialTheme.colorScheme.onSurface)
                            )
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                        .testTag("pdf_page_slider")
                )
                Text(
                    text = "$totalPages",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        AnimatedVisibility(
            visible = drag != null,
            enter = fadeIn(tween(120)) + scaleIn(tween(160), initialScale = 0.85f),
            exit = fadeOut(tween(160)) + scaleOut(tween(160), targetScale = 0.9f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-48).dp)
        ) {
            Text(
                text = "${shown + 1}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.inverseOnSurface,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.inverseSurface)
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }
    }
}
