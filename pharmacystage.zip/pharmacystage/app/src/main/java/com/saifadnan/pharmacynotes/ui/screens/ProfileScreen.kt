package com.saifadnan.pharmacynotes.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.Course
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassDivider
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.ProfileTabSkeleton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.components.bounceClick
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.glass
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
    currentUser: UserEntity?,
    downloadedCount: Int,
    bookmarkedCount: Int,
    isDarkMode: Boolean,
    isAdminMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onNavigateToDownloads: () -> Unit,
    onNavigateToFavorites: () -> Unit = {},
    onNavigateToAdmin: () -> Unit,
    onNavigateToSchedule: () -> Unit,
    onNavigateToExams: () -> Unit = {},
    onNavigateToCard: () -> Unit = {},
    onNavigateToEditProfile: () -> Unit = {},
    onLogoutClick: () -> Unit,
    isTabLoading: Boolean = false,
    isAdminAccount: Boolean = false,
    onToggleAdminMode: () -> Unit = {},
    selectedCourse: Int = Course.FIRST,
    onCourseSelect: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showLogoutDialog by remember { mutableStateOf(false) }
    var showCourseDialog by remember { mutableStateOf(false) }

    val userName = currentUser?.fullName?.ifBlank { "طالب صيدلة" } ?: "طالب صيدلة"
    val userEmail = currentUser?.email?.ifBlank { "غير متوفر" } ?: "غير متوفر"
    val userRole = if (currentUser?.role == "ADMIN") "طالب · أدمن القناة" else "طالب · ${com.saifadnan.pharmacynotes.data.Stages.label(com.saifadnan.pharmacynotes.data.Stages.current)}"
    val groupName = currentUser?.groupName?.ifBlank { "لم يُحدَّد بعد" } ?: "لم يُحدَّد بعد"
    val studentIdText = currentUser?.studentId?.trim().orEmpty()
    val canEditProfile = currentUser != null && currentUser.role != "ADMIN"

    val regDate = remember(currentUser?.registrationDate) {
        val date = Date(currentUser?.registrationDate ?: System.currentTimeMillis())
        SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(date)
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "الحساب الشخصي",
            subtitle = "كلية الصيدلة",
            modifier = Modifier.padding(horizontal = 20.dp)
        )

        if (isTabLoading) {
            ProfileTabSkeleton(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_header_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = userName.trim().firstOrNull()?.toString() ?: "ط",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = userName,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = userRole,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "الجامعة المستنصرية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    StatCard(
                        icon = Icons.Default.DownloadDone,
                        value = downloadedCount,
                        label = "محملة على الجهاز",
                        onClick = onNavigateToDownloads,
                        index = 0,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("profile_downloads_stat")
                    )
                    StatCard(
                        icon = Icons.Default.Bookmark,
                        value = bookmarkedCount,
                        label = "في المفضلة",
                        onClick = onNavigateToFavorites,
                        index = 1,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("profile_bookmarks_stat")
                    )
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        DetailRow(Icons.Default.Groups, "الكروب", groupName)
                        GlassDivider(Modifier.padding(horizontal = 18.dp))
                        DetailRow(Icons.Default.Email, "البريد الإلكتروني", userEmail)
                        if (canEditProfile && studentIdText.isNotEmpty()) {
                            GlassDivider(Modifier.padding(horizontal = 18.dp))
                            DetailRow(Icons.Default.Badge, "الرقم الجامعي", studentIdText)
                        }
                        GlassDivider(Modifier.padding(horizontal = 18.dp))
                        DetailRow(Icons.Default.VerifiedUser, "الحساب", "مفعّل منذ $regDate")
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        if (canEditProfile) {
                            SettingRow(
                                icon = Icons.Default.Edit,
                                title = "تعديل البيانات",
                                subtitle = "لتعديل بياناتك الشخصية وكلمة المرور",
                                onClick = onNavigateToEditProfile,
                                modifier = Modifier.testTag("profile_edit_shortcut"),
                                trailing = { ChevronIcon() }
                            )
                            GlassDivider(Modifier.padding(horizontal = 18.dp))
                        }
                        SettingRow(
                            icon = Icons.Default.School,
                            title = "الكورس الدراسي",
                            subtitle = Course.label(selectedCourse),
                            onClick = { showCourseDialog = true },
                            modifier = Modifier.testTag("profile_course_row"),
                            trailing = { ChevronIcon() }
                        )
                        GlassDivider(Modifier.padding(horizontal = 18.dp))
                        SettingRow(
                            icon = Icons.Default.DarkMode,
                            title = "الوضع الداكن",
                            subtitle = if (isDarkMode) "مفعّل" else "مُعطَّل",
                            onClick = onToggleDarkMode,
                            trailing = {
                                Switch(
                                    checked = isDarkMode,
                                    onCheckedChange = { onToggleDarkMode() },
                                    colors = profileSwitchColors(),
                                    modifier = Modifier.testTag("profile_dark_mode_switch")
                                )
                            }
                        )
                        GlassDivider(Modifier.padding(horizontal = 18.dp))
                        SettingRow(
                            icon = Icons.Default.QrCode2,
                            title = "بطاقة المكتبة",
                            subtitle = "رمز QR للاستعارة من مكتبة الكلية",
                            onClick = onNavigateToCard,
                            modifier = Modifier.testTag("profile_library_card_shortcut"),
                            trailing = { ChevronIcon() }
                        )
                        GlassDivider(Modifier.padding(horizontal = 18.dp))
                        SettingRow(
                            icon = Icons.Default.Schedule,
                            title = if (isAdminMode) "إدارة الجدول الدراسي" else "الجدول الأسبوعي",
                            subtitle = if (isAdminMode) "مواعيد المحاضرات لكل كروب" else "مواعيد المحاضرات والتذكير قبل كل محاضرة",
                            onClick = onNavigateToSchedule,
                            modifier = Modifier.testTag("profile_schedule_shortcut"),
                            trailing = { ChevronIcon() }
                        )
                        if (!isAdminMode) {
                            GlassDivider(Modifier.padding(horizontal = 18.dp))
                            SettingRow(
                                icon = Icons.Default.EventAvailable,
                                title = "جدول الامتحانات",
                                subtitle = "مواعيد الامتحانات مع عداد الايام",
                                onClick = onNavigateToExams,
                                modifier = Modifier.testTag("profile_exams_shortcut"),
                                trailing = { ChevronIcon() }
                            )
                        }
                        if (isAdminAccount) {
                            GlassDivider(Modifier.padding(horizontal = 18.dp))
                            SettingRow(
                                icon = Icons.Default.SwapHoriz,
                                title = "وضع الأدمن",
                                subtitle = if (isAdminMode) "أنت الآن بوضع الأدمن" else "بدّل لعرض لوحة الإدارة",
                                onClick = onToggleAdminMode,
                                trailing = {
                                    Switch(
                                        checked = isAdminMode,
                                        onCheckedChange = { onToggleAdminMode() },
                                        colors = profileSwitchColors(),
                                        modifier = Modifier.testTag("admin_mode_toggle")
                                    )
                                }
                            )
                        }
                        if (isAdminMode) {
                            GlassDivider(Modifier.padding(horizontal = 18.dp))
                            SettingRow(
                                icon = Icons.Default.AdminPanelSettings,
                                title = "لوحة التحكم",
                                subtitle = "المحاضرات والإعلانات والطلاب",
                                iconTint = Amber,
                                onClick = onNavigateToAdmin,
                                trailing = { ChevronIcon() }
                            )
                        }
                    }
                }

                val logoutSource = remember { MutableInteractionSource() }
                Button(
                    onClick = { showLogoutDialog = true },
                    interactionSource = logoutSource,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.10f),
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp, 0.dp, 0.dp, 0.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .bounceClick(scaleDown = 0.97f, interactionSource = logoutSource)
                        .testTag("profile_logout_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Logout,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(text = "تسجيل الخروج", style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }

    if (showCourseDialog) {
        AlertDialog(
            onDismissRequest = { showCourseDialog = false },
            title = {
                Text(text = "اختيار الكورس", style = MaterialTheme.typography.titleMedium)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تظهر لك مواد الكورس المحدد فقط",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Course.all.forEach { course ->
                        CourseOption(
                            course = course,
                            selected = course == selectedCourse,
                            onClick = {
                                showCourseDialog = false
                                if (course != selectedCourse) onCourseSelect(course)
                            }
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showCourseDialog = false }) {
                    Text("إغلاق", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = {
                Text(text = "تسجيل الخروج", style = MaterialTheme.typography.titleMedium)
            },
            text = {
                Text(
                    text = "متأكد تريد تطلع من حسابك؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        onLogoutClick()
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("خروج")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
}

@Composable
private fun CourseOption(course: Int, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) primary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) primary else MaterialTheme.glass.border,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("profile_course_option_$course"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = if (selected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = Course.label(course),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun profileSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
    checkedTrackColor = MaterialTheme.colorScheme.primary,
    checkedBorderColor = MaterialTheme.colorScheme.primary,
    uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
    uncheckedTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
    uncheckedBorderColor = MaterialTheme.glass.border
)

@Composable
private fun ChevronIcon() {
    Icon(
        imageVector = Icons.Default.ChevronLeft,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun StatCard(
    icon: ImageVector,
    value: Int,
    label: String,
    onClick: () -> Unit,
    index: Int,
    modifier: Modifier = Modifier
) {
    GlassCard(
        onClick = onClick,
        modifier = modifier.animateItemEntrance(index = index)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTile(icon = icon, size = 40.dp)
            Column {
                Text(
                    text = "$value",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DetailRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconTile(icon = icon, size = 40.dp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    iconTint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconTile(icon = icon, size = 40.dp, tint = iconTint)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        trailing()
    }
}