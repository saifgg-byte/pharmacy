package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas

private class SvgPaint(val tint: Boolean, val color: Color = Color.Unspecified)

private class SvgShape(
    val path: Path,
    val fill: SvgPaint?,
    val stroke: SvgPaint?,
    val strokeWidth: Float,
    val cap: StrokeCap,
    val join: StrokeJoin,
    val opacity: Float
)

private class SvgText(val x: Float, val y: Float, val text: String, val size: Float, val anchor: String, val fill: SvgPaint, val bold: Boolean)

private class ParsedSvg(val x: Float, val y: Float, val w: Float, val h: Float, val shapes: List<SvgShape>, val texts: List<SvgText> = emptyList())

private val ATTR = Regex("([A-Za-z_:][\\w:.-]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")
private val TOKEN = Regex("<(/?)(svg|g|path|circle|ellipse|rect|line|polyline|polygon)\\b([^>]*?)(/?)>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
private val NUM = Regex("-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?")

private fun attrsOf(raw: String): Map<String, String> {
    val m = HashMap<String, String>()
    for (a in ATTR.findAll(raw)) m[a.groupValues[1].lowercase()] = a.groupValues[2].ifEmpty { a.groupValues[3] }
    m["style"]?.split(';')?.forEach { kv ->
        val i = kv.indexOf(':')
        if (i > 0) m[kv.substring(0, i).trim().lowercase()] = kv.substring(i + 1).trim()
    }
    return m
}

private fun paintOf(v: String?, default: SvgPaint?): SvgPaint? {
    val s = v?.trim()?.lowercase() ?: return default
    if (s.isEmpty()) return default
    if (s == "none" || s == "transparent") return null
    if (s == "currentcolor" || s == "inherit") return SvgPaint(true)
    if (s == "white") return null
    if (s == "black") return SvgPaint(true)
    if (s.startsWith("#")) {
        val hex = s.substring(1).let { if (it.length == 3) it.map { c -> "$c$c" }.joinToString("") else it }
        val rgb = hex.take(6).toLongOrNull(16) ?: return SvgPaint(true)
        val r = ((rgb shr 16) and 0xFF).toInt()
        val g = ((rgb shr 8) and 0xFF).toInt()
        val b = (rgb and 0xFF).toInt()
        val mx = maxOf(r, g, b)
        val mn = minOf(r, g, b)
        if (mx - mn < 28) {
            // رمادي: أبيض تقريباً = ثقب، غير ذلك = لون الواجهة
            return if (mx > 235) null else SvgPaint(true)
        }
        return SvgPaint(false, Color(r, g, b))
    }
    return SvgPaint(true)
}

private fun nums(s: String?): List<Float> = if (s == null) emptyList() else NUM.findAll(s).map { it.value.toFloat() }.toList()

private fun len(s: String?, def: Float = 0f): Float = s?.let { NUM.find(it)?.value?.toFloatOrNull() } ?: def

private fun buildShape(tag: String, a: Map<String, String>): Path? {
    return try {
        when (tag) {
            "path" -> a["d"]?.let { PathParser().parsePathString(it).toPath() }
            "circle" -> {
                val r = len(a["r"])
                Path().apply { addOval(Rect(len(a["cx"]) - r, len(a["cy"]) - r, len(a["cx"]) + r, len(a["cy"]) + r)) }
            }
            "ellipse" -> {
                val rx = len(a["rx"]); val ry = len(a["ry"])
                Path().apply { addOval(Rect(len(a["cx"]) - rx, len(a["cy"]) - ry, len(a["cx"]) + rx, len(a["cy"]) + ry)) }
            }
            "rect" -> {
                val x = len(a["x"]); val y = len(a["y"]); val w = len(a["width"]); val h = len(a["height"])
                val rx = len(a["rx"], len(a["ry"])); val ry = len(a["ry"], rx)
                Path().apply {
                    if (rx > 0f || ry > 0f) addRoundRect(RoundRect(Rect(x, y, x + w, y + h), CornerRadius(rx, ry)))
                    else addRect(Rect(x, y, x + w, y + h))
                }
            }
            "line" -> Path().apply {
                moveTo(len(a["x1"]), len(a["y1"])); lineTo(len(a["x2"]), len(a["y2"]))
            }
            "polyline", "polygon" -> {
                val p = nums(a["points"])
                if (p.size < 4) null else Path().apply {
                    moveTo(p[0], p[1])
                    var i = 2
                    while (i + 1 < p.size) { lineTo(p[i], p[i + 1]); i += 2 }
                    if (tag == "polygon") close()
                }
            }
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

private val TEXT_TAG = Regex("<text\\b([^>]*)>(.*?)</text>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
private val ANY_TAG = Regex("<[^>]+>")

private fun decodeEntities(s: String) = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")

private fun parseSvg(svg: String, missingFillIsNone: Boolean = false): ParsedSvg? {
    val shapes = ArrayList<SvgShape>()
    val stack = ArrayList<Map<String, String>>()
    var vb = floatArrayOf(0f, 0f, 24f, 24f)
    var rootSeen = false
    val inheritable = listOf("fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "opacity", "fill-opacity", "stroke-opacity")

    fun current(): Map<String, String> = stack.lastOrNull() ?: emptyMap()

    for (m in TOKEN.findAll(svg)) {
        val closing = m.groupValues[1] == "/"
        val tag = m.groupValues[2].lowercase()
        val selfClosing = m.groupValues[4] == "/"
        if (tag == "svg" || tag == "g") {
            if (closing) { if (stack.isNotEmpty()) stack.removeAt(stack.size - 1); continue }
            val a = attrsOf(m.groupValues[3])
            if (tag == "svg" && !rootSeen) {
                rootSeen = true
                val v = nums(a["viewbox"])
                if (v.size == 4 && v[2] > 0f && v[3] > 0f) vb = v.toFloatArray()
                else {
                    val w = len(a["width"], 24f); val h = len(a["height"], 24f)
                    if (w > 0f && h > 0f) vb = floatArrayOf(0f, 0f, w, h)
                }
            }
            val merged = HashMap(current())
            for (k in inheritable) a[k]?.let { merged[k] = it }
            if (!selfClosing) stack.add(merged)
            continue
        }
        if (closing) continue
        val a = attrsOf(m.groupValues[3])
        val path = buildShape(tag, a) ?: continue
        val inh = current()
        fun get(k: String) = a[k] ?: inh[k]
        val isLine = tag == "line"
        val fill = if (isLine) null else paintOf(get("fill"), if (missingFillIsNone) null else SvgPaint(true))
        val stroke = paintOf(get("stroke"), null)
        val op = (get("opacity")?.toFloatOrNull() ?: 1f) * (get("fill-opacity")?.toFloatOrNull() ?: 1f)
        shapes.add(
            SvgShape(
                path = path,
                fill = fill,
                stroke = stroke,
                strokeWidth = get("stroke-width")?.let { len(it, 1f) } ?: 1f,
                cap = when (get("stroke-linecap")) { "round" -> StrokeCap.Round; "square" -> StrokeCap.Square; else -> StrokeCap.Butt },
                join = when (get("stroke-linejoin")) { "round" -> StrokeJoin.Round; "bevel" -> StrokeJoin.Bevel; else -> StrokeJoin.Miter },
                opacity = op.coerceIn(0f, 1f)
            )
        )
    }
    val texts = ArrayList<SvgText>()
    for (m in TEXT_TAG.findAll(svg).take(60)) {
        val a = attrsOf(m.groupValues[1])
        val content = decodeEntities(ANY_TAG.replace(m.groupValues[2], "")).replace(Regex("\\s+"), " ").trim()
        if (content.isEmpty() || content.length > 80) continue
        val size = len(a["font-size"], 4f).coerceIn(1.5f, 12f)
        texts.add(
            SvgText(
                x = len(a["x"]), y = len(a["y"]), text = content, size = size,
                anchor = a["text-anchor"] ?: "start",
                fill = paintOf(a["fill"], SvgPaint(true)) ?: SvgPaint(true),
                bold = (a["font-weight"] ?: "") in setOf("bold", "600", "700", "800")
            )
        )
    }
    if (shapes.isEmpty() && texts.isEmpty()) return null
    return ParsedSvg(vb[0], vb[1], vb[2], vb[3], shapes, texts)
}

fun isRenderableSvg(svg: String): Boolean = parseSvg(svg) != null

@Composable
fun SvgIcon(svg: String, tint: Color, modifier: Modifier = Modifier, diagram: Boolean = false) {
    val parsed = remember(svg, diagram) { parseSvg(svg, missingFillIsNone = diagram) } ?: return
    Canvas(modifier) {
        val scale = minOf(size.width / parsed.w, size.height / parsed.h)
        val dx = (size.width - parsed.w * scale) / 2f - parsed.x * scale
        val dy = (size.height - parsed.h * scale) / 2f - parsed.y * scale
        withTransform({
            translate(dx, dy)
            scale(scale, scale, pivot = Offset.Zero)
        }) {
            for (s in parsed.shapes) {
                s.fill?.let { p ->
                    drawPath(s.path, if (p.tint) tint else p.color, alpha = s.opacity)
                }
                s.stroke?.let { p ->
                    drawPath(
                        s.path, if (p.tint) tint else p.color,
                        alpha = s.opacity,
                        style = Stroke(width = s.strokeWidth, cap = s.cap, join = s.join)
                    )
                }
            }
            for (t in parsed.texts) {
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = (if (t.fill.tint) tint else t.fill.color).toArgb()
                    textSize = t.size
                    isFakeBoldText = t.bold
                    textAlign = when (t.anchor) {
                        "middle" -> android.graphics.Paint.Align.CENTER
                        "end" -> android.graphics.Paint.Align.RIGHT
                        else -> android.graphics.Paint.Align.LEFT
                    }
                }
                drawContext.canvas.nativeCanvas.drawText(t.text, t.x, t.y, paint)
            }
        }
    }
}

private const val BASE = "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\">"

val SubjectIconPresets: LinkedHashMap<String, Pair<String, String>> = linkedMapOf(
    "organic" to ("الكيمياء العضوية" to "$BASE<path d=\"M12 3l7.8 4.5v9L12 21l-7.8-4.5v-9z\"/><circle cx=\"12\" cy=\"12\" r=\"3.1\"/><path d=\"M12 3V1M19.8 16.5l1.7 1M4.2 16.5l-1.7 1\"/></svg>"),
    "physical" to ("الصيدلة الفيزيائية" to "$BASE<path d=\"M12 3v17M7 20.5h10M4.5 6.5h15\"/><path d=\"M4.5 6.5L1.8 13.5a3.2 3.2 0 006.4 0zM19.5 6.5l-2.7 7a3.2 3.2 0 006.4 0z\"/></svg>"),
    "physiology" to ("الفسلجة" to "$BASE<path d=\"M12 20.5s-8-4.6-8-10.6a4.4 4.4 0 018-2.6 4.4 4.4 0 018 2.6c0 6-8 10.6-8 10.6z\"/><path d=\"M6.5 12h3l1.5-3 2 6 1.5-3h3\"/></svg>"),
    "microbiology" to ("الأحياء المجهرية" to "$BASE<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 8V4.5M12 19.5V16M8 12H4.5M19.5 12H16M9.2 9.2L6.8 6.8M17.2 17.2l-2.4-2.4M14.8 9.2l2.4-2.4M6.8 17.2l2.4-2.4\"/><circle cx=\"12\" cy=\"3.3\" r=\"1\"/><circle cx=\"12\" cy=\"20.7\" r=\"1\"/><circle cx=\"3.3\" cy=\"12\" r=\"1\"/><circle cx=\"20.7\" cy=\"12\" r=\"1\"/></svg>"),
    "arabic" to ("اللغة العربية" to "$BASE<path d=\"M3 5.5C5.6 4 9 4.2 12 6.2c3-2 6.4-2.2 9-.7V19c-2.6-1.5-6-1.3-9 .7-3-2-6.4-2.2-9-.7z\"/><path d=\"M12 6.2v13.5\"/><path d=\"M6 10.5c1.6 1.2 3 1.2 4 0\"/><circle cx=\"8\" cy=\"8.6\" r=\".6\"/></svg>"),
    "computer" to ("الحاسوب" to "$BASE<rect x=\"3\" y=\"4\" width=\"18\" height=\"12\" rx=\"2\"/><path d=\"M8 20h8M12 16v4M9.5 8.5l-2 2 2 2M14.5 8.5l2 2-2 2\"/></svg>"),
    "law" to ("القانون / الجرائم" to "$BASE<path d=\"M13.5 4.5l6 6-3 3-6-6z\"/><path d=\"M10.5 7.5L4 14l3 3 6.5-6.5M3 21h10\"/></svg>"),
    "pill" to ("دواء" to "$BASE<rect x=\"2.5\" y=\"8\" width=\"19\" height=\"8\" rx=\"4\"/><path d=\"M12 8v8\"/></svg>"),
    "flask" to ("مختبر" to "$BASE<path d=\"M9 3h6M10 3v6L4.6 18.6A1.6 1.6 0 006 21h12a1.6 1.6 0 001.4-2.4L14 9V3\"/><path d=\"M7.5 15h9\"/></svg>"),
    "book" to ("كتاب" to "$BASE<path d=\"M4 4.5A2 2 0 016 2.5h13v16H6a2 2 0 00-2 2z\"/><path d=\"M4 20.5a2 2 0 002 2h13\"/></svg>")
)

fun resolveSubjectIconSvg(icon: String): String? {
    val v = icon.trim()
    if (v.isEmpty()) return null
    if (v.startsWith("preset:")) return SubjectIconPresets[v.removePrefix("preset:")]?.second
    return if (v.startsWith("<svg", ignoreCase = true)) v else null
}

fun suggestPresetFor(subject: String): String? {
    val s = subject.lowercase()
    return when {
        "organic" in s || "عضوية" in s -> "organic"
        "physical" in s || "فيزيائية" in s -> "physical"
        "physiolog" in s || "فسل" in s -> "physiology"
        "microbio" in s || "مجهر" in s || "احياء" in s || "أحياء" in s -> "microbiology"
        "arabic" in s || "عربي" in s || "العربية" in s -> "arabic"
        "comput" in s || "حاسو" in s || "حاسب" in s -> "computer"
        "crime" in s || "baath" in s || "albath" in s || "جرائم" in s || "البعث" in s || "قانون" in s -> "law"
        else -> null
    }
}

@Composable
fun SubjectIconTile(
    icon: String,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 48.dp,
    tint: Color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
    container: Color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
) {
    val svg = remember(icon) { resolveSubjectIconSvg(icon) }
    if (svg == null) {
        IconTile(icon = Icons.Default.Folder, modifier = modifier, size = size, tint = tint, container = container)
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(container),
            contentAlignment = Alignment.Center
        ) {
            SvgIcon(svg, tint, Modifier.size(size * 0.54f))
        }
    }
}