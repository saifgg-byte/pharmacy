package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.BroadcastNotificationEntity
import kotlinx.coroutines.delay

@Composable
fun BroadcastBanner(
    notification: BroadcastNotificationEntity?,
    onDismiss: () -> Unit,
    onViewClick: (BroadcastNotificationEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(notification) {
        if (notification != null) {
            delay(4000)
            onDismiss()
        }
    }

    AnimatedVisibility(
        visible = notification != null,
        enter = slideInVertically(animationSpec = tween(380), initialOffsetY = { -it }) + fadeIn(animationSpec = tween(380)),
        exit = slideOutVertically(animationSpec = tween(300), targetOffsetY = { -it }) + fadeOut(animationSpec = tween(300)),
        modifier = modifier
    ) {
        notification?.let { notif ->
            GlassCard(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                onClick = { if (notif.lectureId != null) onViewClick(notif) else onDismiss() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("broadcast_banner_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconTile(icon = Icons.Default.NotificationsActive, size = 42.dp)

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = notif.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        if (notif.message.isNotBlank()) {
                            Text(
                                text = com.saifadnan.pharmacynotes.util.stripRich(notif.message),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                        }
                        if (notif.lectureId != null) {
                            Text(
                                text = "اضغط لفتح الملف",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.testTag("view_broadcast_lecture_button")
                            )
                        }
                    }

                    GlassIconButton(onClick = onDismiss, size = 34.dp) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
