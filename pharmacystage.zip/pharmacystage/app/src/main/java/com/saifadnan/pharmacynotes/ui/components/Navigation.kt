package com.saifadnan.pharmacynotes.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.interaction.collectIsPressedAsState
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.ui.theme.glass
import com.saifadnan.pharmacynotes.ui.theme.rememberAdaptive

private data class NavItem(
    val key: String,
    val label: String,
    val filled: ImageVector,
    val outlined: ImageVector,
    val tag: String
)

private fun buildNavItems(isAdminMode: Boolean): List<NavItem> = buildList {
    add(NavItem("HOME", "الملازم", Icons.Filled.MenuBook, Icons.Outlined.MenuBook, "nav_home_tab"))
    add(NavItem("NOTIFICATIONS", "التبليغات", Icons.Filled.Notifications, Icons.Outlined.Notifications, "nav_notifications_tab"))
    add(NavItem("PROFILE", "الحساب", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile_tab"))
    if (isAdminMode) {
        add(NavItem("ADMIN", "الأدمن", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings, "nav_admin_tab"))
    }
}

@Composable
fun PharmacyNavRail(
    currentTab: String,
    isAdminMode: Boolean,
    unreadNotificationsCount: Int,
    onTabSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = MaterialTheme.glass
    val items = remember(isAdminMode) { buildNavItems(isAdminMode) }
    val view = LocalView.current
    val railShape = RoundedCornerShape(36.dp)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .padding(start = 12.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(
            modifier = Modifier
                .shadow(
                    elevation = glass.shadowElevation,
                    shape = railShape,
                    clip = false,
                    ambientColor = glass.shadowAmbient,
                    spotColor = glass.shadowSpot
                )
                .clip(railShape)
                .background(glass.navFill)
                .border(1.dp, glass.border, railShape)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items.forEach { item ->
                val selected = currentTab == item.key
                NavTab(
                    item = item,
                    selected = selected,
                    badgeCount = if (item.key == "NOTIFICATIONS") unreadNotificationsCount else 0,
                    showLabel = false,
                    onClick = {
                        if (!selected) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        onTabSelected(item.key)
                    }
                )
            }
        }
    }
}

@Composable
fun PharmacyBottomBar(
    currentTab: String,
    isAdminMode: Boolean,
    unreadNotificationsCount: Int,
    onTabSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = MaterialTheme.glass
    val items = remember(isAdminMode) { buildNavItems(isAdminMode) }
    val view = LocalView.current
    val pillShape = CircleShape
    val wide = rememberAdaptive().isTablet

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .then(if (wide) Modifier.widthIn(max = 520.dp) else Modifier)
                .fillMaxWidth()
                .shadow(
                    elevation = glass.shadowElevation,
                    shape = pillShape,
                    clip = false,
                    ambientColor = glass.shadowAmbient,
                    spotColor = glass.shadowSpot
                )
                .clip(pillShape)
                .background(glass.navFill)
                .border(1.dp, glass.border, pillShape)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val selected = currentTab == item.key
                NavTab(
                    item = item,
                    selected = selected,
                    badgeCount = if (item.key == "NOTIFICATIONS") unreadNotificationsCount else 0,
                    onClick = {
                        if (!selected) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        onTabSelected(item.key)
                    }
                )
            }
        }
    }
}

@Composable
private fun NavTab(
    item: NavItem,
    selected: Boolean,
    badgeCount: Int,
    onClick: () -> Unit,
    showLabel: Boolean = true
) {
    val glass = MaterialTheme.glass
    val onIndicator = if (glass.isDark) Color(0xFF0B1020) else Color.White
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    val container by animateColorAsState(
        targetValue = if (selected) glass.navIndicator else Color.Transparent,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "NavTabContainer"
    )
    val tint by animateColorAsState(
        targetValue = if (selected) onIndicator else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(240),
        label = "NavTabTint"
    )

    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
        label = "NavTabPress"
    )

    val baseScale by animateFloatAsState(
        targetValue = if (selected) 1f else 0.94f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "NavTabScale"
    )

    val pop = remember { Animatable(0f) }
    val wobble = remember { Animatable(0f) }
    val burst = remember { Animatable(1f) }
    var firstComposition by remember { mutableStateOf(true) }
    LaunchedEffect(selected) {
        if (firstComposition) { firstComposition = false; return@LaunchedEffect }
        if (!selected) return@LaunchedEffect
        coroutineScope {
            launch {
                burst.snapTo(0.78f)
                burst.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessMedium))
            }
            when (item.key) {
                "NOTIFICATIONS" -> launch {
                    wobble.snapTo(0f)
                    wobble.animateTo(-16f, tween(70, easing = FastOutSlowInEasing))
                    wobble.animateTo(13f, tween(90, easing = FastOutSlowInEasing))
                    wobble.animateTo(-8f, tween(80, easing = FastOutSlowInEasing))
                    wobble.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium))
                }
                "PROFILE" -> launch {
                    pop.snapTo(0f)
                    pop.animateTo(-1f, tween(110, easing = FastOutSlowInEasing))
                    pop.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
                }
                "ADMIN" -> launch {
                    wobble.snapTo(-14f)
                    wobble.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMediumLow))
                }
                else -> launch {
                    wobble.snapTo(10f)
                    wobble.animateTo(0f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMediumLow))
                }
            }
        }
    }

    Row(
        modifier = Modifier
            .then(if (showLabel) Modifier.height(48.dp) else Modifier.size(52.dp))
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .clip(CircleShape)
            .background(container)
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = if (selected && showLabel) 14.dp else 10.dp)
            .testTag(item.tag),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BadgedBox(
            badge = {
                if (badgeCount > 0) {
                    Badge(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = Color.White
                    ) {
                        Text(
                            text = if (badgeCount > 9) "9+" else "$badgeCount",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        ) {

            Box(
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer {
                        val sc = baseScale * burst.value
                        scaleX = sc
                        scaleY = sc
                        rotationZ = wobble.value
                        translationY = pop.value * 5.dp.toPx()
                        transformOrigin = TransformOrigin(0.5f, if (item.key == "NOTIFICATIONS") 0.1f else 0.5f)
                    }
            ) {
                androidx.compose.animation.Crossfade(
                    targetState = selected,
                    animationSpec = tween(180),
                    label = "NavIconSwap"
                ) { isSel ->
                    Icon(
                        imageVector = if (isSel) item.filled else item.outlined,
                        contentDescription = item.label,
                        tint = tint,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = selected && showLabel,
            enter = fadeIn(tween(240, delayMillis = 70)) + expandHorizontally(
                animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
            ),
            exit = fadeOut(tween(110)) + shrinkHorizontally(tween(220, easing = FastOutSlowInEasing))
        ) {
            Row {
                Spacer(Modifier.width(6.dp))
                Text(
                    text = item.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = tint,
                    maxLines = 1
                )
            }
        }
    }
}
