package com.saifadnan.pharmacynotes.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val OptionTags = listOf("A", "B", "C", "D")

private fun kindLabel(kind: String) = if (kind == "tf") "صح أم غلط" else "اختيار من متعدد"

private fun answerText(q: SupabaseClient.GameQuestionDto): String =
    q.options.getOrNull(q.correct).orEmpty()

private const val ImportExample = "1. ما هي آلية عمل Atropine؟\n" +
    "A) Competitive antagonist at muscarinic receptors\n" +
    "B) Irreversible inhibitor لـ Acetylcholinesterase\n" +
    "C) Agonist at nicotinic receptors\n" +
    "D) Selective β1 blocker\n" +
    "الجواب: A) شرح اختياري\n\n" +
    "2. عبارة صح أو غلط\n" +
    "الجواب: صح - شرح اختياري"

private fun readTextFile(context: Context, uri: Uri): String? {
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.isEmpty() || bytes.size > 1_400_000) return null
        val text = when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() -> String(bytes, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() -> String(bytes, Charsets.UTF_16BE)
            else -> String(bytes, Charsets.UTF_8)
        }.removePrefix("\uFEFF")
        if (text.contains('\u0000')) null else text
    } catch (_: Exception) {
        null
    }
}

@Composable
fun AdminGamePanel(
    onToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<SupabaseClient.GameQuestionDto>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<SupabaseClient.GameQuestionDto?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<SupabaseClient.GameQuestionDto?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var importText by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<SupabaseClient.GameImportReport?>(null) }
    var importActive by remember { mutableStateOf(true) }
    var importBusy by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            importBusy = true
            scope.launch {
                val text = withContext(Dispatchers.IO) { readTextFile(context, uri) }
                if (text == null) {
                    importBusy = false
                    onToast("تعذر قراءة الملف. اختر ملف txt نصي بحجم أقل من 1.4 ميغابايت")
                    return@launch
                }
                val r = SupabaseClient.importGameQuestions(text, dryRun = true, active = true)
                importBusy = false
                val found = r.report
                if (found != null) {
                    importText = text
                    importActive = true
                    report = found
                } else {
                    onToast(r.message ?: "تعذر قراءة الملف")
                }
            }
        }
    }

    LaunchedEffect(reload) {
        val r = SupabaseClient.getAdminGameQuestions()
        if (r == null) {
            failed = true
        } else {
            failed = false
            items = r
        }
    }

    val all = items.orEmpty()
    val shown = when (filter) {
        1 -> all.filter { it.kind == "match" }
        2 -> all.filter { it.kind == "tf" }
        else -> all
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("أسئلة اللعبة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "تظهر للطلاب أثناء تحميل المحاضرة (${all.size} سؤال)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onClick = { error = null; creating = true }, shape = AppShapes.Small) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("إضافة")
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(
                onClick = { picker.launch("*/*") },
                enabled = !importBusy,
                shape = AppShapes.Small,
                modifier = Modifier.weight(1f)
            ) {
                if (importBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("جاري قراءة الملف...")
                } else {
                    Icon(Icons.Default.UploadFile, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("استيراد أسئلة من ملف txt")
                }
            }
            TextButton(onClick = { showHelp = true }) { Text("شكل الملف") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GlassChip(text = "الكل", selected = filter == 0, onClick = { filter = 0 })
            GlassChip(text = "اختيار من متعدد", selected = filter == 1, onClick = { filter = 1 })
            GlassChip(text = "صح أم غلط", selected = filter == 2, onClick = { filter = 2 })
        }

        Text(
            "الأسئلة المضافة هنا تُخلط مع الأسئلة الأساسية داخل التطبيق، وتظهر عند الطلاب بعد التحديث التلقائي خلال دقائق.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        when {
            items == null && !failed -> {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                }
            }
            items == null && failed -> {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("تعذر تحميل الأسئلة", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { failed = false; reload++ }, shape = AppShapes.Small) {
                        Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المحاولة")
                    }
                }
            }
            shown.isEmpty() -> {
                Text(
                    if (all.isEmpty()) "ما أضفت أي سؤال بعد." else "لا توجد أسئلة من هذا النوع.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            }
            else -> shown.forEachIndexed { index, q ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItemEntrance(index = index)
                        .clip(AppShapes.Medium)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, CardBorder, AppShapes.Medium)
                        .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                kindLabel(q.kind),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clip(AppShapes.Pill)
                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                            if (!q.active) {
                                Text(
                                    "مخفي",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                        Text(
                            q.prompt,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "الإجابة: ${answerText(q)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = SuccessGreen,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Switch(
                        checked = q.active,
                        onCheckedChange = { on ->
                            scope.launch {
                                val r = SupabaseClient.saveGameQuestion(q.id, q.copy(active = on))
                                if (r.ok) reload++ else onToast(r.message ?: "تعذر التحديث")
                            }
                        }
                    )
                    IconButton(onClick = { error = null; editing = q }) {
                        Icon(Icons.Default.Edit, "تعديل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { deleting = q }) {
                        Icon(Icons.Default.Delete, "حذف", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        GameQuestionDialog(
            initial = editing,
            busy = busy,
            error = error,
            onDismiss = { if (!busy) { creating = false; editing = null } },
            onConfirm = { dto ->
                busy = true
                error = null
                scope.launch {
                    val r = SupabaseClient.saveGameQuestion(editing?.id, dto)
                    busy = false
                    if (r.ok) {
                        creating = false
                        editing = null
                        reload++
                        onToast("تم حفظ السؤال")
                    } else {
                        error = r.message ?: "تعذر حفظ السؤال"
                    }
                }
            }
        )
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            shape = AppShapes.Card,
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            title = { Text("شكل ملف الأسئلة", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "ملف txt بترميز UTF-8. كل سؤال برقم ونقطة، ثم الخيارات A إلى D، ثم سطر الجواب بحرف الخيار الصحيح. " +
                            "أما سؤال صح أو غلط فبدون خيارات وجوابه صح أو غلط. الشرح بعد الجواب اختياري، والأسطر الفاصلة والعناوين تُتجاهل.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        ImportExample,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(AppShapes.Small)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                            .padding(10.dp)
                    )
                    Text(
                        "قبل الإضافة يظهر لك ملخص بعدد الأسئلة والمكرر وغير الصالح. الحد الأقصى 1000 سؤال، والخيار حتى 160 حرفاً.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("حسناً") } }
        )
    }

    report?.let { rep ->
        AlertDialog(
            onDismissRequest = { if (!importBusy) { report = null; importText = null } },
            shape = AppShapes.Card,
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            title = { Text("استيراد الأسئلة", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تمت قراءة ${rep.found} سؤال من الملف:", style = MaterialTheme.typography.bodyMedium)
                    Text("اختيار من متعدد: ${rep.match}", style = MaterialTheme.typography.bodySmall)
                    Text("صح أم غلط: ${rep.tf}", style = MaterialTheme.typography.bodySmall)
                    if (rep.duplicates > 0) {
                        Text("مكرر (موجود مسبقاً وسيُتخطى): ${rep.duplicates}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (rep.overLimit > 0) {
                        Text(
                            "تجاوز حد 1000 سؤال (لن يُضاف): ${rep.overLimit}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (rep.invalidCount > 0) {
                        Text(
                            "غير صالح (سيُتخطى): ${rep.invalidCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        rep.invalid.forEach {
                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text(
                        "سيُضاف: ${rep.willAdd} سؤال",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ظاهرة للطلاب مباشرة", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = importActive, onCheckedChange = { importActive = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = rep.willAdd > 0 && !importBusy,
                    shape = AppShapes.Small,
                    onClick = {
                        val text = importText
                        if (text != null) {
                            importBusy = true
                            scope.launch {
                                val r = SupabaseClient.importGameQuestions(text, dryRun = false, active = importActive)
                                importBusy = false
                                val done = r.report
                                if (done != null) {
                                    report = null
                                    importText = null
                                    reload++
                                    onToast("تمت إضافة ${done.added} سؤال")
                                } else {
                                    onToast(r.message ?: "تعذر الاستيراد")
                                }
                            }
                        }
                    }
                ) { Text(if (importBusy) "جاري الاستيراد..." else "استيراد ${rep.willAdd} سؤال") }
            },
            dismissButton = {
                TextButton(onClick = { report = null; importText = null }, enabled = !importBusy) { Text("إلغاء") }
            }
        )
    }

    deleting?.let { target ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            shape = AppShapes.Card,
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            title = { Text("حذف السؤال", fontWeight = FontWeight.Bold) },
            text = { Text("سيُحذف هذا السؤال نهائياً من اللعبة.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch {
                        val ok = SupabaseClient.deleteGameQuestion(target.id)
                        if (ok) reload++
                        onToast(if (ok) "تم حذف السؤال" else "تعذر الحذف، تأكد من الاتصال")
                    }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun GameQuestionDialog(
    initial: SupabaseClient.GameQuestionDto?,
    busy: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: (SupabaseClient.GameQuestionDto) -> Unit
) {
    var kind by remember { mutableStateOf(initial?.kind ?: "match") }
    var prompt by remember { mutableStateOf(initial?.prompt ?: "") }
    var why by remember { mutableStateOf(initial?.why ?: "") }
    var active by remember { mutableStateOf(initial?.active ?: true) }
    var options by remember {
        mutableStateOf(
            if (initial != null && initial.kind == "match") List(4) { initial.options.getOrElse(it) { "" } }
            else List(4) { "" }
        )
    }
    var correctMatch by remember { mutableIntStateOf(if (initial != null && initial.kind == "match") initial.correct else 0) }
    var tfTrue by remember { mutableStateOf(if (initial != null && initial.kind == "tf") initial.correct == 0 else true) }

    val filled = options.count { it.isNotBlank() }
    val valid = prompt.trim().length >= 3 &&
        (kind == "tf" || (filled >= 2 && options.getOrElse(correctMatch) { "" }.isNotBlank()))

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = AppShapes.Card,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = { Text(if (initial == null) "إضافة سؤال" else "تعديل السؤال", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نوع السؤال", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassChip(text = "اختيار من متعدد", selected = kind == "match", onClick = { kind = "match" })
                    GlassChip(text = "صح أم غلط", selected = kind == "tf", onClick = { kind = "tf" })
                }

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it.take(300) },
                    label = { Text(if (kind == "tf") "العبارة" else "نص السؤال") },
                    minLines = 2,
                    maxLines = 4,
                    shape = AppShapes.Small,
                    modifier = Modifier.fillMaxWidth()
                )

                if (kind == "match") {
                    Text(
                        "اكتب الخيارات وحدد الدائرة بجانب الإجابة الصحيحة",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    options.forEachIndexed { i, text ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = correctMatch == i, onClick = { correctMatch = i })
                            OutlinedTextField(
                                value = text,
                                onValueChange = { v -> options = options.toMutableList().also { it[i] = v.take(160) } },
                                label = { Text(if (i == 3) "الخيار ${OptionTags[i]} (اختياري)" else "الخيار ${OptionTags[i]}") },
                                singleLine = true,
                                shape = AppShapes.Small,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    Text("هل العبارة صحيحة؟", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        GlassChip(text = "العبارة صح", selected = tfTrue, onClick = { tfTrue = true })
                        GlassChip(text = "العبارة غلط", selected = !tfTrue, onClick = { tfTrue = false })
                    }
                }

                OutlinedTextField(
                    value = why,
                    onValueChange = { why = it.take(300) },
                    label = { Text("شرح الإجابة (اختياري)") },
                    minLines = 2,
                    maxLines = 4,
                    shape = AppShapes.Small,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ظاهر للطلاب", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = active, onCheckedChange = { active = it })
                }

                AnimatedVisibility(
                    visible = !error.isNullOrBlank(),
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Text(error.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = valid && !busy,
                shape = AppShapes.Small,
                onClick = {
                    val dto = if (kind == "tf") {
                        SupabaseClient.GameQuestionDto(
                            id = initial?.id ?: 0L,
                            kind = "tf",
                            prompt = prompt.trim(),
                            options = listOf("صح", "غلط"),
                            correct = if (tfTrue) 0 else 1,
                            why = why.trim(),
                            active = active
                        )
                    } else {
                        SupabaseClient.GameQuestionDto(
                            id = initial?.id ?: 0L,
                            kind = "match",
                            prompt = prompt.trim(),
                            options = options.map { it.trim() },
                            correct = correctMatch,
                            why = why.trim(),
                            active = active
                        )
                    }
                    onConfirm(dto)
                }
            ) { Text(if (busy) "جاري الحفظ..." else "حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}