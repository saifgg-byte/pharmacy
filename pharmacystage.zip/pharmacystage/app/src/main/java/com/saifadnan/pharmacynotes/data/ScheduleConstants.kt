package com.saifadnan.pharmacynotes.data

object ScheduleConstants {

    val GROUPS = listOf("A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4")

    val SUBJECTS = listOf(
        "Organic Chemistry",
        "Physiology",
        "Physical Pharmacy",
        "Arabic",
        "Crimes Of Albath",
        "Computer",
        "Medical Microbiology"
    )

    val SESSION_TYPES = listOf("نظري", "عملي")

    data class DayOption(val calendarDayOfWeek: Int, val arabicName: String)

    val WEEK_DAYS = listOf(
        DayOption(1, "الأحد"),
        DayOption(2, "الإثنين"),
        DayOption(3, "الثلاثاء"),
        DayOption(4, "الأربعاء"),
        DayOption(5, "الخميس"),
        DayOption(6, "الجمعة"),
        DayOption(7, "السبت")
    )

    fun dayName(calendarDayOfWeek: Int): String =
        WEEK_DAYS.firstOrNull { it.calendarDayOfWeek == calendarDayOfWeek }?.arabicName ?: "-"

    const val REMINDER_MINUTES_BEFORE = 5
}
