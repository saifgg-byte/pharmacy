package com.saifadnan.pharmacynotes.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private fun ts(weight: FontWeight, size: Int, line: Int) = TextStyle(
    fontFamily = FontFamily.Default,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = 0.sp
)

val Typography =
  Typography(
    displayLarge = ts(FontWeight.SemiBold, 52, 62),
    displayMedium = ts(FontWeight.SemiBold, 42, 52),
    displaySmall = ts(FontWeight.SemiBold, 34, 44),
    headlineLarge = ts(FontWeight.SemiBold, 32, 42),
    headlineMedium = ts(FontWeight.SemiBold, 28, 38),
    headlineSmall = ts(FontWeight.SemiBold, 24, 32),
    titleLarge = ts(FontWeight.SemiBold, 21, 30),
    titleMedium = ts(FontWeight.SemiBold, 16, 26),
    titleSmall = ts(FontWeight.SemiBold, 14, 22),
    bodyLarge = ts(FontWeight.Normal, 16, 26),
    bodyMedium = ts(FontWeight.Normal, 14, 23),
    bodySmall = ts(FontWeight.Normal, 12, 19),
    labelLarge = ts(FontWeight.Medium, 14, 20),
    labelMedium = ts(FontWeight.Medium, 12, 17),
    labelSmall = ts(FontWeight.Medium, 11, 16)
  )
