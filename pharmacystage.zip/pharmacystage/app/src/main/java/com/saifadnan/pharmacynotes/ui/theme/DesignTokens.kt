package com.saifadnan.pharmacynotes.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object AppShapes {
    val Small = RoundedCornerShape(14.dp)
    val Medium = RoundedCornerShape(20.dp)
    val Card = RoundedCornerShape(28.dp)
    val Pill = RoundedCornerShape(50)
}

object AppElevation {
    val Flat = 0.dp
    val Card = 0.dp
    val Raised = 3.dp
}

@Immutable
data class GlassTokens(
    val isDark: Boolean,
    val fillTop: Color,
    val fillBottom: Color,
    val border: Color,
    val shadowAmbient: Color,
    val shadowSpot: Color,
    val shadowElevation: androidx.compose.ui.unit.Dp,
    val gradient: List<Pair<Float, Color>>,
    val headerSubtitle: Color,
    val navFill: Color,
    val navIndicator: Color
)

val LightGlass = GlassTokens(
    isDark = false,
    fillTop = Color(0xE6FFFFFF),
    fillBottom = Color(0xB8FFFFFF),
    border = Color(0xCCFFFFFF),
    shadowAmbient = Color(0x140E1116),
    shadowSpot = Color(0x240E1116),
    shadowElevation = 10.dp,
    gradient = LightGradient,
    headerSubtitle = Color(0x8C0E1116),
    navFill = Color(0xE0FFFFFF),
    navIndicator = Color(0xFF0E1116)
)

val DarkGlass = GlassTokens(
    isDark = true,
    fillTop = Color(0x1AFFFFFF),
    fillBottom = Color(0x0DFFFFFF),
    border = Color(0x26FFFFFF),
    shadowAmbient = Color.Transparent,
    shadowSpot = Color.Transparent,
    shadowElevation = 0.dp,
    gradient = DarkGradient,
    headerSubtitle = Color(0xFF7C95FF),
    navFill = Color(0x26FFFFFF),
    navIndicator = Color(0xFFF2F5FA)
)

val LocalGlass = staticCompositionLocalOf { LightGlass }

val MaterialTheme.glass: GlassTokens
    @androidx.compose.runtime.Composable
    @androidx.compose.runtime.ReadOnlyComposable
    get() = LocalGlass.current


@Immutable
class PanelTokens(
    val track: Color,
    val chip: Color,
    val chipSelected: Color,
    val cardChip: Color,
    val option: Color,
    val progressTrack: Color,
    val accent: Color
)

@androidx.compose.runtime.Composable
fun panelTokens(): PanelTokens {
    val s = MaterialTheme.colorScheme
    return PanelTokens(
        track = s.onSurface.copy(alpha = 0.06f),
        chip = s.onSurface.copy(alpha = 0.07f),
        chipSelected = s.onSurface.copy(alpha = 0.14f),
        cardChip = s.onSurface.copy(alpha = 0.08f),
        option = s.onSurface.copy(alpha = 0.06f),
        progressTrack = s.onSurface.copy(alpha = 0.10f),
        accent = s.onSurface
    )
}
