package com.saifadnan.pharmacynotes.util

class ScriptSeg(val text: String, val kind: Int) {
    companion object {
        const val NORMAL = 0
        const val SUB = 1
        const val SUP = 2
    }
}

private class Hit(val start: Int, val end: Int, val parts: List<ScriptSeg>)

private val ELEMENTS: Set<String> = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr " +
        "Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu " +
        "Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr"
    ).split(' ').toSet()

private val METALS = setOf("Ca", "Mg", "Zn", "Fe", "Cu", "Al", "Li", "Mn", "Co", "Ni", "Ba", "Sr", "Hg", "Pb", "Sn", "Cr", "Cd", "Ag", "Au", "Pt")
private val SIMPLE_DIATOMIC = setOf("O2", "O3", "N2", "Cl2", "Br2", "F2")
private val BAD_PREFIX = listOf("HIV", "HSV", "HPV", "HHV", "HSP", "NOS", "PON", "CYP", "PI3", "SHP")
private val BAD_REGEX = Regex("^(H\\d+N\\d+|HO\\d+)$")

private val MINUS = '\u2212'

private fun sign(s: String): String = s.replace('-', MINUS).replace('–', MINUS)

private fun seg(t: String, k: Int) = ScriptSeg(t, k)

private fun formulaParts(f: String): List<ScriptSeg> {
    val out = ArrayList<ScriptSeg>()
    val sb = StringBuilder()
    var kind = ScriptSeg.NORMAL
    fun flush() {
        if (sb.isNotEmpty()) { out.add(seg(sb.toString(), kind)); sb.setLength(0) }
    }
    for (ch in f) {
        val k = if (ch.isDigit()) ScriptSeg.SUB else ScriptSeg.NORMAL
        if (k != kind) { flush(); kind = k }
        sb.append(ch)
    }
    flush()
    return out
}

private fun validFormula(tok: String): Boolean {
    if (tok.none { it.isDigit() }) return false
    if (BAD_PREFIX.any { tok.startsWith(it) } || BAD_REGEX.matches(tok)) return false
    if (tok in SIMPLE_DIATOMIC) return true
    val symbols = ArrayList<String>()
    var i = 0
    while (i < tok.length) {
        val c = tok[i]
        when {
            c == '(' || c == ')' || c.isDigit() -> i++
            c.isUpperCase() -> {
                val two = if (i + 1 < tok.length && tok[i + 1].isLowerCase()) tok.substring(i, i + 2) else null
                when {
                    two != null && two in ELEMENTS -> { symbols.add(two); i += 2 }
                    c.toString() in ELEMENTS -> { symbols.add(c.toString()); i++ }
                    else -> return false
                }
            }
            else -> return false
        }
    }
    if (symbols.size < 2) return false
    val hasHO = symbols.any { it == "H" || it == "O" }
    val hasHalogen = symbols.any { it == "Cl" || it == "Br" }
    val hasMetalSalt = symbols.any { it in METALS } && symbols.any { it == "S" || it == "N" || it == "P" || it == "F" || it == "I" }
    return hasHO || hasHalogen || hasMetalSalt
}

// ---------- الأنماط ----------

private val R_SUB_BRACE = Regex("_\\{([^}\\s]{1,12})\\}")
private val R_SUP_BRACE = Regex("\\^\\{([^}\\s]{1,12})\\}")
private val R_SUP_CARET = Regex("(?<=[A-Za-z0-9)\\]])\\^([+\\-\u2212]?\\d{1,3}[+\\-\u2212]?|[+\\-\u2212])")
private val R_SUB_UNDER = Regex("(?<=[A-Za-z0-9)])_(\\d{1,3})(?!\\d)")
private val R_SUB_TILDE = Regex("~(\\d{1,3})~")
private val R_HTML_SUB = Regex("<sub>([^<]{1,12})</sub>", RegexOption.IGNORE_CASE)
private val R_HTML_SUP = Regex("<sup>([^<]{1,12})</sup>", RegexOption.IGNORE_CASE)

private val R_PKA = Regex("(?<![A-Za-z0-9])(pK)(a|b|w)(?![A-Za-z0-9])")
private val R_KCONST = Regex("(?<![A-Za-z0-9])(K)(a|b|w|m|d|i|sp)(?![A-Za-z0-9])")
private val R_IC50 = Regex("(?<![A-Za-z0-9])(IC|EC|LD|ED|TD)(50|90|10)(?![A-Za-z0-9])")
private val R_PK_PARAM = Regex("(?<![A-Za-z0-9])([CTVt])(max|min|ss|av)(?![A-Za-z])")
private val R_HALF_LIFE = Regex("(?<![A-Za-z0-9])(t)(1/2)(?![A-Za-z0-9])")
private val R_AUC = Regex("(?<![A-Za-z])(AUC)(0[-\u2013\u2212](?:t|\u221E|inf|24|12|8))(?![A-Za-z0-9])")
private val R_VD = Regex("(?<![A-Za-z0-9])(V)(d)(?![A-Za-z0-9])")
private val R_GAS = Regex("(?<![A-Za-z0-9])(p|Pa|Sp|Sa|Fi|PA|Pv)(CO2|O2)(?![A-Za-z0-9])")

private val R_ION_POLY = Regex(
    "(?<![A-Za-z0-9])(H2PO4|HPO4|PO4|HSO4|SO4|HCO3|CO3|NO3|NO2|ClO4|MnO4|CrO4|Cr2O7|S2O3|NH4|OH|CN|SCN)(\\d?)([+\\-\u2212])(?![A-Za-z0-9])"
)
private val R_ION_MULTI = Regex("(?<![A-Za-z0-9])(Ca|Mg|Fe|Zn|Cu|Mn|Co|Ni|Ba|Sr|Hg|Pb|Sn|Al|Cr|Cd)([1-4])(\\+)(?![A-Za-z0-9])")
private val R_ION_DOUBLE = Regex("(?<![A-Za-z0-9])(Ca|Mg|Fe|Zn|Cu)(\\+\\+)(?![A-Za-z0-9])")
private val R_ION_POS = Regex("(?<![A-Za-z0-9])(Na|K|Li|Ag|H|Cu)(\\+)(?![A-Za-z0-9])")
private val R_ION_NEG = Regex("(?<![A-Za-z0-9])(Cl|Br)([\\-\u2212])(?![A-Za-z0-9])")

private val R_TIMES10 = Regex("((?:\u00D7|(?<![A-Za-z])[xX])\\s?10)([\\-\u2212\u2013]\\d{1,2})(?![\\d.,A-Za-z])")
private val R_UNIT = Regex("(?<=[\\d/]|\\d\\s)(mm|cm|dm|km|m)([23])(?![A-Za-z0-9])")

private val R_FORMULA = Regex(
    "(?<![A-Za-z_])((?:[A-Z][a-z]?\\d{0,3}|\\((?:[A-Z][a-z]?\\d{0,3})+\\)\\d{0,3})+)(?![A-Za-z0-9_])"
)

private fun overlaps(hits: List<Hit>, s: Int, e: Int): Boolean = hits.any { s < it.end && e > it.start }

private fun scan(
    text: String,
    hits: MutableList<Hit>,
    regex: Regex,
    build: (MatchResult) -> List<ScriptSeg>?
) {
    for (m in regex.findAll(text)) {
        val s = m.range.first
        val e = m.range.last + 1
        if (overlaps(hits, s, e)) continue
        val parts = build(m) ?: continue
        hits.add(Hit(s, e, parts))
    }
}

private fun quickReject(text: String): Boolean {
    // نص بلا أرقام ولا رموز تنسيق لا يحتاج أي معالجة
    for (ch in text) {
        if (ch.isDigit() || ch == '^' || ch == '_' || ch == '+' || ch == '~' || ch == '<' || ch == '-' || ch == '\u2212') return false
    }
    for (p in arrayOf("pK", "Ka", "Kb", "Kw", "Km", "Kd", "Ki", "Cl", "Br")) if (text.contains(p)) return false
    return true
}

fun scriptSegments(text: String): List<ScriptSeg> {
    if (text.length < 2 || quickReject(text)) return listOf(ScriptSeg(text, ScriptSeg.NORMAL))
    val hits = ArrayList<Hit>()

    // 1) صيغ صريحة: _{..} ^{..} ^2 H_2O H~2~O <sub> <sup>
    scan(text, hits, R_HTML_SUB) { listOf(seg(it.groupValues[1], ScriptSeg.SUB)) }
    scan(text, hits, R_HTML_SUP) { listOf(seg(sign(it.groupValues[1]), ScriptSeg.SUP)) }
    scan(text, hits, R_SUB_BRACE) { listOf(seg(it.groupValues[1], ScriptSeg.SUB)) }
    scan(text, hits, R_SUP_BRACE) { listOf(seg(sign(it.groupValues[1]), ScriptSeg.SUP)) }
    scan(text, hits, R_SUP_CARET) { listOf(seg(sign(it.groupValues[1]), ScriptSeg.SUP)) }
    scan(text, hits, R_SUB_UNDER) { listOf(seg(it.groupValues[1], ScriptSeg.SUB)) }
    scan(text, hits, R_SUB_TILDE) { listOf(seg(it.groupValues[1], ScriptSeg.SUB)) }

    // 2) رموز الصيدلة: pKa, IC50, Cmax, t1/2, AUC0-t, Vd, pO2 ...
    scan(text, hits, R_PKA) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_KCONST) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_IC50) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_PK_PARAM) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_HALF_LIFE) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_AUC) { listOf(seg(it.groupValues[1], 0), seg(sign(it.groupValues[2]), ScriptSeg.SUB)) }
    scan(text, hits, R_VD) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUB)) }
    scan(text, hits, R_GAS) { listOf(seg(it.groupValues[1], 0)) + formulaParts(it.groupValues[2]) }

    // 3) الأيونات: Na+ Ca2+ Fe3+ HCO3- SO4 2- Cl-
    scan(text, hits, R_ION_POLY) {
        formulaParts(it.groupValues[1]) + seg(sign(it.groupValues[2] + it.groupValues[3]), ScriptSeg.SUP)
    }
    scan(text, hits, R_ION_MULTI) {
        listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2] + "+", ScriptSeg.SUP))
    }
    scan(text, hits, R_ION_DOUBLE) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUP)) }
    scan(text, hits, R_ION_POS) { listOf(seg(it.groupValues[1], 0), seg("+", ScriptSeg.SUP)) }
    scan(text, hits, R_ION_NEG) { listOf(seg(it.groupValues[1], 0), seg(sign(it.groupValues[2]), ScriptSeg.SUP)) }

    // 4) × 10-3  و  mg/m2  و  cm3
    scan(text, hits, R_TIMES10) { listOf(seg(it.groupValues[1], 0), seg(sign(it.groupValues[2]), ScriptSeg.SUP)) }
    scan(text, hits, R_UNIT) { listOf(seg(it.groupValues[1], 0), seg(it.groupValues[2], ScriptSeg.SUP)) }

    // 5) الصيغ الكيميائية: H2O, CO2, C6H12O6, Ca(OH)2, CuSO4·5H2O
    scan(text, hits, R_FORMULA) { m ->
        val tok = m.groupValues[1]
        if (validFormula(tok)) formulaParts(tok) else null
    }

    if (hits.isEmpty()) return listOf(ScriptSeg(text, ScriptSeg.NORMAL))
    hits.sortBy { it.start }
    val out = ArrayList<ScriptSeg>()
    var pos = 0
    for (h in hits) {
        if (h.start > pos) out.add(ScriptSeg(text.substring(pos, h.start), ScriptSeg.NORMAL))
        out.addAll(h.parts.filter { it.text.isNotEmpty() })
        pos = h.end
    }
    if (pos < text.length) out.add(ScriptSeg(text.substring(pos), ScriptSeg.NORMAL))
    return out
}

private const val SUB_CHARS = "\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089"
private const val SUP_CHARS = "\u2070\u00B9\u00B2\u00B3\u2074\u2075\u2076\u2077\u2078\u2079"

private const val SUB_LETTERS = "aehiklmnoprstux"
private const val SUB_LETTER_CHARS = "\u2090\u2091\u2095\u1D62\u2096\u2097\u2098\u2099\u2092\u209A\u1D63\u209B\u209C\u1D64\u2093"

private fun toUnicodeSub(t: String): String? {
    val sb = StringBuilder()
    for (c in t) {
        when {
            c in '0'..'9' -> sb.append(SUB_CHARS[c - '0'])
            c == '+' -> sb.append('\u208A')
            c == '-' || c == MINUS -> sb.append('\u208B')
            c == '=' -> sb.append('\u208C')
            c == '(' -> sb.append('\u208D')
            c == ')' -> sb.append('\u208E')
            c in SUB_LETTERS -> sb.append(SUB_LETTER_CHARS[SUB_LETTERS.indexOf(c)])
            else -> return null
        }
    }
    return sb.toString()
}

private fun toUnicodeSup(t: String): String? {
    val sb = StringBuilder()
    for (c in t) {
        when {
            c in '0'..'9' -> sb.append(SUP_CHARS[c - '0'])
            c == '+' -> sb.append('\u207A')
            c == '-' || c == MINUS -> sb.append('\u207B')
            else -> return null
        }
    }
    return sb.toString()
}

fun scriptsToUnicode(text: String): String {
    val segs = scriptSegments(text)
    if (segs.size == 1 && segs[0].kind == ScriptSeg.NORMAL) return text
    val sb = StringBuilder()
    for (s in segs) {
        when (s.kind) {
            ScriptSeg.SUB -> sb.append(toUnicodeSub(s.text) ?: s.text)
            ScriptSeg.SUP -> sb.append(toUnicodeSup(s.text) ?: s.text)
            else -> sb.append(s.text)
        }
    }
    return sb.toString()
}
