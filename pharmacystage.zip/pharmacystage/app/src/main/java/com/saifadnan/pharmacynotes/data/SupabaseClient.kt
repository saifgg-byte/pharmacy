package com.saifadnan.pharmacynotes.data

import android.util.Log
import com.saifadnan.pharmacynotes.util.AdminConfig
import com.saifadnan.pharmacynotes.util.JwtUtils
import com.saifadnan.pharmacynotes.util.PdfCompressor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object SupabaseClient {
    private const val TAG = "ServerClient"

    private val base: String get() = ServerConfig.BASE_URL.trimEnd('/')

    private val client = OkHttpClient.Builder()
        .dns(ResilientDns)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private val uploadClient = OkHttpClient.Builder()
        .dns(ResilientDns)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.MINUTES)
        .writeTimeout(30, TimeUnit.MINUTES)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun warmUp() = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url("$base/health").get().build()).execute().close()
        } catch (_: Exception) {
        }
    }

    @Volatile private var accessToken: String? = null
    @Volatile private var currentEmail: String? = null
    @Volatile private var deviceId: String? = null

    fun setDeviceId(id: String?) {
        deviceId = id
    }

    fun setAdminAccessToken(token: String?) {
        accessToken = token
        currentEmail = JwtUtils.email(token)
    }

    fun clearAdminAccessToken() {
        accessToken = null
        currentEmail = null
    }

    fun hasAdminSession(): Boolean = !accessToken.isNullOrBlank()

    fun isMainAdminSession(): Boolean = AdminConfig.isMainAdmin(currentEmail)

    fun isAdminSession(): Boolean = hasAdminSession() && AdminConfig.isAdminRole(JwtUtils.role(accessToken))

    private fun url(vararg segments: String, query: Map<String, String> = emptyMap()): HttpUrl {
        val b = base.toHttpUrl().newBuilder()
        segments.forEach { b.addPathSegment(it) }
        query.forEach { (k, v) -> b.addQueryParameter(k, v) }
        return b.build()
    }

    private fun req(u: HttpUrl): Request.Builder {
        val b = Request.Builder().url(u)
        accessToken?.takeIf { it.isNotBlank() }?.let { b.addHeader("Authorization", "Bearer $it") }
        deviceId?.let { b.addHeader("X-Device-Id", it) }
        b.addHeader("X-Stage", Stages.current.toString())
        return b
    }

    private fun json(block: JSONObject.() -> Unit): RequestBody =
        JSONObject().apply(block).toString().toRequestBody(jsonMediaType)

    private fun noBody(): RequestBody = ByteArray(0).toRequestBody(null)

    private fun str(o: JSONObject, key: String): String =
        if (o.isNull(key)) "" else o.optString(key, "")

    private fun errorOf(code: Int, body: String, fallback: String): String {
        val detail = try { JSONObject(body).opt("detail") } catch (_: Exception) { null }
        return when (detail) {
            is String -> detail
            is JSONArray -> "البيانات المدخلة غير صالحة."
            else -> "$fallback (كود: $code)"
        }
    }

    private const val CONNECT_ERROR = "عذرًا، يتعذر الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت."

    private fun send(request: Request, what: String): Boolean = try {
        client.newCall(request).execute().use { r ->
            if (!r.isSuccessful) Log.w(TAG, "$what failed (${r.code}): ${r.body?.string()}")
            r.isSuccessful
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error: $what", e)
        false
    }

    data class ApiResult(val ok: Boolean, val message: String? = null)

    private fun sendResult(request: Request, what: String): ApiResult = try {
        client.newCall(request).execute().use { r ->
            if (r.isSuccessful) ApiResult(true)
            else {
                val body = r.body?.string() ?: ""
                Log.w(TAG, "$what failed (${r.code}): $body")
                ApiResult(false, errorOf(r.code, body, "تعذر تنفيذ العملية"))
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error: $what", e)
        ApiResult(false, CONNECT_ERROR)
    }

    private class CachedArray(val etag: String, val array: JSONArray)

    private val arrayCache = java.util.concurrent.ConcurrentHashMap<String, CachedArray>()

    private fun getArray(u: HttpUrl, what: String): JSONArray? = try {
        val key = "${Stages.current}|$u"
        val cached = arrayCache[key]
        val builder = req(u).get()
        if (cached != null) builder.header("If-None-Match", cached.etag)
        client.newCall(builder.build()).execute().use { r ->
            when {
                r.code == 304 && cached != null -> cached.array
                !r.isSuccessful -> {
                    Log.w(TAG, "$what failed (${r.code})")
                    null
                }
                else -> {
                    val arr = JSONArray(r.body?.string() ?: "[]")
                    val tag = r.header("ETag")
                    if (tag != null) arrayCache[key] = CachedArray(tag, arr) else arrayCache.remove(key)
                    arr
                }
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error: $what", e)
        null
    }

    suspend fun getSubjects(): List<SubjectEntity>? = withContext(Dispatchers.IO) {
        val arr = getArray(url("subjects"), "getSubjects") ?: return@withContext null
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val name = str(o, "name")
            if (name.isBlank()) null
            else SubjectEntity(
                name = name,
                section = str(o, "section").ifBlank { Section.THEORY },
                semester = if (o.optInt("semester", 1) == 2) 2 else 1,
                isExamPinned = o.optBoolean("isExamPinned", false),
                icon = str(o, "icon")
            )
        }
    }

    suspend fun upsertSubject(subject: SubjectEntity): Boolean = withContext(Dispatchers.IO) {
        send(
            req(url("subjects", subject.name, query = mapOf("section" to subject.section, "semester" to subject.semester.toString()))).put(json {
                put("isExamPinned", subject.isExamPinned)
                put("addedAt", subject.addedAt)
            }).build(), "upsertSubject"
        )
    }

    suspend fun updateSubjectExamPinned(subjectName: String, section: String, semester: Int, isPinned: Boolean): Boolean =
        withContext(Dispatchers.IO) {

            send(
                req(url("subjects", subjectName, query = mapOf("section" to section, "semester" to semester.toString()))).put(json {
                    put("isExamPinned", isPinned)
                    put("addedAt", 0)
                }).build(), "updateSubjectExamPinned"
            )
        }

    suspend fun deleteSubject(subjectName: String, section: String, semester: Int): Boolean = withContext(Dispatchers.IO) {
        send(req(url("subjects", subjectName, query = mapOf("section" to section, "semester" to semester.toString()))).delete().build(), "deleteSubject")
    }

    suspend fun renameSubject(oldName: String, newName: String, section: String, semester: Int): ApiResult =
        withContext(Dispatchers.IO) {
            sendResult(
                req(url("subjects", "rename")).post(json {
                    put("oldName", oldName)
                    put("newName", newName)
                    put("section", section)
                    put("semester", semester)
                }).build(), "renameSubject"
            )
        }

    suspend fun setSubjectIcon(name: String, section: String, semester: Int, icon: String): ApiResult =
        withContext(Dispatchers.IO) {
            sendResult(
                req(url("subjects", "icon")).post(json {
                    put("name", name)
                    put("section", section)
                    put("semester", semester)
                    put("icon", icon)
                }).build(), "setSubjectIcon"
            )
        }

    suspend fun getExams(): List<ExamEntity>? = withContext(Dispatchers.IO) {
        val arr = getArray(url("exams"), "getExams") ?: return@withContext null
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamEntity(
                id = str(o, "id"),
                subject = str(o, "subject"),
                examDate = str(o, "examDate"),
                startHour = o.optInt("startHour", 9),
                startMinute = o.optInt("startMinute", 0),
                durationMin = o.optInt("durationMin", 60),
                examType = str(o, "examType").ifBlank { ExamTypes.FINAL },
                groupName = str(o, "groupName"),
                hall = str(o, "hall"),
                notes = str(o, "notes"),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    }

    suspend fun upsertExam(e: ExamEntity): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("exams", e.id)).put(json {
                put("subject", e.subject)
                put("examDate", e.examDate)
                put("startHour", e.startHour)
                put("startMinute", e.startMinute)
                put("durationMin", e.durationMin)
                put("examType", e.examType)
                put("groupName", e.groupName)
                put("hall", e.hall)
                put("notes", e.notes)
                put("updatedAt", e.updatedAt)
            }).build(), "upsertExam"
        )
    }

    suspend fun deleteExam(id: String): Boolean = withContext(Dispatchers.IO) {
        send(req(url("exams", id)).delete().build(), "deleteExam")
    }

    suspend fun deleteAllSubjects(): Boolean = withContext(Dispatchers.IO) {
        send(req(url("subjects")).delete().build(), "deleteAllSubjects")
    }

    suspend fun getSchedule(): List<ScheduleEntity>? = withContext(Dispatchers.IO) {
        val arr = getArray(url("schedule"), "getSchedule") ?: return@withContext null
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ScheduleEntity(
                id = str(o, "id"),
                groupName = str(o, "groupName"),
                subject = str(o, "subject"),
                sessionType = str(o, "sessionType"),
                dayOfWeek = o.optInt("dayOfWeek"),
                startHour = o.optInt("startHour"),
                startMinute = o.optInt("startMinute"),
                endHour = o.optInt("endHour"),
                endMinute = o.optInt("endMinute"),
                room = str(o, "room"),
                doctorName = str(o, "doctorName"),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    }

    suspend fun upsertScheduleEntry(entry: ScheduleEntity): Boolean = withContext(Dispatchers.IO) {
        send(
            req(url("schedule", entry.id)).put(json {
                put("groupName", entry.groupName)
                put("subject", entry.subject)
                put("sessionType", entry.sessionType)
                put("dayOfWeek", entry.dayOfWeek)
                put("startHour", entry.startHour)
                put("startMinute", entry.startMinute)
                put("endHour", entry.endHour)
                put("endMinute", entry.endMinute)
                put("room", entry.room)
                put("doctorName", entry.doctorName)
                put("updatedAt", entry.updatedAt)
            }).build(), "upsertScheduleEntry"
        )
    }

    suspend fun deleteScheduleEntry(id: String): Boolean = withContext(Dispatchers.IO) {
        send(req(url("schedule", id)).delete().build(), "deleteScheduleEntry")
    }

    suspend fun deleteAllSchedule(): Boolean = withContext(Dispatchers.IO) {
        send(req(url("schedule")).delete().build(), "deleteAllSchedule")
    }

    suspend fun getLectures(): List<LectureEntity>? = withContext(Dispatchers.IO) {
        val arr = getArray(url("lectures"), "getLectures") ?: return@withContext null
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            LectureEntity(
                id = o.getLong("id"),
                title = str(o, "title"),
                subject = str(o, "subject"),
                stage = o.optInt("stage", 2),
                stageName = str(o, "stageName").ifBlank { "المرحلة الثانية" },
                semester = o.optInt("semester", 1),
                doctorName = str(o, "doctorName"),
                fileUrl = str(o, "fileUrl"),
                fileSize = str(o, "fileSize"),
                pageCount = o.optInt("pageCount", 0),
                summary = str(o, "summary"),
                examTips = str(o, "examTips"),
                isPinned = o.optBoolean("isPinned", false),
                downloadCount = o.optInt("downloadCount", 0),
                viewCount = o.optInt("viewCount", 0),
                uploadTimestamp = o.optLong("uploadTimestamp", System.currentTimeMillis()),
                section = str(o, "section").ifBlank { Section.THEORY },
                category = str(o, "category").ifBlank { Category.OFFICIAL },
                worksheetUrl = str(o, "worksheetUrl"),
                worksheetType = str(o, "worksheetType"),
                youtubeUrl = str(o, "youtubeUrl")
            )
        }
    }

    suspend fun upsertLecture(lecture: LectureEntity): Boolean = upsertLectureResult(lecture).ok

    suspend fun upsertLectureResult(lecture: LectureEntity): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("lectures", lecture.id.toString())).put(json {
                put("title", lecture.title)
                put("subject", lecture.subject)
                put("stage", lecture.stage)
                put("stageName", lecture.stageName)
                put("semester", lecture.semester)
                put("doctorName", lecture.doctorName)
                put("fileUrl", lecture.fileUrl)
                put("fileSize", lecture.fileSize)
                put("pageCount", lecture.pageCount)
                put("summary", lecture.summary)
                put("examTips", lecture.examTips)
                put("isPinned", lecture.isPinned)
                put("downloadCount", lecture.downloadCount)
                put("viewCount", lecture.viewCount)
                put("uploadTimestamp", lecture.uploadTimestamp)
                put("section", lecture.section)
                put("category", lecture.category)
                put("worksheetUrl", lecture.worksheetUrl)
                put("worksheetType", lecture.worksheetType)
                put("youtubeUrl", lecture.youtubeUrl)
            }).build(), "upsertLecture"
        )
    }

    @Suppress("UNUSED_PARAMETER")
    suspend fun deleteLecture(lectureId: Long, title: String? = null, fileUrl: String? = null): Boolean =
        withContext(Dispatchers.IO) {
            send(req(url("lectures", lectureId.toString())).delete().build(), "deleteLecture")
        }

    suspend fun deleteLecturesBySubject(subjectName: String, section: String, semester: Int): Boolean = withContext(Dispatchers.IO) {
        send(
            req(url("lectures", query = mapOf("subject" to subjectName, "section" to section, "semester" to semester.toString()))).delete().build(),
            "deleteLecturesBySubject"
        )
    }

    suspend fun deleteAllLectures(): Boolean = withContext(Dispatchers.IO) {
        send(req(url("lectures")).delete().build(), "deleteAllLectures")
    }

    suspend fun getNotifications(): List<BroadcastNotificationEntity>? = withContext(Dispatchers.IO) {
        val arr = getArray(url("broadcasts"), "getNotifications") ?: return@withContext null
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val title = str(o, "title")
            if (title.isBlank()) null
            else BroadcastNotificationEntity(
                id = o.getLong("id"),
                title = title,
                message = str(o, "message"),
                lectureId = if (o.isNull("lectureId")) null else o.optLong("lectureId"),
                stage = if (o.isNull("stage")) null else o.optInt("stage"),
                timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                isRead = false,
                type = str(o, "type").ifBlank { "ANNOUNCEMENT" },
                url = str(o, "url").takeIf { it.isNotBlank() },
                imageUrl = str(o, "imageUrl").takeIf { it.isNotBlank() },
                isPinned = o.optBoolean("isPinned", false),
                style = str(o, "style")
            )
        }
    }

    suspend fun upsertNotification(notification: BroadcastNotificationEntity): Boolean = withContext(Dispatchers.IO) {
        send(
            req(url("broadcasts", notification.id.toString())).put(json {
                put("title", notification.title)
                put("message", notification.message)
                put("lectureId", notification.lectureId ?: JSONObject.NULL)
                put("stage", notification.stage ?: JSONObject.NULL)
                put("timestamp", notification.timestamp)
                put("type", notification.type)
                put("url", notification.url ?: JSONObject.NULL)
                put("imageUrl", notification.imageUrl ?: JSONObject.NULL)
                put("isPinned", notification.isPinned)
                put("style", notification.style)
            }).build(), "upsertNotification"
        )
    }

    suspend fun toggleNotificationPinned(id: Long, isPinned: Boolean): Boolean = withContext(Dispatchers.IO) {
        send(
            req(url("broadcasts", id.toString(), "pin")).patch(json { put("isPinned", isPinned) }).build(),
            "toggleNotificationPinned"
        )
    }

    suspend fun deleteAllNotifications(): Boolean = withContext(Dispatchers.IO) {
        send(req(url("broadcasts")).delete().build(), "deleteAllNotifications")
    }

    data class SupabaseAuthResult(
        val isSuccess: Boolean,
        val accessToken: String? = null,
        val userId: String? = null,
        val email: String? = null,
        val errorMessage: String? = null,
        val refreshToken: String? = null,
        val expiresAtMs: Long = 0L,
        val isAuthRejected: Boolean = false,

        val user: UserEntity? = null,
        val stage: Int = 0
    )

    private fun parseUser(o: JSONObject): UserEntity {
        val email = str(o, "email")

        val isAdmin = AdminConfig.isAdminEmail(email) || AdminConfig.isAdminRole(str(o, "role"))
        return UserEntity(
            email = email,
            fullName = str(o, "fullName"),
            studentId = str(o, "studentId"),
            role = if (isAdmin) "ADMIN" else "STUDENT",
            registrationDate = o.optLong("registrationDate", System.currentTimeMillis()),
            isApproved = if (isAdmin) true else o.optBoolean("isApproved", true),
            authUid = str(o, "authUid"),
            idCardUrl = str(o, "idCardUrl"),
            groupName = str(o, "groupName")
        )
    }

    private fun parseAuth(body: String): SupabaseAuthResult {
        val o = JSONObject(body)
        val token = o.optString("accessToken")
        val user = o.optJSONObject("user")?.let { parseUser(it) }
        val expires = o.optLong("expiresAt", 0L).takeIf { it > 0 } ?: JwtUtils.expiryMs(token)
        return SupabaseAuthResult(
            isSuccess = token.isNotBlank(),
            accessToken = token,
            userId = user?.authUid,
            email = user?.email,
            refreshToken = o.optString("refreshToken").takeIf { it.isNotBlank() },
            expiresAtMs = expires,
            user = user,
            stage = o.optInt("stage", 0)
        )
    }

    private fun authCall(path: String, body: RequestBody, failMsg: String, rejectOnAnyError: Boolean): SupabaseAuthResult =
        try {
            val request = Request.Builder().url(url("auth", path)).post(body)
                .apply { deviceId?.let { header("X-Device-Id", it) } }
                .header("X-Stage", Stages.current.toString())
                .build()
            client.newCall(request).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) parseAuth(s)
                else SupabaseAuthResult(
                    isSuccess = false,
                    errorMessage = errorOf(r.code, s, failMsg),
                    isAuthRejected = rejectOnAnyError || r.code == 400 || r.code == 401 || r.code == 403
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "auth/$path failed", e)
            SupabaseAuthResult(isSuccess = false, errorMessage = CONNECT_ERROR)
        }

    suspend fun signUpWithSupabase(
        email: String,
        password: String,
        fullName: String,
        studentId: String,
        groupName: String = ""
    ): SupabaseAuthResult = withContext(Dispatchers.IO) {
        authCall("signup", json {
            put("email", email.trim().lowercase())
            put("password", password)
            put("fullName", fullName.trim())
            put("studentId", studentId.trim())
            put("groupName", groupName.trim())
        }, "تعذر إنشاء الحساب", false)
    }

    suspend fun signInWithSupabase(identifier: String, password: String, groupName: String = ""): SupabaseAuthResult =
        withContext(Dispatchers.IO) {
            authCall("login", json {
                put("email", identifier.trim())
                put("password", password)
                if (groupName.isNotBlank()) put("groupName", groupName.trim())
            }, "خطأ في تسجيل الدخول", true)
        }

    suspend fun signInAuto(identifier: String, password: String): SupabaseAuthResult =
        withContext(Dispatchers.IO) {
            authCall("login-auto", json {
                put("email", identifier.trim())
                put("password", password)
            }, "خطأ في تسجيل الدخول", true)
        }

    suspend fun refreshSession(refreshToken: String): SupabaseAuthResult = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url("auth", "refresh"))
                .header("X-Stage", Stages.current.toString())
                .post(json { put("refreshToken", refreshToken) }).build()
            client.newCall(request).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) parseAuth(s)
                else SupabaseAuthResult(
                    isSuccess = false, errorMessage = "refresh failed (${r.code})",
                    isAuthRejected = r.code == 400 || r.code == 401 || r.code == 403
                )
            }
        } catch (e: Exception) {
            SupabaseAuthResult(isSuccess = false, errorMessage = "network", isAuthRejected = false)
        }
    }

    suspend fun getStages(): List<StageInfo>? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url("stages")).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) {
                    null
                } else {
                    val arr = JSONArray(r.body?.string() ?: "[]")
                    val list = (0 until arr.length()).mapNotNull { i ->
                        val id = arr.getJSONObject(i).optInt("id", 0)
                        if (Stages.isValid(id)) StageInfo(id, Stages.label(id)) else null
                    }
                    if (list.isEmpty()) null else list
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "getStages failed", e)
            null
        }
    }

    suspend fun switchStage(stage: Int): SupabaseAuthResult = withContext(Dispatchers.IO) {
        try {
            val request = req(url("auth", "switch-stage")).post(json { put("stage", stage) }).build()
            client.newCall(request).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) parseAuth(s)
                else SupabaseAuthResult(isSuccess = false, errorMessage = errorOf(r.code, s, "تعذر تبديل المرحلة"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "switchStage failed", e)
            SupabaseAuthResult(isSuccess = false, errorMessage = CONNECT_ERROR)
        }
    }

    suspend fun updateProfile(
        fullName: String?,
        email: String?,
        studentId: String?,
        stage: Int?,
        currentPassword: String,
        newPassword: String?
    ): SupabaseAuthResult = withContext(Dispatchers.IO) {
        try {
            val request = req(url("auth", "update-profile")).post(json {
                fullName?.let { put("fullName", it.trim()) }
                email?.let { put("email", it.trim().lowercase()) }
                studentId?.let { put("studentId", it.trim()) }
                stage?.let { put("stage", it) }
                put("currentPassword", currentPassword)
                newPassword?.takeIf { it.isNotEmpty() }?.let { put("newPassword", it) }
            }).build()
            client.newCall(request).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) parseAuth(s)
                else SupabaseAuthResult(isSuccess = false, errorMessage = errorOf(r.code, s, "تعذر حفظ التعديلات"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "updateProfile failed", e)
            SupabaseAuthResult(isSuccess = false, errorMessage = CONNECT_ERROR)
        }
    }

    suspend fun studentLogin(fullName: String, groupName: String): SupabaseAuthResult =
        withContext(Dispatchers.IO) {
            authCall("student", json { put("fullName", fullName.trim()); put("groupName", groupName.trim()) },
                "تعذر تسجيل الدخول", false)
        }

    data class AiAnswer(
        val ok: Boolean,
        val text: String = "",
        val remaining: Int = -1,
        val message: String? = null,
        val qid: String = "",
        val provider: String = "",
        val providerName: String = "",
        val switchedFrom: String = "",
        val retryAfter: Int = 0
    )

    data class AiProvider(val id: String, val name: String, val hint: String, val state: String, val retryIn: Int)

    data class AiStatus(val enabled: Boolean, val remaining: Int, val providers: List<AiProvider>)

    data class AiCacheStatus(val actions: Set<String>, val questions: List<Boolean>)

    data class AiChatInfo(
        val id: String,
        val head: String,
        val preview: String,
        val count: Int,
        val created: Long,
        val updated: Long
    )

    data class AiChatItem(
        val role: String,
        val text: String,
        val page: Int = 0,
        val action: String = "",
        val qid: String = "",
        val prov: String = ""
    )

    data class WeeklySchedule(val imageUrl: String, val title: String, val updatedAt: Long, val mode: String = "WEEKLY")

    data class LibraryLoan(val id: Long, val title: String, val author: String, val dueAt: Long, val overdue: Boolean)

    data class LibraryCard(
        val name: String,
        val email: String,
        val group: String,
        val studentId: String,
        val code: String,
        val payload: String,
        val loans: List<LibraryLoan>
    )

    private val aiClient by lazy { client.newBuilder().readTimeout(100, TimeUnit.SECONDS).build() }

    data class StatRow(val label: String, val sub: String, val n: Int)

    data class AdminStats(
        val days: Int,
        val totalAi: Int,
        val topViewed: List<StatRow>,
        val topAiLectures: List<StatRow>,
        val topAiPages: List<StatRow>,
        val topQuestions: List<StatRow>,
        val actions: List<StatRow>
    )

    data class GameQuestionDto(
        val id: Long,
        val kind: String,
        val prompt: String,
        val options: List<String>,
        val correct: Int,
        val why: String,
        val active: Boolean = true
    )

    private fun parseGameQuestions(body: String): List<GameQuestionDto> {
        val arr = JSONObject(body).optJSONArray("items") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val opts = o.optJSONArray("options") ?: return@mapNotNull null
            GameQuestionDto(
                id = o.optLong("id"),
                kind = o.optString("kind"),
                prompt = o.optString("prompt"),
                options = (0 until opts.length()).map { opts.optString(it) },
                correct = o.optInt("correct"),
                why = o.optString("why"),
                active = o.optBoolean("active", true)
            )
        }
    }

    private fun fetchGameQuestions(u: HttpUrl): List<GameQuestionDto>? = try {
        client.newCall(req(u).get().build()).execute().use { r ->
            if (!r.isSuccessful) {
                Log.w(TAG, "game questions failed (${r.code})")
                null
            } else {
                parseGameQuestions(r.body?.string() ?: "{}")
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error: game questions", e)
        null
    }

    suspend fun getGameQuestions(): List<GameQuestionDto>? = withContext(Dispatchers.IO) {
        fetchGameQuestions(url("game", "questions"))
    }

    suspend fun getAdminGameQuestions(): List<GameQuestionDto>? = withContext(Dispatchers.IO) {
        fetchGameQuestions(url("admin", "game", "questions"))
    }

    suspend fun saveGameQuestion(id: Long?, q: GameQuestionDto): ApiResult = withContext(Dispatchers.IO) {
        val body = json {
            put("kind", q.kind)
            put("prompt", q.prompt)
            put("options", JSONArray(q.options))
            put("correct", q.correct)
            put("why", q.why)
            put("active", q.active)
        }
        val builder = if (id == null) req(url("admin", "game", "questions")) else req(url("admin", "game", "questions", id.toString()))
        sendResult((if (id == null) builder.post(body) else builder.put(body)).build(), "saveGameQuestion")
    }

    suspend fun deleteGameQuestion(id: Long): Boolean = withContext(Dispatchers.IO) {
        send(req(url("admin", "game", "questions", id.toString())).delete().build(), "deleteGameQuestion")
    }

    data class GameImportReport(
        val found: Int,
        val match: Int,
        val tf: Int,
        val duplicates: Int,
        val invalidCount: Int,
        val invalid: List<String>,
        val overLimit: Int,
        val willAdd: Int,
        val added: Int
    )

    data class GameImportResult(val report: GameImportReport? = null, val message: String? = null)

    suspend fun importGameQuestions(text: String, dryRun: Boolean, active: Boolean): GameImportResult =
        withContext(Dispatchers.IO) {
            val body = json {
                put("text", text)
                put("dryRun", dryRun)
                put("active", active)
            }
            try {
                client.newCall(req(url("admin", "game", "questions", "import")).post(body).build()).execute().use { r ->
                    val raw = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        Log.w(TAG, "importGameQuestions failed (${r.code}): $raw")
                        GameImportResult(message = errorOf(r.code, raw, "تعذر قراءة الملف"))
                    } else {
                        val o = JSONObject(raw)
                        val inv = o.optJSONArray("invalid")
                        GameImportResult(
                            report = GameImportReport(
                                found = o.optInt("found"),
                                match = o.optInt("match"),
                                tf = o.optInt("tf"),
                                duplicates = o.optInt("duplicates"),
                                invalidCount = o.optInt("invalidCount"),
                                invalid = if (inv == null) emptyList() else (0 until inv.length()).map { inv.optString(it) },
                                overLimit = o.optInt("overLimit"),
                                willAdd = o.optInt("willAdd"),
                                added = o.optInt("added")
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error: importGameQuestions", e)
                GameImportResult(message = CONNECT_ERROR)
            }
        }

    suspend fun trackLecture(id: Long, kind: String) {
        if (id <= 0) return
        withContext(Dispatchers.IO) {
            try {
                client.newCall(req(url("lectures", id.toString(), kind)).post(noBody()).build()).execute().close()
            } catch (e: Exception) {
                Log.w(TAG, "track $kind failed", e)
            }
        }
    }

    suspend fun getAdminStats(days: Int): AdminStats? = withContext(Dispatchers.IO) {
        try {
            val request = req(url("admin", "stats", query = mapOf("days" to days.toString()))).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) {
                    Log.w(TAG, "admin stats failed (${r.code})")
                    return@use null
                }
                val o = JSONObject(r.body?.string() ?: "{}")
                fun rows(key: String, label: (JSONObject) -> String, sub: (JSONObject) -> String): List<StatRow> {
                    val a = o.optJSONArray(key) ?: return emptyList()
                    return (0 until a.length()).map { i ->
                        val x = a.getJSONObject(i)
                        StatRow(label(x), sub(x), x.optInt("n"))
                    }
                }
                AdminStats(
                    days = o.optInt("days", days),
                    totalAi = o.optInt("totalAi", 0),
                    topViewed = rows("topViewed", { it.optString("title") }, { it.optString("subject") }),
                    topAiLectures = rows("topAiLectures", { it.optString("title") }, { it.optString("subject") }),
                    topAiPages = rows(
                        "topAiPages",
                        { it.optString("title") },
                        { "${it.optString("subject")} · صفحة ${it.optInt("page")}" }
                    ),
                    topQuestions = rows("topQuestions", { it.optString("question") }, { "" }),
                    actions = rows("actions", { it.optString("action") }, { "" })
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: admin stats", e)
            null
        }
    }

    class ChemDepict(val ok: Boolean, val formula: String, val mw: String, val png: ByteArray?, val reason: String?)

    suspend fun depictChem(smiles: String): ChemDepict = withContext(Dispatchers.IO) {
        try {
            val request = req(url("chem", "depict", query = mapOf("smiles" to smiles))).get().build()
            client.newCall(request).execute().use { r ->
                val body = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    ChemDepict(false, "", "", null, "http")
                } else {
                    val o = JSONObject(body)
                    if (o.optBoolean("ok", false)) {
                        val b64 = o.optString("png", "")
                        ChemDepict(
                            true,
                            o.optString("formula", ""),
                            if (o.has("mw")) String.format(java.util.Locale.US, "%.2f", o.optDouble("mw")) else "",
                            if (b64.isNotEmpty()) android.util.Base64.decode(b64, android.util.Base64.DEFAULT) else null,
                            null
                        )
                    } else {
                        ChemDepict(false, "", "", null, o.optString("reason", "error"))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: chem depict", e)
            ChemDepict(false, "", "", null, "network")
        }
    }

    suspend fun vizFetch(path: String, body: String): String = withContext(Dispatchers.IO) {
        try {
            val request = req(url("viz", path)).post(body.toRequestBody(jsonMediaType)).build()
            client.newCall(request).execute().use { r ->
                val text = r.body?.string() ?: ""
                if (r.isSuccessful && text.isNotBlank()) text else "{\"ok\":false,\"reason\":\"http\"}"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: viz fetch", e)
            "{\"ok\":false,\"reason\":\"network\"}"
        }
    }

    class PageWord(val l: Float, val t: Float, val r: Float, val b: Float, val text: String, val line: Int)
    class PageWords(val available: Boolean, val words: List<PageWord>, val failed: Boolean = false)

    suspend fun getPageWords(id: Long, page: Int): PageWords = withContext(Dispatchers.IO) {
        try {
            val request = req(url("lectures", id.toString(), "words", query = mapOf("page" to page.toString()))).get().build()
            client.newCall(request).execute().use { r ->
                val body = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    PageWords(false, emptyList(), failed = true)
                } else {
                    val o = JSONObject(body)
                    val a = o.optJSONArray("words")
                    val words = if (a == null) emptyList() else (0 until a.length()).mapNotNull { i ->
                        val x = a.optJSONArray(i) ?: return@mapNotNull null
                        if (x.length() < 6) return@mapNotNull null
                        PageWord(
                            x.optDouble(0).toFloat(), x.optDouble(1).toFloat(),
                            x.optDouble(2).toFloat(), x.optDouble(3).toFloat(),
                            x.optString(4), x.optInt(5)
                        )
                    }
                    PageWords(o.optBoolean("available", true), words)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: page words", e)
            PageWords(false, emptyList(), failed = true)
        }
    }

    data class SearchHit(val page: Int, val count: Int, val snippet: String)
    data class LectureSearch(val available: Boolean, val hits: List<SearchHit>, val error: String? = null)

    suspend fun searchLecture(id: Long, q: String): LectureSearch = withContext(Dispatchers.IO) {
        try {
            val request = req(url("lectures", id.toString(), "search", query = mapOf("q" to q))).get().build()
            client.newCall(request).execute().use { r ->
                val body = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    LectureSearch(false, emptyList(), errorOf(r.code, body, "تعذر البحث"))
                } else {
                    val o = JSONObject(body)
                    val a = o.optJSONArray("results")
                    val hits = if (a == null) emptyList() else (0 until a.length()).map { i ->
                        val x = a.getJSONObject(i)
                        SearchHit(x.optInt("page"), x.optInt("count", 1), x.optString("snippet"))
                    }
                    LectureSearch(o.optBoolean("available", true), hits)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: lecture search", e)
            LectureSearch(false, emptyList(), CONNECT_ERROR)
        }
    }

    suspend fun askSlideAi(
        action: String,
        question: String,
        jpeg: ByteArray?,
        page: Int,
        subject: String,
        title: String,
        fileUrl: String,
        history: List<Pair<String, String>>,
        pages: List<Int> = emptyList(),
        allPages: Boolean = false,
        extraImages: List<ByteArray> = emptyList(),
        provider: String = "auto"
    ): AiAnswer = withContext(Dispatchers.IO) {
        try {
            val body = json {
                put("action", action)
                put("question", question)
                put(
                    "imageBase64",
                    if (jpeg != null) android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP) else ""
                )
                put("pages", JSONArray().apply { pages.forEach { put(it) } })
                put("allPages", allPages)
                put("images", JSONArray().apply {
                    extraImages.forEach { put(android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP)) }
                })
                put("page", page)
                put("subject", subject)
                put("title", title)
                put("fileUrl", fileUrl)
                put("provider", provider)
                put("history", JSONArray().apply {
                    history.forEach { (role, text) ->
                        put(JSONObject().put("role", role).put("text", text))
                    }
                })
            }
            val request = req(url("ai", "slide")).post(body).build()
            aiClient.newCall(request).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) {
                    val o = JSONObject(s)
                    AiAnswer(
                        true, o.optString("answer", ""), o.optInt("remaining", -1), qid = o.optString("qid", ""),
                        provider = o.optString("provider", ""),
                        providerName = o.optString("providerName", ""),
                        switchedFrom = o.optString("switchedFrom", "")
                    )
                } else {
                    Log.w(TAG, "ai slide failed (${r.code}): $s")
                    AiAnswer(
                        false,
                        message = errorOf(r.code, s, "تعذر الحصول على إجابة"),
                        retryAfter = (r.header("Retry-After")?.toIntOrNull() ?: 0).coerceIn(0, 90)
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: ai slide", e)
            AiAnswer(false, message = CONNECT_ERROR)
        }
    }

    suspend fun slideAiSuggestions(fileUrl: String, page: Int): List<String> = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "slide-suggestions", query = mapOf("fileUrl" to fileUrl, "page" to page.toString()))).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return@use emptyList<String>()
                val a = JSONObject(r.body?.string() ?: "").optJSONArray("items") ?: return@use emptyList<String>()
                (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
            }
        } catch (e: Exception) {
            Log.w(TAG, "slide ai suggestions failed", e)
            emptyList()
        }
    }

    suspend fun aiStatus(): AiStatus? = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "status")).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val o = JSONObject(r.body?.string() ?: return@use null)
                val a = o.optJSONArray("providers")
                val list = (0 until (a?.length() ?: 0)).mapNotNull { i ->
                    val p = a!!.optJSONObject(i) ?: return@mapNotNull null
                    AiProvider(
                        id = p.optString("id"),
                        name = p.optString("name"),
                        hint = p.optString("hint"),
                        state = p.optString("state", "ready"),
                        retryIn = p.optInt("retryIn", 0)
                    )
                }
                AiStatus(o.optBoolean("enabled", true), o.optInt("remaining", -1), list)
            }
        } catch (e: Exception) {
            Log.w(TAG, "ai status failed", e)
            null
        }
    }

    suspend fun aiCacheStatus(fileUrl: String, page: Int, questions: List<String>): AiCacheStatus? = withContext(Dispatchers.IO) {
        try {
            val body = json {
                put("fileUrl", fileUrl)
                put("page", page)
                put("questions", JSONArray(questions))
            }
            val request = req(url("ai", "cache-status")).post(body).build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val o = JSONObject(r.body?.string() ?: return@use null)
                val a = o.optJSONArray("actions")
                val q = o.optJSONArray("questions")
                AiCacheStatus(
                    actions = (0 until (a?.length() ?: 0)).map { a!!.optString(it) }.toSet(),
                    questions = (0 until (q?.length() ?: 0)).map { q!!.optBoolean(it) }
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "ai cache status failed", e)
            null
        }
    }

    suspend fun getWeeklySchedule(): WeeklySchedule? = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("weekly-schedule")).get().build()).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val o = JSONObject(r.body?.string() ?: return@use null)
                WeeklySchedule(o.optString("imageUrl", ""), o.optString("title", ""), o.optLong("updatedAt", 0L), o.optString("mode", "WEEKLY"))
            }
        } catch (e: Exception) {
            Log.w(TAG, "get weekly schedule failed", e)
            null
        }
    }

    suspend fun setWeeklySchedule(imageUrl: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = req(url("weekly-schedule")).put(json { put("imageUrl", imageUrl) }).build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "set weekly schedule failed", e)
            false
        }
    }

    suspend fun setWeeklyScheduleMode(mode: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = req(url("weekly-schedule", "mode")).put(json { put("mode", mode) }).build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "set weekly schedule mode failed", e)
            false
        }
    }

    suspend fun getLibraryCard(): LibraryCard? = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("library-api", "my-card")).get().build()).execute().use { r ->
                if (!r.isSuccessful) return@use null
                parseLibraryCard(r.body?.string() ?: return@use null)
            }
        } catch (e: Exception) {
            Log.w(TAG, "get library card failed", e)
            null
        }
    }

    fun parseLibraryCard(body: String): LibraryCard? = try {
        val o = JSONObject(body)
        val arr = o.optJSONArray("loans") ?: JSONArray()
        val loans = (0 until arr.length()).map { i ->
            val l = arr.getJSONObject(i)
            LibraryLoan(l.optLong("id"), l.optString("title"), l.optString("author"), l.optLong("dueAt"), l.optBoolean("overdue"))
        }
        LibraryCard(
            o.optString("name"), o.optString("email"), o.optString("group"), o.optString("studentId"),
            o.optString("code"), o.optString("payload"), loans
        )
    } catch (e: Exception) {
        null
    }

    suspend fun deleteWeeklySchedule(): Boolean = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("weekly-schedule")).delete().build()).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "delete weekly schedule failed", e)
            false
        }
    }

    suspend fun aiChatList(fileUrl: String): List<AiChatInfo>? = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "chats", query = mapOf("fileUrl" to fileUrl))).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val a = JSONObject(r.body?.string() ?: return@use null).optJSONArray("items") ?: return@use emptyList()
                (0 until a.length()).mapNotNull { i ->
                    val o = a.optJSONObject(i) ?: return@mapNotNull null
                    val id = o.optString("id")
                    if (id.isBlank()) return@mapNotNull null
                    AiChatInfo(
                        id = id,
                        head = o.optString("head"),
                        preview = o.optString("preview"),
                        count = o.optInt("count"),
                        created = o.optLong("created") * 1000L,
                        updated = o.optLong("updated") * 1000L
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ai chat list failed", e)
            null
        }
    }

    suspend fun aiChatLoad(chatId: String): List<AiChatItem>? = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "chats", chatId)).get().build()
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val a = JSONObject(r.body?.string() ?: return@use null).optJSONArray("items") ?: return@use emptyList()
                (0 until a.length()).mapNotNull { i ->
                    val o = a.optJSONObject(i) ?: return@mapNotNull null
                    AiChatItem(
                        role = o.optString("role"),
                        text = o.optString("text"),
                        page = o.optInt("page"),
                        action = o.optString("action"),
                        qid = o.optString("qid"),
                        prov = o.optString("prov")
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ai chat load failed", e)
            null
        }
    }

    suspend fun aiChatAppend(
        chatId: String,
        fileUrl: String,
        subject: String,
        title: String,
        items: List<AiChatItem>
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = json {
                put("fileUrl", fileUrl)
                put("subject", subject)
                put("title", title)
                put("items", JSONArray().apply {
                    items.forEach {
                        put(
                            JSONObject()
                                .put("role", it.role)
                                .put("text", it.text.take(24000))
                                .put("page", it.page)
                                .put("action", it.action)
                                .put("qid", it.qid)
                                .put("prov", it.prov)
                        )
                    }
                })
            }
            val request = req(url("ai", "chats", chatId, "append")).post(body).build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "ai chat append failed", e)
            false
        }
    }

    suspend fun aiChatDelete(chatId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("ai", "chats", chatId)).delete().build()).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "ai chat delete failed", e)
            false
        }
    }

    suspend fun aiChatClear(fileUrl: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "chats", query = mapOf("fileUrl" to fileUrl))).delete().build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "ai chat clear failed", e)
            false
        }
    }

    suspend fun reportAiAnswer(qid: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = req(url("ai", "report")).post(json { put("qid", qid) }).build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.w(TAG, "report ai answer failed", e)
            false
        }
    }

    suspend fun getUsers(): List<UserEntity> = withContext(Dispatchers.IO) {
        val arr = getArray(url("users"), "getUsers") ?: return@withContext emptyList()
        (0 until arr.length()).map { parseUser(arr.getJSONObject(it)) }.filter { it.email.isNotBlank() }
    }

    suspend fun upsertUser(user: UserEntity): Boolean = withContext(Dispatchers.IO) {
        val me = currentEmail
        val isSelf = me != null && me.equals(user.email, ignoreCase = true)
        if (isSelf) {
            send(
                req(url("users", "me")).patch(json {
                    if (user.fullName.isNotBlank()) put("fullName", user.fullName)
                    if (user.studentId.isNotBlank()) put("studentId", user.studentId)
                    if (user.groupName.isNotBlank()) put("groupName", user.groupName)
                    if (user.idCardUrl.isNotBlank()) put("idCardUrl", user.idCardUrl)
                }).build(), "upsertUser(me)"
            )
        } else {

            send(
                req(url("users", user.email)).put(json {
                    if (user.fullName.isNotBlank()) put("fullName", user.fullName)
                    if (user.studentId.isNotBlank()) put("studentId", user.studentId)
                    if (user.groupName.isNotBlank()) put("groupName", user.groupName)
                    if (user.idCardUrl.isNotBlank()) put("idCardUrl", user.idCardUrl)
                    put("role", user.role)
                    put("isApproved", user.isApproved)
                    put("registrationDate", user.registrationDate)
                    if (user.authUid.isNotBlank()) put("authUid", user.authUid)
                }).build(), "upsertUser(admin)"
            )
        }
    }

    data class BanRequest(
        val id: Long,
        val targetEmail: String,
        val targetName: String,
        val targetGroup: String,
        val requestedBy: String,
        val requestedByName: String,
        val createdAt: Long,
        val status: String,
        val decidedAt: Long
    )

    data class BlockOutcome(val ok: Boolean, val pending: Boolean = false, val message: String? = null)

    suspend fun blockStudent(email: String): BlockOutcome = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("users", email)).patch(json { put("isApproved", false) }).build())
                .execute().use { r ->
                    val body = r.body?.string().orEmpty()
                    if (r.isSuccessful) {
                        val pending = try { JSONObject(body).optBoolean("banPending", false) } catch (_: Exception) { false }
                        BlockOutcome(true, pending)
                    } else {
                        Log.w(TAG, "blockStudent failed (${r.code}): $body")
                        BlockOutcome(false, message = errorOf(r.code, body, "تعذر تنفيذ العملية"))
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error: blockStudent", e)
            BlockOutcome(false, message = CONNECT_ERROR)
        }
    }

    suspend fun getBanRequests(): List<BanRequest>? = withContext(Dispatchers.IO) {
        try {
            client.newCall(req(url("admin", "ban-requests")).get().build()).execute().use { r ->
                if (!r.isSuccessful) {
                    null
                } else {
                    val items = JSONObject(r.body?.string().orEmpty()).optJSONArray("items") ?: JSONArray()
                    (0 until items.length()).map { i ->
                        val o = items.getJSONObject(i)
                        BanRequest(
                            id = o.optLong("id"),
                            targetEmail = str(o, "targetEmail"),
                            targetName = str(o, "targetName"),
                            targetGroup = str(o, "targetGroup"),
                            requestedBy = str(o, "requestedBy"),
                            requestedByName = str(o, "requestedByName"),
                            createdAt = o.optLong("createdAt"),
                            status = str(o, "status"),
                            decidedAt = o.optLong("decidedAt")
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error: getBanRequests", e)
            null
        }
    }

    suspend fun decideBanRequest(id: Long, approve: Boolean): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("admin", "ban-requests", id.toString(), if (approve) "approve" else "reject"))
                .post(noBody()).build(),
            "decideBanRequest"
        )
    }

    suspend fun adminUpdateUser(
        email: String,
        fullName: String?,
        studentId: String? = null,
        groupName: String? = null,
        newPassword: String? = null
    ): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("users", email)).patch(json {
                fullName?.let { put("fullName", it.trim()) }
                studentId?.let { put("studentId", it.trim()) }
                groupName?.let { put("groupName", it.trim()) }
                newPassword?.takeIf { it.isNotBlank() }?.let { put("newPassword", it) }
            }).build(), "adminUpdateUser"
        )
    }

    suspend fun changeUserEmail(email: String, newEmail: String): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("users", email, "change-email")).post(json { put("newEmail", newEmail.trim()) }).build(),
            "changeUserEmail"
        )
    }

    suspend fun createAdmin(email: String, password: String, fullName: String): ApiResult = withContext(Dispatchers.IO) {
        sendResult(
            req(url("admin", "admins")).post(json {
                put("email", email.trim())
                put("password", password)
                put("fullName", fullName.trim())
            }).build(), "createAdmin"
        )
    }

    suspend fun promoteStudent(studentEmail: String, newEmail: String, password: String, fullName: String): ApiResult =
        withContext(Dispatchers.IO) {
            sendResult(
                req(url("admin", "admins")).post(json {
                    put("email", newEmail.trim())
                    put("password", password)
                    put("fullName", fullName.trim())
                    put("studentEmail", studentEmail.trim())
                }).build(), "promoteStudent"
            )
        }

    suspend fun demoteAdmin(email: String): ApiResult = withContext(Dispatchers.IO) {
        sendResult(req(url("users", email)).patch(json { put("role", "STUDENT") }).build(), "demoteAdmin")
    }

    suspend fun deleteUserResult(email: String): ApiResult = withContext(Dispatchers.IO) {
        sendResult(req(url("users", email)).delete().build(), "deleteUser")
    }

    suspend fun resetUserDevices(email: String): ApiResult = withContext(Dispatchers.IO) {
        sendResult(req(url("users", email, "devices")).delete().build(), "resetUserDevices")
    }

    suspend fun deleteUser(email: String): Boolean = withContext(Dispatchers.IO) {
        send(req(url("users", email)).delete().build(), "deleteUser")
    }

    private class ProgressRequestBody(
        private val file: File,
        private val contentType: okhttp3.MediaType?,
        private val onProgress: ((bytesUploaded: Long, totalBytes: Long) -> Unit)?
    ) : RequestBody() {
        override fun contentType(): okhttp3.MediaType? = contentType
        override fun contentLength(): Long = file.length()
        override fun writeTo(sink: okio.BufferedSink) {
            val length = contentLength()
            val buffer = ByteArray(64 * 1024)
            java.io.FileInputStream(file).use { input ->
                var uploaded = 0L
                var read: Int
                var lastReport = 0L
                while (input.read(buffer).also { read = it } != -1) {
                    sink.write(buffer, 0, read)
                    uploaded += read
                    val now = System.currentTimeMillis()
                    if (now - lastReport > 200 || uploaded == length) {
                        lastReport = now
                        onProgress?.invoke(uploaded, length)
                    }
                }
            }
        }
    }

    data class UploadResult(
        val url: String? = null,
        val error: String? = null,
        val tooLarge: Boolean = false,
        val networkError: Boolean = false,
        val finalSizeBytes: Long? = null
    ) {
        val isSuccess: Boolean get() = url != null
    }

    private fun isNetworkFailure(e: Throwable): Boolean =
        e is java.net.UnknownHostException || e is java.net.ConnectException ||
            e is java.net.SocketTimeoutException || e is java.net.NoRouteToHostException

    private const val NETWORK_MESSAGE =
        "تعذر الاتصال بالسيرفر. تأكد من الإنترنت وأن السيرفر شغّال، وجرّب تبديل الشبكة (واي فاي ↔ بيانات الهاتف) أو إيقاف الـ VPN."

    suspend fun uploadImageFile(file: File, fileName: String): String? = withContext(Dispatchers.IO) {
        try {
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, file.asRequestBody("image/jpeg".toMediaType()))
                .build()
            uploadClient.newCall(req(url("files", "img")).post(body).build()).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) JSONObject(s).optString("fileUrl").takeIf { it.isNotBlank() }
                else {
                    Log.e(TAG, "Image upload failed: ${r.code} $s")
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during image upload", e)
            null
        }
    }

    suspend fun uploadPdfFile(
        file: File,
        fileName: String,
        onStatus: ((String) -> Unit)? = null,
        onProgress: ((bytesUploaded: Long, totalBytes: Long) -> Unit)? = null
    ): UploadResult {
        val first = uploadPdfDirect(file, fileName, onProgress)
        if (!first.tooLarge) return first

        val compressed = File(file.parentFile, "compressed_${file.name}")
        try {
            val mb = 1024L * 1024L
            for (targetMb in listOf(45L, 30L, 20L)) {
                if (targetMb * mb >= file.length()) continue
                onStatus?.invoke("الملف أكبر من الحد المسموح على السيرفر — جاري ضغطه تلقائياً إلى أقل من $targetMb MB...")
                val fits = PdfCompressor.compress(file, compressed, targetMb * mb) { done, total, level, levels ->
                    onStatus?.invoke("جاري ضغط الملف (محاولة ${level + 1}/$levels): صفحة $done من $total")
                }
                if (!fits) break
                onStatus?.invoke("تم الضغط إلى ${"%.1f".format(java.util.Locale.US, compressed.length() / (1024.0 * 1024.0))} MB — جاري الرفع...")
                val r = uploadPdfDirect(compressed, fileName, onProgress)
                if (r.isSuccess) return r.copy(finalSizeBytes = compressed.length())
                if (!r.tooLarge) return r
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Auto-compress failed", e)
        } finally {
            compressed.delete()
        }
        return first.copy(
            error = "تعذر رفع الملف حتى بعد ضغطه تلقائياً. حجمه كبير جداً؛ قسّم الملف إلى جزئين أو ارفع حد MAX_PDF_MB في ملف run_server.bat."
        )
    }

    private suspend fun uploadPdfDirect(
        file: File,
        fileName: String,
        onProgress: ((bytesUploaded: Long, totalBytes: Long) -> Unit)?
    ): UploadResult = withContext(Dispatchers.IO) {
        if (file.length() <= 0) return@withContext UploadResult(error = "الملف المحلي فارغ أو غير موجود")
        try {
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, ProgressRequestBody(file, "application/pdf".toMediaType(), onProgress))
                .build()
            uploadClient.newCall(req(url("files", "pdf")).post(body).build()).execute().use { r ->
                val s = r.body?.string() ?: ""
                when {
                    r.isSuccessful -> {
                        val u = JSONObject(s).optString("fileUrl")
                        if (u.isNotBlank()) UploadResult(url = u) else UploadResult(error = "رد غير متوقع من السيرفر")
                    }
                    r.code == 413 -> UploadResult(error = errorOf(r.code, s, "حجم الملف كبير"), tooLarge = true)
                    else -> UploadResult(error = "فشل رفع الملف: " + errorOf(r.code, s, "HTTP"))
                }
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            Log.e(TAG, "Exception during upload", e)
            if (isNetworkFailure(e)) UploadResult(error = NETWORK_MESSAGE, networkError = true)
            else UploadResult(error = "تعذر رفع الملف: ${e.message ?: "خطأ في الاتصال"}")
        }
    }
}
