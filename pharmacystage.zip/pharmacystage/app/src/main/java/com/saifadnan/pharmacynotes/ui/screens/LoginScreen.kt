package com.saifadnan.pharmacynotes.ui.screens

import com.saifadnan.pharmacynotes.util.AdminConfig
import androidx.compose.animation.SizeTransform
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import com.saifadnan.pharmacynotes.ui.components.GlassSegmented
import com.saifadnan.pharmacynotes.ui.components.SegmentOption
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import com.saifadnan.pharmacynotes.ui.components.AuthIcons
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import kotlinx.coroutines.delay
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.TextButton
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.graphicsLayer
import com.saifadnan.pharmacynotes.data.StageInfo
import com.saifadnan.pharmacynotes.data.Stages
import com.saifadnan.pharmacynotes.ui.components.bounceClick
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.foundation.layout.width
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.draw.rotate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.glass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    errorMessage: String?,
    onLogin: (emailOrCode: String, password: String, studentName: String, studentId: String, isSignUpMode: Boolean, groupName: String, stage: Int) -> Unit,
    modifier: Modifier = Modifier,
    stages: List<StageInfo> = Stages.ALL,
    initialStage: Int = Stages.current,
    animateLogoEntrance: Boolean = false,
    logoFromBounds: Rect? = null,
    onLogoEntranceFinished: () -> Unit = {}
) {
    var identifier by remember { mutableStateOf("") }
    var signupEmail by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var studentId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isSignUpMode by remember { mutableStateOf(false) }
    var selectedGroup by remember { mutableStateOf("") }
    var selectedStage by remember { mutableIntStateOf(if (Stages.isValid(initialStage)) initialStage else Stages.DEFAULT) }
    var step by remember { mutableIntStateOf(1) }
    var autoTried by remember { mutableStateOf(false) }
    var groupOnly by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }
    var submitting by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }
    val dirSign = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1 else 1

    val glass = MaterialTheme.glass
    val isMainAdmin = !isSignUpMode && AdminConfig.isAdminEmail(identifier)
    val isEmail = identifier.trim().contains('@')
    val visibleError = localError ?: errorMessage?.takeIf { it != Stages.NEED_GROUP && (step == 2 || autoTried) }
    val errorIsPositive = visibleError?.let { it.contains("بانتظار") || it.contains("تم إرسال") || it.contains("بنجاح") } == true

    LaunchedEffect(errorMessage) {
        if (errorMessage != null) submitting = false
        if (errorMessage == Stages.NEED_GROUP) {
            selectedStage = Stages.current
            groupOnly = true
            step = 2
        }
    }
    LaunchedEffect(localError) { if (localError != null) submitting = false }
    LaunchedEffect(submitting) {
        if (submitting) {
            delay(15_000)
            submitting = false
        }
    }
    LaunchedEffect(visibleError) {
        if (visibleError != null && !errorIsPositive) {
            for (target in floatArrayOf(-10f, 8f, -6f, 3f, 0f)) {
                shake.animateTo(target, tween(55, easing = LinearOutSlowInEasing))
            }
        }
    }
    val fieldShape = RoundedCornerShape(20.dp)
    val iconTint = MaterialTheme.colorScheme.onSurfaceVariant
    val density = LocalDensity.current
    val focusManager = LocalFocusManager.current

    val imeInsets = WindowInsets.ime
    val imeVisible by remember(imeInsets, density) {
        derivedStateOf { imeInsets.getBottom(density) > 0 }
    }
    val logoSize by animateDpAsState(
        targetValue = if (imeVisible) 56.dp else 76.dp,
        animationSpec = tween(260, easing = MotionSpecs.EmphasizedEasing),
        label = "login_logo_size"
    )
    val headerGap by animateDpAsState(
        targetValue = if (imeVisible) 14.dp else 24.dp,
        animationSpec = tween(260, easing = MotionSpecs.EmphasizedEasing),
        label = "login_header_gap"
    )

    val hasTravel = animateLogoEntrance && logoFromBounds != null
    val logoTravel = remember { Animatable(if (hasTravel) 0f else 1f) }
    var travelDx by remember { mutableFloatStateOf(0f) }
    var travelDy by remember { mutableFloatStateOf(0f) }
    var travelScale by remember { mutableFloatStateOf(1f) }
    var logoReady by remember { mutableStateOf(!hasTravel) }
    val settle = remember { Animatable(1f) }
    val arrivalRing = remember { Animatable(1f) }
    val slotCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }

    val headerReveal = remember { Animatable(0f) }
    val cardReveal = remember { Animatable(0f) }
    val footerReveal = remember { Animatable(0f) }
    val ringColor = MaterialTheme.colorScheme.onBackground
    val ambient = rememberInfiniteTransition(label = "login_ambient")
    val drift by ambient.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "login_drift"
    )
    val breathe by ambient.animateFloat(
        initialValue = 1f, targetValue = 1.028f,
        animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "login_breathe"
    )
    val glowA = MaterialTheme.colorScheme.primary
    val glowB = MaterialTheme.colorScheme.tertiary

    LaunchedEffect(Unit) {
        if (hasTravel && logoFromBounds != null) {
            withFrameNanos { }
            withFrameNanos { }
            val target = slotCoords[0]?.takeIf { it.isAttached }?.boundsInRoot()
            if (target != null && target.width > 0f) {
                travelDx = logoFromBounds.center.x - target.center.x
                travelDy = logoFromBounds.center.y - target.center.y
                travelScale = logoFromBounds.width / target.width
            } else {
                logoTravel.snapTo(1f)
            }
            logoReady = true
            coroutineScope {
                launch { logoTravel.animateTo(1f, tween(780, easing = MotionSpecs.LogoTravelEasing)) }
                launch {
                    delay(190)
                    headerReveal.animateTo(1f, tween(460, easing = MotionSpecs.EmphasizedEasing))
                }
                launch {
                    delay(320)
                    cardReveal.animateTo(1f, tween(520, easing = MotionSpecs.EmphasizedEasing))
                }
                launch {
                    delay(460)
                    footerReveal.animateTo(1f, tween(400, easing = MotionSpecs.EmphasizedEasing))
                }
                launch {
                    delay(480)
                    coroutineScope {
                        launch {
                            settle.snapTo(1.07f)
                            settle.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 420f))
                        }
                        launch {
                            arrivalRing.snapTo(0f)
                            arrivalRing.animateTo(1f, tween(900, easing = LinearOutSlowInEasing))
                        }
                    }
                }
            }
            onLogoEntranceFinished()
        } else {
            coroutineScope {
                launch { headerReveal.animateTo(1f, tween(380, easing = MotionSpecs.EmphasizedEasing)) }
                launch {
                    delay(90)
                    cardReveal.animateTo(1f, tween(420, easing = MotionSpecs.EmphasizedEasing))
                }
                launch {
                    delay(180)
                    footerReveal.animateTo(1f, tween(360, easing = MotionSpecs.EmphasizedEasing))
                }
            }
            if (animateLogoEntrance) onLogoEntranceFinished()
        }
    }

    val doContinue: (Boolean) -> Unit = { signUp ->
        val err = if (signUp) {
            when {
                fullName.trim().split(Regex("\\s+")).size < 3 -> "اكتب الاسم الثلاثي على الأقل."
                !Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$").matches(signupEmail.trim()) -> "تحقق من صيغة البريد الإلكتروني."
                studentId.trim().isBlank() -> "اكتب الرقم الجامعي حتى تتمكن من الدخول به لاحقاً."
                password.length < 8 -> "كلمة المرور يجب أن تتكون من 8 أحرف على الأقل."
                password.toByteArray(Charsets.UTF_8).size > 72 -> "كلمة المرور طويلة جداً، اختَر كلمة أقصر."
                else -> null
            }
        } else {
            when {
                identifier.trim().isBlank() -> "اكتب الإيميل أو الرقم الجامعي أولاً"
                password.isBlank() -> "اكتب كلمة المرور للمتابعة."
                else -> null
            }
        }
        localError = err
        if (err == null) {
            focusManager.clearFocus()
            if (!signUp && !AdminConfig.isAdminEmail(identifier)) {
                autoTried = true
                groupOnly = false
                submitting = true
                onLogin(identifier.trim(), password, "", "", false, "", Stages.AUTO)
            } else {
                step = 2
            }
        }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.13f),
        focusedContainerColor = glass.fillBottom,
        unfocusedContainerColor = glass.fillBottom.copy(alpha = glass.fillBottom.alpha * 0.7f),
        focusedTextColor = MaterialTheme.colorScheme.onSurface,
        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
        disabledTextColor = MaterialTheme.colorScheme.onSurface,
        disabledBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
        disabledContainerColor = glass.fillBottom.copy(alpha = glass.fillBottom.alpha * 0.7f),
        focusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
        cursorColor = MaterialTheme.colorScheme.primary
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val w = size.width
                val h = size.height
                val r1 = maxOf(w, h) * 0.62f
                val c1 = Offset(w * (0.15f + 0.22f * drift), h * (0.12f + 0.06f * drift))
                drawCircle(
                    brush = Brush.radialGradient(listOf(glowA.copy(alpha = 0.16f), Color.Transparent), center = c1, radius = r1),
                    radius = r1, center = c1
                )
                val r2 = maxOf(w, h) * 0.55f
                val c2 = Offset(w * (0.88f - 0.20f * drift), h * (0.90f - 0.07f * drift))
                drawCircle(
                    brush = Brush.radialGradient(listOf(glowB.copy(alpha = 0.12f), Color.Transparent), center = c2, radius = r2),
                    radius = r2, center = c2
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .wrapContentWidth(Alignment.CenterHorizontally)
                .widthIn(max = 480.dp)
                .statusBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(logoSize)
                    .onGloballyPositioned { slotCoords[0] = it }
                    .drawBehind {
                        val t = arrivalRing.value
                        if (t < 1f) {
                            drawCircle(
                                color = ringColor.copy(alpha = (1f - t) * 0.20f),
                                radius = size.minDimension / 2f * (1f + 0.85f * t),
                                center = Offset(size.width / 2f, size.height / 2f),
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val inv = 1f - logoTravel.value
                            translationX = travelDx * inv
                            translationY = travelDy * inv
                            val sc = (1f + (travelScale - 1f) * inv) * settle.value * breathe
                            scaleX = sc
                            scaleY = sc
                            alpha = if (logoReady) 1f else 0f
                        }
                        .clip(CircleShape)
                        .background(glass.fillBottom)
                        .border(1.dp, glass.border, CircleShape)
                        .padding(logoSize * 0.0667f),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.pharmacy_icon_1784744273743),
                        contentDescription = "شعار تطبيق ملازم الصيدلة",
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer {
                    val r = headerReveal.value
                    alpha = r
                    translationY = (1f - r) * 18.dp.toPx()
                }
            ) {
                val titleText = if (step == 1) {
                    if (isSignUpMode) "إنشاء حساب طالب" else "أهلاً بعودتك"
                } else if (isMainAdmin) "اختيار مرحلة الإدارة" else if (isSignUpMode) "أكمل بياناتك الدراسية" else "خلّينا نكمل إعداد الدخول"
                AnimatedContent(
                    targetState = titleText,
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                    transitionSpec = {
                        (fadeIn(tween(300, delayMillis = 90, easing = MotionSpecs.EmphasizedEasing)) +
                            slideInVertically(tween(320, delayMillis = 90, easing = MotionSpecs.EmphasizedEasing)) { it / 4 }) togetherWith
                            (fadeOut(tween(150)) + slideOutVertically(tween(200, easing = FastOutSlowInEasing)) { -it / 4 }) using
                            SizeTransform(clip = false) { _, _ -> tween(300, easing = MotionSpecs.EmphasizedEasing) }
                    },
                    label = "login_title"
                ) { t ->
                    Text(
                        text = t,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                AnimatedVisibility(
                    visible = !imeVisible,
                    enter = fadeIn(tween(200)) + expandVertically(tween(240)),
                    exit = fadeOut(tween(120)) + shrinkVertically(tween(200))
                ) {
                    val subText = if (step == 1) {
                        "ملازم الصيدلة · الجامعة المستنصرية"
                    } else if (isMainAdmin) {
                        "اختَر المرحلة التي تريد إدارتها"
                    } else {
                        if (groupOnly) "اختَر المجموعة" else "اختار المرحلة والكروب"
                    }
                    AnimatedContent(
                        targetState = subText,
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center,
                        transitionSpec = {
                            (fadeIn(tween(280, delayMillis = 90, easing = MotionSpecs.EmphasizedEasing)) +
                                slideInVertically(tween(300, delayMillis = 90, easing = MotionSpecs.EmphasizedEasing)) { it / 4 }) togetherWith
                                (fadeOut(tween(150)) + slideOutVertically(tween(200, easing = FastOutSlowInEasing)) { -it / 4 }) using
                                SizeTransform(clip = false) { _, _ -> tween(300, easing = MotionSpecs.EmphasizedEasing) }
                        },
                        label = "login_subtitle"
                    ) { t ->
                        Text(
                            text = t,
                            style = MaterialTheme.typography.titleSmall,
                            color = glass.headerSubtitle,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(headerGap))

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        val r = cardReveal.value
                        alpha = r
                        translationY = (1f - r) * 28.dp.toPx()
                        translationX = shake.value.dp.toPx()
                    }
                    .testTag("login_card_container")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (isSignUpMode || isMainAdmin || step == 2) Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(2) { index ->
                            val fill by animateFloatAsState(
                                targetValue = if (step >= index + 1) 1f else 0f,
                                animationSpec = tween(420, easing = MotionSpecs.EmphasizedEasing),
                                label = "login_progress_$index"
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fill)
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                        }
                        AnimatedContent(
                            targetState = step,
                            transitionSpec = {
                                (fadeIn(tween(200)) + slideInVertically(tween(220)) { it / 2 }) togetherWith
                                    (fadeOut(tween(120)) + slideOutVertically(tween(160)) { -it / 2 })
                            },
                            label = "login_step_counter"
                        ) { st ->
                            Text(
                                text = "$st / 2",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = visibleError != null,
                        enter = fadeIn(tween(180)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(140)) + shrinkVertically(tween(180))
                    ) {
                        visibleError?.let { msg ->
                            val isPendingOrSuccess = msg.contains("بانتظار") || msg.contains("تم إرسال") || msg.contains("بنجاح")
                            val tone = if (isPendingOrSuccess) SuccessGreen else MaterialTheme.colorScheme.error
                            Surface(
                                color = tone.copy(alpha = 0.10f),
                                shape = fieldShape,
                                border = BorderStroke(1.dp, tone.copy(alpha = 0.28f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPendingOrSuccess) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = tone,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = msg,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        AnimatedVisibility(
                            visible = step == 1 && !isMainAdmin,
                            enter = fadeIn(tween(220)) + expandVertically(tween(260, easing = MotionSpecs.EmphasizedEasing)),
                            exit = fadeOut(tween(140)) + shrinkVertically(tween(200))
                        ) {
                            Column {
                                GlassSegmented(
                                    options = listOf(
                                        SegmentOption("login", "تسجيل الدخول", Icons.Default.Person),
                                        SegmentOption("signup", "إنشاء حساب جديد", Icons.Default.PersonAdd)
                                    ),
                                    selectedKey = if (isSignUpMode) "signup" else "login",
                                    onSelect = { key ->
                                        isSignUpMode = key == "signup"
                                        autoTried = false
                                        localError = null
                                    },
                                    tagPrefix = "auth_mode_"
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                            }
                        }
                        AnimatedContent(
                            targetState = step to isSignUpMode,
                            transitionSpec = {
                                val stepChanged = targetState.first != initialState.first
                                val forward = targetState.first > initialState.first
                                val dir = if (forward) dirSign else -dirSign
                                val transition = if (stepChanged) {
                                    (fadeIn(tween(280, delayMillis = 60, easing = MotionSpecs.EmphasizedEasing)) +
                                        slideInHorizontally(tween(340, easing = MotionSpecs.EmphasizedEasing)) { dir * it / 5 }) togetherWith
                                        (fadeOut(tween(140)) + slideOutHorizontally(tween(220, easing = FastOutSlowInEasing)) { -dir * it / 6 })
                                } else {
                                    fadeIn(tween(240, delayMillis = 50)) togetherWith fadeOut(tween(130))
                                }
                                transition.using(SizeTransform(clip = false) { _, _ -> tween(300, easing = MotionSpecs.EmphasizedEasing) })
                            },
                            label = "login_two_step_transition"
                        ) { pageState ->
                            val currentStep = pageState.first
                            val currentSignUpMode = pageState.second
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (currentStep == 1) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = if (currentSignUpMode) "إنشاء حساب جديد" else "تسجيل الدخول",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    if (currentSignUpMode) {
                                        OutlinedTextField(
                                            value = fullName,
                                            onValueChange = { fullName = it; localError = null },
                                            label = { Text("اسم الطالب الكامل") },
                                            placeholder = { Text("الاسم الثلاثي أو الكامل") },
                                            leadingIcon = { Icon(AuthIcons.PersonName, contentDescription = null, tint = iconTint) },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                            modifier = Modifier.fillMaxWidth().staggerIn(0).testTag("signup_full_name_input"),
                                            singleLine = true,
                                            shape = fieldShape,
                                            colors = fieldColors
                                        )
                                        OutlinedTextField(
                                            value = signupEmail,
                                            onValueChange = { signupEmail = it.trimStart(); localError = null },
                                            label = { Text("البريد الإلكتروني") },
                                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = iconTint) },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                            modifier = Modifier.fillMaxWidth().staggerIn(1).testTag("signup_email_input"),
                                            singleLine = true,
                                            shape = fieldShape,
                                            colors = fieldColors
                                        )
                                        OutlinedTextField(
                                            value = studentId,
                                            onValueChange = { studentId = it.trimStart(); localError = null },
                                            label = { Text("الرقم الجامعي") },
                                            leadingIcon = { Icon(AuthIcons.StudentId, contentDescription = null, tint = iconTint) },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                            modifier = Modifier.fillMaxWidth().staggerIn(2).testTag("signup_student_id_input"),
                                            singleLine = true,
                                            shape = fieldShape,
                                            colors = fieldColors
                                        )
                                    } else {
                                        OutlinedTextField(
                                            value = identifier,
                                            onValueChange = { identifier = it; localError = null },
                                            label = { Text("الإيميل أو الرقم الجامعي") },
                                            leadingIcon = {
                                                Crossfade(
                                                    targetState = isEmail,
                                                    animationSpec = tween(180),
                                                    label = "login_identifier_icon"
                                                ) { email ->
                                                    Icon(
                                                        imageVector = if (email) Icons.Default.Email else AuthIcons.StudentId,
                                                        contentDescription = null,
                                                        tint = iconTint
                                                    )
                                                }
                                            },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                            modifier = Modifier.fillMaxWidth().staggerIn(0).testTag("login_identifier_input"),
                                            singleLine = true,
                                            shape = fieldShape,
                                            colors = fieldColors
                                        )
                                    }

                                    OutlinedTextField(
                                        value = password,
                                        onValueChange = { password = it; localError = null },
                                        label = { Text("كلمة المرور") },
                                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = iconTint) },
                                        trailingIcon = {
                                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                                Icon(
                                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = if (passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور",
                                                    tint = iconTint
                                                )
                                            }
                                        },
                                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { doContinue(currentSignUpMode) }),
                                        modifier = Modifier.fillMaxWidth().staggerIn(if (currentSignUpMode) 3 else 1).testTag("login_password_input"),
                                        singleLine = true,
                                        shape = fieldShape,
                                        colors = fieldColors
                                    )
                                    val directLogin = !currentSignUpMode && !isMainAdmin
                                    PillButton(
                                        loading = directLogin && submitting,
                                        text = if (currentSignUpMode) "متابعة إنشاء الحساب"
                                        else if (directLogin) (if (submitting) "جارٍ التحقق…" else "تسجيل الدخول")
                                        else "متابعة",
                                        onClick = { doContinue(currentSignUpMode) },
                                        modifier = Modifier.fillMaxWidth().staggerIn(if (currentSignUpMode) 4 else 2).testTag("login_continue_button")
                                    )
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                            modifier = Modifier.size(42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text(
                                                text = if (groupOnly) "المجموعة الدراسية" else "المرحلة والمجموعة",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "حتى يعرض لك التطبيق مواد المرحلة الخاصة بيك",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    if (!groupOnly) StagePicker(
                                        stages = stages,
                                        selected = selectedStage,
                                        onSelect = { selectedStage = it; localError = null }
                                    )
                                    AnimatedVisibility(
                                        visible = !isMainAdmin,
                                        enter = fadeIn(tween(180)) + expandVertically(tween(220)),
                                        exit = fadeOut(tween(120)) + shrinkVertically(tween(180))
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(
                                                text = "المجموعة الدراسية",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                                            )
                                            GroupPicker(
                                                selected = selectedGroup,
                                                onSelect = { selectedGroup = it; localError = null }
                                            )
                                        }
                                    }
                                    PillButton(
                                        loading = submitting,
                                        text = if (submitting) "جارٍ التحقق…" else when {
                                            isMainAdmin -> "دخول الإدارة"
                                            currentSignUpMode -> "إنشاء الحساب والدخول"
                                            else -> "تسجيل الدخول"
                                        },
                                        onClick = {
                                            val err = when {
                                                !Stages.isValid(selectedStage) -> "اختر المرحلة الدراسية للمتابعة."
                                                !isMainAdmin && selectedGroup.isBlank() -> "اختر مجموعتك الدراسية للمتابعة."
                                                else -> null
                                            }
                                            localError = err
                                            if (err == null) {
                                                submitting = true
                                                onLogin(
                                                    if (currentSignUpMode) signupEmail.trim() else identifier.trim(),
                                                    password,
                                                    if (currentSignUpMode) fullName.trim().replace(Regex("\\s+"), " ") else "",
                                                    if (currentSignUpMode) studentId.trim() else "",
                                                    currentSignUpMode,
                                                    selectedGroup,
                                                    selectedStage
                                                )
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("login_submit_button")
                                    )
                                    TextButton(
                                        onClick = { localError = null; groupOnly = false; step = 1 },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("الرجوع لتعديل البيانات")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !imeVisible,
                enter = fadeIn(tween(200)) + expandVertically(tween(240)),
                exit = fadeOut(tween(120)) + shrinkVertically(tween(200))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.graphicsLayer { alpha = footerReveal.value }
                ) {
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "ملازم الصيدلة · الجامعة المستنصرية",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

private fun Modifier.staggerIn(index: Int): Modifier = composed {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(60L + index * 55L)
        p.animateTo(1f, tween(360, easing = MotionSpecs.EmphasizedEasing))
    }
    graphicsLayer {
        alpha = p.value
        translationY = (1f - p.value) * 14.dp.toPx()
    }
}

@Composable
private fun GroupPicker(
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = MaterialTheme.glass
    val colors = MaterialTheme.colorScheme
    val density = LocalDensity.current
    var expanded by remember { mutableStateOf(false) }
    var fieldWidthPx by remember { mutableIntStateOf(0) }
    val fieldShape = RoundedCornerShape(20.dp)
    val menuShape = RoundedCornerShape(20.dp)

    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(200),
        label = "group_arrow_rotation"
    )
    val edge by animateColorAsState(
        targetValue = if (expanded) colors.onSurface.copy(alpha = 0.55f) else colors.onSurface.copy(alpha = 0.12f),
        animationSpec = tween(180),
        label = "group_field_edge"
    )

    Box(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .onGloballyPositioned { fieldWidthPx = it.size.width }
                .clip(fieldShape)
                .background(glass.fillBottom.copy(alpha = glass.fillBottom.alpha * if (expanded) 1f else 0.7f))
                .border(1.dp, edge, fieldShape)
                .clickable(role = Role.DropdownList) { expanded = !expanded }
                .padding(horizontal = 14.dp)
                .testTag("group_selector_field")
        ) {
            Icon(
                imageVector = Icons.Default.Groups,
                contentDescription = null,
                tint = colors.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = if (selected.isEmpty()) "اختر الكروب" else selected,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (selected.isEmpty()) FontWeight.Normal else FontWeight.SemiBold,
                color = if (selected.isEmpty()) colors.onSurfaceVariant else colors.onSurface,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = colors.onSurfaceVariant,
                modifier = Modifier
                    .size(24.dp)
                    .rotate(arrowRotation)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            shape = menuShape,
            containerColor = colors.surfaceContainerHigh,
            tonalElevation = 0.dp,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, colors.onSurface.copy(alpha = 0.10f)),
            modifier = Modifier.width(with(density) { fieldWidthPx.toDp() })
        ) {
            ScheduleConstants.GROUPS.forEach { group ->
                val isSelected = group == selected
                DropdownMenuItem(
                    text = {
                        Text(
                            text = group,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = colors.onSurface
                        )
                    },
                    trailingIcon = {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = colors.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    onClick = {
                        onSelect(group)
                        expanded = false
                    },
                    modifier = Modifier
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) colors.onSurface.copy(alpha = 0.07f) else Color.Transparent)
                )
            }
        }
    }
}

@Composable
internal fun StagePicker(
    stages: List<StageInfo>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage_picker"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.School,
                contentDescription = null,
                tint = colors.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = "المرحلة الدراسية",
                style = MaterialTheme.typography.labelLarge,
                color = colors.onSurfaceVariant
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            stages.forEach { stage ->
                StageTile(
                    stage = stage,
                    selected = stage.id == selected,
                    onClick = { onSelect(stage.id) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StageTile(
    stage: StageInfo,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = MaterialTheme.glass
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)

    val container by animateColorAsState(
        targetValue = if (selected) colors.primary else glass.fillBottom.copy(alpha = glass.fillBottom.alpha * 0.7f),
        animationSpec = tween(220),
        label = "stage_tile_bg"
    )
    val content by animateColorAsState(
        targetValue = if (selected) colors.onPrimary else colors.onSurface,
        animationSpec = tween(220),
        label = "stage_tile_fg"
    )
    val edge by animateColorAsState(
        targetValue = if (selected) colors.primary else colors.onSurface.copy(alpha = 0.12f),
        animationSpec = tween(220),
        label = "stage_tile_edge"
    )
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.05f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "stage_tile_scale"
    )

    Column(
        modifier = modifier
            .height(62.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .background(container)
            .border(1.dp, edge, shape)
            .bounceClick(onClick = onClick)
            .testTag("stage_tile_${stage.id}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stage.id.toString(),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = content
        )
        Text(
            text = Stages.short(stage.id),
            style = MaterialTheme.typography.labelSmall,
            color = content.copy(alpha = 0.85f),
            maxLines = 1
        )
    }
}