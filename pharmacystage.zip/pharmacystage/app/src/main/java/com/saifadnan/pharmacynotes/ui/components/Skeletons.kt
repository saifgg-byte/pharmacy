package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.Accent

@Composable
fun HomeTabSkeleton(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .shimmerEffect()
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .shimmerEffect()
            )
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .shimmerEffect()
            )
        }

        Box(
            modifier = Modifier
                .width(180.dp)
                .height(20.dp)
                .clip(RoundedCornerShape(4.dp))
                .shimmerEffect()
        )

        repeat(3) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .shimmerEffect()
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.55f)
                                .height(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerEffect()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.35f)
                                .height(10.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerEffect()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(72.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .shimmerEffect()
                    )
                }
            }
        }
    }
}

@Composable
fun NotificationsTabSkeleton(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .width(160.dp)
                        .height(22.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerEffect()
                )
                Box(
                    modifier = Modifier
                        .width(220.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerEffect()
                )
            }
            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .shimmerEffect()
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        repeat(4) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .shimmerEffect()
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerEffect()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .height(12.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerEffect()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileTabSkeleton(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorder, RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .shimmerEffect()
                )
                Box(
                    modifier = Modifier
                        .width(140.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerEffect()
                )
                Box(
                    modifier = Modifier
                        .width(180.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerEffect()
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .weight(1f)
                    .height(90.dp)
                    .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                        .shimmerEffect()
                )
            }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .weight(1f)
                    .height(90.dp)
                    .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                        .shimmerEffect()
                )
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .height(70.dp)
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .shimmerEffect()
            )
        }
    }
}

@Composable
fun AdminTabSkeleton(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .width(160.dp)
                .height(24.dp)
                .clip(RoundedCornerShape(4.dp))
                .shimmerEffect()
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .shimmerEffect()
            )
        }
    }
}

@Composable
fun PdfViewerSkeleton(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "PdfScanLineTransition")
    val scanProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ScanProgress"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .shimmerEffect()
                    .drawWithContent {
                        drawContent()
                        val lineY = scanProgress * size.height

                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Accent.copy(alpha = 0.10f),
                                    Accent.copy(alpha = 0.35f),
                                    Accent.copy(alpha = 0.50f),
                                    Accent.copy(alpha = 0.35f),
                                    Accent.copy(alpha = 0.10f),
                                    Color.Transparent
                                ),
                                startY = (lineY - 70f).coerceAtLeast(0f),
                                endY = (lineY + 70f).coerceAtMost(size.height)
                            )
                        )
                    }
            )
        }

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .width(260.dp)
                .height(48.dp)
                .border(1.dp, CardBorder, RoundedCornerShape(20.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .shimmerEffect()
            )
        }
    }
}

@Composable
fun MedicalEmptyFolderState(
    message: String = "لا توجد مجلدات مواد حالياً",
    subtitle: String = "سيتم إضافة مجلدات جديدة قريباً بواسطة المشرف",
    modifier: Modifier = Modifier
) {
    val ink = MaterialTheme.colorScheme.onSurface
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(110.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(90.dp)) {
                val w = size.width
                val h = size.height
                val teal = ink.copy(alpha = 0.72f)
                val tealLight = ink.copy(alpha = 0.08f)

                drawRoundRect(
                    color = tealLight,
                    topLeft = Offset(w * 0.1f, h * 0.25f),
                    size = Size(w * 0.8f, h * 0.6f),
                    cornerRadius = CornerRadius(16f, 16f)
                )

                drawRoundRect(
                    color = teal,
                    topLeft = Offset(w * 0.1f, h * 0.25f),
                    size = Size(w * 0.8f, h * 0.6f),
                    cornerRadius = CornerRadius(16f, 16f),
                    style = Stroke(width = 4f)
                )

                val tabPath = Path().apply {
                    moveTo(w * 0.1f, h * 0.25f)
                    lineTo(w * 0.22f, h * 0.14f)
                    lineTo(w * 0.48f, h * 0.14f)
                    lineTo(w * 0.56f, h * 0.25f)
                    close()
                }
                drawPath(tabPath, color = teal)

                val cx = w * 0.5f
                val cy = h * 0.55f
                val arm = 14f
                val th = 6f
                drawRoundRect(color = teal, topLeft = Offset(cx - arm, cy - th), size = Size(arm * 2, th * 2), cornerRadius = CornerRadius(3f, 3f))
                drawRoundRect(color = teal, topLeft = Offset(cx - th, cy - arm), size = Size(th * 2, arm * 2), cornerRadius = CornerRadius(3f, 3f))
            }
        }

        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun MedicalEmptyLectureState(
    message: String = "لا توجد محاضرات في هذا المجلد",
    subtitle: String = "ستظهر المحاضرات المرفوعة من قبل أطباء المادة هنا",
    modifier: Modifier = Modifier
) {
    val ink = MaterialTheme.colorScheme.onSurface
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(110.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(90.dp)) {
                val w = size.width
                val h = size.height
                val teal = ink.copy(alpha = 0.72f)
                val tealLight = ink.copy(alpha = 0.08f)

                drawRoundRect(
                    color = tealLight,
                    topLeft = Offset(w * 0.2f, h * 0.18f),
                    size = Size(w * 0.6f, h * 0.72f),
                    cornerRadius = CornerRadius(14f, 14f)
                )
                drawRoundRect(
                    color = teal,
                    topLeft = Offset(w * 0.2f, h * 0.18f),
                    size = Size(w * 0.6f, h * 0.72f),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 4f)
                )

                drawRoundRect(
                    color = teal,
                    topLeft = Offset(w * 0.35f, h * 0.10f),
                    size = Size(w * 0.3f, h * 0.12f),
                    cornerRadius = CornerRadius(6f, 6f)
                )

                val lineY1 = h * 0.38f
                val lineY2 = h * 0.52f
                val lineY3 = h * 0.66f
                drawLine(color = teal, start = Offset(w * 0.32f, lineY1), end = Offset(w * 0.68f, lineY1), strokeWidth = 4f, cap = StrokeCap.Round)
                drawLine(color = teal, start = Offset(w * 0.32f, lineY2), end = Offset(w * 0.60f, lineY2), strokeWidth = 4f, cap = StrokeCap.Round)
                drawLine(color = teal, start = Offset(w * 0.32f, lineY3), end = Offset(w * 0.48f, lineY3), strokeWidth = 4f, cap = StrokeCap.Round)
            }
        }

        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun MedicalEmptyNotificationState(
    message: String = "لا توجد إشعارات حالياً",
    subtitle: String = "ستصلك التنبيهات والأخبار الطبية الهامة فور صدورها",
    modifier: Modifier = Modifier
) {
    val ink = MaterialTheme.colorScheme.onSurface
    val surface = MaterialTheme.colorScheme.surface
    val badgeFill = MaterialTheme.colorScheme.primary
    val badgeInk = MaterialTheme.colorScheme.onPrimary

    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        enter.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 260f))
    }

    val infinite = rememberInfiniteTransition(label = "empty_bell")
    val swing by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 5200
                0f at 0
                9f at 200 using FastOutSlowInEasing
                -7f at 480 using FastOutSlowInEasing
                5f at 760 using FastOutSlowInEasing
                -3.2f at 1040 using FastOutSlowInEasing
                1.6f at 1300 using FastOutSlowInEasing
                0f at 1560 using FastOutSlowInEasing
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "bell_swing"
    )
    val twinkle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bell_twinkle"
    )
    val breathe by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bell_breathe"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(132.dp)
                .graphicsLayer {
                    val e = enter.value
                    alpha = e.coerceIn(0f, 1f)
                    scaleX = 0.82f + 0.18f * e
                    scaleY = 0.82f + 0.18f * e
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(132.dp)) {
                val u = size.width / 100f
                fun p(x: Float, y: Float) = Offset(x * u, y * u)

                val haloR = 50f * u * (0.92f + 0.08f * breathe)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(ink.copy(alpha = 0.10f + 0.03f * breathe), Color.Transparent),
                        center = p(50f, 50f),
                        radius = haloR
                    ),
                    radius = haloR,
                    center = p(50f, 50f)
                )

                rotate(degrees = swing, pivot = p(50f, 12f)) {
                    val body = Path().apply {
                        moveTo(50f * u, 17f * u)
                        cubicTo(35f * u, 17f * u, 28.5f * u, 29f * u, 28.5f * u, 43f * u)
                        lineTo(28.5f * u, 53f * u)
                        cubicTo(28.5f * u, 60f * u, 24.5f * u, 64f * u, 20f * u, 67.5f * u)
                        lineTo(80f * u, 67.5f * u)
                        cubicTo(75.5f * u, 64f * u, 71.5f * u, 60f * u, 71.5f * u, 53f * u)
                        lineTo(71.5f * u, 43f * u)
                        cubicTo(71.5f * u, 29f * u, 65f * u, 17f * u, 50f * u, 17f * u)
                        close()
                    }
                    drawPath(
                        path = body,
                        brush = Brush.verticalGradient(
                            colors = listOf(ink.copy(alpha = 0.05f), ink.copy(alpha = 0.14f)),
                            startY = 17f * u,
                            endY = 68f * u
                        )
                    )
                    drawPath(
                        path = body,
                        color = ink.copy(alpha = 0.82f),
                        style = Stroke(width = 2.3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    val shine = Path().apply {
                        moveTo(37f * u, 30f * u)
                        quadraticTo(34f * u, 36f * u, 34f * u, 46f * u)
                    }
                    drawPath(
                        path = shine,
                        color = surface.copy(alpha = 0.85f),
                        style = Stroke(width = 2.4f * u, cap = StrokeCap.Round)
                    )

                    drawRoundRect(
                        color = ink.copy(alpha = 0.86f),
                        topLeft = p(17f, 66.5f),
                        size = Size(66f * u, 5.2f * u),
                        cornerRadius = CornerRadius(2.6f * u, 2.6f * u)
                    )

                    drawRoundRect(
                        color = ink.copy(alpha = 0.86f),
                        topLeft = p(45.5f, 8f),
                        size = Size(9f * u, 8f * u),
                        cornerRadius = CornerRadius(3.2f * u, 3.2f * u)
                    )

                    drawCircle(
                        color = ink.copy(alpha = 0.86f),
                        radius = 4.6f * u,
                        center = p(50f - swing * 0.55f, 77.5f)
                    )
                }

                fun sparkle(cx: Float, cy: Float, r: Float, a: Float) {
                    val star = Path().apply {
                        moveTo(cx * u, (cy - r) * u)
                        quadraticTo(cx * u, cy * u, (cx + r) * u, cy * u)
                        quadraticTo(cx * u, cy * u, cx * u, (cy + r) * u)
                        quadraticTo(cx * u, cy * u, (cx - r) * u, cy * u)
                        quadraticTo(cx * u, cy * u, cx * u, (cy - r) * u)
                        close()
                    }
                    drawPath(star, color = ink.copy(alpha = a))
                }
                sparkle(84f, 22f, 5.2f, 0.20f + 0.45f * twinkle)
                sparkle(15f, 34f, 3.6f, 0.20f + 0.45f * (1f - twinkle))
                sparkle(88f, 48f, 2.6f, 0.15f + 0.40f * (1f - twinkle))

                drawCircle(color = surface, radius = 12.6f * u, center = p(79f, 79f))
                drawCircle(color = badgeFill.copy(alpha = 0.92f), radius = 10.4f * u, center = p(79f, 79f))
                val tick = Path().apply {
                    moveTo(73.6f * u, 79.4f * u)
                    lineTo(77.4f * u, 83.2f * u)
                    lineTo(84.6f * u, 74.8f * u)
                }
                drawPath(
                    path = tick,
                    color = badgeInk,
                    style = Stroke(width = 2.4f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }

        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
    }
}