package com.saifadnan.pharmacynotes.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.ExamEntity
import com.saifadnan.pharmacynotes.data.ExamTypes
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import java.util.Calendar
import java.util.Locale


object ExamUtil {
    val MONTHS = listOf(
        "كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران",
        "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"
    )

    fun parse(date: String): Calendar? {
        val p = date.split("-")
        if (p.size != 3) return null
        val y = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        val d = p[2].toIntOrNull() ?: return null
        return Calendar.getInstance().apply {
            clear(); set(y, m - 1, d, 0, 0, 0)
        }
    }

    fun format(y: Int, m0: Int, d: Int) = String.format(Locale.US, "%04d-%02d-%02d", y, m0 + 1, d)

    fun startMillis(e: ExamEntity): Long =
        (parse(e.examDate) ?: Calendar.getInstance()).apply {
            set(Calendar.HOUR_OF_DAY, e.startHour); set(Calendar.MINUTE, e.startMinute)
        }.timeInMillis

    fun endMillis(e: ExamEntity): Long = startMillis(e) + e.durationMin * 60_000L

    fun today(): Calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    fun daysUntil(e: ExamEntity): Int {
        val d = parse(e.examDate) ?: return Int.MAX_VALUE
        return Math.round((d.timeInMillis - today().timeInMillis) / 86_400_000.0).toInt()
    }

    fun time(h: Int, m: Int) = String.format(Locale.US, "%02d:%02d", h, m)

    fun range(e: ExamEntity): String {
        val end = e.startHour * 60 + e.startMinute + e.durationMin
        return "${time(e.startHour, e.startMinute)} - ${time((end / 60) % 24, end % 60)}"
    }

    fun duration(min: Int): String = when {
        min % 60 == 0 -> "${min / 60} ساعة"
        min < 60 -> "$min دقيقة"
        else -> "${min / 60} س و${min % 60} د"
    }

    fun dayName(cal: Calendar) = ScheduleConstants.dayName(cal.get(Calendar.DAY_OF_WEEK))

    fun typeColor(t: String): Color = when (t) {
        ExamTypes.FINAL -> Color(0xFFEF4444)
        ExamTypes.MIDTERM -> Color(0xFF3B82F6)
        ExamTypes.PRACTICAL -> Color(0xFF14B8A6)
        else -> Color(0xFFF59E0B)
    }
}

@Composable
fun StudentExamScreen(
    myGroup: String,
    exams: List<ExamEntity>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val mine = remember(exams, myGroup) {
        exams.filter { it.groupName.isBlank() || it.groupName == myGroup }
    }
    val now = System.currentTimeMillis()
    val upcoming = remember(mine) { mine.filter { ExamUtil.endMillis(it) >= now }.sortedBy { ExamUtil.startMillis(it) } }
    val past = remember(mine) { mine.filter { ExamUtil.endMillis(it) < now }.sortedByDescending { ExamUtil.startMillis(it) } }
    var tab by remember { mutableStateOf(0) }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "جدول الامتحانات",
            subtitle = if (myGroup.isBlank()) "كل الكروبات" else "كروب $myGroup",
            modifier = Modifier.padding(horizontal = 20.dp),
            leading = {
                GlassIconButton(onClick = onBack, modifier = Modifier.testTag("exams_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                }
            }
        )

        if (mine.isEmpty()) {
            EmptyExams()
            return@Column
        }

        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(text = "القادمة (${upcoming.size})", selected = tab == 0, onClick = { tab = 0 })
            GlassChip(text = "السابقة (${past.size})", selected = tab == 1, onClick = { tab = 1 })
        }

        AnimatedContent(
            targetState = tab,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 4 * dir } + fadeIn(tween(260)))
                    .togetherWith(slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 4 * dir } + fadeOut(tween(160)))
            },
            label = "ExamTabs"
        ) { t ->
            val list = if (t == 0) upcoming else past
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(top = 60.dp), contentAlignment = Alignment.TopCenter) {
                    Text(
                        if (t == 0) "ما باقي امتحانات قادمة" else "لا توجد امتحانات سابقة",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(list, key = { _, e -> e.id }) { index, e ->
                        Column(Modifier.animateItemEntrance(index = index)) {
                            if (t == 0 && index == 0) {
                                NextExamHero(e)
                                Spacer(Modifier.height(12.dp))
                            }
                            val prev = list.getOrNull(index - 1)
                            val month = ExamUtil.parse(e.examDate)?.get(Calendar.MONTH)
                            val prevMonth = prev?.let { ExamUtil.parse(it.examDate)?.get(Calendar.MONTH) }
                            if (index == 0 || month != prevMonth) {
                                Text(
                                    "${ExamUtil.MONTHS.getOrElse(month ?: 0) { "" }} ${ExamUtil.parse(e.examDate)?.get(Calendar.YEAR) ?: ""}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(bottom = 8.dp, top = if (index == 0) 0.dp else 6.dp)
                                )
                            }
                            ExamCard(e, dimmed = t == 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyExams() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.EventAvailable, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(56.dp))
            Text("ما نزل جدول الامتحانات بعد", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text("راح يظهر هنا أول ما ينزّله المسؤول", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun NextExamHero(e: ExamEntity) {
    val days = ExamUtil.daysUntil(e).coerceAtLeast(0)
    val animated by animateFloatAsState(days.toFloat(), tween(900, easing = FastOutSlowInEasing), label = "countdown")
    val color = ExamUtil.typeColor(e.examType)
    val pulse = rememberInfiniteTransition(label = "heroPulse")
    val glow by pulse.animateFloat(0.10f, 0.22f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "heroGlow")
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(AppShapes.Card)
            .background(Brush.linearGradient(listOf(color.copy(alpha = glow + 0.12f), color.copy(alpha = 0.04f))))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("الامتحان القادم", style = MaterialTheme.typography.labelLarge, color = color, fontWeight = FontWeight.Bold)
        Text(e.subject, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (days == 0) {
                Text("اليوم", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold, color = color)
            } else {
                Text(animated.toInt().toString(), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.ExtraBold, color = color)
                Text(if (days == 1) "يوم" else "أيام", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
            }
        }
        Text(
            "${ExamUtil.parse(e.examDate)?.let { ExamUtil.dayName(it) } ?: ""} · ${ExamUtil.range(e)}" +
                if (e.hall.isNotBlank()) " · ${e.hall}" else "",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ExamCard(e: ExamEntity, dimmed: Boolean) {
    val cal = ExamUtil.parse(e.examDate)
    val color = ExamUtil.typeColor(e.examType)
    val days = ExamUtil.daysUntil(e)
    GlassCard(modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (dimmed) 0.62f else 1f }) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .width(58.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(color.copy(alpha = 0.14f))
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(cal?.get(Calendar.DAY_OF_MONTH)?.toString() ?: "-", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = color)
                Text(cal?.let { ExamUtil.dayName(it) } ?: "", style = MaterialTheme.typography.labelSmall, color = color)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(e.subject, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    TypePill(e.examType)
                }
                MetaLine(Icons.Default.Schedule, "${ExamUtil.range(e)}  ·  ${ExamUtil.duration(e.durationMin)}")
                if (e.hall.isNotBlank()) MetaLine(Icons.Default.MeetingRoom, e.hall)
                if (e.groupName.isNotBlank()) MetaLine(Icons.Default.CalendarMonth, "كروب ${e.groupName}")
                if (e.notes.isNotBlank()) {
                    Text(e.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (!dimmed && days in 0..3) {
                    Text(
                        when (days) { 0 -> "اليوم!"; 1 -> "باجر"; else -> "بعد $days أيام" },
                        style = MaterialTheme.typography.labelMedium, color = color, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun TypePill(type: String) {
    val c = ExamUtil.typeColor(type)
    Text(
        ExamTypes.label(type),
        style = MaterialTheme.typography.labelSmall,
        color = c,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

@Composable
private fun MetaLine(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminExamsPanel(
    exams: List<ExamEntity>,
    onSave: (ExamEntity, (String?) -> Unit) -> Unit,
    onDelete: (ExamEntity, (Boolean) -> Unit) -> Unit,
    onToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf<ExamEntity?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<ExamEntity?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("جدول الامتحانات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("يظهر للطلاب في حسابهم الشخصي (${exams.size} امتحان)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { error = null; creating = true }, shape = AppShapes.Small, modifier = Modifier.testTag("add_exam_button")) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("إضافة")
            }
        }

        if (exams.isEmpty()) {
            Text("ما أضفت أي امتحان بعد.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp))
        }

        exams.forEachIndexed { index, e ->
            val cal = ExamUtil.parse(e.examDate)
            val color = ExamUtil.typeColor(e.examType)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateItemEntrance(index = index)
                    .clip(AppShapes.Medium)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    Modifier.width(48.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.14f)).padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(cal?.get(Calendar.DAY_OF_MONTH)?.toString() ?: "-", fontWeight = FontWeight.ExtraBold, color = color)
                    Text(cal?.let { ExamUtil.MONTHS[it.get(Calendar.MONTH)].take(6) } ?: "", style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(e.subject, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text(
                        "${ExamTypes.label(e.examType)} · ${ExamUtil.range(e)}" +
                            (if (e.groupName.isNotBlank()) " · ${e.groupName}" else " · كل الكروبات") +
                            (if (e.hall.isNotBlank()) " · ${e.hall}" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { error = null; editing = e }) {
                    Icon(Icons.Default.Edit, "تعديل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { deleting = e }) {
                    Icon(Icons.Default.Delete, "حذف", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (creating || editing != null) {
        ExamEditorDialog(
            initial = editing,
            busy = busy,
            error = error,
            onDismiss = { if (!busy) { creating = false; editing = null } },
            onConfirm = { exam ->
                busy = true; error = null
                onSave(exam) { err ->
                    busy = false
                    if (err == null) {
                        creating = false; editing = null
                        onToast("تم حفظ الامتحان (${exam.subject})")
                    } else error = err
                }
            }
        )
    }
    deleting?.let { target ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف الامتحان") },
            text = { Text("حذف امتحان (${target.subject}) من جدول الطلاب؟") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    onDelete(target) { ok -> onToast(if (ok) "تم حذف الامتحان" else "تعذر الحذف، تأكد من الاتصال") }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExamEditorDialog(
    initial: ExamEntity?,
    busy: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: (ExamEntity) -> Unit
) {
    val context = LocalContext.current
    var subject by remember { mutableStateOf(initial?.subject ?: "") }
    var date by remember { mutableStateOf(initial?.examDate ?: "") }
    var hour by remember { mutableStateOf(initial?.startHour ?: 9) }
    var minute by remember { mutableStateOf(initial?.startMinute ?: 0) }
    var duration by remember { mutableStateOf((initial?.durationMin ?: 60).toString()) }
    var type by remember { mutableStateOf(initial?.examType ?: ExamTypes.FINAL) }
    var group by remember { mutableStateOf(initial?.groupName ?: "") }
    var hall by remember { mutableStateOf(initial?.hall ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    val durationInt = duration.toIntOrNull() ?: 0
    val valid = subject.isNotBlank() && ExamUtil.parse(date) != null && durationInt in 5..600

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = AppShapes.Card,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = { Text(if (initial == null) "إضافة امتحان" else "تعديل الامتحان", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("المادة", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ScheduleConstants.SUBJECTS.forEach { s ->
                        GlassChip(text = s, selected = subject == s, onClick = { subject = s })
                    }
                }
                OutlinedTextField(
                    value = subject, onValueChange = { subject = it },
                    label = { Text("اسم المادة") }, singleLine = true,
                    shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PickerBox("التاريخ", date.ifBlank { "اختر" }, Modifier.weight(1f)) {
                        val c = ExamUtil.parse(date) ?: Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d -> date = ExamUtil.format(y, m, d) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }
                    PickerBox("الوقت", ExamUtil.time(hour, minute), Modifier.weight(1f)) {
                        TimePickerDialog(context, { _, h, m -> hour = h; minute = m }, hour, minute, true).show()
                    }
                }
                OutlinedTextField(
                    value = duration, onValueChange = { duration = it.filter(Char::isDigit).take(3) },
                    label = { Text("المدة بالدقائق") }, singleLine = true,
                    isError = durationInt !in 5..600,
                    shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
                )

                Text("نوع الامتحان", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExamTypes.ALL.forEach { t -> GlassChip(text = ExamTypes.label(t), selected = type == t, onClick = { type = t }) }
                }

                Text("الكروب", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassChip(text = "الكل", selected = group.isBlank(), onClick = { group = "" })
                    ScheduleConstants.GROUPS.forEach { g -> GlassChip(text = g, selected = group == g, onClick = { group = g }) }
                }

                OutlinedTextField(
                    value = hall, onValueChange = { hall = it },
                    label = { Text("القاعة (اختياري)") }, singleLine = true,
                    shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes, onValueChange = { notes = it },
                    label = { Text("ملاحظات (اختياري)") }, minLines = 2, maxLines = 4,
                    shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
                )
                AnimatedVisibility(!error.isNullOrBlank(), enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Text(error.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = valid && !busy,
                shape = AppShapes.Small,
                onClick = {
                    onConfirm(
                        ExamEntity(
                            id = initial?.id ?: "ex_" + java.util.UUID.randomUUID().toString().replace("-", "").take(16),
                            subject = subject.trim(), examDate = date, startHour = hour, startMinute = minute,
                            durationMin = durationInt, examType = type, groupName = group,
                            hall = hall.trim(), notes = notes.trim(), updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            ) { Text(if (busy) "جاري الحفظ..." else "حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun PickerBox(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(
            Modifier
                .fillMaxWidth()
                .clip(AppShapes.Small)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                .clickable(onClick = onClick)
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) { Text(value, fontWeight = FontWeight.Bold) }
    }
}
