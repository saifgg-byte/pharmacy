package com.saifadnan.pharmacynotes.ui.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.util.PdfHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class ExportScope { CURRENT, ANNOTATED, ALL }

enum class ExportQuality(val maxSide: Int) { STANDARD(1600), HIGH(2400) }

class ExportResult(val path: String, val uri: Uri?)

object ReaderExport {

    fun pagesFor(scope: ExportScope, current: Int, total: Int, annotations: ReaderAnnotations): List<Int> = when (scope) {
        ExportScope.CURRENT -> listOf(current.coerceIn(0, (total - 1).coerceAtLeast(0)))
        ExportScope.ANNOTATED -> annotations.annotatedPages().filter { it in 0 until total }
        ExportScope.ALL -> (0 until total).toList()
    }

    suspend fun export(
        context: Context,
        session: PdfSession,
        annotations: ReaderAnnotations,
        pages: List<Int>,
        quality: ExportQuality,
        title: String,
        onProgress: (done: Int, total: Int) -> Unit
    ): ExportResult {
        val displayName = "$title - Edited"
        val tmp = withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, "ink_export").apply { mkdirs() }
            val out = File(dir, "export_${System.currentTimeMillis()}.pdf")
            val doc = PdfDocument()
            try {
                pages.forEachIndexed { i, p ->
                    ensureActive()
                    val full = session.renderFull(p, quality.maxSide)
                        ?: throw java.io.IOException("تعذر رسم الصفحة ${p + 1}")
                    val bmp = full.bitmap
                    try {
                        val c = Canvas(bmp)
                        InkRenderer.drawPage(
                            c, bmp.width.toFloat(), bmp.height.toFloat(),
                            annotations.strokes[p].orEmpty(),
                            annotations.texts.filter { it.page == p }
                        )
                        val info = PdfDocument.PageInfo.Builder(full.widthPt, full.heightPt, i + 1).create()
                        val page = doc.startPage(info)
                        page.canvas.drawBitmap(bmp, null, RectF(0f, 0f, full.widthPt.toFloat(), full.heightPt.toFloat()), null)
                        doc.finishPage(page)
                    } finally {
                        bmp.recycle()
                    }
                    onProgress(i + 1, pages.size)
                }
                FileOutputStream(out).use { doc.writeTo(it) }
            } finally {
                doc.close()
            }
            out
        }
        return withContext(Dispatchers.IO) {
            try {
                saveToDownloads(context, tmp, displayName)
            } finally {
                tmp.delete()
            }
        }
    }

    private fun saveToDownloads(context: Context, file: File, displayName: String): ExportResult {
        val safe = displayName.replace(Regex("[^a-zA-Z0-9_آ-ي -]"), "_") + ".pdf"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Mustansiriyah_Pharmacy")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return ExportResult("Download/Mustansiriyah_Pharmacy/$safe", uri)
            }
        }
        return ExportResult(PdfHelper.savePdfToPublicDeviceStorage(context, file, displayName), null)
    }

    fun open(context: Context, uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(i, "افتح ملف PDF بواسطة...").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "لم يتم العثور على تطبيق لقراءة ملفات PDF!", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun share(context: Context, uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(i, "مشاركة نسختي").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@Composable
fun ExportDialog(
    currentPage: Int,
    totalPages: Int,
    annotatedCount: Int,
    onStart: (ExportScope, ExportQuality) -> Unit,
    onDismiss: () -> Unit
) {
    var scope by remember { mutableStateOf(if (annotatedCount > 0) ExportScope.ANNOTATED else ExportScope.CURRENT) }
    var quality by remember { mutableStateOf(ExportQuality.STANDARD) }
    InkDialog(
        title = "تصدير نسخة",
        onDismiss = onDismiss,
        actions = {
            DialogButton("إلغاء", false, Modifier.weight(1f), onDismiss)
            DialogButton("تصدير", true, Modifier.weight(1f)) { onStart(scope, quality) }
        }
    ) {
        Text(
            "ينشئ ملف pdf يحتوي على التعديلات اللي سويتهن على المحاضرة",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceRow("الصفحة الحالية", "صفحة ${currentPage + 1}", scope == ExportScope.CURRENT, true) { scope = ExportScope.CURRENT }
            ChoiceRow(
                "الصفحات التي عدّلتها فقط",
                if (annotatedCount > 0) "$annotatedCount صفحة" else "لا توجد تعديلات بعد",
                scope == ExportScope.ANNOTATED, annotatedCount > 0
            ) { scope = ExportScope.ANNOTATED }
            ChoiceRow("المحاضرة كاملة", "$totalPages صفحة", scope == ExportScope.ALL, true) { scope = ExportScope.ALL }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("الجودة", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(end = 4.dp))
            QualityChip("عادية", quality == ExportQuality.STANDARD) { quality = ExportQuality.STANDARD }
            QualityChip("عالية", quality == ExportQuality.HIGH) { quality = ExportQuality.HIGH }
        }
    }
}

@Composable
private fun ChoiceRow(title: String, subtitle: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(14.dp)
    val border by animateColorAsState(
        if (selected) primary else CardBorder, tween(MotionSpecs.DurationQuick + 60), label = "choice_border"
    )
    val bg by animateColorAsState(
        if (selected) primary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f),
        tween(MotionSpecs.DurationQuick + 60), label = "choice_bg"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = if (selected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.4f)
            )
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QualityChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val bg by animateColorAsState(
        if (selected) primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f),
        tween(MotionSpecs.DurationQuick + 60), label = "q_bg"
    )
    Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected) primary else MaterialTheme.colorScheme.onSurface,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp)
    )
}

@Composable
fun ExportProgressDialog(done: Int, total: Int, onCancel: () -> Unit) {
    val target = if (total > 0) done.toFloat() / total else 0f
    val p by animateFloatAsState(target, tween(MotionSpecs.DurationMedium), label = "export_progress")
    InkDialog(
        title = "جاري تجهيز النسخة...",
        onDismiss = {},
        actions = { DialogButton("إلغاء", false, Modifier.weight(1f), onCancel) }
    ) {
        LinearProgressIndicator(
            progress = { p },
            modifier = Modifier
                .fillMaxWidth()
                .clip(CircleShape),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
        )
        Text("$done من $total", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ExportDoneDialog(result: ExportResult, onOpen: () -> Unit, onShare: () -> Unit, onDismiss: () -> Unit) {
    InkDialog(
        title = "تم حفظ نسختك",
        onDismiss = onDismiss,
        actions = {
            DialogButton("إغلاق", false, Modifier.weight(1f), onDismiss)
            if (result.uri != null) {
                DialogButton("مشاركة", false, Modifier.weight(1f), onShare)
                DialogButton("فتح", true, Modifier.weight(1f), onOpen)
            }
        }
    ) {
        Text(result.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}