package com.saifadnan.pharmacynotes.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import com.saifadnan.pharmacynotes.data.SupabaseClient.LibraryCard
import java.io.File
import java.io.FileOutputStream

object CardExport {
    private const val W = 1012
    private const val CARD_W_MM = 85.6f
    private const val CARD_H_MM = 54f

    fun render(card: LibraryCard, dark: Boolean = false): Bitmap {
        val k = W / CARD_W_MM
        val h = Math.round(CARD_H_MM * k)
        fun mm(v: Float) = v * k
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val layer = c.saveLayer(null, null)

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, W.toFloat(), h.toFloat(),
            if (dark) intArrayOf(0xFF0F1736.toInt(), 0xFF1A2662.toInt(), 0xFF2A3F8C.toInt())
            else intArrayOf(0xFF2E5A85.toInt(), 0xFF4A7BA6.toInt(), 0xFF6F9FD0.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W.toFloat(), h.toFloat(), p)
        p.shader = null
        p.color = Color.argb(23, 255, 255, 255)
        c.drawCircle(W - mm(8f), 0f, mm(30f), p)
        p.color = Color.argb(20, 255, 255, 255)
        c.drawCircle(mm(7f), h + mm(3f), mm(23f), p)

        val right = mm(81.1f)
        val left = mm(4.5f)
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        fun text(
            s: String, x: Float, cy: Float, sizeMm: Float, align: Paint.Align,
            alpha: Float, face: Typeface = Typeface.DEFAULT, spacing: Float = 0f
        ): Float {
            val t = Paint(Paint.ANTI_ALIAS_FLAG)
            t.color = Color.WHITE
            t.alpha = (alpha * 255).toInt()
            t.typeface = face
            t.textSize = mm(sizeMm)
            t.textAlign = align
            t.letterSpacing = spacing
            val baseline = cy - (t.ascent() + t.descent()) / 2f
            c.drawText(s, x, baseline, t)
            return t.measureText(s)
        }

        text("كلية الصيدلة · الجامعة المستنصرية", right, mm(6.32f), 2.9f, Paint.Align.RIGHT, 0.95f, bold)
        text("بطاقة المكتبة", left, mm(6.32f), 2.5f, Paint.Align.LEFT, 0.85f)

        val cy = mm(27.16f)

        val qs = mm(27f)
        val qy = cy - qs / 2f
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        c.drawRoundRect(RectF(left, qy, left + qs, qy + qs), mm(2.6f), mm(2.6f), white)
        val m = QrCode.matrix(card.payload)
        val n = m.size
        if (n > 0) {
            val s = (qs - mm(3.2f)) / (n + 4)
            val ox = left + mm(1.6f)
            val oy = qy + mm(1.6f)
            val dark = Paint().apply { color = Color.BLACK; isAntiAlias = false }
            for (y in 0 until n) for (x in 0 until n) {
                if (m[y][x]) {
                    val x0 = Math.round(ox + (x + 2) * s).toFloat()
                    val x1 = Math.round(ox + (x + 3) * s).toFloat()
                    val y0 = Math.round(oy + (y + 2) * s).toFloat()
                    val y1 = Math.round(oy + (y + 3) * s).toFloat()
                    c.drawRect(x0, y0, x1, y1, dark)
                }
            }
        }

        val maxW = (right - (left + qs + mm(4f))).toInt()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = bold
            textSize = mm(4.6f)
        }
        val name = card.name.ifBlank { "—" }
        val layout = StaticLayout.Builder.obtain(name, 0, name.length, tp, maxW)
            .setMaxLines(2)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setLineSpacing(0f, 1.1f)
            .build()
        val lhR = mm(2.9f * 1.7f)
        val rows = listOf("الكروب" to card.group, "رقم الطالب" to card.studentId)
        val total = layout.height + mm(2f) + rows.size * lhR
        var y = cy - total / 2f
        c.save()
        c.translate(right - maxW, y)
        layout.draw(c)
        c.restore()
        y += layout.height + mm(2f)
        for ((label, value) in rows) {
            val lw = text(label, right, y + lhR / 2f, 2.9f, Paint.Align.RIGHT, 0.8f, bold)
            text(value.ifBlank { "—" }, right - lw - mm(1.5f), y + lhR / 2f, 2.9f, Paint.Align.RIGHT, 0.95f)
            y += lhR
        }

        text(
            QrCode.formatCode(card.code), left, mm(47.84f), 2.7f, Paint.Align.LEFT, 0.9f,
            Typeface.MONOSPACE, 0.08f
        )

        if (dark) {
            val sw = mm(0.5f)
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = sw
                color = Color.argb(56, 255, 255, 255)
            }
            c.drawRoundRect(
                RectF(sw / 2f, sw / 2f, W - sw / 2f, h - sw / 2f),
                mm(4.2f) - sw / 2f, mm(4.2f) - sw / 2f, ring
            )
        }

        val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        val maskBmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        Canvas(maskBmp).drawRoundRect(
            RectF(0f, 0f, W.toFloat(), h.toFloat()), mm(4.2f), mm(4.2f),
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        )
        c.drawBitmap(maskBmp, 0f, 0f, mask)
        c.restoreToCount(layer)
        maskBmp.recycle()
        return bmp
    }

        fun print(context: Context, card: LibraryCard, cardSize: Boolean, dark: Boolean = false) {
        val pm = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val bmp = render(card, dark)
        val media = if (cardSize) PrintAttributes.MediaSize("PH_CARD", "بطاقة 85.6×54 مم", 3370, 2126)
        else PrintAttributes.MediaSize.ISO_A4
        val attrs = PrintAttributes.Builder()
            .setMediaSize(media)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        pm.print("بطاقة المكتبة", CardPrintAdapter(bmp), attrs)
    }

    private class CardPrintAdapter(private val bmp: Bitmap) : PrintDocumentAdapter() {
        private var media: PrintAttributes.MediaSize = PrintAttributes.MediaSize.ISO_A4

        override fun onLayout(
            oldAttributes: PrintAttributes?, newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback.onLayoutCancelled()
                return
            }
            newAttributes.mediaSize?.let { media = it }
            val info = PrintDocumentInfo.Builder("library_card.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(1)
                .build()
            callback.onLayoutFinished(info, oldAttributes != newAttributes)
        }

        override fun onWrite(
            pages: Array<out PageRange>, destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal?, callback: WriteResultCallback
        ) {
            val pdf = PdfDocument()
            try {
                val pw = Math.round(media.widthMils * 72f / 1000f)
                val ph = Math.round(media.heightMils * 72f / 1000f)
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, 0).create())
                val cw = CARD_W_MM / 25.4f * 72f
                val ch = CARD_H_MM / 25.4f * 72f
                val cv = page.canvas
                val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                if (pw <= cw * 1.15f) {

                    val sc = minOf(pw / cw, ph / ch)
                    val dw = cw * sc
                    val dh = ch * sc
                    val l = (pw - dw) / 2f
                    val t = (ph - dh) / 2f
                    cv.drawBitmap(bmp, null, RectF(l, t, l + dw, t + dh), bp)
                } else {

                    val l = (pw - cw) / 2f
                    val t = 48f
                    cv.drawBitmap(bmp, null, RectF(l, t, l + cw, t + ch), bp)
                    val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = Color.argb(150, 120, 120, 120)
                        strokeWidth = 0.6f
                        pathEffect = android.graphics.DashPathEffect(floatArrayOf(4f, 3f), 0f)
                    }
                    cv.drawRect(l - 4f, t - 4f, l + cw + 4f, t + ch + 4f, guide)
                }
                pdf.finishPage(page)
                FileOutputStream(destination.fileDescriptor).use { pdf.writeTo(it) }
                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            } finally {
                pdf.close()
            }
        }
    }

    private fun fileName(card: LibraryCard) = "library_card_" + card.code.ifBlank { "student" } + ".png"

        fun saveToGallery(context: Context, card: LibraryCard, dark: Boolean = false): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val bmp = render(card, dark)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName(card))
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pharmacy")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }

        fun share(context: Context, card: LibraryCard, dark: Boolean = false) {
        try {
            val dir = File(context.cacheDir, "shared_cards").apply { mkdirs() }
            val file = File(dir, fileName(card))
            FileOutputStream(file).use { render(card, dark).compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "مشاركة بطاقة المكتبة"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
