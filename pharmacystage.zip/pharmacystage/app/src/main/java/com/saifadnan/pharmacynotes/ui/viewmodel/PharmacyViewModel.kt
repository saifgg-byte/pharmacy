package com.saifadnan.pharmacynotes.ui.viewmodel

import com.saifadnan.pharmacynotes.util.AdminConfig
import kotlinx.coroutines.isActive
import com.saifadnan.pharmacynotes.util.JwtUtils
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.saifadnan.pharmacynotes.data.AppDatabase
import com.saifadnan.pharmacynotes.data.BroadcastNotificationEntity
import com.saifadnan.pharmacynotes.data.Category
import com.saifadnan.pharmacynotes.data.NewLectureRequest
import com.saifadnan.pharmacynotes.data.Section
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.data.PharmacyRepository
import com.saifadnan.pharmacynotes.data.ScheduleEntity
import com.saifadnan.pharmacynotes.data.ExamEntity
import com.saifadnan.pharmacynotes.data.SubjectEntity
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.util.ClassAlarmScheduler
import com.saifadnan.pharmacynotes.util.ClassReminderSettings
import com.saifadnan.pharmacynotes.util.PdfHelper
import com.saifadnan.pharmacynotes.util.SessionManager
import com.saifadnan.pharmacynotes.util.SystemNotificationHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortOrder {
    NEWEST_FIRST,
    OLDEST_FIRST,
    ALPHABETICAL
}

class PharmacyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PharmacyRepository
    private val sessionManager = SessionManager(application)

    private val _isDarkMode = MutableStateFlow(sessionManager.isDarkMode())
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        val newMode = !_isDarkMode.value
        _isDarkMode.value = newMode
        sessionManager.setDarkMode(newMode)
    }

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loginErrorMessage = MutableStateFlow<String?>(null)
    val loginErrorMessage: StateFlow<String?> = _loginErrorMessage.asStateFlow()

    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _stages = MutableStateFlow<List<com.saifadnan.pharmacynotes.data.StageInfo>>(com.saifadnan.pharmacynotes.data.Stages.ALL)
    val stages: StateFlow<List<com.saifadnan.pharmacynotes.data.StageInfo>> = _stages.asStateFlow()

    init {
        com.saifadnan.pharmacynotes.data.Stages.current = sessionManager.getStage()
        SupabaseClient.setDeviceId(sessionManager.getOrCreateDeviceId())
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = PharmacyRepository(db, application)

        viewModelScope.launch {
            SupabaseClient.getStages()?.let { _stages.value = it }
        }

        viewModelScope.launch {
            repository.allLectures.collect { lectures ->
                val pendingId = _pendingLectureId.value
                if (pendingId != null && lectures.isNotEmpty()) {
                    lectures.find { it.id == pendingId }?.let { target ->
                        selectLecture(target)
                        _pendingLectureId.value = null
                    }
                }
            }
        }

        viewModelScope.launch {
            val processedNotifIds = mutableSetOf<Long>()

            repository.allNotifications.collect { notifList ->
                val now = System.currentTimeMillis()
                notifList.forEach { notif ->
                    if (!processedNotifIds.contains(notif.id)) {
                        processedNotifIds.add(notif.id)
                        if (now - notif.timestamp < 30_000) {
                            _latestBroadcastAlert.emit(notif)
                            SystemNotificationHelper.sendSystemNotification(
                                context = application,
                                notificationId = (notif.id.hashCode() and 0x7FFFFFFF),
                                title = notif.title,
                                message = notif.message,
                                lectureId = notif.lectureId
                            )
                        }
                    }
                }
            }
        }

        viewModelScope.launch {
            val banPrefs = application.getSharedPreferences("pharmacy_ban_notified", Context.MODE_PRIVATE)
            val seen = (banPrefs.getStringSet("keys", emptySet()) ?: emptySet()).toMutableSet()
            repository.banRequests.collect { list ->
                val isMain = com.saifadnan.pharmacynotes.util.AdminConfig.isMainAdmin(_currentUser.value?.email)
                var changed = false
                list.forEach { r ->
                    val key = "${r.id}:${r.status}"
                    if (!seen.add(key)) return@forEach
                    changed = true
                    val (title, msg) = when {
                        isMain && r.status == "PENDING" ->
                            "طلب حظر طالب" to "${r.requestedByName} يطلب حظر ${r.targetName}. افتح إدارة الطلاب للقبول أو الرفض."
                        !isMain && r.status == "APPROVED" ->
                            "تمت الموافقة على الحظر" to "وافق الأدمن الرئيسي على حظر ${r.targetName}."
                        !isMain && r.status == "REJECTED" ->
                            "تم رفض طلب الحظر" to "رفض الأدمن الرئيسي حظر ${r.targetName}."
                        else -> return@forEach
                    }
                    SystemNotificationHelper.sendSystemNotification(
                        context = application,
                        notificationId = (key.hashCode() and 0x7FFFFFFF),
                        title = title,
                        message = msg
                    )
                }
                if (changed) banPrefs.edit().putStringSet("keys", seen.toSet()).apply()
            }
        }

        viewModelScope.launch {
            repository.allStudents.collect { students ->
                val current = _currentUser.value
                if (current != null && current.role != "ADMIN" && _isLoggedIn.value) {
                    val dbUser = students.find {
                        it.email.equals(current.email, ignoreCase = true) ||
                        (it.studentId.isNotBlank() && it.studentId == current.studentId) ||
                        (it.fullName.isNotBlank() && it.fullName.trim().equals(current.fullName.trim(), ignoreCase = true))
                    }
                    if (dbUser != null && !dbUser.isApproved) {
                        logout()
                        _loginErrorMessage.value = "تم حظر حسابك!."
                    }
                }
            }
        }

        if (sessionManager.isLoggedIn() && sessionManager.getAccessToken().isNullOrBlank()) {
            sessionManager.clearSession()
        }
        if (sessionManager.isLoggedIn()) {
            val email = sessionManager.getUserEmail() ?: ""
            val claimsAdmin = AdminConfig.isAdminEmail(email) || AdminConfig.isAdminRole(sessionManager.getUserRole())
            val isRealAdmin = claimsAdmin && hasVerifiedAdminSession()
            if (claimsAdmin && !isRealAdmin) sessionManager.clearSession()
            val role = if (isRealAdmin) "ADMIN" else "STUDENT"
            val name = sessionManager.getUserName()
            val studentId = sessionManager.getStudentId()
            val authUid = sessionManager.getAuthUid() ?: ""

            if (email.isNotEmpty() && (isRealAdmin || !claimsAdmin)) {
                val cachedUser = UserEntity(
                    email = email,
                    fullName = name.ifBlank { if (isRealAdmin) "سيف عدنان" else "طالب صيدلة" },
                    studentId = studentId,
                    role = role,
                    authUid = authUid,
                    groupName = sessionManager.getSavedGroupName() ?: ""
                )
                _currentUser.value = cachedUser
                _isAdminMode.value = isRealAdmin
                _isLoggedIn.value = true

                SupabaseClient.setAdminAccessToken(sessionManager.getAccessToken())
                startAdminTokenMaintenance()

                viewModelScope.launch {
                    val dbUser = repository.getUserByEmail(email)
                    if (dbUser != null) {
                        val updatedUser = dbUser.copy(role = role)
                        _currentUser.value = updatedUser
                        _isAdminMode.value = isRealAdmin
                    } else {
                        repository.registerUser(
                            email = email,
                            fullName = cachedUser.fullName,
                            studentId = cachedUser.studentId,
                            role = role,
                            authUid = authUid
                        )
                    }
                }
            }
        }
    }

    private fun isAdminUser(user: UserEntity?): Boolean =
        user != null && (AdminConfig.isAdminEmail(user.email) || AdminConfig.isAdminRole(user.role))

    fun toggleAdminMode() {
        if (isAdminUser(_currentUser.value) && SupabaseClient.hasAdminSession()) {
            _isAdminMode.value = !_isAdminMode.value
        }
    }

    private var adminFailedAttempts = 0
    private var adminLockedUntilMs = 0L
    private var tokenJob: kotlinx.coroutines.Job? = null

    private fun hasVerifiedAdminSession(): Boolean {
        val access = sessionManager.getAccessToken()
        if (access.isNullOrBlank()) return false
        if (!AdminConfig.isAdminEmail(JwtUtils.email(access)) && !AdminConfig.isAdminRole(JwtUtils.role(access))) return false
        val expiry = sessionManager.getTokenExpiryMs().takeIf { it > 0 } ?: JwtUtils.expiryMs(access)
        val notExpired = expiry > System.currentTimeMillis()
        return notExpired || !sessionManager.getRefreshToken().isNullOrBlank()
    }

    private fun startAdminTokenMaintenance() {
        tokenJob?.cancel()
        tokenJob = viewModelScope.launch {
            while (isActive) {
                val expiry = sessionManager.getTokenExpiryMs()
                    .takeIf { it > 0 } ?: JwtUtils.expiryMs(sessionManager.getAccessToken())
                val wait = (expiry - 5 * 60_000L) - System.currentTimeMillis()
                if (wait > 0) {
                    kotlinx.coroutines.delay(minOf(wait, 60_000L))
                    continue
                }
                val refresh = sessionManager.getRefreshToken()
                if (refresh.isNullOrBlank()) {
                    if (System.currentTimeMillis() >= expiry) {
                        logout()
                        _loginErrorMessage.value = "انتهت الجلسة. سجّل الدخول من جديد."
                    }
                    return@launch
                }
                val res = SupabaseClient.refreshSession(refresh)
                if (res.isSuccess && !res.accessToken.isNullOrBlank()) {
                    val newExpiry = if (res.expiresAtMs > 0) res.expiresAtMs else JwtUtils.expiryMs(res.accessToken)
                    sessionManager.saveAdminTokens(res.accessToken, res.refreshToken, newExpiry)
                    SupabaseClient.setAdminAccessToken(res.accessToken)
                } else if (res.isAuthRejected) {
                    logout()
                    _loginErrorMessage.value = "انتهت الجلسة. سجّل الدخول من جديد."
                    return@launch
                } else {
                    kotlinx.coroutines.delay(30_000L)
                }
            }
        }
    }

    fun approveStudent(student: UserEntity) {
        viewModelScope.launch {
            repository.approveUser(student)
            repository.refreshUsers()
        }
    }

    val banRequests: StateFlow<List<com.saifadnan.pharmacynotes.data.SupabaseClient.BanRequest>> =
        repository.banRequests

    private val _adminMessage = kotlinx.coroutines.flow.MutableSharedFlow<String>(extraBufferCapacity = 8)
    val adminMessage: kotlinx.coroutines.flow.SharedFlow<String> = _adminMessage

    private suspend fun blockAndReport(student: UserEntity) {
        val r = repository.blockUser(student)
        when {
            !r.ok -> _adminMessage.emit(r.message ?: "تعذر تنفيذ الحظر.")
            r.pending -> _adminMessage.emit("أُرسل طلب حظر «${student.fullName}» إلى الأدمن الرئيسي بانتظار موافقته.")
        }
        repository.refreshUsers()
    }

    fun rejectStudent(student: UserEntity) {
        viewModelScope.launch { blockAndReport(student) }
    }

    fun blockStudent(student: UserEntity) {
        viewModelScope.launch { blockAndReport(student) }
    }

    fun decideBanRequest(id: Long, approve: Boolean) {
        viewModelScope.launch {
            val r = repository.decideBanRequest(id, approve)
            if (!r.ok) _adminMessage.emit(r.message ?: "تعذر تنفيذ العملية.")
        }
    }

    fun refreshUsers() {
        viewModelScope.launch {
            repository.refreshUsers()
        }
    }

    fun login(
        emailOrCode: String,
        password: String,
        studentName: String = "",
        studentId: String = "",
        isSignUpMode: Boolean = false,
        idCardUrl: String = "",
        groupName: String = "",
        stage: Int = com.saifadnan.pharmacynotes.data.Stages.current
    ) {
        _loginErrorMessage.value = null
        val identifier = emailOrCode.trim()
        val autoLogin = stage == com.saifadnan.pharmacynotes.data.Stages.AUTO && !isSignUpMode
        if (!autoLogin) com.saifadnan.pharmacynotes.data.Stages.current = stage

        if (identifier.isBlank()) {
            _loginErrorMessage.value = "يرجى إدخال البريد الإلكتروني أو الرقم الجامعي."
            return
        }
        if (password.isBlank()) {
            _loginErrorMessage.value = "يرجى إدخال كلمة المرور."
            return
        }
        if (!autoLogin && !com.saifadnan.pharmacynotes.data.Stages.isValid(stage)) {
            _loginErrorMessage.value = "اختر مرحلة دراسية صحيحة."
            return
        }

        viewModelScope.launch {
            var effStage = stage
            var effGroup = groupName.trim()
            val isMainAdminInput = AdminConfig.isAdminEmail(identifier)
            val now = System.currentTimeMillis()
            if (isMainAdminInput && now < adminLockedUntilMs) {
                val secs = ((adminLockedUntilMs - now) / 1000L).coerceAtLeast(1L)
                _loginErrorMessage.value = "محاولات كثيرة. انتظر $secs ثانية ثم أعد المحاولة."
                return@launch
            }

            val auth = try {
                if (isSignUpMode) {
                    if (studentName.isBlank() || studentId.isBlank()) {
                        _loginErrorMessage.value = "أدخل اسم الطالب والرقم الجامعي لإنشاء الحساب."
                        return@launch
                    }
                    if (groupName.isBlank()) {
                        _loginErrorMessage.value = "اختر مجموعتك الدراسية قبل إنشاء الحساب."
                        return@launch
                    }
                    SupabaseClient.signUpWithSupabase(
                        email = identifier,
                        password = password,
                        fullName = studentName,
                        studentId = studentId,
                        groupName = groupName.trim()
                    )
                } else if (autoLogin) {
                    SupabaseClient.signInAuto(identifier, password)
                } else {
                    SupabaseClient.signInWithSupabase(identifier, password, groupName.trim())
                }
            } catch (e: Exception) {
                _loginErrorMessage.value = if (isSignUpMode) {
                    "تعذر الاتصال بالخادم لإنشاء الحساب."
                } else "تعذر الاتصال بالخادم للتحقق من بيانات الدخول."
                return@launch
            }
            val token = auth.accessToken
            val serverUser = auth.user
            if (!auth.isSuccess || token.isNullOrBlank() || serverUser == null) {
                if (isMainAdminInput && auth.isAuthRejected) {
                    adminFailedAttempts++
                    if (adminFailedAttempts >= 5) {
                        adminLockedUntilMs = System.currentTimeMillis() + 60_000L * minOf(adminFailedAttempts - 4, 10)
                    }
                }
                _loginErrorMessage.value = auth.errorMessage ?: "البريد الإلكتروني/الرقم الجامعي أو كلمة المرور غير صحيحة."
                return@launch
            }

            if (autoLogin) {
                if (!com.saifadnan.pharmacynotes.data.Stages.isValid(auth.stage)) {
                    _loginErrorMessage.value = "تعذر تحديد مرحلة حسابك. تواصل مع الإدارة."
                    return@launch
                }
                effStage = auth.stage
                com.saifadnan.pharmacynotes.data.Stages.current = effStage
                effGroup = serverUser.groupName.trim()
            }

            val verifiedEmail = JwtUtils.email(token) ?: auth.email ?: serverUser.email
            val isAdminAccount = AdminConfig.isAdminEmail(verifiedEmail) ||
                AdminConfig.isAdminRole(JwtUtils.role(token)) ||
                AdminConfig.isAdminRole(serverUser.role)

            if (isAdminAccount) {
                if (verifiedEmail.isBlank()) {
                    _loginErrorMessage.value = "تعذر التحقق من هوية حساب الإدارة."
                    return@launch
                }
                if (isMainAdminInput) {
                    adminFailedAttempts = 0
                    adminLockedUntilMs = 0L
                }
                val expiry = if (auth.expiresAtMs > 0) auth.expiresAtMs else JwtUtils.expiryMs(token)
                val adminUser = UserEntity(
                    email = verifiedEmail,
                    fullName = serverUser.fullName.takeIf { it.isNotBlank() }
                        ?: if (AdminConfig.isAdminEmail(verifiedEmail)) "سيف عدنان" else "أدمن",
                    studentId = serverUser.studentId.takeIf { it.isNotBlank() } ?: "ADMIN",
                    role = "ADMIN",
                    isApproved = true,
                    authUid = auth.userId ?: serverUser.authUid
                )

                SupabaseClient.setAdminAccessToken(token)
                sessionManager.saveSession(
                    email = adminUser.email,
                    fullName = adminUser.fullName,
                    studentId = adminUser.studentId,
                    role = "ADMIN",
                    accessToken = token,
                    authUid = adminUser.authUid
                )
                sessionManager.saveAdminTokens(token, auth.refreshToken, expiry)
                prepareStageCache(effStage)
                repository.registerUser(
                    email = adminUser.email,
                    fullName = adminUser.fullName,
                    studentId = adminUser.studentId,
                    role = "ADMIN",
                    authUid = adminUser.authUid,
                    isApproved = true
                )
                _currentUser.value = adminUser
                _isAdminMode.value = true
                _isLoggedIn.value = true
                _selectedTab.value = "HOME"
                startAdminTokenMaintenance()
                return@launch
            }

            if (!serverUser.isApproved) {
                _loginErrorMessage.value = "حسابك بانتظار موافقة الإدارة أو تم إيقافه."
                return@launch
            }
            if (effGroup.isBlank()) {
                _loginErrorMessage.value = if (autoLogin) {
                    com.saifadnan.pharmacynotes.data.Stages.NEED_GROUP
                } else "اختر مجموعتك الدراسية قبل تسجيل الدخول."
                return@launch
            }

            val expiry = if (auth.expiresAtMs > 0) auth.expiresAtMs else JwtUtils.expiryMs(token)
            SupabaseClient.setAdminAccessToken(token)
            sessionManager.saveSession(
                email = serverUser.email,
                fullName = serverUser.fullName,
                studentId = serverUser.studentId,
                role = "STUDENT",
                accessToken = token,
                authUid = serverUser.authUid
            )
            sessionManager.saveAdminTokens(token, auth.refreshToken, expiry)
            sessionManager.saveGroupName(effGroup)
            prepareStageCache(effStage)
            repository.cacheUser(serverUser.copy(groupName = effGroup))
            _currentUser.value = serverUser.copy(groupName = effGroup)
            _isAdminMode.value = false
            _isLoggedIn.value = true
            _selectedTab.value = "HOME"
            startAdminTokenMaintenance()
        }
    }

    private suspend fun prepareStageCache(stage: Int) {
        sessionManager.saveStage(stage)
        if (sessionManager.getCacheStage() != stage) {
            repository.resetForStageChange()
            sessionManager.saveCacheStage(stage)
        }
    }

    fun switchStage(stage: Int, onResult: (String?) -> Unit) {
        if (stage == com.saifadnan.pharmacynotes.data.Stages.current) {
            onResult(null)
            return
        }
        viewModelScope.launch {
            val auth = SupabaseClient.switchStage(stage)
            val token = auth.accessToken
            if (!auth.isSuccess || token.isNullOrBlank()) {
                onResult(auth.errorMessage ?: "تعذر تبديل المرحلة.")
                return@launch
            }
            val expiry = if (auth.expiresAtMs > 0) auth.expiresAtMs else JwtUtils.expiryMs(token)
            com.saifadnan.pharmacynotes.data.Stages.current = stage
            SupabaseClient.setAdminAccessToken(token)
            sessionManager.saveAdminTokens(token, auth.refreshToken, expiry)
            sessionManager.saveStage(stage)
            repository.resetForStageChange()
            sessionManager.saveCacheStage(stage)
            auth.user?.let { repository.cacheUser(it) }
            _selectedTab.value = "HOME"
            onResult(null)
        }
    }

    fun updateProfile(
        fullName: String?,
        email: String?,
        studentId: String?,
        stage: Int?,
        currentPassword: String,
        newPassword: String?,
        onResult: (String?) -> Unit
    ) {
        val user = _currentUser.value
        if (user == null || user.role == "ADMIN") {
            onResult("هذا الحساب لا يمكن تعديله من هنا.")
            return
        }
        viewModelScope.launch {
            val auth = SupabaseClient.updateProfile(fullName, email, studentId, stage, currentPassword, newPassword)
            val token = auth.accessToken
            val serverUser = auth.user
            if (!auth.isSuccess || token.isNullOrBlank() || serverUser == null) {
                onResult(auth.errorMessage ?: "تعذر حفظ التعديلات.")
                return@launch
            }
            val newStage = if (com.saifadnan.pharmacynotes.data.Stages.isValid(auth.stage)) auth.stage
            else com.saifadnan.pharmacynotes.data.Stages.current
            val stageChanged = newStage != com.saifadnan.pharmacynotes.data.Stages.current
            val expiry = if (auth.expiresAtMs > 0) auth.expiresAtMs else JwtUtils.expiryMs(token)

            com.saifadnan.pharmacynotes.data.Stages.current = newStage
            SupabaseClient.setAdminAccessToken(token)
            sessionManager.saveSession(
                email = serverUser.email,
                fullName = serverUser.fullName,
                studentId = serverUser.studentId,
                role = "STUDENT",
                accessToken = token,
                authUid = serverUser.authUid
            )
            sessionManager.saveAdminTokens(token, auth.refreshToken, expiry)

            val updated = serverUser.copy(groupName = serverUser.groupName.ifBlank { user.groupName })
            if (stageChanged) {
                sessionManager.saveStage(newStage)
                repository.resetForStageChange()
                sessionManager.saveCacheStage(newStage)
                repository.cacheUser(updated)
            } else {
                repository.replaceCachedUser(user.email, updated)
            }
            _currentUser.value = updated
            if (stageChanged) _selectedTab.value = "HOME"
            startAdminTokenMaintenance()
            onResult(null)
        }
    }

    fun logout() {
        tokenJob?.cancel()
        tokenJob = null
        sessionManager.clearSession()
        SupabaseClient.clearAdminAccessToken()
        _currentUser.value = null
        _isLoggedIn.value = false
        _isAdminMode.value = false
        _selectedTab.value = "HOME"
    }

    private val _selectedTab = MutableStateFlow("HOME")
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _isTabLoading = MutableStateFlow(false)
    val isTabLoading: StateFlow<Boolean> = _isTabLoading.asStateFlow()

    fun setSelectedTab(tab: String) {
        val isRealAdmin = isAdminUser(_currentUser.value) && SupabaseClient.hasAdminSession()
        val targetTab = if (tab == "ADMIN" && !isRealAdmin) "HOME" else tab

        if (_selectedTab.value != targetTab) {
            _selectedTab.value = targetTab
            _isTabLoading.value = true
            viewModelScope.launch {
                kotlinx.coroutines.delay(280)
                _isTabLoading.value = false
            }
        }
        if (targetTab == "NOTIFICATIONS") {
            markNotificationsRead()
        }
    }

    private val _selectedSection = MutableStateFlow(Section.THEORY)
    val selectedSection: StateFlow<String> = _selectedSection.asStateFlow()

    private val _selectedCategory = MutableStateFlow(Category.OFFICIAL)
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    fun selectSection(section: String) {
        if (_selectedSection.value != section) {
            _selectedSection.value = section
            _selectedSubject.value = null
            _selectedCategory.value = Category.OFFICIAL
            _searchQuery.value = ""
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    private val _selectedSubject = MutableStateFlow<String?>(null)
    val selectedSubject: StateFlow<String?> = _selectedSubject.asStateFlow()

    fun selectSubject(subjectName: String?) {
        if (_selectedSubject.value != subjectName) {
            _selectedSubject.value = subjectName
            _selectedCategory.value = Category.OFFICIAL
            _isTabLoading.value = true
            viewModelScope.launch {
                kotlinx.coroutines.delay(200)
                _isTabLoading.value = false
            }
        }
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private val _selectedSemester = MutableStateFlow(sessionManager.getCourse())
    val selectedSemester: StateFlow<Int> = _selectedSemester.asStateFlow()

    fun setSelectedSemester(semester: Int) {
        val course = if (semester == 2) 2 else 1
        if (_selectedSemester.value == course) return
        sessionManager.saveCourse(course)
        _selectedSemester.value = course
        _selectedSubject.value = null
        _selectedCategory.value = Category.OFFICIAL
        _searchQuery.value = ""
    }

    private val _onlyDownloaded = MutableStateFlow(false)
    val onlyDownloaded: StateFlow<Boolean> = _onlyDownloaded.asStateFlow()

    fun toggleOnlyDownloaded() {
        _onlyDownloaded.value = !_onlyDownloaded.value
    }

    private val _onlyBookmarked = MutableStateFlow(false)
    val onlyBookmarked: StateFlow<Boolean> = _onlyBookmarked.asStateFlow()

    fun toggleOnlyBookmarked() {
        _onlyBookmarked.value = !_onlyBookmarked.value
    }

    private val _sortOrder = MutableStateFlow(SortOrder.OLDEST_FIRST)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
    }

    private fun sortSubjects(subjects: List<SubjectEntity>, order: SortOrder): List<SubjectEntity> {
        val bySelectedOrder: Comparator<SubjectEntity> = when (order) {
            SortOrder.NEWEST_FIRST -> compareByDescending { it.addedAt }
            SortOrder.OLDEST_FIRST -> compareBy { it.addedAt }
            SortOrder.ALPHABETICAL -> compareBy { it.name.lowercase() }
        }
        return subjects.sortedWith(
            compareBy<SubjectEntity> { com.saifadnan.pharmacynotes.util.LectureOrder.subjectPriorityGroup(it.name) }
                .then(bySelectedOrder)
        )
    }

    val allSubjects: StateFlow<List<SubjectEntity>> = combine(
        repository.allSubjects,
        _sortOrder,
        _selectedSection,
        _selectedSemester
    ) { subjects, order, section, semester ->
        sortSubjects(subjects.filter { it.section == section && it.semester == semester }, order)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val subjectsAllSections: StateFlow<List<SubjectEntity>> = combine(
        repository.allSubjects,
        _sortOrder
    ) { subjects, order -> sortSubjects(subjects, order) }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val examPinnedSubjects: StateFlow<List<SubjectEntity>> = repository.examPinnedSubjects.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allLectures: StateFlow<List<LectureEntity>> = repository.allLectures.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allStudents: StateFlow<List<UserEntity>> = repository.allStudents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allAdmins: StateFlow<List<UserEntity>> = repository.allAdmins.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private data class BaseFilter(
        val subject: String?,
        val query: String,
        val semester: Int,
        val downloadedOnly: Boolean,
        val bookmarkedOnly: Boolean
    )

    private data class LectureFilterState(
        val base: BaseFilter,
        val section: String,
        val category: String
    )

    private val lectureFilterState: Flow<LectureFilterState> = combine(
        combine(
            _selectedSubject,
            _searchQuery,
            _selectedSemester,
            _onlyDownloaded,
            _onlyBookmarked
        ) { subject, query, semester, downloadedOnly, bookmarkedOnly ->
            BaseFilter(subject, query, semester, downloadedOnly, bookmarkedOnly)
        },
        _selectedSection,
        _selectedCategory
    ) { base, section, category -> LectureFilterState(base, section, category) }

    val filteredLectures: StateFlow<List<LectureEntity>> = combine(
        allLectures,
        lectureFilterState
    ) { lectures, state ->
        val f = state.base
        val inFolder = f.subject != null
        lectures.filter { lecture ->

            val matchesFolder = !inFolder ||
                (lecture.subject == f.subject && lecture.section == state.section && lecture.category == state.category)
            val matchesSemester = !(inFolder || f.query.isNotBlank()) || lecture.semester == f.semester
            val matchesQuery = f.query.isBlank() ||
                    com.saifadnan.pharmacynotes.util.ArabicSearch.matches(lecture.title, f.query) ||
                    com.saifadnan.pharmacynotes.util.ArabicSearch.matches(lecture.subject, f.query) ||
                    com.saifadnan.pharmacynotes.util.ArabicSearch.matches(lecture.doctorName, f.query)
            val matchesDownload = !f.downloadedOnly || lecture.isDownloaded
            val matchesBookmark = !f.bookmarkedOnly || lecture.isBookmarked
            matchesFolder && matchesQuery && matchesSemester && matchesDownload && matchesBookmark
        }
    }.combine(_sortOrder) { filtered, order ->
        when (order) {
            SortOrder.NEWEST_FIRST -> filtered.sortedByDescending { it.uploadTimestamp }
            SortOrder.OLDEST_FIRST -> filtered.sortedBy { it.uploadTimestamp }
            SortOrder.ALPHABETICAL -> filtered.sortedBy { it.title.lowercase() }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val categoryCounts: StateFlow<Map<String, Int>> = combine(
        allLectures,
        _selectedSubject,
        _selectedSection,
        _selectedSemester
    ) { lectures, subject, section, semester ->
        if (subject == null) emptyMap()
        else lectures.filter { it.subject == subject && it.section == section && it.semester == semester }
            .groupingBy { it.category }.eachCount()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap()
    )

    val notifications: StateFlow<List<BroadcastNotificationEntity>> = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val unreadCount: StateFlow<Int> = repository.unreadNotificationsCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val allSchedule: StateFlow<List<ScheduleEntity>> = repository.allSchedule.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allExams: StateFlow<List<ExamEntity>> = repository.allExams.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun upsertExam(e: ExamEntity, onResult: (String?) -> Unit = {}) {
        viewModelScope.launch { onResult(repository.upsertExam(e)) }
    }

    fun deleteExam(e: ExamEntity, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onResult(repository.deleteExam(e)) }
    }

    fun setSubjectIcon(name: String, section: String, semester: Int, icon: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.setSubjectIcon(name, section, semester, icon)) }
    }

    val myGroupName: StateFlow<String> = _currentUser.combine(
        MutableStateFlow(sessionManager.getSavedGroupName() ?: "")
    ) { user, savedGroup ->
        user?.groupName?.takeIf { it.isNotBlank() } ?: savedGroup
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = sessionManager.getSavedGroupName() ?: ""
    )

    val myScheduleFlow: StateFlow<List<ScheduleEntity>> = combine(
        allSchedule,
        myGroupName
    ) { schedule, group ->
        if (group.isBlank()) emptyList() else schedule.filter { it.groupName == group }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        var previousScheduledEntries = listOf<ScheduleEntity>()
        viewModelScope.launch {
            myScheduleFlow.collect { entries ->
                ClassAlarmScheduler.rescheduleAll(application, previousScheduledEntries, entries)
                previousScheduledEntries = entries
            }
        }
    }

    private val _classRemindersEnabled = MutableStateFlow(ClassReminderSettings.isEnabled(application))

    val classRemindersEnabled: StateFlow<Boolean> = _classRemindersEnabled.asStateFlow()

    fun setClassRemindersEnabled(enabled: Boolean) {
        val app = getApplication<Application>()
        ClassReminderSettings.setEnabled(app, enabled)
        _classRemindersEnabled.value = enabled
        val entries = myScheduleFlow.value
        if (enabled) ClassAlarmScheduler.scheduleAll(app, entries) else ClassAlarmScheduler.cancelAll(app, entries)
    }

    fun setMyGroup(groupName: String) {
        sessionManager.saveGroupName(groupName)
        viewModelScope.launch {
            val user = _currentUser.value
            if (user != null) {
                val updated = repository.setUserGroup(user, groupName)
                _currentUser.value = updated
            }
        }
    }

    fun upsertScheduleEntry(entry: ScheduleEntity) {
        viewModelScope.launch {
            repository.upsertScheduleEntry(entry)
        }
    }

    fun deleteScheduleEntry(entry: ScheduleEntity) {
        viewModelScope.launch {
            repository.deleteScheduleEntry(entry)
        }
    }

    private val _latestBroadcastAlert = MutableSharedFlow<BroadcastNotificationEntity>()
    val latestBroadcastAlert: SharedFlow<BroadcastNotificationEntity> = _latestBroadcastAlert.asSharedFlow()

    private val _selectedLecture = MutableStateFlow<LectureEntity?>(null)
    val selectedLecture: StateFlow<LectureEntity?> = _selectedLecture.asStateFlow()

    private val _pendingLectureId = MutableStateFlow<Long?>(null)

    fun selectLectureById(id: Long) {
        _pendingLectureId.value = id
        val target = allLectures.value.find { it.id == id }
        if (target != null) {
            selectLecture(target)
            _pendingLectureId.value = null
        }
    }

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    fun reloadServerData(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            _isRefreshing.value = true
            repository.forceSyncWithServer()
            kotlinx.coroutines.delay(600)
            _isRefreshing.value = false
            onComplete?.invoke()
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.markAllNotificationsAsRead()
        }
    }

    fun updateNotification(notification: BroadcastNotificationEntity, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            onResult(repository.updateNotification(notification))
        }
    }

    fun toggleNotificationPinned(id: Long, isPinned: Boolean) {
        viewModelScope.launch {
            repository.toggleNotificationPinned(id, isPinned)
        }
    }

    fun selectLecture(lecture: LectureEntity?) {
        _selectedLecture.value = lecture
        lecture?.takeIf { it.id > 0 }?.let {
            viewModelScope.launch {
                repository.incrementViewCount(it.id)
            }
        }
    }

    fun toggleBookmark(lecture: LectureEntity) {
        viewModelScope.launch {
            repository.toggleBookmark(lecture.id, lecture.isBookmarked)
            _selectedLecture.value = _selectedLecture.value?.let {
                if (it.id == lecture.id) it.copy(isBookmarked = !lecture.isBookmarked) else it
            }
        }
    }

    private val _downloadProgress = MutableStateFlow<Map<Long, Int>>(emptyMap())

    val downloadProgress: StateFlow<Map<Long, Int>> = _downloadProgress.asStateFlow()
    private val downloadPercentRegex = Regex("""\((\d{1,3})%\)""")

    private fun setDownloadProgress(id: Long, percent: Int?) {
        synchronized(_downloadProgress) {
            val m = _downloadProgress.value
            _downloadProgress.value = if (percent == null) m - id else m + (id to percent)
        }
    }

    fun downloadLectureFile(context: Context, lecture: LectureEntity, onResult: (Boolean, String) -> Unit) {
        if (lecture.id < 0) {
            viewModelScope.launch {
                try {
                    val path = PdfHelper.saveWorksheetToDevice(context, lecture)
                    _selectedLecture.value = _selectedLecture.value?.let {
                        if (it.id == lecture.id) it.copy(isDownloaded = true) else it
                    }
                    onResult(true, PdfHelper.worksheetSavedMessage(path))
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    e.printStackTrace()
                    onResult(false, (e as? PdfHelper.LectureFileException)?.message ?: "تعذر تنزيل الملف")
                }
            }
            return
        }
        if (lecture.isDownloaded) {
            onResult(true, "المحاضرة مثبّتة على جهازك مسبقاً")
            return
        }
        if (_downloadProgress.value.containsKey(lecture.id)) return
        viewModelScope.launch {
            setDownloadProgress(lecture.id, -1)
            try {
                val pdfFile = PdfHelper.getOrDownloadPdfFile(context, lecture, onProgress = { status ->
                    downloadPercentRegex.find(status)?.groupValues?.getOrNull(1)?.toIntOrNull()
                        ?.let { setDownloadProgress(lecture.id, it.coerceIn(0, 100)) }
                })
                setDownloadProgress(lecture.id, 100)
                val publicPath = PdfHelper.savePdfToPublicDeviceStorage(context, pdfFile, lecture.title)
                repository.toggleDownload(lecture.id, false, publicPath)
                _selectedLecture.value = _selectedLecture.value?.let {
                    if (it.id == lecture.id) it.copy(isDownloaded = true, downloadCount = it.downloadCount + 1, downloadPath = publicPath) else it
                }

                SystemNotificationHelper.sendSystemNotification(
                    context = context,
                    notificationId = (lecture.id.hashCode() and 0x7FFFFFFF),
                    title = "تم تنزيل المحاضرة بنجاح",
                    message = "تم حفظ محاضرة '${lecture.title}' بنجاح في جهازك (مجلد Downloads)."
                )

                onResult(true, "تم تنزيل المحاضرة وحفظها في جهازك (مجلد Downloads) بنجاح!")

                viewModelScope.launch {
                    kotlinx.coroutines.delay(650)
                    setDownloadProgress(lecture.id, null)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                setDownloadProgress(lecture.id, null)
                throw e
            } catch (e: Exception) {
                e.printStackTrace()
                setDownloadProgress(lecture.id, null)
                onResult(false, "حدث خطأ أثناء تنزيل المحاضرة")
            }
        }
    }

    fun toggleDownload(lecture: LectureEntity) {
        viewModelScope.launch {
            repository.toggleDownload(lecture.id, lecture.isDownloaded)
            _selectedLecture.value = _selectedLecture.value?.let {
                if (it.id == lecture.id) it.copy(isDownloaded = !lecture.isDownloaded, downloadCount = it.downloadCount + if (!lecture.isDownloaded) 1 else 0) else it
            }
        }
    }

    fun markAvailableOffline(lecture: LectureEntity) {
        viewModelScope.launch {
            repository.markAvailableOffline(lecture.id)
        }
    }

    fun toggleSubjectExamPinned(subjectName: String, section: String, semester: Int, isPinned: Boolean) {
        viewModelScope.launch {
            repository.toggleSubjectExamPinned(subjectName, section, semester, isPinned)
        }
    }

    fun addSubjectFolder(subjectName: String, section: String, semester: Int, onSuccess: () -> Unit) {
        if (subjectName.isBlank()) return
        viewModelScope.launch {
            repository.addSubjectFolder(subjectName, section, semester)
            onSuccess()
        }
    }

    fun deleteSubjectFolder(subjectName: String, section: String, semester: Int, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.deleteSubjectFolder(subjectName, section, semester)
            if (ok && _selectedSubject.value == subjectName && _selectedSection.value == section && _selectedSemester.value == semester) {
                _selectedSubject.value = null
            }
            try {
                repository.forceSyncWithServer()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            onResult(ok)
        }
    }

    fun renameSubjectFolder(oldName: String, newName: String, section: String, semester: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = repository.renameSubjectFolder(oldName, newName, section, semester)
            if (err == null && _selectedSubject.value == oldName.trim() && _selectedSection.value == section && _selectedSemester.value == semester) {
                _selectedSubject.value = newName.trim()
            }
            onResult(err)
        }
    }

    fun uploadLectureByAdmin(req: NewLectureRequest, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val (_, isServerSuccess) = repository.uploadLectureByAdmin(req)
            try {
                repository.forceSyncWithServer()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            onResult(isServerSuccess)
        }
    }

    fun updateLecture(lecture: LectureEntity, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = repository.updateLecture(lecture)
            if (err == null && _selectedLecture.value?.id == lecture.id) _selectedLecture.value = lecture
            onResult(err)
        }
    }

    fun updateStudent(email: String, fullName: String, studentId: String, newPassword: String = "", onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.updateStudent(email, fullName, studentId, newPassword)) }
    }

    fun changeUserEmail(email: String, newEmail: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.changeUserEmail(email, newEmail)) }
    }

    fun createAdmin(email: String, password: String, fullName: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.createAdmin(email, password, fullName)) }
    }

    fun promoteStudent(studentEmail: String, newEmail: String, password: String, fullName: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.promoteStudent(studentEmail, newEmail, password, fullName)) }
    }

    fun demoteAdmin(email: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.demoteAdmin(email)) }
    }

    fun deleteUserAccount(email: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.deleteUserOnServer(email)) }
    }

    fun resetUserDevices(email: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.resetUserDevices(email)) }
    }

    fun publishAnnouncement(
        title: String,
        message: String,
        url: String? = null,
        imageUrl: String? = null,
        style: String = "",
        onSuccess: () -> Unit
    ) {
        if (title.isBlank() || message.isBlank()) return
        viewModelScope.launch {
            repository.publishAnnouncementByAdmin(title, message, url, imageUrl, style)
            onSuccess()
        }
    }

    fun dismissNotification(id: Long) {
        viewModelScope.launch {
            repository.dismissNotification(id)
        }
    }

    fun dismissAllNotifications() {
        viewModelScope.launch {
            repository.dismissAllNotifications()
        }
    }

    fun deleteLecture(lecture: LectureEntity) {
        viewModelScope.launch {
            repository.deleteLecture(lecture)
            if (_selectedLecture.value?.id == lecture.id) {
                _selectedLecture.value = null
            }
            try {
                repository.forceSyncWithServer()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.markAllNotificationsAsRead()
        }
    }

    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.markNotificationAsRead(id)
        }
    }
}
