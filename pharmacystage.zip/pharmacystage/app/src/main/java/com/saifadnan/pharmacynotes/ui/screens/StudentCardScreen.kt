package com.saifadnan.pharmacynotes.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.data.SupabaseClient.LibraryCard
import com.saifadnan.pharmacynotes.data.SupabaseClient.LibraryLoan
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassDivider
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.bounceClick
import com.saifadnan.pharmacynotes.ui.components.shimmerEffect
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.glass
import com.saifadnan.pharmacynotes.util.CardExport
import com.saifadnan.pharmacynotes.util.QrCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CardGradient = listOf(Color(0xFF2E5A85), Color(0xFF4A7BA6), Color(0xFF6F9FD0))
private val CardGradientDark = listOf(Color(0xFF0F1736), Color(0xFF1A2662), Color(0xFF2A3F8C))

@Composable
fun StudentCardScreen(
    userEmail: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val darkCard = MaterialTheme.glass.isDark
    val prefs = remember { context.getSharedPreferences("library_card", Context.MODE_PRIVATE) }
    var card by remember { mutableStateOf(loadCachedCard(prefs, userEmail)) }
    var refreshing by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var showQr by remember { mutableStateOf(false) }
    var showPrint by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val reload: () -> Unit = {
        if (!refreshing) {
            scope.launch {
                refreshing = true
                val t0 = System.currentTimeMillis()
                val fresh = SupabaseClient.getLibraryCard()
                if (fresh != null) {
                    card = fresh
                    failed = false
                    saveCachedCard(prefs, fresh)
                } else {
                    failed = true
                }
                val rest = 750L - (System.currentTimeMillis() - t0)
                if (rest > 0) delay(rest)
                refreshing = false
            }
        }
    }
    LaunchedEffect(Unit) { reload() }

    // أعلى سطوع للشاشة أثناء عرض البطاقة حتى يقرأها الماسح بسهولة
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        val previous = window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = 1f } }
        onDispose {
            window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = previous } }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "بطاقة المكتبة",
            subtitle = "للاستعارة من مكتبة الكلية",
            modifier = Modifier.padding(horizontal = 20.dp),
            leading = {
                GlassIconButton(onClick = onBack, modifier = Modifier.testTag("card_back_button")) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }
            },
            trailing = { SpinRefreshButton(refreshing = refreshing, onClick = reload) }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val current = card
            if (current == null) {
                if (failed && !refreshing) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            IconTile(icon = Icons.Default.CloudOff, size = 56.dp, tint = MaterialTheme.colorScheme.error)
                            Text(
                                "تعذر تحميل البطاقة",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "تأكد من الاتصال بالإنترنت وحاول مرة ثانية. بعد أول تحميل تبقى بطاقتك محفوظة على الجهاز.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            PillButton(text = "إعادة المحاولة", onClick = reload, icon = Icons.Default.Refresh)
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.585f)
                            .clip(RoundedCornerShape(26.dp))
                            .shimmerEffect()
                    )
                }
            } else {
                LibraryIdCard(card = current, onClick = { showQr = true })

                if (failed) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.CloudOff, contentDescription = null, tint = Amber, modifier = Modifier.size(18.dp))
                        Text(
                            "تعذر التحديث، معروضة آخر نسخة محفوظة (تشتغل بدون إنترنت).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        IconTile(icon = Icons.Default.QrCode2, size = 46.dp)
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                "اعرض الرمز للأمينة",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "اضغط البطاقة لتكبير الباركود والامينة تمسح الباركود خلال الموقع",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            IconTile(icon = Icons.Default.Print, size = 46.dp)
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "اطبع بطاقتك",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    "اطبع بطاقة المكتبة واحتفظ بيها او احفظها صورة بجهازك نفس الرمز بالحالتين",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        PillButton(
                            text = "طباعة البطاقة",
                            onClick = { showPrint = true },
                            icon = Icons.Default.Print,
                            height = 46.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_print_button")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            PillButton(
                                text = "حفظ صورة",
                                onClick = {
                                    scope.launch {
                                        val ok = withContext(Dispatchers.IO) { CardExport.saveToGallery(context, current, darkCard) }
                                        if (ok) {
                                            Toast.makeText(context, "تم حفظ البطاقة في المعرض", Toast.LENGTH_SHORT).show()
                                        } else {
                                            CardExport.share(context, current, darkCard)
                                        }
                                    }
                                },
                                icon = Icons.Default.Download,
                                height = 46.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("card_save_button")
                            )
                            PillButton(
                                text = "مشاركة",
                                onClick = { CardExport.share(context, current, darkCard) },
                                icon = Icons.Default.Share,
                                height = 46.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("card_share_button")
                            )
                        }
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                            Text(
                                "الكتب المستعارة",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            if (current.loans.isNotEmpty()) {
                                Text(
                                    "${current.loans.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (current.loans.isEmpty()) {
                            Text(
                                "ماكو كتب مستعارة حالياً",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 18.dp)
                            )
                        } else {
                            current.loans.forEachIndexed { i, loan ->
                                if (i > 0) GlassDivider(Modifier.padding(horizontal = 18.dp))
                                LoanRow(loan)
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
    }

    val shown = card
    if (showPrint && shown != null) {
        AlertDialog(
            onDismissRequest = { showPrint = false },
            title = { Text("طباعة البطاقة") },
            text = { Text("اختر حجم الطباعة, يمكنك أيضاً اختيار «حفظ كـ PDF» من نافذة الطباعة.") },
            confirmButton = {
                TextButton(onClick = {
                    showPrint = false
                    CardExport.print(context, shown, cardSize = false, dark = darkCard)
                }) { Text("ورقة A4 (للقص)") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPrint = false
                    CardExport.print(context, shown, cardSize = true, dark = darkCard)
                }) { Text("بحجم البطاقة") }
            }
        )
    }
    if (showQr && shown != null) {
        QrFullDialog(card = shown, onDismiss = { showQr = false })
    }
}

@Composable
private fun LibraryIdCard(card: LibraryCard, onClick: () -> Unit) {
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        enter.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow))
    }
    val transition = rememberInfiniteTransition(label = "card_sweep")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3600, delayMillis = 1400, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "card_sweep_x"
    )
    val shape = RoundedCornerShape(26.dp)
    val darkCard = MaterialTheme.glass.isDark
    val gradientStart by animateColorAsState(
        if (darkCard) CardGradientDark[0] else CardGradient[0], tween(450), label = "card_grad_start"
    )
    val gradientMid by animateColorAsState(
        if (darkCard) CardGradientDark[1] else CardGradient[1], tween(450), label = "card_grad_mid"
    )
    val gradientEnd by animateColorAsState(
        if (darkCard) CardGradientDark[2] else CardGradient[2], tween(450), label = "card_grad_end"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.585f)
            .bounceClick(scaleDown = 0.98f, onClick = onClick)
            .graphicsLayer {
                val e = enter.value
                alpha = e.coerceIn(0f, 1f)
                scaleX = 0.9f + 0.1f * e
                scaleY = 0.9f + 0.1f * e
                rotationX = (1f - e) * 16f
                cameraDistance = 14f * density
            }
            .shadow(16.dp, shape, ambientColor = if (darkCard) Color(0x99000000) else Color(0x55294A6B), spotColor = if (darkCard) Color(0xCC000000) else Color(0x66294A6B))
            .clip(shape)
            .background(Brush.linearGradient(listOf(gradientStart, gradientMid, gradientEnd)))
            .then(if (darkCard) Modifier.border(1.dp, Color(0x38FFFFFF), shape) else Modifier)
            .drawBehind {
                drawCircle(Color.White.copy(alpha = 0.09f), radius = size.width * 0.36f, center = Offset(size.width * 0.05f, -size.height * 0.1f))
                drawCircle(Color.White.copy(alpha = 0.08f), radius = size.width * 0.28f, center = Offset(size.width * 0.98f, size.height * 1.05f))
            }
            .drawWithContent {
                drawContent()
                val w = size.width
                val x = -w * 0.5f + sweep * w * 2.0f
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent),
                        startX = x,
                        endX = x + w * 0.45f
                    )
                )
            }
            .testTag("library_id_card")
    ) {
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "كلية الصيدلة · الجامعة المستنصرية",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.95f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "بطاقة المكتبة",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Text(
                        card.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    CardInfo("الكروب", card.group.ifBlank { "—" })
                    CardInfo("رقم الطالب", card.studentId.ifBlank { "—" })
                }
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .aspectRatio(1f, matchHeightConstraintsFirst = true)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .padding(8.dp)
                ) {
                    QrView(payload = card.payload, modifier = Modifier.fillMaxSize())
                }
            }
            Text(
                QrCode.formatCode(card.code),
                style = MaterialTheme.typography.labelMedium,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp,
                color = Color.White.copy(alpha = 0.9f)
            )
        }
    }
}

@Composable
private fun CardInfo(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
        Text(
            value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = Color.White.copy(alpha = 0.95f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun QrView(payload: String, modifier: Modifier = Modifier, dark: Color = Color.Black) {
    val matrix = remember(payload) { QrCode.matrix(payload) }
    Canvas(modifier = modifier) {
        val n = matrix.size
        if (n == 0) return@Canvas
        val cell = size.minDimension / n
        for (y in 0 until n) {
            val row = matrix[y]
            for (x in 0 until row.size) {
                if (row[x]) {
                    drawRect(dark, topLeft = Offset(x * cell, y * cell), size = Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

@Composable
private fun LoanRow(loan: LibraryLoan) {
    val now = System.currentTimeMillis()
    val days = Math.ceil((loan.dueAt - now) / 86_400_000.0).toInt()
    val (label, color) = when {
        loan.overdue -> "متأخر" to MaterialTheme.colorScheme.error
        days <= 3 -> (if (days <= 0) "يُرجع اليوم" else "باقي $days يوم") to Amber
        else -> "حتى " + formatDay(loan.dueAt) to SuccessGreen
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                loan.title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (loan.author.isNotBlank()) {
                Text(
                    loan.author,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(color.copy(alpha = 0.14f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun QrFullDialog(card: LibraryCard, onDismiss: () -> Unit) {
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow)) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f * enter.value.coerceIn(0f, 1f)))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .graphicsLayer {
                        alpha = enter.value.coerceIn(0f, 1f)
                        scaleX = 0.85f + 0.15f * enter.value
                        scaleY = 0.85f + 0.15f * enter.value
                    }
                    .width(310.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color.White)
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QrView(payload = card.payload, modifier = Modifier.size(266.dp))
                Text(
                    card.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF0E1116),
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
                Text(
                    QrCode.formatCode(card.code),
                    style = MaterialTheme.typography.labelLarge,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = Color(0xFF59616F)
                )
                Text("اضغط بأي مكان للإغلاق", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A0))
            }
        }
    }
}

private fun formatDay(ms: Long): String = SimpleDateFormat("d MMM", Locale.forLanguageTag("ar")).format(Date(ms))

private fun loadCachedCard(p: SharedPreferences, email: String): LibraryCard? {
    if (email.isBlank() || p.getString("email", "") != email) return null
    val payload = p.getString("payload", "").orEmpty()
    if (payload.isBlank()) return null
    return LibraryCard(
        name = p.getString("name", "").orEmpty(),
        email = email,
        group = p.getString("group", "").orEmpty(),
        studentId = p.getString("studentId", "").orEmpty(),
        code = p.getString("code", "").orEmpty(),
        payload = payload,
        loans = emptyList()
    )
}

private fun saveCachedCard(p: SharedPreferences, c: LibraryCard) {
    p.edit()
        .putString("email", c.email)
        .putString("name", c.name)
        .putString("group", c.group)
        .putString("studentId", c.studentId)
        .putString("code", c.code)
        .putString("payload", c.payload)
        .apply()
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
