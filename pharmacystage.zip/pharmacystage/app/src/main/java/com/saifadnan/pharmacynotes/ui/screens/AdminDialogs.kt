package com.saifadnan.pharmacynotes.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.BroadcastNotificationEntity
import com.saifadnan.pharmacynotes.data.Category
import com.saifadnan.pharmacynotes.data.Course
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.data.Section
import com.saifadnan.pharmacynotes.data.SubjectEntity
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.data.WorksheetType
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import com.saifadnan.pharmacynotes.ui.components.GlassSegmented
import com.saifadnan.pharmacynotes.ui.components.LazyCoilImage
import com.saifadnan.pharmacynotes.ui.components.SegmentOption
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.YoutubeRed
import com.saifadnan.pharmacynotes.util.PdfHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = true
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = AppShapes.Card,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(
                    confirmText,
                    fontWeight = FontWeight.Bold,
                    color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun FormDialog(
    title: String,
    confirmText: String,
    busy: Boolean,
    error: String?,
    confirmEnabled: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        shape = AppShapes.Card,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                content()
                if (!error.isNullOrBlank()) {
                    Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = confirmEnabled && !busy,
                shape = AppShapes.Small
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text(confirmText, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
fun rememberWorksheetPicker(onStart: () -> Unit, onResult: (String?) -> Unit): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            onStart()
            scope.launch {
                var failure: String? = null
                val url = try {
                    withContext(Dispatchers.IO) {
                        val dir = File(context.filesDir, "shared_worksheets").apply { mkdirs() }
                        val f = File(dir, "ws_${System.currentTimeMillis()}.pdf")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            f.outputStream().use { out -> input.copyTo(out) }
                        }
                        val result = SupabaseClient.uploadPdfFile(f, f.name)
                        f.delete()
                        if (!result.isSuccess) failure = result.error
                        result.url
                    }
                } catch (e: Exception) {
                    null
                }
                if (url == null) {
                    Toast.makeText(context, failure ?: "تعذر رفع الملف (المسموح PDF فقط)", Toast.LENGTH_LONG).show()
                }
                onResult(url)
            }
        }
    }
    return remember(launcher) { { launcher.launch("application/pdf") } }
}

@Composable
fun AdminSectionToggle(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    GlassSegmented(
        options = Section.all.map { SegmentOption(it, Section.label(it)) },
        selectedKey = selected,
        onSelect = onSelect,
        modifier = modifier,
        height = 44.dp,
        tagPrefix = "admin_section_"
    )
}

@Composable
fun AdminCategoryToggle(section: String, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val safe = if (section == Section.PRACTICAL && selected == Category.REEYUS) Category.GHRADI else selected
    GlassSegmented(
        options = Category.forSection(section).map { SegmentOption(it, Category.label(it)) },
        selectedKey = safe,
        onSelect = onSelect,
        modifier = modifier,
        height = 44.dp,
        tagPrefix = "admin_category_"
    )
}

@Composable
fun AdminSemesterToggle(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    GlassSegmented(
        options = listOf(SegmentOption("1", "الكورس الأول"), SegmentOption("2", "الكورس الثاني")),
        selectedKey = selected.toString(),
        onSelect = { onSelect(it.toIntOrNull() ?: 1) },
        modifier = modifier,
        height = 44.dp,
        tagPrefix = "admin_semester_"
    )
}

@Composable
fun AdminWorksheetTypeToggle(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    GlassSegmented(
        options = WorksheetType.all.map { SegmentOption(it, WorksheetType.label(it)) },
        selectedKey = selected.ifBlank { WorksheetType.WORKSHEET },
        onSelect = onSelect,
        modifier = modifier,
        height = 44.dp,
        tagPrefix = "admin_wstype_"
    )
}

@Composable
fun SubjectChips(subjects: List<SubjectEntity>, selectedName: String, onPick: (String) -> Unit) {
    if (subjects.isEmpty()) return
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(subjects, key = { it.name + "|" + it.section }) { s ->
            GlassChip(text = s.name, selected = s.name == selectedName.trim(), onClick = { onPick(s.name) })
        }
    }
}

@Composable
fun WorksheetEditor(
    url: String,
    type: String,
    uploading: Boolean,
    onPick: () -> Unit,
    onTypeChange: (String) -> Unit,
    onRemove: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "ملف Worksheet / Datasheet بصيغة PDF (اختياري)",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (url.isBlank()) {
            OutlinedButton(
                onClick = onPick,
                enabled = !uploading,
                modifier = Modifier.fillMaxWidth(),
                shape = AppShapes.Small
            ) {
                if (uploading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("جاري رفع الملف...")
                } else {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("إضافة ملف PDF")
                }
            }
        } else {
            AdminWorksheetTypeToggle(selected = type, onSelect = onTypeChange)
            if (PdfHelper.isPdfUrl(url)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ملف PDF مرفق", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "يعرضه الطالب داخل التطبيق ويقدر ينزله على جهازه",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(16.dp))
                ) {
                    LazyCoilImage(
                        model = url,
                        contentDescription = "معاينة",
                        modifier = Modifier.fillMaxWidth().height(150.dp)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onPick, enabled = !uploading, shape = AppShapes.Small, modifier = Modifier.weight(1f)) {
                    Text(if (uploading) "جاري الرفع..." else "تغيير الملف")
                }
                OutlinedButton(onClick = onRemove, enabled = !uploading, shape = AppShapes.Small) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف الملف", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun RenameFolderDialog(
    initialName: String,
    section: String,
    semester: Int,
    busy: Boolean,
    error: String?,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    FormDialog(
        title = "تعديل اسم المجلد (${Section.label(section)} · ${Course.label(semester)})",
        confirmText = "حفظ",
        busy = busy,
        error = error,
        confirmEnabled = name.isNotBlank() && name.trim() != initialName,
        onConfirm = { onConfirm(name.trim()) },
        onDismiss = onDismiss
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("اسم المجلد") },
            singleLine = true,
            shape = AppShapes.Small,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "كل محاضرات المجلد تنتقل مع الاسم الجديد.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun EditLectureDialog(
    lecture: LectureEntity,
    subjects: List<SubjectEntity>,
    busy: Boolean,
    error: String?,
    onSave: (LectureEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(lecture.title) }
    var doctor by remember { mutableStateOf(lecture.doctorName) }
    var subject by remember { mutableStateOf(lecture.subject) }
    var section by remember { mutableStateOf(lecture.section) }
    var category by remember { mutableStateOf(lecture.category) }
    var semester by remember { mutableStateOf(lecture.semester) }
    var worksheetUrl by remember { mutableStateOf(lecture.worksheetUrl) }
    var worksheetType by remember { mutableStateOf(lecture.worksheetType.ifBlank { WorksheetType.WORKSHEET }) }
    var youtube by remember { mutableStateOf(lecture.youtubeUrl) }
    var uploading by remember { mutableStateOf(false) }
    var fileUrl by remember { mutableStateOf(lecture.fileUrl) }
    var fileSize by remember { mutableStateOf(lecture.fileSize) }
    var pageCount by remember { mutableStateOf(lecture.pageCount) }
    var newFileName by remember { mutableStateOf("") }
    var fileStatus by remember { mutableStateOf("") }
    var fileUploading by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val pickLectureFile = rememberLecturePdfPicker(
        onStart = { name ->
            newFileName = name
            fileStatus = "جاري تجهيز الملف..."
            fileUploading = true
        },
        onStatus = { fileStatus = it },
        onDone = { url, size, pages, failure ->
            fileUploading = false
            fileStatus = ""
            if (url != null) {
                fileUrl = url
                fileSize = size
                pageCount = pages
            } else {
                newFileName = ""
                Toast.makeText(context, failure ?: "تعذر رفع الملف", Toast.LENGTH_LONG).show()
            }
        }
    )

    val pickWorksheet = rememberWorksheetPicker(
        onStart = { uploading = true },
        onResult = { url ->
            uploading = false
            if (url != null) worksheetUrl = url
        }
    )
    val effectiveCategory = if (section == Section.PRACTICAL && category == Category.REEYUS) Category.GHRADI else category

    FormDialog(
        title = "تعديل المحاضرة",
        confirmText = "حفظ",
        busy = busy,
        error = error,
        confirmEnabled = title.isNotBlank() && subject.isNotBlank() && !uploading && !fileUploading &&
            com.saifadnan.pharmacynotes.util.YoutubeLinks.isValid(youtube),
        onConfirm = {
            val practical = section == Section.PRACTICAL
            onSave(
                lecture.copy(
                    title = title.trim(),
                    doctorName = doctor.trim(),
                    subject = subject.trim(),
                    section = section,
                    category = effectiveCategory,
                    semester = semester,
                    youtubeUrl = youtube.trim(),
                    fileUrl = fileUrl,
                    fileSize = fileSize,
                    pageCount = pageCount,
                    worksheetUrl = if (practical) worksheetUrl else "",
                    worksheetType = if (practical && worksheetUrl.isNotBlank()) worksheetType else ""
                )
            )
        },
        onDismiss = onDismiss
    ) {
        OutlinedTextField(
            value = title, onValueChange = { title = it },
            label = { Text("عنوان المحاضرة") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = doctor, onValueChange = { doctor = it },
            label = { Text("اسم الدكتور (اختياري)") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        AdminSectionToggle(selected = section, onSelect = { section = it })
        AdminCategoryToggle(section = section, selected = category, onSelect = { category = it })
        AdminSemesterToggle(selected = semester, onSelect = { semester = it })
        OutlinedTextField(
            value = subject, onValueChange = { subject = it },
            label = { Text("المجلد (المادة)") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        SubjectChips(subjects.filter { it.section == section && it.semester == semester }, subject) { subject = it }
        YoutubeLinkField(value = youtube, onValueChange = { youtube = it })
        LectureFileEditor(
            fileSize = fileSize,
            pages = pageCount,
            newName = newFileName,
            status = fileStatus,
            uploading = fileUploading,
            replaced = fileUrl != lecture.fileUrl,
            onPick = pickLectureFile
        )
        if (section == Section.PRACTICAL) {
            WorksheetEditor(
                url = worksheetUrl,
                type = worksheetType,
                uploading = uploading,
                onPick = pickWorksheet,
                onTypeChange = { worksheetType = it },
                onRemove = { worksheetUrl = "" }
            )
        }
    }
}

@Composable
fun rememberLecturePdfPicker(
    onStart: (name: String) -> Unit,
    onStatus: (String) -> Unit,
    onDone: (url: String?, size: String, pages: Int, failure: String?) -> Unit
): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            var shownName = "ملف جديد"
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) shownName = c.getString(i) ?: shownName
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            onStart(shownName)
            scope.launch {
                var url: String? = null
                var size = ""
                var pages = 0
                var failure: String? = null
                try {
                    withContext(Dispatchers.IO) {
                        val dir = File(context.filesDir, "shared_pdf_lectures").apply { mkdirs() }
                        val f = File(dir, "lec_${System.currentTimeMillis()}.pdf")
                        try {
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                f.outputStream().use { out -> input.copyTo(out) }
                            }
                            if (!f.exists() || f.length() <= 0L) {
                                failure = "تعذر قراءة الملف"
                                return@withContext
                            }
                            try {
                                val pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
                                try {
                                    val renderer = android.graphics.pdf.PdfRenderer(pfd)
                                    pages = renderer.pageCount
                                    renderer.close()
                                } finally {
                                    pfd.close()
                                }
                            } catch (e: Exception) {
                                failure = "الملف ليس PDF صالحاً أو محمي بكلمة مرور"
                                return@withContext
                            }
                            val res = SupabaseClient.uploadPdfFile(f, f.name, onStatus = { st -> onStatus(st) }) { bytes, total ->
                                if (total > 0) onStatus("جاري رفع الملف: ${(bytes * 100 / total).toInt()}%")
                            }
                            if (res.isSuccess && res.url != null) {
                                url = res.url
                                val b = res.finalSizeBytes ?: f.length()
                                val mb = b / (1024.0 * 1024.0)
                                size = if (mb >= 1.0) String.format(java.util.Locale.US, "%.1f MB", mb)
                                else String.format(java.util.Locale.US, "%d KB", b / 1024)
                            } else {
                                failure = res.error ?: "فشل رفع الملف"
                            }
                        } finally {
                            f.delete()
                        }
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    e.printStackTrace()
                    failure = "خطأ غير متوقع أثناء الرفع"
                }
                onDone(url, size, pages, failure)
            }
        }
    }
    return remember(launcher) { { launcher.launch("application/pdf") } }
}

@Composable
private fun LectureFileEditor(
    fileSize: String,
    pages: Int,
    newName: String,
    status: String,
    uploading: Boolean,
    replaced: Boolean,
    onPick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "ملف المحاضرة (PDF)",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Default.PictureAsPdf,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = if (replaced) newName.ifBlank { "ملف جديد" } else "الملف الحالي",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                val info = buildString {
                    if (pages > 0) append("$pages صفحة")
                    if (fileSize.isNotBlank()) {
                        if (isNotEmpty()) append(" • ")
                        append(fileSize)
                    }
                }
                if (info.isNotBlank()) {
                    Text(
                        text = info,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (uploading && status.isNotBlank()) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        OutlinedButton(
            onClick = onPick,
            enabled = !uploading,
            modifier = Modifier.fillMaxWidth(),
            shape = AppShapes.Small
        ) {
            if (uploading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("جاري رفع الملف...")
            } else {
                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("استبدال ملف المحاضرة")
            }
        }
    }
}

@Composable
fun EditNotificationDialog(
    notif: BroadcastNotificationEntity,
    busy: Boolean,
    error: String?,
    onSave: (BroadcastNotificationEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(notif.title) }
    var message by remember { mutableStateOf(notif.message) }
    var link by remember { mutableStateOf(notif.url.orEmpty()) }
    var image by remember { mutableStateOf(notif.imageUrl.orEmpty()) }
    var style by remember { mutableStateOf(com.saifadnan.pharmacynotes.ui.components.NotifStyle.parse(notif.style)) }
    FormDialog(
        title = "تعديل التبليغ",
        confirmText = "حفظ",
        busy = busy,
        error = error,
        confirmEnabled = title.isNotBlank(),
        onConfirm = {
            onSave(
                notif.copy(
                    title = title.trim(),
                    message = message.trim(),
                    url = link.trim().ifBlank { null },
                    imageUrl = image.trim().ifBlank { null },
                    style = style.toJson()
                )
            )
        },
        onDismiss = onDismiss
    ) {
        OutlinedTextField(
            value = title, onValueChange = { title = it },
            label = { Text("عنوان التبليغ") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = message, onValueChange = { message = it },
            label = { Text("نص التبليغ") }, minLines = 4, maxLines = 10,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = link, onValueChange = { link = it },
            label = { Text("رابط (اختياري)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = image, onValueChange = { image = it },
            label = { Text("رابط صورة (اختياري)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        com.saifadnan.pharmacynotes.ui.components.NotifStyleEditor(
            title = title, message = message, style = style, onChange = { style = it }
        )
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun SubjectIconDialog(
    subject: SubjectEntity,
    busy: Boolean,
    error: String?,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var value by remember { mutableStateOf(subject.icon) }
    var custom by remember { mutableStateOf(if (subject.icon.startsWith("<svg", true)) subject.icon else "") }
    val svg = com.saifadnan.pharmacynotes.ui.components.resolveSubjectIconSvg(value)
    val customInvalid = custom.isNotBlank() && !com.saifadnan.pharmacynotes.ui.components.isRenderableSvg(custom)
    FormDialog(
        title = "أيقونة مادة (${subject.name})",
        confirmText = "حفظ",
        busy = busy,
        error = error,
        confirmEnabled = !customInvalid && value != subject.icon,
        onConfirm = { onSave(value) },
        onDismiss = onDismiss
    ) {
        Text("المعاينة في الوضعين", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                Triple("عادي", androidx.compose.ui.graphics.Color(0xFFF4F4F6), androidx.compose.ui.graphics.Color(0xFF1B1B1F)),
                Triple("داكن", androidx.compose.ui.graphics.Color(0xFF16161A), androidx.compose.ui.graphics.Color(0xFFEDEDF0))
            ).forEach { (label, bg, fg) ->
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(bg)
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    com.saifadnan.pharmacynotes.ui.components.SubjectIconTile(
                        icon = value, size = 44.dp, tint = fg, container = fg.copy(alpha = 0.09f)
                    )
                    Text(label, color = fg, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        Text("أيقونات جاهزة", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        androidx.compose.foundation.layout.FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PresetChip(label = "الافتراضي", selected = value.isBlank()) { value = ""; custom = "" }
            com.saifadnan.pharmacynotes.ui.components.SubjectIconPresets.forEach { (key, pair) ->
                PresetChip(label = pair.first, svg = pair.second, selected = value == "preset:$key") {
                    value = "preset:$key"; custom = ""
                }
            }
        }
        val suggestion = com.saifadnan.pharmacynotes.ui.components.suggestPresetFor(subject.name)
        if (suggestion != null && value != "preset:$suggestion") {
            TextButton(onClick = { value = "preset:$suggestion"; custom = "" }) {
                Text("اقتراح مناسب لاسم المادة: ${com.saifadnan.pharmacynotes.ui.components.SubjectIconPresets[suggestion]?.first}")
            }
        }

        Text("أو الصق كود SVG خاص", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = custom,
            onValueChange = {
                custom = it
                value = if (it.isBlank()) "" else it.trim()
            },
            label = { Text("<svg viewBox=...> ... </svg>") },
            minLines = 3, maxLines = 6,
            isError = customInvalid,
            shape = AppShapes.Small,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            if (customInvalid) "الكود غير قابل للرسم. استخدم path/circle/rect/line/polyline/polygon فقط."
            else "الألوان الرمادية والسوداء تتبدل تلقائياً مع الوضع الداكن/العادي، والأبيض يصير شفاف. بدون سكربتات أو صور.",
            style = MaterialTheme.typography.bodySmall,
            color = if (customInvalid) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun PresetChip(label: String, selected: Boolean, svg: String? = null, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) c.primary.copy(alpha = 0.16f) else c.onSurface.copy(alpha = 0.06f))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (svg != null) {
            com.saifadnan.pharmacynotes.ui.components.SvgIcon(svg, if (selected) c.primary else c.onSurface, Modifier.size(20.dp))
        } else {
            Icon(Icons.Default.Folder, null, tint = if (selected) c.primary else c.onSurface, modifier = Modifier.size(20.dp))
        }
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (selected) c.primary else c.onSurface)
    }
}

@Composable
fun EditStudentDialog(
    student: UserEntity,
    busy: Boolean,
    error: String?,
    onSave: (name: String, studentId: String, email: String, newPassword: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(student.fullName) }
    var studentId by remember { mutableStateOf(student.studentId) }
    var email by remember { mutableStateOf(student.email) }
    var newPassword by remember { mutableStateOf("") }
    val changed = name.trim() != student.fullName || studentId.trim() != student.studentId ||
        email.trim().lowercase() != student.email.lowercase() || newPassword.isNotBlank()
    val passwordValid = newPassword.isBlank() || newPassword.length >= 8
    FormDialog(
        title = "تعديل بيانات الطالب",
        confirmText = if (newPassword.isBlank()) "حفظ" else "حفظ وتعيين كلمة المرور",
        busy = busy,
        error = error,
        confirmEnabled = name.isNotBlank() && email.isNotBlank() && changed && passwordValid,
        onConfirm = { onSave(name.trim(), studentId.trim(), email.trim(), newPassword) },
        onDismiss = onDismiss
    ) {
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("الاسم الثلاثي") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = studentId, onValueChange = { studentId = it },
            label = { Text("الرقم الجامعي") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("البريد الإلكتروني") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = newPassword,
            onValueChange = { newPassword = it },
            label = { Text("كلمة مرور جديدة (اختياري)") },
            placeholder = { Text("٨ أحرف على الأقل") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = !passwordValid,
            shape = AppShapes.Small,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = if (!passwordValid) "كلمة المرور يجب أن تكون ٨ أحرف على الأقل."
            else "اترك حقل كلمة المرور فارغاً للاحتفاظ بالحالية. تغييرها يلغي الجلسات القديمة للطالب.",
            style = MaterialTheme.typography.bodySmall,
            color = if (!passwordValid) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AddAdminDialog(
    busy: Boolean,
    error: String?,
    onCreate: (email: String, name: String, password: String) -> Unit,
    onDismiss: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    FormDialog(
        title = "إضافة أدمن جديد",
        confirmText = "إضافة",
        busy = busy,
        error = error,
        confirmEnabled = email.contains("@") && name.isNotBlank() && password.length >= 8,
        onConfirm = { onCreate(email.trim(), name.trim(), password) },
        onDismiss = onDismiss
    ) {
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("الاسم") }, singleLine = true,
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("البريد الإلكتروني") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("كلمة المرور (8 أحرف أو أكثر)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        Text(
            "يدخل من خانة الاسم بالبريد وكلمة المرور، ويحصل على كل صلاحيات الأدمن.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


@Composable
fun PromoteStudentDialog(
    student: com.saifadnan.pharmacynotes.data.UserEntity,
    busy: Boolean,
    error: String?,
    onPromote: (email: String, password: String) -> Unit,
    onDismiss: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    FormDialog(
        title = "تعيين أدمن",
        confirmText = "تعيين",
        busy = busy,
        error = error,
        confirmEnabled = email.contains("@") && password.length >= 8,
        onConfirm = { onPromote(email.trim(), password) },
        onDismiss = onDismiss
    ) {
        Text(
            text = student.fullName,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("بريد الدخول للأدمن") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("كلمة المرور (8 أحرف أو أكثر)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            shape = AppShapes.Small, modifier = Modifier.fillMaxWidth()
        )
        Text(
            "يصير أدمن بهذه المرحلة فقط، ويدخل من خانة الاسم بالبريد وكلمة المرور. بياناته كطالب تبقى محفوظة.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
