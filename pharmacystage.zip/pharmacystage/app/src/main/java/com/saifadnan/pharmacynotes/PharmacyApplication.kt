package com.saifadnan.pharmacynotes

import android.app.Application
import android.content.Context
import com.saifadnan.pharmacynotes.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PharmacyApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        appScope.launch {

            warmUpPrefs("pharmacy_user_session") { it.getBoolean("key_is_logged_in", false) }
            warmUpPrefs("pharmacy_dismissed_notifs") { it.getStringSet("dismissed_ids", emptySet()) }
            warmUpPrefs("pharmacy_read_notifs") { it.getStringSet("read_ids", emptySet()) }

            AppDatabase.getDatabase(this@PharmacyApplication, appScope)
        }

        appScope.launch {
            com.saifadnan.pharmacynotes.data.SupabaseClient.warmUp()
        }
    }

    private inline fun warmUpPrefs(name: String, touch: (android.content.SharedPreferences) -> Unit) {
        try {
            touch(getSharedPreferences(name, Context.MODE_PRIVATE))
        } catch (e: Exception) {

        }
    }
}
