package com.saifadnan.pharmacynotes

import com.saifadnan.pharmacynotes.util.AdminConfig
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.compose.ui.geometry.Rect
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saifadnan.pharmacynotes.data.BroadcastNotificationEntity
import com.saifadnan.pharmacynotes.ui.components.BroadcastBanner
import com.saifadnan.pharmacynotes.ui.components.PharmacyBottomBar
import com.saifadnan.pharmacynotes.ui.components.PharmacyNavRail
import com.saifadnan.pharmacynotes.ui.theme.AdaptiveContent
import com.saifadnan.pharmacynotes.ui.theme.rememberAdaptive
import com.saifadnan.pharmacynotes.ui.components.AppBackground
import com.saifadnan.pharmacynotes.ui.components.softBlur
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import androidx.compose.animation.AnimatedContentScope
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.graphics.Color
import com.saifadnan.pharmacynotes.ui.screens.AdminScreen
import com.saifadnan.pharmacynotes.ui.screens.AdminScheduleScreen
import com.saifadnan.pharmacynotes.ui.screens.HomeScreen
import com.saifadnan.pharmacynotes.ui.screens.LectureDetailScreen
import com.saifadnan.pharmacynotes.ui.screens.LoginScreen
import com.saifadnan.pharmacynotes.ui.screens.NotificationsScreen
import com.saifadnan.pharmacynotes.ui.screens.ProfileScreen
import com.saifadnan.pharmacynotes.ui.screens.SplashScreen
import com.saifadnan.pharmacynotes.ui.screens.StudentScheduleScreen
import com.saifadnan.pharmacynotes.ui.theme.MustansiriyahTheme
import com.saifadnan.pharmacynotes.ui.viewmodel.PharmacyViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: PharmacyViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        @Suppress("DEPRECATION")
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        com.saifadnan.pharmacynotes.util.SystemNotificationHelper.clearAllNotifications(this)

        handleNotificationIntent(intent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            MustansiriyahTheme(darkTheme = isDarkMode) {
                AppBackground {
                    PharmacyApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        com.saifadnan.pharmacynotes.util.SystemNotificationHelper.clearAllNotifications(this)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        com.saifadnan.pharmacynotes.util.SystemNotificationHelper.clearAllNotifications(this)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(intent: android.content.Intent?) {
        val lectureId = intent?.getLongExtra("LECTURE_ID", -1L) ?: -1L
        if (lectureId != -1L) {
            viewModel.selectLectureById(lectureId)
        }
    }
}

@Composable
fun PharmacyApp(viewModel: PharmacyViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val adaptive = rememberAdaptive()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val loginError by viewModel.loginErrorMessage.collectAsStateWithLifecycle()
    val loginStages by viewModel.stages.collectAsStateWithLifecycle()
    val isAdminMode by viewModel.isAdminMode.collectAsStateWithLifecycle()
    val banRequests by viewModel.banRequests.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(viewModel) {
        viewModel.adminMessage.collect { msg ->
            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()

    val subjects by viewModel.allSubjects.collectAsStateWithLifecycle()
    val examPinnedSubjects by viewModel.examPinnedSubjects.collectAsStateWithLifecycle()
    val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedSemester by viewModel.selectedSemester.collectAsStateWithLifecycle()
    val onlyDownloaded by viewModel.onlyDownloaded.collectAsStateWithLifecycle()
    val onlyBookmarked by viewModel.onlyBookmarked.collectAsStateWithLifecycle()
    val sortOrder by viewModel.sortOrder.collectAsStateWithLifecycle()

    val allLectures by viewModel.allLectures.collectAsStateWithLifecycle()
    val filteredLectures by viewModel.filteredLectures.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadCount.collectAsStateWithLifecycle()
    val selectedLecture by viewModel.selectedLecture.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val allSchedule by viewModel.allSchedule.collectAsStateWithLifecycle()
    val myGroupName by viewModel.myGroupName.collectAsStateWithLifecycle()
    val mySchedule by viewModel.myScheduleFlow.collectAsStateWithLifecycle()
    val allExams by viewModel.allExams.collectAsStateWithLifecycle()
    val isTabLoading by viewModel.isTabLoading.collectAsStateWithLifecycle()
    val classRemindersEnabled by viewModel.classRemindersEnabled.collectAsStateWithLifecycle()
    val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val categoryCounts by viewModel.categoryCounts.collectAsStateWithLifecycle()
    val allSubjectsAll by viewModel.subjectsAllSections.collectAsStateWithLifecycle()
    val allAdmins by viewModel.allAdmins.collectAsStateWithLifecycle()

    var showSplash by remember { mutableStateOf(true) }
    val uiPreferences = remember(context) {
        context.getSharedPreferences("pharmacy_ui_preferences", android.content.Context.MODE_PRIVATE)
    }
    var splashLogoBounds by remember { mutableStateOf<Rect?>(null) }
    var activeBroadcastAlert by remember { mutableStateOf<BroadcastNotificationEntity?>(null) }

    LaunchedEffect(Unit) {
        viewModel.latestBroadcastAlert.collect { notif ->
            activeBroadcastAlert = notif
        }
    }

    val homeScreen: @Composable () -> Unit = {
        HomeScreen(
            downloadProgress = downloadProgress,
            subjects = subjects,
            examPinnedSubjects = examPinnedSubjects,
            lectures = filteredLectures,
            totalLecturesCount = allLectures.size,
            allLectures = allLectures,
            selectedSection = selectedSection,
            onSectionSelect = { viewModel.selectSection(it) },
            selectedCategory = selectedCategory,
            onCategorySelect = { viewModel.selectCategory(it) },
            categoryCounts = categoryCounts,
            selectedSubject = selectedSubject,
            searchQuery = searchQuery,
            selectedSemester = selectedSemester,
            onlyDownloaded = onlyDownloaded,
            onlyBookmarked = onlyBookmarked,
            sortOrder = sortOrder,
            onSubjectSelect = { viewModel.selectSubject(it) },
            onSearchQueryChange = { viewModel.setSearchQuery(it) },
            onSemesterSelect = { viewModel.setSelectedSemester(it) },
            onToggleOnlyDownloaded = { viewModel.toggleOnlyDownloaded() },
            onToggleOnlyBookmarked = { viewModel.toggleOnlyBookmarked() },
            onSortOrderChange = { viewModel.setSortOrder(it) },
            onLectureClick = { viewModel.selectLecture(it) },
            onToggleBookmark = { viewModel.toggleBookmark(it) },
            onToggleDownload = { lecture ->
                viewModel.downloadLectureFile(context, lecture) { _, msg ->
                    android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                }
            },
            isRefreshing = isRefreshing,
            isTabLoading = isTabLoading,
            onReloadClick = { viewModel.reloadServerData() },
            isDarkMode = isDarkMode,
            onThemeToggle = { viewModel.toggleDarkMode() }
        )
    }

    AnimatedContent(
        targetState = Pair(showSplash, isLoggedIn),
        transitionSpec = {
            if (initialState.first && !targetState.first && !targetState.second) {
                fadeIn(tween(140, easing = MotionSpecs.EmphasizedEasing))
                    .togetherWith(fadeOut(tween(320, easing = MotionSpecs.EmphasizedEasing)))
                    .using(SizeTransform(clip = false))
            } else {
                (fadeIn(tween(400, delayMillis = 80, easing = MotionSpecs.EmphasizedEasing)) +
                    scaleIn(tween(400, delayMillis = 80, easing = MotionSpecs.EmphasizedEasing), initialScale = 0.96f))
                    .togetherWith(fadeOut(tween(260)) + scaleOut(tween(260), targetScale = 1.03f))
                    .using(SizeTransform(clip = false))
            }
        },
        label = "MainAppScreenTransition"
    ) { (splash, loggedIn) ->
        if (splash) {
            SplashScreen(
                onSplashFinished = { bounds ->
                    splashLogoBounds = bounds
                    showSplash = false
                }
            )
        } else if (!loggedIn) {
            LoginScreen(
                errorMessage = loginError,
                stages = loginStages,
                initialStage = com.saifadnan.pharmacynotes.data.Stages.current,
                animateLogoEntrance = splashLogoBounds != null,
                logoFromBounds = splashLogoBounds,
                onLogoEntranceFinished = { splashLogoBounds = null },
                onLogin = { emailOrCode, password, name, studentId, isSignUp, groupName, stage ->
                    viewModel.login(emailOrCode, password, name, studentId, isSignUp, groupName = groupName, stage = stage)
                }
            )
        } else {
            BackHandler(enabled = selectedLecture == null && selectedTab != "HOME") {
                viewModel.setSelectedTab("HOME")
            }

            Scaffold(
                bottomBar = {
                    if (selectedLecture == null && !adaptive.useRail) {
                        PharmacyBottomBar(
                            currentTab = selectedTab,
                            isAdminMode = isAdminMode,
                            unreadNotificationsCount = unreadCount,
                            onTabSelected = { tab ->
                                viewModel.setSelectedTab(tab)
                                if (tab == "NOTIFICATIONS") {
                                    viewModel.markAllNotificationsRead()
                                }
                            }
                        )
                    }
                },
                containerColor = Color.Transparent,
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                AnimatedVisibility(
                    visible = adaptive.useRail && selectedLecture == null,
                    enter = fadeIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay)) +
                        expandHorizontally(tween(MotionSpecs.ScreenIn, easing = MotionSpecs.EmphasizedEasing)),
                    exit = fadeOut(tween(MotionSpecs.ScreenOut)) +
                        shrinkHorizontally(tween(MotionSpecs.ScreenOut))
                ) {
                    PharmacyNavRail(
                        currentTab = selectedTab,
                        isAdminMode = isAdminMode,
                        unreadNotificationsCount = unreadCount,
                        onTabSelected = { tab ->
                            viewModel.setSelectedTab(tab)
                            if (tab == "NOTIFICATIONS") {
                                viewModel.markAllNotificationsRead()
                            }
                        }
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .then(if (selectedLecture == null) Modifier.statusBarsPadding() else Modifier)
                ) {
                    AnimatedContent(
                        targetState = selectedLecture,
                        contentKey = { it?.id },
                        transitionSpec = {
                            if (targetState != null) {
                                (fadeIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay)) +
                                    scaleIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay, easing = MotionSpecs.EmphasizedEasing), initialScale = 0.95f))
                                    .togetherWith(fadeOut(tween(MotionSpecs.ScreenOut)) + scaleOut(tween(MotionSpecs.ScreenOut), targetScale = 1.04f))
                                    .using(SizeTransform(clip = false))
                            } else {
                                (fadeIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay)) +
                                    scaleIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay, easing = MotionSpecs.EmphasizedEasing), initialScale = 1.04f))
                                    .togetherWith(fadeOut(tween(MotionSpecs.ScreenOut)) + scaleOut(tween(MotionSpecs.ScreenOut), targetScale = 0.95f))
                                    .using(SizeTransform(clip = false))
                            }
                        },
                        label = "LectureDetailTransition"
                    ) { currentSelectedLecture ->
                        val liveLecture = if (currentSelectedLecture != null) (selectedLecture ?: currentSelectedLecture) else null
                        SoftTransitionBox(maxRadius = 12f) {
                        if (liveLecture != null) {
                            LectureDetailScreen(
                                lecture = liveLecture,
                                onBack = { viewModel.selectLecture(null) },
                                onToggleBookmark = { viewModel.toggleBookmark(liveLecture) },
                                onToggleDownload = { lecture ->
                                    viewModel.downloadLectureFile(context, lecture) { success, msg ->
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onAvailableOffline = { viewModel.markAvailableOffline(it) }
                            )
                        } else {
                            AnimatedContent(
                                targetState = selectedTab,
                                transitionSpec = {
                                    val tabOrder = listOf("HOME", "BOOKMARKS", "NOTIFICATIONS", "ADMIN", "PROFILE", "MY_SCHEDULE", "MY_EXAMS", "MY_CARD", "ADMIN_SCHEDULE", "EDIT_PROFILE")
                                    val initialIdx = tabOrder.indexOf(initialState).coerceAtLeast(0)
                                    val targetIdx = tabOrder.indexOf(targetState).coerceAtLeast(0)
                                    val dir = if (targetIdx >= initialIdx) 1 else -1
                                    (fadeIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay, easing = MotionSpecs.EmphasizedEasing)) +
                                        slideInHorizontally(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay, easing = MotionSpecs.EmphasizedEasing)) { w -> dir * w / 16 } +
                                        scaleIn(tween(MotionSpecs.ScreenIn, delayMillis = MotionSpecs.ScreenInDelay, easing = MotionSpecs.EmphasizedEasing), initialScale = 0.985f))
                                        .togetherWith(
                                            fadeOut(tween(MotionSpecs.ScreenOut)) +
                                                slideOutHorizontally(tween(MotionSpecs.ScreenOut)) { w -> -dir * w / 24 }
                                        )
                                        .using(SizeTransform(clip = false))
                                },
                                label = "TabTransition"
                            ) { targetTab ->
                        SoftTransitionBox(maxRadius = 8f) {
                        AdaptiveContent(
                            maxWidth = if (targetTab == "HOME" || targetTab == "ADMIN") adaptive.gridMaxWidth else adaptive.contentMaxWidth
                        ) {
                        when (targetTab) {
                            "HOME" -> homeScreen()

                            "NOTIFICATIONS" -> NotificationsScreen(
                                notifications = notifications,
                                onMarkAllRead = { viewModel.markNotificationsRead() },
                                onDismissNotification = { notifId -> viewModel.dismissNotification(notifId) },
                                onDismissAll = { viewModel.dismissAllNotifications() },
                                onNotificationClick = { notif ->
                                    if (notif.lectureId != null) {
                                        viewModel.selectLectureById(notif.lectureId)
                                    }
                                },
                                isAdmin = isAdminMode,
                                onTogglePin = { notifId, isPinned -> viewModel.toggleNotificationPinned(notifId, isPinned) },
                                onEditNotification = { updated, onResult -> viewModel.updateNotification(updated, onResult) },
                                isTabLoading = isTabLoading
                            )

                            "PROFILE" -> ProfileScreen(
                                currentUser = currentUser,
                                downloadedCount = allLectures.count { it.isDownloaded },
                                bookmarkedCount = allLectures.count { it.isBookmarked },
                                isDarkMode = isDarkMode,
                                isAdminMode = isAdminMode,
                                onToggleDarkMode = { viewModel.toggleDarkMode() },
                                onNavigateToDownloads = {
                                    if (onlyBookmarked) viewModel.toggleOnlyBookmarked()
                                    if (!onlyDownloaded) viewModel.toggleOnlyDownloaded()
                                    viewModel.setSelectedTab("HOME")
                                },
                                onNavigateToFavorites = {
                                    if (onlyDownloaded) viewModel.toggleOnlyDownloaded()
                                    if (!onlyBookmarked) viewModel.toggleOnlyBookmarked()
                                    viewModel.setSelectedTab("HOME")
                                },
                                onNavigateToAdmin = {
                                    viewModel.setSelectedTab("ADMIN")
                                },
                                onNavigateToExams = { viewModel.setSelectedTab("MY_EXAMS") },
                                onNavigateToCard = { viewModel.setSelectedTab("MY_CARD") },
                                onNavigateToEditProfile = { viewModel.setSelectedTab("EDIT_PROFILE") },
                                onNavigateToSchedule = {
                                    viewModel.setSelectedTab(if (isAdminMode) "ADMIN_SCHEDULE" else "MY_SCHEDULE")
                                },
                                onLogoutClick = {
                                    viewModel.logout()
                                },
                                isTabLoading = isTabLoading,
                                isAdminAccount = currentUser?.role == "ADMIN",
                                selectedCourse = selectedSemester,
                                onCourseSelect = { viewModel.setSelectedSemester(it) },
                                onToggleAdminMode = {
                                    viewModel.toggleAdminMode()
                                    if (!isAdminMode) {
                                        viewModel.setSelectedTab("ADMIN")
                                    } else if (selectedTab == "ADMIN") {
                                        viewModel.setSelectedTab("HOME")
                                    }
                                }
                            )

                            "EDIT_PROFILE" -> if (currentUser != null && currentUser?.role != "ADMIN") {
                                com.saifadnan.pharmacynotes.ui.screens.EditProfileScreen(
                                    user = currentUser,
                                    stages = loginStages,
                                    onSave = { fullName, email, studentId, stage, currentPassword, newPassword, onResult ->
                                        viewModel.updateProfile(fullName, email, studentId, stage, currentPassword, newPassword, onResult)
                                    },
                                    onBack = { viewModel.setSelectedTab("PROFILE") }
                                )
                            }

                            "MY_CARD" -> com.saifadnan.pharmacynotes.ui.screens.StudentCardScreen(
                                userEmail = currentUser?.email.orEmpty(),
                                onBack = { viewModel.setSelectedTab("PROFILE") }
                            )

                            "MY_EXAMS" -> com.saifadnan.pharmacynotes.ui.screens.StudentExamScreen(
                                myGroup = myGroupName,
                                exams = allExams,
                                onBack = { viewModel.setSelectedTab("PROFILE") }
                            )

                            "MY_SCHEDULE" -> StudentScheduleScreen(
                                myGroup = myGroupName,
                                schedule = mySchedule,
                                onGroupSelected = { group -> viewModel.setMyGroup(group) },
                                remindersEnabled = classRemindersEnabled,
                                onRemindersToggle = { viewModel.setClassRemindersEnabled(it) },
                                onBack = { viewModel.setSelectedTab("PROFILE") }
                            )

                            "ADMIN_SCHEDULE" -> AdminScheduleScreen(
                                schedule = allSchedule,
                                onAdd = { entry -> viewModel.upsertScheduleEntry(entry) },
                                onDelete = { entry -> viewModel.deleteScheduleEntry(entry) },
                                onBack = { viewModel.setSelectedTab("PROFILE") }
                            )

                            "ADMIN" -> if (isAdminMode && currentUser?.role == "ADMIN") {
                                AdminScreen(
                                    subjects = allSubjectsAll,
                                    lectures = allLectures,
                                    students = allStudents,
                                    admins = allAdmins,
                                    currentAdminEmail = currentUser?.email.orEmpty(),
                                    banRequests = banRequests,
                                    onDecideBanRequest = { id, approve -> viewModel.decideBanRequest(id, approve) },
                                    onUploadLecture = { req, onResult -> viewModel.uploadLectureByAdmin(req, onResult) },
                                    onToggleSubjectExamPinned = { name, section, semester, pinned ->
                                        viewModel.toggleSubjectExamPinned(name, section, semester, pinned)
                                    },
                                    onPublishAnnouncement = { title, msg, url, imgUrl, style ->
                                        viewModel.publishAnnouncement(title, msg, url, imgUrl, style) {}
                                    },
                                    exams = allExams,
                                    onSaveExam = { exam, onResult -> viewModel.upsertExam(exam, onResult) },
                                    onDeleteExam = { exam, onResult -> viewModel.deleteExam(exam, onResult) },
                                    onSetSubjectIcon = { name, section, semester, icon, onResult ->
                                        viewModel.setSubjectIcon(name, section, semester, icon, onResult)
                                    },
                                    onDeleteLecture = { viewModel.deleteLecture(it) },
                                    onUpdateLecture = { lecture, onResult -> viewModel.updateLecture(lecture, onResult) },
                                    onAddSubjectFolder = { name, section, semester -> viewModel.addSubjectFolder(name, section, semester) {} },
                                    onDeleteSubjectFolder = { name, section, semester, onResult ->
                                        viewModel.deleteSubjectFolder(name, section, semester, onResult)
                                    },
                                    onRenameSubjectFolder = { old, new, section, semester, onResult ->
                                        viewModel.renameSubjectFolder(old, new, section, semester, onResult)
                                    },
                                    onApproveStudent = { student -> viewModel.approveStudent(student) },
                                    onRejectStudent = { student -> viewModel.rejectStudent(student) },
                                    onUpdateStudent = { email, name, studentId, newPassword, onResult ->
                                        viewModel.updateStudent(email, name, studentId, newPassword, onResult)
                                    },
                                    onChangeEmail = { email, newEmail, onResult ->
                                        viewModel.changeUserEmail(email, newEmail, onResult)
                                    },
                                    onDeleteStudent = { email, onResult -> viewModel.deleteUserAccount(email, onResult) },
                                    onResetDevices = { email, onResult -> viewModel.resetUserDevices(email, onResult) },
                                    onCreateAdmin = { email, name, password, onResult ->
                                        viewModel.createAdmin(email, password, name, onResult)
                                    },
                                    onDemoteAdmin = { email, onResult -> viewModel.demoteAdmin(email, onResult) },
                                    onPromoteStudent = { student, newEmail, password, onResult ->
                                        viewModel.promoteStudent(student.email, newEmail, password, student.fullName, onResult)
                                    },
                                    onSwitchStage = { stage, onResult -> viewModel.switchStage(stage, onResult) },
                                    onRefreshUsers = { viewModel.refreshUsers() },
                                    isTabLoading = isTabLoading
                                )
                            } else {
                                homeScreen()
                            }

                            else -> homeScreen()
                        }
                        }
                        }
                    }
                }
                        }
            }

                val focusPrefs = remember { context.getSharedPreferences("focus_ack", android.content.Context.MODE_PRIVATE) }
                var ackedFocus by remember { mutableStateOf(focusPrefs.getStringSet("ids", emptySet()) ?: emptySet()) }
                val pendingFocus = if (showSplash || currentUser == null || currentUser?.role == "ADMIN") null else
                    notifications.firstOrNull {
                        it.style.isNotBlank() &&
                            com.saifadnan.pharmacynotes.ui.components.NotifStyle.parse(it.style).focus &&
                            it.id.toString() !in ackedFocus &&
                            System.currentTimeMillis() - it.timestamp < 7L * 24 * 3600 * 1000
                    }
                pendingFocus?.let { n ->
                    com.saifadnan.pharmacynotes.ui.components.FocusNoticeDialog(
                        title = n.title,
                        message = n.message,
                        style = com.saifadnan.pharmacynotes.ui.components.NotifStyle.parse(n.style),
                        onAck = {
                            ackedFocus = ackedFocus + n.id.toString()
                            focusPrefs.edit().putStringSet("ids", ackedFocus).apply()
                            if (activeBroadcastAlert?.id == n.id) activeBroadcastAlert = null
                        }
                    )
                }

                BroadcastBanner(
                    notification = activeBroadcastAlert,
                    onDismiss = { activeBroadcastAlert = null },
                    onViewClick = { notif ->
                        activeBroadcastAlert = null
                        notif.lectureId?.let { id ->
                            val target = allLectures.find { it.id == id }
                            if (target != null) {
                                viewModel.selectLecture(target)
                            }
                        }
                    },
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
                }
        }
    }
}
}
@Composable
@Suppress("UNUSED_PARAMETER")
private fun AnimatedContentScope.SoftTransitionBox(maxRadius: Float, content: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        content()
    }
}