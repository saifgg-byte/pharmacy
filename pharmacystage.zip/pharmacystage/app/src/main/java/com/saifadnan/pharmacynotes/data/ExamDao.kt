package com.saifadnan.pharmacynotes.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {
    @Query("SELECT * FROM exam_schedule ORDER BY examDate ASC, startHour ASC, startMinute ASC")
    fun getAll(): Flow<List<ExamEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(e: ExamEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<ExamEntity>)

    @Query("DELETE FROM exam_schedule WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM exam_schedule WHERE id NOT IN (:ids)")
    suspend fun deleteNotIn(ids: List<String>)

    @Query("DELETE FROM exam_schedule")
    suspend fun clearAll()
}
