package com.saifadnan.pharmacynotes.util

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureTokenStore(context: Context) {
    private val appContext = context.applicationContext

    @Volatile private var memAccess: String? = null
    @Volatile private var memRefresh: String? = null
    @Volatile private var memExpiry: Long = 0L

    private val prefs: SharedPreferences? = open() ?: run {

        try { appContext.deleteSharedPreferences(FILE) } catch (_: Exception) {}
        open()
    }

    private fun open(): SharedPreferences? = try {
        val key = MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            appContext, FILE, key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.e("SecureTokenStore", "Encrypted prefs unavailable, using memory only", e)
        null
    }

    fun save(access: String?, refresh: String?, expiresAtMs: Long) {
        memAccess = access; memRefresh = refresh; memExpiry = expiresAtMs
        prefs?.edit()
            ?.putString(K_ACCESS, access)
            ?.putString(K_REFRESH, refresh)
            ?.putLong(K_EXPIRY, expiresAtMs)
            ?.apply()
    }

    fun accessToken(): String? = memAccess ?: prefs?.getString(K_ACCESS, null)
    fun refreshToken(): String? = memRefresh ?: prefs?.getString(K_REFRESH, null)
    fun expiresAtMs(): Long = if (memExpiry > 0) memExpiry else (prefs?.getLong(K_EXPIRY, 0L) ?: 0L)

    fun clear() {
        memAccess = null; memRefresh = null; memExpiry = 0L
        prefs?.edit()?.clear()?.apply()
    }

    companion object {
        const val FILE = "pharmacy_secure_tokens"
        private const val K_ACCESS = "access"
        private const val K_REFRESH = "refresh"
        private const val K_EXPIRY = "expiry"
    }
}
