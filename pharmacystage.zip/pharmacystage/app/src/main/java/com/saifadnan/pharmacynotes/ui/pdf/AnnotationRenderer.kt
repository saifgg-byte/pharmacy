package com.saifadnan.pharmacynotes.ui.pdf

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.LruCache
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.toArgb
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal object InkRenderer {

    private const val MAX_TEXT_W = 0.92f
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val layoutCache = LruCache<String, StaticLayout>(64)

    private class Ctx {
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val path = Path()
    }

    private fun withAlpha(rgb: Int, opacity: Float): Int {
        val a = (255f * opacity).roundToInt().coerceIn(0, 255)
        return (rgb and 0x00FFFFFF) or (a shl 24)
    }

    fun drawPage(
        canvas: Canvas,
        w: Float,
        h: Float,
        strokes: List<HStroke>,
        texts: List<TextItem>,
        live: HStroke? = null
    ) {
        if (w <= 0f || h <= 0f) return
        val ctx = Ctx()
        val needLayer = live?.tool == InkTool.ERASER || strokes.any { it.tool == InkTool.ERASER }
        val layer = if (needLayer) canvas.saveLayer(0f, 0f, w, h, null) else -1
        for (s in strokes) drawStroke(canvas, ctx, w, h, s)
        if (live != null) drawStroke(canvas, ctx, w, h, live)
        if (needLayer) canvas.restoreToCount(layer)
        for (t in texts) drawText(canvas, t, w, h)
    }

    // ---------------------------------------------------------------- الخطوط

    private fun buildPath(path: Path, pts: List<androidx.compose.ui.geometry.Offset>, w: Float, h: Float) {
        path.reset()
        val n = pts.size
        val p0 = pts[0]
        path.moveTo(p0.x * w, p0.y * h)
        if (n == 1) {
            path.lineTo(p0.x * w + 0.01f, p0.y * h)
            return
        }
        if (n == 2) {
            val p1 = pts[1]
            path.lineTo(p1.x * w + 0.01f, p1.y * h)
            return
        }
        for (i in 1 until n - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            path.quadTo(a.x * w, a.y * h, (a.x + b.x) / 2f * w, (a.y + b.y) / 2f * h)
        }
        val last = pts[n - 1]
        path.lineTo(last.x * w, last.y * h)
    }

    private fun drawStroke(canvas: Canvas, ctx: Ctx, w: Float, h: Float, st: HStroke) {
        val legacy = st.tool == InkTool.LEGACY
        val tool = if (legacy) InkTool.HIGHLIGHTER else st.tool
        val rgb = if (legacy) HighlightColors[st.color.coerceIn(0, HighlightColors.lastIndex)].toArgb() else st.argb
        val opacity = if (legacy) 0.4f else st.opacity
        val widthPx = max(0.6f, (if (legacy) 0.022f else st.width) * w)

        val rects = st.rects
        if (rects != null && st.points.size < 2) {
            ctx.fill.xfermode = null
            ctx.fill.color = withAlpha(rgb, opacity)
            for (r in rects) canvas.drawRect(r.left * w, r.top * h, r.right * w, r.bottom * h, ctx.fill)
            return
        }
        if (st.points.isEmpty()) return

        buildPath(ctx.path, st.points, w, h)
        val p = ctx.stroke
        p.xfermode = null
        when (tool) {
            InkTool.ERASER -> {
                p.xfermode = clearMode
                p.color = 0xFF000000.toInt()
                p.strokeWidth = widthPx
                canvas.drawPath(ctx.path, p)
                p.xfermode = null
            }
            InkTool.BRUSH -> drawBrush(canvas, ctx, st, rgb, opacity, widthPx, w, h)
            else -> {
                p.color = withAlpha(rgb, opacity)
                p.strokeWidth = widthPx
                canvas.drawPath(ctx.path, p)
            }
        }
    }

    private fun drawBrush(canvas: Canvas, ctx: Ctx, st: HStroke, rgb: Int, opacity: Float, widthPx: Float, w: Float, h: Float) {
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (o in st.points) {
            minX = min(minX, o.x * w); maxX = max(maxX, o.x * w)
            minY = min(minY, o.y * h); maxY = max(maxY, o.y * h)
        }
        val pad = widthPx + 2f
        val layer = canvas.saveLayerAlpha(
            minX - pad, minY - pad, maxX + pad, maxY + pad,
            (255f * opacity).roundToInt().coerceIn(0, 255)
        )
        val p = ctx.stroke
        val widths = floatArrayOf(1f, 0.82f, 0.62f)
        val alphas = intArrayOf(70, 130, 255)
        for (i in widths.indices) {
            p.color = (rgb and 0x00FFFFFF) or (alphas[i] shl 24)
            p.strokeWidth = widthPx * widths[i]
            canvas.drawPath(ctx.path, p)
        }
        canvas.restoreToCount(layer)
    }

    // ---------------------------------------------------------------- النصوص

    private class TextGeo(val layout: StaticLayout, val pad: Float, val boxW: Float, val boxH: Float)

    @Suppress("DEPRECATION")
    private fun geo(item: TextItem, w: Float): TextGeo {
        val size = max(4f, item.size * w)
        val pad = size * 0.3f
        val key = "${item.text.hashCode()}|${item.text.length}|${size.roundToInt()}|${item.bold}|${w.roundToInt()}"
        var layout = layoutCache.get(key)
        if (layout == null) {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                typeface = if (item.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            val maxW = max(size, MAX_TEXT_W * w - 2f * pad)
            val desired = ceil(Layout.getDesiredWidth(item.text, tp)).toInt().coerceAtLeast(1)
            val width = min(desired, maxW.toInt()).coerceAtLeast(1)
            layout = if (Build.VERSION.SDK_INT >= 23) {
                StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, width)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 1.12f)
                    .setIncludePad(false)
                    .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                    .build()
            } else {
                StaticLayout(item.text, tp, width, Layout.Alignment.ALIGN_NORMAL, 1.12f, 0f, false)
            }
            layoutCache.put(key, layout)
        }
        val l = layout!!
        return TextGeo(l, pad, l.width + 2f * pad, l.height + 2f * pad)
    }

    fun textBox(item: TextItem, w: Float, h: Float): Rect {
        if (w <= 0f || h <= 0f || item.text.isEmpty()) return Rect(item.x * w, item.y * h, item.x * w, item.y * h)
        val g = geo(item, w)
        val l = item.x * w
        val t = item.y * h
        return Rect(l, t, l + g.boxW, t + g.boxH)
    }

    private fun bgColorFor(argb: Int, opacity: Float, custom: Int = 0): Int {
        if (custom != 0) return withAlpha(custom, 0.9f * opacity)
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        val lum = 0.299f * r + 0.587f * g + 0.114f * b
        val base = if (lum > 150f) 0x111827 else 0xFFFFFF
        return withAlpha(base, 0.9f * opacity)
    }

    private fun drawText(canvas: Canvas, item: TextItem, w: Float, h: Float) {
        if (item.text.isBlank()) return
        val g = geo(item, w)
        val left = item.x * w
        val top = item.y * h
        if (item.bg) {
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = bgColorFor(item.argb, item.opacity, item.bgArgb)
            }
            val r = item.size * w * 0.35f
            canvas.drawRoundRect(left, top, left + g.boxW, top + g.boxH, r, r, fill)
        }
        g.layout.paint.color = withAlpha(item.argb, item.opacity)
        val save = canvas.save()
        canvas.translate(left + g.pad, top + g.pad)
        g.layout.draw(canvas)
        canvas.restoreToCount(save)
    }
}