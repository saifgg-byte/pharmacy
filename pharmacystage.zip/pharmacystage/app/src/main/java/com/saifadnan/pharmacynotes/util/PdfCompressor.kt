package com.saifadnan.pharmacynotes.util

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import kotlin.coroutines.coroutineContext
import kotlin.math.max

object PdfCompressor {

    private val LEVELS = listOf(
        2000 to 74,
        1700 to 66,
        1450 to 58,
        1200 to 50,
        1000 to 44
    )

    suspend fun compress(
        input: File,
        output: File,
        targetBytes: Long,
        onProgress: (donePages: Int, totalPages: Int, levelIndex: Int, levelCount: Int) -> Unit = { _, _, _, _ -> }
    ): Boolean = withContext(Dispatchers.IO) {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val total = renderer.pageCount
            if (total == 0) return@withContext false

            for ((li, level) in LEVELS.withIndex()) {
                val (maxSide, quality) = level
                val fits = writeLevel(renderer, output, total, maxSide, quality, targetBytes) { done ->
                    onProgress(done, total, li, LEVELS.size)
                }
                if (fits) return@withContext true
            }
            output.delete()
            false
        } catch (e: kotlinx.coroutines.CancellationException) {
            output.delete()
            throw e
        } catch (e: Throwable) {
            e.printStackTrace()
            output.delete()
            false
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    private class Out(private val out: OutputStream) {
        var count = 0L
            private set

        fun write(bytes: ByteArray) {
            out.write(bytes)
            count += bytes.size
        }

        fun write(text: String) = write(text.toByteArray(Charsets.ISO_8859_1))
        fun flush() = out.flush()
        fun close() = out.close()
    }

    private suspend fun writeLevel(
        renderer: PdfRenderer,
        output: File,
        total: Int,
        maxSide: Int,
        quality: Int,
        targetBytes: Long,
        onPage: (Int) -> Unit
    ): Boolean {
        output.delete()
        val out = Out(BufferedOutputStream(FileOutputStream(output), 256 * 1024))

        val offsets = LongArray(3 + total * 3)
        var ok = true
        try {
            out.write("%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n")

            offsets[1] = out.count
            out.write("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")

            val kids = StringBuilder()
            for (i in 0 until total) {
                coroutineContext.ensureActive()
                val pageId = 3 + i * 3
                val contentId = pageId + 1
                val imageId = pageId + 2

                val page = renderer.openPage(i)
                val pw = page.width.toFloat().coerceAtLeast(1f)
                val ph = page.height.toFloat().coerceAtLeast(1f)
                val scale = maxSide / max(pw, ph)
                val bw = (pw * scale).toInt().coerceAtLeast(1)
                val bh = (ph * scale).toInt().coerceAtLeast(1)
                val jpeg: ByteArray
                try {
                    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    val bos = ByteArrayOutputStream(bw * bh / 8)
                    bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                    bmp.recycle()
                    jpeg = bos.toByteArray()
                } finally {
                    page.close()
                }

                val pwS = String.format(Locale.US, "%.2f", pw)
                val phS = String.format(Locale.US, "%.2f", ph)

                offsets[pageId] = out.count
                out.write(
                    "$pageId 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pwS $phS] " +
                        "/Resources << /XObject << /Im0 $imageId 0 R >> >> /Contents $contentId 0 R >>\nendobj\n"
                )

                val content = "q $pwS 0 0 $phS 0 0 cm /Im0 Do Q"
                offsets[contentId] = out.count
                out.write("$contentId 0 obj\n<< /Length ${content.length} >>\nstream\n$content\nendstream\nendobj\n")

                offsets[imageId] = out.count
                out.write(
                    "$imageId 0 obj\n<< /Type /XObject /Subtype /Image /Width $bw /Height $bh " +
                        "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.size} >>\nstream\n"
                )
                out.write(jpeg)
                out.write("\nendstream\nendobj\n")

                kids.append("$pageId 0 R ")
                onPage(i + 1)

                val done = i + 1
                if (done >= 6 && done < total) {
                    val projected = out.count.toDouble() / done * total
                    if (projected > targetBytes * 1.12) {
                        ok = false
                        break
                    }
                }
            }

            if (ok) {
                offsets[2] = out.count
                out.write("2 0 obj\n<< /Type /Pages /Kids [ $kids] /Count $total >>\nendobj\n")

                val xrefPos = out.count
                val size = offsets.size
                out.write("xref\n0 $size\n0000000000 65535 f \n")
                for (id in 1 until size) {
                    out.write(String.format(Locale.US, "%010d 00000 n \n", offsets[id]))
                }
                out.write("trailer\n<< /Size $size /Root 1 0 R >>\nstartxref\n$xrefPos\n%%EOF\n")
            }
            out.flush()
        } finally {
            try { out.close() } catch (_: Exception) {}
        }
        if (!ok) {
            output.delete()
            return false
        }
        return output.length() in 1..targetBytes
    }
}
