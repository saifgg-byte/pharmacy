package com.saifadnan.pharmacynotes.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.ui.theme.TelegramAccent
import com.saifadnan.pharmacynotes.ui.theme.glass

@Composable
fun TelegramSupportButton(
    modifier: Modifier = Modifier,
    label: String = "للتبليغ عن أي مشكلة: Saif Adnan",
    url: String = "https://t.me/Saifer1653"
) {
    val context = LocalContext.current
    val glass = MaterialTheme.glass
    Row(
        modifier = modifier
            .height(44.dp)
            .iconInteractiveClick(
                behavior = IconClickBehavior.SPRING_BOUNCE,
                scaleDown = 0.96f,
                onClick = {
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }
            )
            .clip(CircleShape)
            .background(TelegramAccent.copy(alpha = if (glass.isDark) 0.12f else 0.09f))
            .border(1.dp, TelegramAccent.copy(alpha = 0.28f), CircleShape)
            .padding(start = 8.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_telegram),
            contentDescription = "Telegram Support",
            tint = Color.Unspecified,
            modifier = Modifier.size(28.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
