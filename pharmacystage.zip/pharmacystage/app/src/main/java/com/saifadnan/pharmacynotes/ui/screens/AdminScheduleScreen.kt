package com.saifadnan.pharmacynotes.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.data.ScheduleEntity
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.Spacing
import java.util.UUID

@Composable
fun AdminScheduleScreen(
    schedule: List<ScheduleEntity>,
    onAdd: (ScheduleEntity) -> Unit,
    onDelete: (ScheduleEntity) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedGroup by remember { mutableStateOf(ScheduleConstants.GROUPS.first()) }
    var selectedSubject by remember { mutableStateOf(ScheduleConstants.SUBJECTS.first()) }
    var selectedSessionType by remember { mutableStateOf(ScheduleConstants.SESSION_TYPES.first()) }
    var selectedDay by remember { mutableStateOf(ScheduleConstants.WEEK_DAYS.first()) }
    var startHour by remember { mutableIntStateOf(8) }
    var startMinute by remember { mutableIntStateOf(0) }
    var endHour by remember { mutableIntStateOf(9) }
    var endMinute by remember { mutableIntStateOf(0) }
    var room by remember { mutableStateOf("") }
    var doctorName by remember { mutableStateOf("") }

    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_schedule_screen"),
        contentPadding = PaddingValues(bottom = Spacing.Xxl)
    ) {
        item {
            ScreenHeader(
                title = "إدارة الجدول",
                subtitle = "حصص كل كروب",
                modifier = Modifier.padding(horizontal = 20.dp),
                leading = {
                    GlassIconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admin_schedule_back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            )
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = Spacing.Lg)
                    .clip(AppShapes.Card)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, CardBorder, AppShapes.Card)
                    .padding(Spacing.Lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.Md)
            ) {
                Text(
                    text = "إضافة حصة دراسية جديدة",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                LabeledDropdown(
                    label = "الكروب",
                    options = ScheduleConstants.GROUPS,
                    selected = selectedGroup,
                    onSelect = { selectedGroup = it },
                    testTagPrefix = "schedule_group"
                )

                LabeledDropdown(
                    label = "المادة",
                    options = ScheduleConstants.SUBJECTS,
                    selected = selectedSubject,
                    onSelect = { selectedSubject = it },
                    testTagPrefix = "schedule_subject"
                )

                LabeledDropdown(
                    label = "نوع المحاضرة",
                    options = ScheduleConstants.SESSION_TYPES,
                    selected = selectedSessionType,
                    onSelect = { selectedSessionType = it },
                    testTagPrefix = "schedule_session_type"
                )

                LabeledDropdown(
                    label = "اليوم",
                    options = ScheduleConstants.WEEK_DAYS.map { it.arabicName },
                    selected = selectedDay.arabicName,
                    onSelect = { name ->
                        selectedDay = ScheduleConstants.WEEK_DAYS.first { it.arabicName == name }
                    },
                    testTagPrefix = "schedule_day"
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(Spacing.Sm),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TimePickerField(
                        label = "من الساعة",
                        hour = startHour,
                        minute = startMinute,
                        onTimeChange = { h, m -> startHour = h; startMinute = m },
                        context = context,
                        modifier = Modifier.weight(1f),
                        testTag = "schedule_start_time"
                    )
                    TimePickerField(
                        label = "إلى الساعة",
                        hour = endHour,
                        minute = endMinute,
                        onTimeChange = { h, m -> endHour = h; endMinute = m },
                        context = context,
                        modifier = Modifier.weight(1f),
                        testTag = "schedule_end_time"
                    )
                }

                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("القاعة (اختياري)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("schedule_room_field")
                )

                OutlinedTextField(
                    value = doctorName,
                    onValueChange = { doctorName = it },
                    label = { Text("اسم التدريسي (اختياري)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("schedule_doctor_field")
                )

                Button(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    onClick = {
                        onAdd(
                            ScheduleEntity(
                                id = UUID.randomUUID().toString(),
                                groupName = selectedGroup,
                                subject = selectedSubject,
                                sessionType = selectedSessionType,
                                dayOfWeek = selectedDay.calendarDayOfWeek,
                                startHour = startHour,
                                startMinute = startMinute,
                                endHour = endHour,
                                endMinute = endMinute,
                                room = room.trim(),
                                doctorName = doctorName.trim()
                            )
                        )
                        room = ""
                        doctorName = ""
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("schedule_add_button")
                ) {
                    Text("إضافة للجدول", fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Text(
                text = "الجدول الحالي (${schedule.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = Spacing.Lg, vertical = Spacing.Sm)
            )
        }

        val sortedSchedule = schedule.sortedWith(
            compareBy({ it.groupName }, { it.dayOfWeek }, { it.startHour }, { it.startMinute })
        )

        if (sortedSchedule.isEmpty()) {
            item {
                Text(
                    text = "ماكو أي حصص مضافة لحد الآن",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = Spacing.Lg)
                )
            }
        } else {
            items(sortedSchedule, key = { it.id }) { entry ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Spacing.Lg, vertical = Spacing.Xs)
                        .clip(AppShapes.Medium)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, CardBorder, AppShapes.Medium)
                        .padding(Spacing.Md),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${entry.groupName} · ${entry.subject} (${entry.sessionType})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${ScheduleConstants.dayName(entry.dayOfWeek)} · " +
                                String.format("%02d:%02d", entry.startHour, entry.startMinute) +
                                " - " +
                                String.format("%02d:%02d", entry.endHour, entry.endMinute) +
                                if (entry.room.isNotBlank()) " · قاعة ${entry.room}" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = { onDelete(entry) },
                        modifier = Modifier.testTag("schedule_delete_${entry.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledDropdown(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    testTagPrefix: String
) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(Spacing.Xs)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Box {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AppShapes.Medium)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, CardBorder, AppShapes.Medium)
                    .clickable { expanded = true }
                    .padding(horizontal = Spacing.Md, vertical = Spacing.Md)
                    .testTag("${testTagPrefix}_field"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = selected, style = MaterialTheme.typography.bodyMedium)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            onSelect(option)
                            expanded = false
                        },
                        modifier = Modifier.testTag("${testTagPrefix}_option_$option")
                    )
                }
            }
        }
    }
}

@Composable
private fun TimePickerField(
    label: String,
    hour: Int,
    minute: Int,
    onTimeChange: (Int, Int) -> Unit,
    context: android.content.Context,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(Spacing.Xs)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(AppShapes.Medium)
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, CardBorder, AppShapes.Medium)
                .clickable {
                    TimePickerDialog(
                        context,
                        { _, h, m -> onTimeChange(h, m) },
                        hour,
                        minute,
                        true
                    ).show()
                }
                .padding(horizontal = Spacing.Md, vertical = Spacing.Md)
                .testTag(testTag),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = String.format("%02d:%02d", hour, minute),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
