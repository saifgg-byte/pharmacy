package com.saifadnan.pharmacynotes.data

object Section {
    const val THEORY = "THEORY"
    const val PRACTICAL = "PRACTICAL"

    val all = listOf(THEORY, PRACTICAL)

    fun label(section: String): String = when (section) {
        PRACTICAL -> "العملي"
        else -> "النظري"
    }
}

object Category {
    const val OFFICIAL = "OFFICIAL"
    const val GHRADI = "GHRADI"
    const val REEYUS = "REEYUS"

    fun label(category: String): String = when (category) {
        GHRADI -> "غراضي"
        REEYUS -> "ريوس"
        else -> "المحاضرات"
    }

    fun forSection(section: String): List<String> =
        if (section == Section.PRACTICAL) listOf(OFFICIAL, GHRADI) else listOf(OFFICIAL, GHRADI, REEYUS)
}

object Course {
    const val FIRST = 1
    const val SECOND = 2

    val all = listOf(FIRST, SECOND)

    fun label(course: Int): String = if (course == SECOND) "الكورس الثاني" else "الكورس الأول"
}

object WorksheetType {
    const val WORKSHEET = "WORKSHEET"
    const val DATASHEET = "DATASHEET"

    val all = listOf(WORKSHEET, DATASHEET)

    fun label(type: String): String = when (type) {
        DATASHEET -> "Datasheet"
        else -> "Worksheet"
    }
}

data class NewLectureRequest(
    val title: String,
    val subject: String,
    val semester: Int,
    val fileUrl: String,
    val sendNotification: Boolean,
    val fileSize: String? = null,
    val pageCount: Int? = null,
    val section: String = Section.THEORY,
    val category: String = Category.OFFICIAL,
    val worksheetUrl: String = "",
    val worksheetType: String = "",
    val youtubeUrl: String = ""
)
