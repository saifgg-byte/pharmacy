package com.saifadnan.pharmacynotes.ui.screens

import android.util.Patterns
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.StageInfo
import com.saifadnan.pharmacynotes.data.Stages
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.ui.components.AuthIcons
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.glass
import kotlinx.coroutines.delay

private const val MIN_PASSWORD_LENGTH = 8

@Composable
fun EditProfileScreen(
    user: UserEntity?,
    stages: List<StageInfo>,
    onSave: (
        fullName: String?,
        email: String?,
        studentId: String?,
        stage: Int?,
        currentPassword: String,
        newPassword: String?,
        onResult: (String?) -> Unit
    ) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val originalName = remember { user?.fullName.orEmpty().trim() }
    val originalEmail = remember { user?.email.orEmpty().trim() }
    val originalId = remember { user?.studentId.orEmpty().trim() }
    val originalStage = remember { Stages.current }

    var name by remember { mutableStateOf(originalName) }
    var email by remember { mutableStateOf(originalEmail) }
    var studentId by remember { mutableStateOf(originalId) }
    var selectedStage by remember { mutableIntStateOf(originalStage) }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var currentPassword by remember { mutableStateOf("") }
    var newPasswordVisible by remember { mutableStateOf(false) }
    var currentPasswordVisible by remember { mutableStateOf(false) }

    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var lastError by remember { mutableStateOf("") }

    val focusManager = LocalFocusManager.current
    val shake = remember { Animatable(0f) }

    val nameChanged = name.trim() != originalName
    val emailChanged = !email.trim().equals(originalEmail, ignoreCase = true)
    val idChanged = studentId.trim() != originalId
    val stageChanged = selectedStage != originalStage
    val passwordChanged = newPassword.isNotEmpty() || confirmPassword.isNotEmpty()
    val needsCurrentPassword = emailChanged || idChanged || stageChanged || passwordChanged
    val hasChanges = nameChanged || needsCurrentPassword

    LaunchedEffect(error) {
        error?.let { lastError = it }
        if (error != null) {
            for (target in floatArrayOf(-10f, 8f, -6f, 3f, 0f)) {
                shake.animateTo(target, tween(55, easing = LinearOutSlowInEasing))
            }
        }
    }
    LaunchedEffect(saved) {
        if (saved) {
            delay(1000)
            onBack()
        }
    }

    BackHandler(enabled = !saving) { onBack() }

    fun validate(): String? = when {
        nameChanged && name.trim().split(Regex("\\s+")).size < 3 -> "اكتب الاسم الثلاثي على الأقل."
        !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "صيغة البريد الإلكتروني غير صحيحة."
        studentId.trim().isEmpty() -> "الرقم الجامعي مطلوب."
        passwordChanged && newPassword.length < MIN_PASSWORD_LENGTH ->
            "كلمة المرور الجديدة يجب أن تتكون من $MIN_PASSWORD_LENGTH أحرف على الأقل."
        passwordChanged && newPassword != confirmPassword -> "تأكيد كلمة المرور غير مطابق."
        needsCurrentPassword && currentPassword.isEmpty() -> "أدخل كلمة المرور الحالية لتأكيد التغيير."
        else -> null
    }

    fun submit() {
        if (saving || saved || !hasChanges) return
        val problem = validate()
        if (problem != null) {
            error = problem
            return
        }
        focusManager.clearFocus()
        error = null
        saving = true
        onSave(
            name.trim().takeIf { nameChanged },
            email.trim().takeIf { emailChanged },
            studentId.trim().takeIf { idChanged },
            selectedStage.takeIf { stageChanged },
            currentPassword,
            newPassword.takeIf { passwordChanged }
        ) { message ->
            saving = false
            if (message == null) saved = true else error = message
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "تعديل بيانات",
            subtitle = "حسابك الشخصي",
            modifier = Modifier.padding(horizontal = 20.dp),
            leading = {
                GlassIconButton(onClick = { if (!saving) onBack() }, modifier = Modifier.testTag("edit_profile_back")) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth().animateItemEntrance(0)) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CardTitle(Icons.Default.Person, "البيانات الشخصية", "تكدر تغير معلومات الشخصية هنا")
                    EditField(
                        value = name,
                        onValueChange = { name = it; error = null },
                        label = "اسم الطالب الكامل",
                        icon = AuthIcons.PersonName,
                        enabled = !saving && !saved,
                        modifier = Modifier.testTag("edit_profile_name")
                    )
                    EditField(
                        value = email,
                        onValueChange = { email = it.trimStart(); error = null },
                        label = "البريد الإلكتروني",
                        icon = Icons.Default.Email,
                        keyboardType = KeyboardType.Email,
                        enabled = !saving && !saved,
                        modifier = Modifier.testTag("edit_profile_email")
                    )
                    EditField(
                        value = studentId,
                        onValueChange = { studentId = it.trimStart(); error = null },
                        label = "الرقم الجامعي",
                        icon = AuthIcons.StudentId,
                        enabled = !saving && !saved,
                        modifier = Modifier.testTag("edit_profile_student_id")
                    )
                }
            }

            if (stages.size > 1) {
                GlassCard(modifier = Modifier.fillMaxWidth().animateItemEntrance(1)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CardTitle(Icons.Default.School, "المرحلة الدراسية", "تحدد المواد والمحاضرات اللي تطلع الك")
                        StagePicker(
                            stages = stages,
                            selected = selectedStage,
                            onSelect = { if (!saving && !saved) { selectedStage = it; error = null } }
                        )
                        AnimatedVisibility(
                            visible = stageChanged,
                            enter = fadeIn(tween(180)) + expandVertically(tween(240, easing = MotionSpecs.EmphasizedEasing)),
                            exit = fadeOut(tween(140)) + shrinkVertically(tween(200))
                        ) {
                            StatusBanner(
                                text = "سينتقل حسابك إلى ${Stages.label(selectedStage)}. ستُمسح المحاضرات المحملة والمفضلة المحفوظة على جهازك وتظهر لك محاضرات المرحلة الجديدة.",
                                tone = Amber,
                                icon = Icons.Default.WarningAmber
                            )
                        }
                    }
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth().animateItemEntrance(2)) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CardTitle(Icons.Default.LockReset, "كلمة المرور", "اتركها فارغة إذا ما تريد تغييرها")
                    EditField(
                        value = newPassword,
                        onValueChange = { newPassword = it; error = null },
                        label = "كلمة المرور الجديدة",
                        icon = Icons.Default.Lock,
                        keyboardType = KeyboardType.Password,
                        password = true,
                        passwordVisible = newPasswordVisible,
                        onToggleVisible = { newPasswordVisible = !newPasswordVisible },
                        enabled = !saving && !saved,
                        modifier = Modifier.testTag("edit_profile_new_password")
                    )
                    AnimatedVisibility(
                        visible = newPassword.isNotEmpty(),
                        enter = fadeIn(tween(180)) + expandVertically(tween(240, easing = MotionSpecs.EmphasizedEasing)),
                        exit = fadeOut(tween(140)) + shrinkVertically(tween(200))
                    ) {
                        EditField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it; error = null },
                            label = "تأكيد كلمة المرور الجديدة",
                            icon = Icons.Default.Lock,
                            keyboardType = KeyboardType.Password,
                            password = true,
                            passwordVisible = newPasswordVisible,
                            onToggleVisible = { newPasswordVisible = !newPasswordVisible },
                            enabled = !saving && !saved,
                            modifier = Modifier.testTag("edit_profile_confirm_password")
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = needsCurrentPassword,
                enter = fadeIn(tween(200)) + expandVertically(tween(260, easing = MotionSpecs.EmphasizedEasing)),
                exit = fadeOut(tween(140)) + shrinkVertically(tween(200))
            ) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CardTitle(Icons.Default.Shield, "تأكيد الهوية", "أدخل كلمة مرورك الحالية لحفظ هذه التغييرات")
                        EditField(
                            value = currentPassword,
                            onValueChange = { currentPassword = it; error = null },
                            label = "كلمة المرور الحالية",
                            icon = Icons.Default.Lock,
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done,
                            onImeAction = { submit() },
                            password = true,
                            passwordVisible = currentPasswordVisible,
                            onToggleVisible = { currentPasswordVisible = !currentPasswordVisible },
                            enabled = !saving && !saved,
                            modifier = Modifier.testTag("edit_profile_current_password")
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = error != null || saved,
                enter = fadeIn(tween(180)) + expandVertically(tween(220)),
                exit = fadeOut(tween(140)) + shrinkVertically(tween(180))
            ) {
                val positive = saved
                val text = if (positive) "تم حفظ بياناتك بنجاح." else (error ?: lastError)
                StatusBanner(
                    text = text,
                    tone = if (positive) SuccessGreen else MaterialTheme.colorScheme.error,
                    icon = if (positive) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                    modifier = Modifier.graphicsLayer { translationX = shake.value.dp.toPx() }
                )
            }

            PillButton(
                text = when {
                    saved -> "تم الحفظ"
                    saving -> "جارٍ الحفظ…"
                    else -> "حفظ التعديلات"
                },
                icon = if (saved) Icons.Default.Check else Icons.Default.Save,
                onClick = { submit() },
                enabled = hasChanges && !saved,
                loading = saving,
                modifier = Modifier.fillMaxWidth().testTag("edit_profile_save")
            )
        }
    }
}

@Composable
private fun CardTitle(icon: ImageVector, title: String, subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconTile(icon = icon, size = 40.dp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StatusBanner(
    text: String,
    tone: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        color = tone.copy(alpha = 0.10f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, tone.copy(alpha = 0.28f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tone, modifier = Modifier.size(20.dp))
            Text(
                text = text,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun EditField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    onImeAction: (() -> Unit)? = null,
    password: Boolean = false,
    passwordVisible: Boolean = false,
    onToggleVisible: (() -> Unit)? = null,
    enabled: Boolean = true
) {
    val glass = MaterialTheme.glass
    val iconTint = MaterialTheme.colorScheme.onSurfaceVariant
    val focusManager = LocalFocusManager.current
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null, tint = iconTint) },
        trailingIcon = if (password && onToggleVisible != null) {
            {
                IconButton(onClick = onToggleVisible) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = if (passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور",
                        tint = iconTint
                    )
                }
            }
        } else null,
        visualTransformation = if (password && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(
            onNext = { focusManager.moveFocus(FocusDirection.Down) },
            onDone = { if (onImeAction != null) onImeAction() else focusManager.clearFocus() }
        ),
        singleLine = true,
        enabled = enabled,
        shape = RoundedCornerShape(20.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
            unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.13f),
            focusedContainerColor = glass.fillBottom,
            unfocusedContainerColor = glass.fillBottom.copy(alpha = glass.fillBottom.alpha * 0.7f),
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
            disabledTextColor = MaterialTheme.colorScheme.onSurface,
            disabledBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
            disabledContainerColor = glass.fillBottom.copy(alpha = glass.fillBottom.alpha * 0.7f),
            focusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            cursorColor = MaterialTheme.colorScheme.primary
        ),
        modifier = modifier.fillMaxWidth()
    )
}