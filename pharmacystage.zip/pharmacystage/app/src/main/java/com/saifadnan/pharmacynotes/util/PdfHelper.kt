package com.saifadnan.pharmacynotes.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.saifadnan.pharmacynotes.data.LectureEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap

object PdfHelper {

    open class LectureFileException(message: String, cause: Throwable? = null) : IOException(message, cause)

    class NoInternetException(cause: Throwable? = null) : LectureFileException(
        "لا يوجد اتصال بالإنترنت، وهذه المحاضرة غير محفوظة على جهازك بعد. افتحها مرة واحدة وأنت متصل بالإنترنت لتبقى محفوظة وتفتح بدون إنترنت.",
        cause
    )

    private const val RETRY_DELAY_MS = 3000L
    private const val ONLINE_POLL_MS = 1000L

    fun isConnectionIssue(context: Context, error: Throwable): Boolean =
        error is NoInternetException ||
            error.cause is UnknownHostException ||
            error.cause is SocketException ||
            error.cause is SocketTimeoutException ||
            (error is LectureFileException && error.cause != null && !ClassReminderSettings.isOnline(context))

    suspend fun awaitConnection(context: Context) {
        delay(RETRY_DELAY_MS)
        while (!ClassReminderSettings.isOnline(context)) delay(ONLINE_POLL_MS)
    }

    private const val OFFLINE_DIR_NAME = "offline_lectures"

    private val downloadLocks = ConcurrentHashMap<Long, Mutex>()

    private fun lockFor(lectureId: Long): Mutex = downloadLocks.getOrPut(lectureId) { Mutex() }

    private fun offlineDir(context: Context): File {
        val dir = File(context.filesDir, OFFLINE_DIR_NAME)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun offlineFile(context: Context, lectureId: Long): File =
        File(offlineDir(context), "lecture_$lectureId.pdf")

    private fun legacyDir(context: Context): File =
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir

    private fun legacyFile(context: Context, lecture: LectureEntity): File {
        val safeFileName = lecture.title.replace(Regex("[^a-zA-Z0-9_ -]"), "_") + "_${lecture.id}.pdf"
        return File(legacyDir(context), safeFileName)
    }

    private fun looksLikePdf(file: File): Boolean {
        if (!file.exists() || file.length() < 8) return false
        return try {
            file.inputStream().use { input ->
                val head = ByteArray(1024)
                val n = input.read(head)
                n > 0 && String(head, 0, n, Charsets.ISO_8859_1).contains("%PDF-")
            }
        } catch (e: Exception) {
            false
        }
    }

    fun getOfflineCopy(context: Context, lecture: LectureEntity): File? {
        val target = offlineFile(context, lecture.id)
        if (looksLikePdf(target)) {
            val saved = try {
                File(target.parentFile, target.name + ".src").takeIf { it.exists() }?.readText()
            } catch (e: Exception) {
                null
            }
            if (saved == null || saved == lecture.fileUrl.substringAfterLast('/')) return target
            deleteOfflineCopy(context, lecture.id)
            return null
        }
        if (target.exists()) target.delete()

        val legacy = legacyFile(context, lecture)
        if (looksLikePdf(legacy)) {
            return try {
                legacy.copyTo(target, overwrite = true)
                legacy.delete()
                target
            } catch (e: Exception) {
                e.printStackTrace()
                if (target.exists()) target.delete()
                legacy
            }
        }
        return null
    }

    fun deleteOfflineCopy(context: Context, lectureId: Long) {
        val target = offlineFile(context, lectureId)
        target.delete()
        File(target.parentFile, target.name + ".tmp").delete()
        File(target.parentFile, target.name + ".src").delete()
        offlineDir(context).listFiles { f -> f.isFile && f.name.startsWith("worksheet_${lectureId}_") }
            ?.forEach { it.delete() }
        legacyDir(context).listFiles { f -> f.isFile && f.name.endsWith("_$lectureId.pdf") }
            ?.forEach { it.delete() }
    }

    suspend fun getOrDownloadPdfFile(
        context: Context,
        lecture: LectureEntity,
        cacheFile: File? = null,
        onProgress: (String) -> Unit = {}
    ): File = withContext(Dispatchers.IO) {
        lockFor(lecture.id).withLock {

            if (cacheFile != null) {
                if (looksLikePdf(cacheFile)) return@withLock cacheFile
            } else {
                getOfflineCopy(context, lecture)?.let { return@withLock it }
            }

            val urlString = lecture.fileUrl
            if (urlString.isBlank()) {
                throw LectureFileException("رابط الملف فارغ")
            }

            val targetFile = cacheFile ?: offlineFile(context, lecture.id)
            val tempFile = File(targetFile.parentFile, targetFile.name + ".tmp")
            val isRemote = urlString.startsWith("http://") || urlString.startsWith("https://")

            try {
                when {

                    urlString.startsWith("data:application/pdf;base64,") ||
                        urlString.startsWith("data:pdf;base64,") ||
                        urlString.startsWith("base64:") ||
                        urlString.contains("base64,") -> {
                        val base64Data = if (urlString.contains("base64,")) urlString.substringAfter("base64,") else urlString.removePrefix("base64:")
                        val cleanBase64 = base64Data.replace("\n", "").replace("\r", "").replace(" ", "").trim()
                        val bytes = android.util.Base64.decode(cleanBase64, android.util.Base64.DEFAULT)
                        FileOutputStream(tempFile).use { output -> output.write(bytes) }
                    }

                    urlString.startsWith("file://") || urlString.startsWith("/") -> {
                        val sourceFile = File(urlString.removePrefix("file://"))
                        if (!sourceFile.exists() || sourceFile.length() <= 0) {
                            throw java.io.FileNotFoundException("الملف غير موجود")
                        }
                        sourceFile.copyTo(tempFile, overwrite = true)
                    }

                    urlString.startsWith("content://") -> {
                        context.contentResolver.openInputStream(Uri.parse(urlString))?.use { input ->
                            FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                        } ?: throw java.io.FileNotFoundException("تعذر قراءة الملف")
                    }

                    isRemote -> downloadHttp(context, urlString, tempFile, onProgress)
                    else -> throw LectureFileException("رابط الملف غير صالح")
                }

                if (!tempFile.exists() || tempFile.length() <= 0) {
                    throw LectureFileException("تعذر تحميل ملف الـ PDF. تأكد من توفر الاتصال ورابط الملف الحقيقي.")
                }
                if (!looksLikePdf(tempFile)) {
                    throw LectureFileException("الملف الذي تم تنزيله ليس ملف PDF صالحاً. يرجى إبلاغ إدارة التطبيق.")
                }

                if (targetFile.exists()) targetFile.delete()
                if (!tempFile.renameTo(targetFile)) {
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }
                if (cacheFile == null) {
                    try {
                        File(targetFile.parentFile, targetFile.name + ".src").writeText(urlString.substringAfterLast('/'))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                targetFile
            } catch (e: CancellationException) {
                tempFile.delete()
                throw e
            } catch (e: LectureFileException) {
                tempFile.delete()
                throw e
            } catch (e: Exception) {
                e.printStackTrace()
                tempFile.delete()
                throw when {
                    isRemote && (e is UnknownHostException || e is SocketException || e is SocketTimeoutException) ->
                        NoInternetException(e)
                    isRemote ->
                        LectureFileException("تعذر تنزيل المحاضرة من السيرفر. يرجى التأكد من توفر الاتصال بالإنترنت.", e)
                    else ->
                        LectureFileException("تعذر تحميل ملف الـ PDF. تأكد من توفر الاتصال ورابط الملف الحقيقي.", e)
                }
            }
        }
    }

    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    private const val PARALLEL_PARTS = 6
    private const val FIRST_BYTES = 512L * 1024
    private const val MIN_SLICE = 768L * 1024
    private const val MAX_SLICE = 4L * 1024 * 1024
    private const val BUFFER_BYTES = 128 * 1024

    private val downloadClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .dns(com.saifadnan.pharmacynotes.data.ResilientDns)
            .protocols(listOf(okhttp3.Protocol.HTTP_1_1))
            .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
            .connectionPool(okhttp3.ConnectionPool(PARALLEL_PARTS + 2, 5, java.util.concurrent.TimeUnit.MINUTES))
            .dispatcher(okhttp3.Dispatcher().apply { maxRequests = 32; maxRequestsPerHost = 16 })
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private fun fileRequest(url: String, range: String? = null): okhttp3.Request =
        okhttp3.Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept-Encoding", "identity")
            .apply { if (range != null) header("Range", range) }
            .build()

    private fun reportBytes(onProgress: (String) -> Unit, done: Long, total: Long, lastPercent: IntArray) {
        if (total > 0) {
            val percent = ((done * 100) / total).toInt().coerceIn(0, 100)
            if (percent != lastPercent[0]) {
                lastPercent[0] = percent
                onProgress("جاري تنزيل المحاضرة من السيرفر ($percent%)...")
            }
        } else {
            val mb = String.format(java.util.Locale.US, "%.1f MB", done / (1024.0 * 1024.0))
            onProgress("جاري تنزيل المحاضرة ($mb)...")
        }
    }

    private fun downloadHttp(
        context: Context,
        urlString: String,
        tempFile: File,
        onProgress: (String) -> Unit
    ) {
        onProgress("جاري الاتصال بالخادم السحابي...")

        var total = -1L
        var firstLen = 0L
        var singleDone = false

        downloadClient.newCall(fileRequest(urlString, "bytes=0-${FIRST_BYTES - 1}")).execute().use { response ->
            when {
                response.code == 206 -> {
                    total = response.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
                    if (total > 0) {
                        ensureFreeSpace(context, total)
                        val body = response.body ?: throw IOException("رد فارغ من السيرفر")
                        java.io.RandomAccessFile(tempFile, "rw").use { raf ->
                            raf.setLength(total)
                            raf.seek(0)
                            val buf = ByteArray(BUFFER_BYTES)
                            body.byteStream().use { input ->
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    raf.write(buf, 0, n)
                                    firstLen += n
                                }
                            }
                        }
                        if (firstLen < minOf(FIRST_BYTES, total)) {
                            throw IOException("انقطع الاتصال قبل اكتمال الجزء الأول")
                        }
                    }
                }
                response.isSuccessful -> {
                    streamSingle(context, response, tempFile, onProgress)
                    singleDone = true
                }
                else -> throw IOException("استجابة غير صالحة من السيرفر: ${response.code}")
            }
        }
        if (singleDone) return

        if (total > 0) {
            if (firstLen >= total) return
            try {
                downloadParallel(urlString, tempFile, firstLen, total, onProgress)
                if (tempFile.length() == total) return
            } catch (e: CancellationException) {
                throw e
            } catch (e: LectureFileException) {
                throw e
            } catch (e: Exception) {
                e.printStackTrace()
            }
            tempFile.delete()
            onProgress("إعادة المحاولة باتصال واحد...")
        }

        downloadClient.newCall(fileRequest(urlString)).execute().use { response ->
            if (!response.isSuccessful) throw IOException("استجابة غير صالحة من السيرفر: ${response.code}")
            streamSingle(context, response, tempFile, onProgress)
        }
    }

    private fun streamSingle(context: Context, response: okhttp3.Response, tempFile: File, onProgress: (String) -> Unit) {
        val body = response.body ?: throw IOException("رد فارغ من السيرفر")
        val contentLength = body.contentLength()
        ensureFreeSpace(context, contentLength)
        val last = intArrayOf(-1)
        body.byteStream().use { input ->
            FileOutputStream(tempFile).use { output ->
                val buffer = ByteArray(BUFFER_BYTES)
                var bytesRead: Int
                var totalRead = 0L
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    totalRead += bytesRead
                    reportBytes(onProgress, totalRead, contentLength, last)
                }
            }
        }
    }

    private fun downloadParallel(
        urlString: String,
        tempFile: File,
        from: Long,
        total: Long,
        onProgress: (String) -> Unit
    ) {
        val remaining = total - from
        val slice = (remaining / (PARALLEL_PARTS * 3)).coerceIn(MIN_SLICE, MAX_SLICE)
        val sliceCount = ((remaining + slice - 1) / slice).toInt()
        val workers = minOf(PARALLEL_PARTS, sliceCount).coerceAtLeast(1)
        val next = java.util.concurrent.atomic.AtomicInteger(0)
        val done = java.util.concurrent.atomic.AtomicLong(from)
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val calls = java.util.concurrent.CopyOnWriteArrayList<okhttp3.Call>()
        val pool = java.util.concurrent.Executors.newFixedThreadPool(workers)
        try {
            java.io.RandomAccessFile(tempFile, "rw").use { raf ->
                val channel = raf.channel
                val futures = ArrayList<java.util.concurrent.Future<*>>()
                for (w in 0 until workers) {
                    futures.add(pool.submit(Runnable {
                        while (failure.get() == null) {
                            val i = next.getAndIncrement()
                            if (i >= sliceCount) break
                            val start = from + i * slice
                            val end = minOf(total - 1, start + slice - 1)
                            try {
                                downloadSlice(urlString, channel, start, end, done, calls)
                            } catch (t: Throwable) {
                                if (failure.compareAndSet(null, t)) calls.forEach { it.cancel() }
                                break
                            }
                        }
                    }))
                }
                val last = intArrayOf(-1)
                while (futures.any { !it.isDone }) {
                    Thread.sleep(120)
                    if (Thread.currentThread().isInterrupted) throw InterruptedException()
                    reportBytes(onProgress, done.get(), total, last)
                }
                failure.get()?.let { throw (it as? Exception) ?: IOException("فشل تنزيل جزء من الملف", it) }
                reportBytes(onProgress, total, total, last)
            }
        } finally {
            calls.forEach { it.cancel() }
            pool.shutdownNow()
        }
    }

    private fun downloadSlice(
        urlString: String,
        channel: java.nio.channels.FileChannel,
        start: Long,
        end: Long,
        done: java.util.concurrent.atomic.AtomicLong,
        calls: java.util.concurrent.CopyOnWriteArrayList<okhttp3.Call>
    ) {
        var pos = start
        var attempt = 0
        val buf = ByteArray(BUFFER_BYTES)
        while (pos <= end) {
            val call = downloadClient.newCall(fileRequest(urlString, "bytes=$pos-$end"))
            try {
                calls.add(call)
                call.execute().use { r ->
                    if (r.code != 206) throw IOException("السيرفر لا يدعم التنزيل بالأجزاء (${r.code})")
                    val body = r.body ?: throw IOException("رد فارغ من السيرفر")
                    body.byteStream().use { input ->
                        while (pos <= end) {
                            val n = input.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                            if (n < 0) break
                            var off = 0
                            while (off < n) {
                                off += channel.write(java.nio.ByteBuffer.wrap(buf, off, n - off), pos + off)
                            }
                            pos += n
                            done.addAndGet(n.toLong())
                        }
                    }
                }
                if (pos <= end) throw IOException("انقطع الاتصال قبل اكتمال الجزء")
            } catch (e: Exception) {
                if (Thread.currentThread().isInterrupted || call.isCanceled() || ++attempt >= 3) throw e
                Thread.sleep(300L * attempt)
            } finally {
                calls.remove(call)
            }
        }
    }

    private fun ensureFreeSpace(context: Context, contentLength: Long) {
        if (contentLength <= 0) return
        val free = context.filesDir.usableSpace
        if (free > 0 && free < contentLength + 5L * 1024 * 1024) {
            throw LectureFileException("مساحة التخزين في جهازك غير كافية لحفظ هذه المحاضرة. يرجى تفريغ بعض المساحة والمحاولة مرة أخرى.")
        }
    }

    fun isPdfUrl(url: String): Boolean = url.substringBefore('?').lowercase().endsWith(".pdf")

    private fun baseId(lecture: LectureEntity): Long = if (lecture.id < 0) -lecture.id else lecture.id

    fun worksheetTag(url: String): String =
        url.substringBefore('?').substringAfterLast('/').substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9_-]"), "")
            .ifBlank { url.hashCode().toString().replace("-", "n") }

    private fun worksheetPrefs(context: Context) = context.getSharedPreferences("worksheet_saved", Context.MODE_PRIVATE)

    private fun savedKey(lecture: LectureEntity) = "${baseId(lecture)}|${worksheetTag(lecture.worksheetUrl)}"

    fun isWorksheetSaved(context: Context, lecture: LectureEntity): Boolean =
        worksheetPrefs(context).getBoolean(savedKey(lecture), false)

    private fun markWorksheetSaved(context: Context, lecture: LectureEntity) {
        worksheetPrefs(context).edit().putBoolean(savedKey(lecture), true).apply()
    }

    fun worksheetDisplayTitle(lecture: LectureEntity): String =
        if (lecture.id < 0) lecture.title
        else "${com.saifadnan.pharmacynotes.data.WorksheetType.label(lecture.worksheetType)} - ${lecture.title}"

    fun worksheetSavedMessage(path: String): String =
        if (path.contains("Mustansiriyah_Pharmacy")) "تم حفظ الملف في التنزيلات (مجلد Mustansiriyah_Pharmacy)"
        else "تم تنزيل الملف على جهازك"

    fun worksheetEntity(lecture: LectureEntity, saved: Boolean = false): LectureEntity = lecture.copy(
        id = -baseId(lecture),
        title = worksheetDisplayTitle(lecture.copy(id = baseId(lecture))),
        fileUrl = lecture.worksheetUrl,
        pageCount = 1,
        isDownloaded = saved,
        isBookmarked = false,
        downloadPath = null,
        youtubeUrl = ""
    )

    fun deleteWorksheetCopy(context: Context, lecture: LectureEntity) {
        offlineDir(context).listFiles { f -> f.isFile && f.name.startsWith("worksheet_${baseId(lecture)}_") }
            ?.forEach { it.delete() }
    }

    suspend fun getWorksheetFile(
        context: Context,
        lecture: LectureEntity,
        onProgress: (String) -> Unit = {}
    ): File {
        val tag = worksheetTag(lecture.worksheetUrl)
        val dir = offlineDir(context)
        val target = File(dir, "worksheet_${baseId(lecture)}_$tag.pdf")
        withContext(Dispatchers.IO) {
            dir.listFiles { f -> f.isFile && f.name.startsWith("worksheet_${baseId(lecture)}_") && f.name != target.name }
                ?.forEach { it.delete() }
        }
        return getOrDownloadPdfFile(context, worksheetEntity(lecture), cacheFile = target, onProgress = onProgress)
    }

    suspend fun saveWorksheetToDevice(
        context: Context,
        lecture: LectureEntity,
        onProgress: (String) -> Unit = {}
    ): String {
        val file = getWorksheetFile(context, lecture, onProgress)
        val path = withContext(Dispatchers.IO) { savePdfToPublicDeviceStorage(context, file, worksheetDisplayTitle(lecture)) }
        markWorksheetSaved(context, lecture)
        return path
    }

    fun savePdfToPublicDeviceStorage(context: Context, sourceFile: File, lectureTitle: String): String {
        val safeTitle = lectureTitle.replace(Regex("[^a-zA-Z0-9_آ-ي -]"), "_") + ".pdf"
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, safeTitle)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Mustansiriyah_Pharmacy")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                    return "Download/Mustansiriyah_Pharmacy/$safeTitle"
                }
            }

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appDir = File(downloadsDir, "Mustansiriyah_Pharmacy")
            if (!appDir.exists()) {
                appDir.mkdirs()
            }
            val publicFile = File(appDir, safeTitle)
            sourceFile.copyTo(publicFile, overwrite = true)

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as? android.app.DownloadManager
            downloadManager?.addCompletedDownload(
                safeTitle,
                "محاضرة صيدلة - $lectureTitle",
                true,
                "application/pdf",
                publicFile.absolutePath,
                publicFile.length(),
                true
            )
            return publicFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            return sourceFile.absolutePath
        }
    }

    fun openPdfInExternalApp(context: Context, pdfFile: File) {
        try {
            val authority = "${context.packageName}.provider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, pdfFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "افتح ملف PDF بواسطة..."))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "لم يتم العثور على تطبيق لقراءة ملفات PDF!", Toast.LENGTH_SHORT).show()
        }
    }
}
