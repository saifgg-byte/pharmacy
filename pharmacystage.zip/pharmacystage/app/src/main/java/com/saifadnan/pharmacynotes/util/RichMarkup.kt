package com.saifadnan.pharmacynotes.util

private val HEADER_LINE = Regex("^\\s{0,3}(#{1,3})\\s+(.*)$")
private val BOLD_ITALIC = Regex("\\*\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*\\*")
private val BOLD = Regex("\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*")
private val ITALIC = Regex("\\*(?!\\s)(.+?)(?<!\\s)\\*")
private val RULE_LINE = Regex("^\\s*[-*_]{3,}\\s*$")
private val BULLET_LINE = Regex("^\\s*[-*]\\s+")

fun stripRich(text: String): String =
    text.lines().joinToString("\n") { raw ->
        var line = raw.replace(HEADER_LINE) { it.groupValues[2] }
        line = line.replace(BOLD_ITALIC) { it.groupValues[1] }
            .replace(BOLD) { it.groupValues[1] }
            .replace(ITALIC) { it.groupValues[1] }
        line
    }.trim().let { scriptsToUnicode(normalizeMathForCopy(it)) }

fun cleanAiMarkup(raw: String): String =
    raw.replace("`", "")
        .lines()
        .filterNot { RULE_LINE.matches(it) }
        .joinToString("\n") { line ->
            line.trimEnd().replace(BULLET_LINE, "• ")
        }
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
