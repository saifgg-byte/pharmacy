package com.saifadnan.pharmacynotes.util

private const val LRM = "\u200E"

private val LATEX_CMD = Regex("\\\\[A-Za-z]")
private val PROTECTED_TAG = Regex("\\{\\{[^}]*\\}\\}")
private val MANY_SPACES = Regex("[ \\t]{2,}")
private val PLAIN_SUB_SHORT = Regex("(?<![A-Za-z0-9_])([A-Za-z]{1,3})_([A-Za-z])(?![A-Za-z0-9_{])")
private val PLAIN_SUB_LONG = Regex("(?<![A-Za-z0-9_])([A-Za-z])_([A-Za-z]{2,4})(?![A-Za-z0-9_{])")
private val SIMPLE_TOKEN = Regex("^[\\p{L}\\p{N}.\u00B0%]+(?:[\\^_]\\{[^}\\s]*\\})*$")

private val SYMBOLS: Map<String, String> = mapOf(
    "times" to "\u00D7", "cdot" to "\u00B7", "div" to "\u00F7", "pm" to "\u00B1", "mp" to "\u2213",
    "leq" to "\u2264", "le" to "\u2264", "geq" to "\u2265", "ge" to "\u2265", "neq" to "\u2260", "ne" to "\u2260",
    "approx" to "\u2248", "sim" to "\u223C", "simeq" to "\u2243", "equiv" to "\u2261", "propto" to "\u221D",
    "ll" to "\u226A", "gg" to "\u226B", "infty" to "\u221E", "degree" to "\u00B0", "circ" to "\u00B0",
    "to" to "\u2192", "rightarrow" to "\u2192", "longrightarrow" to "\u2192", "Rightarrow" to "\u21D2",
    "leftarrow" to "\u2190", "longleftarrow" to "\u2190", "Leftarrow" to "\u21D0",
    "leftrightarrow" to "\u2194", "Leftrightarrow" to "\u21D4", "uparrow" to "\u2191", "downarrow" to "\u2193",
    "rightleftharpoons" to "\u21CC", "leftrightharpoons" to "\u21CC", "rightharpoonup" to "\u21C0",
    "implies" to "\u21D2", "iff" to "\u21D4", "therefore" to "\u2234", "because" to "\u2235",
    "ldots" to "\u2026", "dots" to "\u2026", "cdots" to "\u22EF", "vdots" to "\u22EE",
    "in" to "\u2208", "notin" to "\u2209", "subset" to "\u2282", "cup" to "\u222A", "cap" to "\u2229",
    "sum" to "\u03A3", "prod" to "\u03A0", "int" to "\u222B", "partial" to "\u2202", "nabla" to "\u2207",
    "prime" to "\u2032", "ast" to "*", "star" to "*", "bullet" to "\u2022", "angle" to "\u2220",
    "alpha" to "\u03B1", "beta" to "\u03B2", "gamma" to "\u03B3", "delta" to "\u03B4", "epsilon" to "\u03B5",
    "varepsilon" to "\u03B5", "zeta" to "\u03B6", "eta" to "\u03B7", "theta" to "\u03B8", "vartheta" to "\u03D1",
    "iota" to "\u03B9", "kappa" to "\u03BA", "lambda" to "\u03BB", "mu" to "\u03BC", "nu" to "\u03BD",
    "xi" to "\u03BE", "pi" to "\u03C0", "rho" to "\u03C1", "sigma" to "\u03C3", "tau" to "\u03C4",
    "upsilon" to "\u03C5", "phi" to "\u03C6", "varphi" to "\u03C6", "chi" to "\u03C7", "psi" to "\u03C8",
    "omega" to "\u03C9",
    "Gamma" to "\u0393", "Delta" to "\u0394", "Theta" to "\u0398", "Lambda" to "\u039B", "Xi" to "\u039E",
    "Pi" to "\u03A0", "Sigma" to "\u03A3", "Phi" to "\u03A6", "Psi" to "\u03A8", "Omega" to "\u03A9",
    "quad" to " ", "qquad" to " ", "enspace" to " ", "newline" to "\n", "cr" to "\n"
)

private val FUNCTIONS = setOf(
    "log", "ln", "lg", "exp", "sin", "cos", "tan", "cot", "sec", "csc", "min", "max", "lim", "det", "sup", "inf", "arg", "mod"
)

private val CONTENT_ONLY = setOf(
    "text", "textrm", "textsf", "texttt", "textbf", "textit", "textnormal", "mathrm", "mathbf", "mathit", "mathsf",
    "mathtt", "mathcal", "mathbb", "mathfrak", "boldsymbol", "bm", "operatorname", "mbox", "hbox", "ce", "cee",
    "underline", "overline", "widehat", "widetilde", "hat", "tilde", "vec", "dot", "ddot", "overrightarrow",
    "emph", "boxed", "cancel", "xcancel", "bcancel", "phantom", "mathop", "mathrel", "mathbin"
)

private val SKIP_ARG = setOf(
    "begin", "end", "label", "tag", "hspace", "vspace", "hphantom", "vphantom", "nonumber", "notag"
)

private val SKIP_ONLY = setOf(
    "left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr",
    "displaystyle", "textstyle", "scriptstyle", "scriptscriptstyle", "limits", "nolimits", "mathstrut", "strut", "centering"
)

private class MathParser(private val s: String) {
    private var i = 0
    private var math = false
    private val out = StringBuilder()

    fun runTop(): String {
        loop(s, topLevel = true)
        if (math) out.append(LRM)
        return out.toString()
    }

    private fun convNested(sub: String): String {
        val p = MathParser(sub.replace("$", ""))
        p.math = true
        p.loop(p.s, topLevel = false)
        return p.out.toString()
    }

    private fun loop(src: String, topLevel: Boolean) {
        while (i < src.length) {
            val c = src[i]
            when (c) {
                '$' -> {
                    i++
                    if (i < src.length && src[i] == '$') i++
                    if (topLevel) toggle()
                }
                '\\' -> backslash(src, topLevel)
                '{' -> {
                    val g = readGroup(src)
                    if (g != null) out.append(convNested(g)) else i++
                }
                '}' -> i++
                '^', '_' -> script(src, c)
                '~' -> { out.append(' '); i++ }
                else -> { out.append(c); i++ }
            }
        }
    }

    private fun toggle() {
        out.append(LRM)
        math = !math
    }

    private fun readGroup(src: String): String? {
        var j = i
        while (j < src.length && src[j] == ' ') j++
        if (j >= src.length || src[j] != '{') return null
        var depth = 0
        var k = j
        while (k < src.length) {
            val ch = src[k]
            if (ch == '\\' && k + 1 < src.length) { k += 2; continue }
            if (ch == '{') depth++
            if (ch == '}') {
                depth--
                if (depth == 0) {
                    val inner = src.substring(j + 1, k)
                    i = k + 1
                    return inner
                }
            }
            k++
        }
        return null
    }

    private fun readArg(src: String): String? {
        val g = readGroup(src)
        if (g != null) return g
        while (i < src.length && src[i] == ' ') i++
        if (i >= src.length) return null
        val ch = src[i]
        if (ch == '\\') {
            var j = i + 1
            while (j < src.length && src[j].isLetter()) j++
            val tok = src.substring(i, maxOf(j, i + 2).coerceAtMost(src.length))
            i = maxOf(j, i + 2).coerceAtMost(src.length)
            return tok
        }
        if (ch == '$' || ch == '}' || ch == '^' || ch == '_') return null
        i++
        return ch.toString()
    }

    private fun readOptional(src: String): String? {
        var j = i
        while (j < src.length && src[j] == ' ') j++
        if (j >= src.length || src[j] != '[') return null
        val end = src.indexOf(']', j)
        if (end < 0) return null
        val inner = src.substring(j + 1, end)
        if (inner.length > 6 || inner.any { it == '{' || it == '\\' }) return null
        i = end + 1
        return inner
    }

    private fun backslash(src: String, topLevel: Boolean) {
        if (i + 1 >= src.length) { i++; return }
        val next = src[i + 1]
        if (next.isLetter()) {
            var j = i + 1
            while (j < src.length && src[j].isLetter()) j++
            val name = src.substring(i + 1, j)
            i = j
            command(name, src)
            return
        }
        i += 2
        when (next) {
            ',', ';', ':', ' ' -> out.append(' ')
            '!', '-', '/', '|' -> {}
            '\\' -> out.append('\n')
            '[', ']', '(', ')', '$' -> if (topLevel) toggle()
            else -> out.append(next)
        }
    }

    private fun command(name: String, src: String) {
        when {
            name == "frac" || name == "dfrac" || name == "tfrac" || name == "cfrac" -> {
                val a = readArg(src)
                val b = readArg(src)
                if (a != null && b != null) out.append(fraction(convNested(a), convNested(b))) else out.append(name)
            }
            name == "sqrt" -> {
                val idx = readOptional(src)
                val g = readArg(src)
                if (g == null) {
                    out.append('\u221A')
                } else {
                    if (idx != null) out.append(scriptText('^', idx))
                    val body = convNested(g)
                    out.append('\u221A').append(if (isSimple(body)) body else "($body)")
                }
            }
            name == "bar" -> {
                val g = readArg(src)
                if (g != null) {
                    val body = convNested(g)
                    out.append(body)
                    if (body.length == 1 && body[0].isLetter()) out.append('\u0304')
                }
            }
            name == "ce" || name == "cee" -> {
                val g = readArg(src)
                if (g != null) {
                    out.append(
                        convNested(g).replace("<=>", "\u21CC").replace("<->", "\u2194").replace("->", "\u2192").replace("<-", "\u2190")
                    )
                }
            }
            name in CONTENT_ONLY -> {
                val g = readArg(src)
                if (g != null) out.append(convNested(g))
            }
            name in SKIP_ARG -> readArg(src)
            name in SKIP_ONLY -> {
                if (name == "left" || name == "right" || name.startsWith("big") || name.startsWith("Big")) {
                    if (i < src.length && src[i] == '.') i++
                }
            }
            name in FUNCTIONS -> out.append(name)
            name == "text" -> {}
            SYMBOLS.containsKey(name) -> out.append(SYMBOLS.getValue(name))
            else -> {
                val g = readGroup(src)
                if (g != null) out.append(convNested(g)) else out.append(name)
            }
        }
    }

    private fun script(src: String, op: Char) {
        val explicit = i + 1 < src.length && (src[i + 1] == '{' || src[i + 1] == '\\')
        if (!math && !explicit) {
            out.append(op)
            i++
            return
        }
        i++
        val arg = readScriptArg(src, op)
        if (arg == null) {
            out.append(op)
            return
        }
        out.append(scriptText(op, convNested(arg).trim()))
    }

    private fun readScriptArg(src: String, op: Char): String? {
        if (i >= src.length) return null
        val ch = src[i]
        if (ch == '{') return readGroup(src)
        if (ch == '\\') {
            var j = i + 1
            while (j < src.length && src[j].isLetter()) j++
            val tok = src.substring(i, maxOf(j, i + 2).coerceAtMost(src.length))
            i = maxOf(j, i + 2).coerceAtMost(src.length)
            return tok
        }
        if (op == '^') {
            var j = i
            if (src[j] == '+' || src[j] == '-' || src[j] == '\u2212') j++
            val digitsStart = j
            while (j < src.length && src[j].isDigit() && j - digitsStart < 3) j++
            if (j > digitsStart) {
                if (j < src.length && (src[j] == '+' || src[j] == '-' || src[j] == '\u2212')) {
                    val after = if (j + 1 < src.length) src[j + 1] else ' '
                    if (!(after.isLetterOrDigit() || after == '(' || after == '\\')) j++
                }
                val tok = src.substring(i, j)
                i = j
                return tok
            }
            if (src[i] == '+' || src[i] == '-' || src[i] == '\u2212') {
                i++
                return ch.toString()
            }
            if (ch.isLetterOrDigit()) {
                i++
                return ch.toString()
            }
            return null
        }
        if (ch.isDigit()) {
            var j = i
            while (j < src.length && src[j].isDigit() && j - i < 3) j++
            val tok = src.substring(i, j)
            i = j
            return tok
        }
        if (ch.isLetter()) {
            val base = trailingLetters()
            var j = i
            while (j < src.length && src[j].isLetter()) j++
            val run = src.substring(i, j)
            val whole = base.length == 1 && run.length in 2..4
            val tok = if (whole) run else run.substring(0, 1)
            i += tok.length
            return tok
        }
        if (ch == '+' || ch == '-' || ch == '\u2212' || ch == '(') {
            i++
            return ch.toString()
        }
        return null
    }

    private fun trailingLetters(): String {
        var k = out.length
        while (k > 0 && out[k - 1].isLetter()) k--
        return out.substring(k)
    }
}

private fun isSimple(s: String): Boolean = SIMPLE_TOKEN.matches(s)

private val TRAILING_SCRIPT = Regex("(?:[\\^_]\\{[^}\\s]*\\})+$")

private fun isSingleBracketGroup(raw: String): Boolean {
    val s = TRAILING_SCRIPT.replace(raw, "")
    if (s.length < 2) return false
    val open = s[0]
    val close = when (open) { '[' -> ']'; '(' -> ')'; else -> return false }
    if (s.last() != close) return false
    var depth = 0
    for ((idx, ch) in s.withIndex()) {
        if (ch == open) depth++
        if (ch == close) {
            depth--
            if (depth == 0 && idx != s.lastIndex) return false
        }
    }
    return depth == 0
}

private fun wrapIfNeeded(s: String): String {
    val t = s.trim()
    if (t.isEmpty()) return t
    return if (isSimple(t) || isSingleBracketGroup(t)) t else "($t)"
}

private fun fraction(a: String, b: String): String {
    val num = wrapIfNeeded(a)
    val den = wrapIfNeeded(b)
    if (num.isEmpty()) return den
    if (den.isEmpty()) return num
    val spaced = !(isSimple(num) && isSimple(den))
    return if (spaced) "$num / $den" else "$num/$den"
}

private fun scriptText(op: Char, content: String): String {
    if (content.isEmpty()) return ""
    if (op == '^' && content == "\u00B0") return content
    val simple = content.length <= 12 && content.none { it.isWhitespace() || it == '{' || it == '}' }
    return when {
        simple -> "$op{$content}"
        op == '_' -> "($content)"
        else -> "^($content)"
    }
}

private fun plainScripts(text: String): String {
    if (!text.contains('_')) return text
    return PLAIN_SUB_LONG.replace(PLAIN_SUB_SHORT.replace(text) { "${it.groupValues[1]}_{${it.groupValues[2]}}" }) {
        "${it.groupValues[1]}_{${it.groupValues[2]}}"
    }
}

fun normalizeMath(text: String): String {
    if (text.length < 2) return text
    if (!text.any { it == '$' || it == '\\' || it == '_' || it == '^' }) return text

    val tags = ArrayList<String>()
    var work = text
    if (work.contains("{{")) {
        work = PROTECTED_TAG.replace(work) {
            tags.add(it.value)
            "\uE000${tags.lastIndex}\uE001"
        }
    }

    val latexish = work.contains('$') || LATEX_CMD.containsMatchIn(work) || work.contains("_{") || work.contains("^{")
    var result = if (latexish) {
        val parsed = MathParser(work).runTop()
        MANY_SPACES.replace(parsed.replace("$LRM$LRM", ""), " ")
    } else {
        work
    }
    result = plainScripts(result)

    if (tags.isNotEmpty()) {
        for ((idx, tag) in tags.withIndex()) result = result.replace("\uE000$idx\uE001", tag)
    }
    return result
}

fun normalizeMathForCopy(text: String): String = normalizeMath(text).replace(LRM, "")
