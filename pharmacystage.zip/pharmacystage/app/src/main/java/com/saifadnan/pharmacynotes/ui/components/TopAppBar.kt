package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.ui.theme.GoldAccent

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Send

import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import com.saifadnan.pharmacynotes.R

import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyTopAppBar(
    isDarkMode: Boolean,
    isAdminMode: Boolean,
    currentUser: UserEntity?,
    unreadNotificationsCount: Int,
    onThemeToggle: () -> Unit,
    onAdminToggle: () -> Unit,
    onNotificationClick: () -> Unit,
    onLogoutClick: () -> Unit,
    onReloadClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Surface(
        shadowElevation = 3.dp,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Title & Emblem
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column {
                    Text(
                        text = "ملازم المرحلة الثانية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (currentUser?.role == "ADMIN") "طالب (أدمن): ${currentUser.fullName}" else "الطالب: ${currentUser?.fullName ?: "زائر"}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Actions: Light/Dark Theme Switcher, Admin Switch, Notification Bell, Logout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Theme Toggle Button (Day / Night mode with 360 spin & spring scale)
                AnimatedThemeToggleButton(
                    isDarkMode = isDarkMode,
                    onThemeToggle = onThemeToggle,
                    modifier = Modifier.testTag("theme_mode_toggle")
                )

                if (currentUser?.role == "ADMIN") {
                    // Admin Toggle Button
                    Card(
                        onClick = onAdminToggle,
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isAdminMode) GoldAccent else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier
                            .bounceClick()
                            .testTag("admin_mode_toggle")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Mode",
                                tint = if (isAdminMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isAdminMode) "لوحة الأدمن" else "الطلاب",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isAdminMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Notifications Bell with ring animation
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .iconInteractiveClick(
                            behavior = IconClickBehavior.BELL_SHAKE,
                            onClick = onNotificationClick
                        )
                        .padding(6.dp)
                        .testTag("notification_bell_icon")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationsCount > 0) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = "$unreadNotificationsCount",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        AnimatedBellIcon(
                            hasUnread = unreadNotificationsCount > 0,
                            tint = MaterialTheme.colorScheme.onSurface,
                            iconSize = 20.dp
                        )
                    }
                }

                // Logout
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .iconInteractiveClick(
                            behavior = IconClickBehavior.SPRING_BOUNCE,
                            onClick = onLogoutClick
                        )
                        .padding(6.dp)
                        .testTag("logout_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Logout",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
