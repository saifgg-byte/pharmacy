package com.saifadnan.pharmacynotes.ui.game

import android.content.Context
import android.os.SystemClock
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.util.ClassReminderSettings
import org.json.JSONArray
import org.json.JSONObject

internal object GameRemote {
    private const val PREFS = "game_questions"
    private const val KEY = "items"
    private const val REFRESH_MS = 5 * 60 * 1000L
    private val TrueFalseLabels = listOf("صح", "غلط")

    @Volatile
    var match: List<GameItem> = emptyList()
        private set

    @Volatile
    var trueFalse: List<GameItem> = emptyList()
        private set

    private var restored = false
    private var lastFetch = 0L

    private fun restore(context: Context) {
        if (restored) return
        restored = true
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return
        try {
            apply(parse(JSONArray(raw)))
        } catch (_: Exception) {
        }
    }

    suspend fun refresh(context: Context) {
        val app = context.applicationContext
        restore(app)
        val now = SystemClock.elapsedRealtime()
        if (lastFetch != 0L && now - lastFetch < REFRESH_MS) return
        if (!ClassReminderSettings.isOnline(app)) return
        val fetched = SupabaseClient.getGameQuestions() ?: return
        lastFetch = now
        apply(fetched)
        val arr = JSONArray()
        fetched.forEach { q ->
            arr.put(
                JSONObject().apply {
                    put("id", q.id)
                    put("kind", q.kind)
                    put("prompt", q.prompt)
                    put("options", JSONArray(q.options))
                    put("correct", q.correct)
                    put("why", q.why)
                }
            )
        }
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun parse(arr: JSONArray): List<SupabaseClient.GameQuestionDto> =
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val opts = o.optJSONArray("options") ?: return@mapNotNull null
            SupabaseClient.GameQuestionDto(
                id = o.optLong("id"),
                kind = o.optString("kind"),
                prompt = o.optString("prompt"),
                options = (0 until opts.length()).map { opts.optString(it) },
                correct = o.optInt("correct"),
                why = o.optString("why")
            )
        }

    private fun apply(list: List<SupabaseClient.GameQuestionDto>) {
        val items = list.mapNotNull(::toItem)
        match = items.filter { it.kind == GameKind.Match }
        trueFalse = items.filter { it.kind == GameKind.TrueFalse }
    }

    private fun toItem(q: SupabaseClient.GameQuestionDto): GameItem? {
        if (q.prompt.isBlank()) return null
        return when (q.kind) {
            "match" -> {
                if (q.options.size !in 2..4 || q.correct !in q.options.indices) null
                else GameItem(GameKind.Match, q.prompt, q.options, q.correct, q.why)
            }
            "tf" -> {
                if (q.correct !in 0..1) null
                else GameItem(GameKind.TrueFalse, q.prompt, TrueFalseLabels, q.correct, q.why)
            }
            else -> null
        }
    }
}
