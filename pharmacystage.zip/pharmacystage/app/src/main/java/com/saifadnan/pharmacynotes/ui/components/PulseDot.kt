package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.theme.glass

@Composable
fun PulseDot(
    colorA: Color,
    colorB: Color = colorA,
    modifier: Modifier = Modifier,
    size: Dp = 10.dp
) {
    val transition = rememberInfiniteTransition(label = "pulse_dot")
    val ring by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "pulse_ring"
    )
    val core by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(750, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse_core"
    )
    val brush = Brush.linearGradient(listOf(colorA, colorB))
    Box(
        modifier = modifier.size(size * 2.4f),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    val s = 1f + ring * 1.2f
                    scaleX = s
                    scaleY = s
                    alpha = (1f - ring) * 0.5f
                }
                .background(brush, CircleShape)
        )
        Box(
            modifier = Modifier
                .size(size)
                .graphicsLayer { alpha = core }
                .background(brush, CircleShape)
        )
    }
}

@Composable
fun BrandGlowDot(
    visible: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 9.dp
) {
    val dark = MaterialTheme.glass.isDark
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(300), label = "brand_dot_alpha")
    if (a > 0.01f) {
        PulseDot(
            colorA = if (dark) Color(0xFF8FB0FF) else Color(0xFF5B8DB8),
            colorB = if (dark) Color(0xFF5B83D6) else Color(0xFF3F6E99),
            size = size,
            modifier = modifier.graphicsLayer { alpha = a }
        )
    }
}
