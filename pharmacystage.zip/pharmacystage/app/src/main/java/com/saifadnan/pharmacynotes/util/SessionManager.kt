package com.saifadnan.pharmacynotes.util

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.saifadnan.pharmacynotes.data.Stages
import java.security.MessageDigest
import java.util.UUID

class SessionManager(context: Context) {
    private val appContext: Context = context.applicationContext

    private val prefs: SharedPreferences =
        context.getSharedPreferences("pharmacy_user_session", Context.MODE_PRIVATE)
    private val secure = SecureTokenStore(context)

    init {

        if (prefs.contains(KEY_ACCESS_TOKEN)) prefs.edit().remove(KEY_ACCESS_TOKEN).apply()
    }

    fun getOrCreateDeviceId(): String {
        prefs.getString(KEY_DEVICE_ID, null)?.takeIf { it.length >= 16 }?.let { return it }
        val androidId = try {
            Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }
        val id = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") {
            MessageDigest.getInstance("SHA-256")
                .digest("pharmacynotes|$androidId".toByteArray())
                .joinToString("") { "%02x".format(it) }
                .take(32)
        } else {
            UUID.randomUUID().toString().replace("-", "")
        }
        prefs.edit().putString(KEY_DEVICE_ID, id).apply()
        return id
    }

    companion object {
        private const val KEY_DEVICE_ID = "key_device_id"
        private const val KEY_IS_LOGGED_IN = "key_is_logged_in"
        private const val KEY_EMAIL = "key_user_email"
        private const val KEY_NAME = "key_user_name"
        private const val KEY_STUDENT_ID = "key_student_id"
        private const val KEY_ROLE = "key_user_role"
        private const val KEY_ACCESS_TOKEN = "key_access_token"
        private const val KEY_AUTH_UID = "key_auth_uid"
        private const val KEY_IS_DARK_MODE = "key_is_dark_mode"
        private const val KEY_GROUP_NAME = "key_group_name"
        private const val KEY_COURSE = "key_course"
        private const val KEY_STAGE = "key_stage"
        private const val KEY_CACHE_STAGE = "key_cache_stage"
    }

    fun saveSession(
        email: String,
        fullName: String,
        studentId: String,
        role: String,
        accessToken: String? = null,
        authUid: String? = null
    ) {
        val editor = prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_EMAIL, email.trim())
            .putString(KEY_NAME, fullName.trim())
            .putString(KEY_STUDENT_ID, studentId.trim())
            .putString(KEY_ROLE, role.trim())

        if (!accessToken.isNullOrBlank()) {
            secure.save(accessToken, secure.refreshToken(), secure.expiresAtMs())
        }
        if (!authUid.isNullOrBlank()) {
            editor.putString(KEY_AUTH_UID, authUid)
        }
        editor.apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)

    fun getUserEmail(): String? = prefs.getString(KEY_EMAIL, null)
    fun getUserName(): String = prefs.getString(KEY_NAME, "") ?: ""
    fun getStudentId(): String = prefs.getString(KEY_STUDENT_ID, "") ?: ""
    fun getUserRole(): String = prefs.getString(KEY_ROLE, "STUDENT") ?: "STUDENT"
    fun getAccessToken(): String? = secure.accessToken()
    fun getRefreshToken(): String? = secure.refreshToken()
    fun getTokenExpiryMs(): Long = secure.expiresAtMs()

    fun saveAdminTokens(accessToken: String, refreshToken: String?, expiresAtMs: Long) {
        secure.save(accessToken, refreshToken ?: secure.refreshToken(), expiresAtMs)
    }
    fun getAuthUid(): String? = prefs.getString(KEY_AUTH_UID, null)

    fun isDarkMode(): Boolean = prefs.getBoolean(KEY_IS_DARK_MODE, false)

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_IS_DARK_MODE, enabled).apply()
    }

    fun getSavedGroupName(): String? = prefs.getString(KEY_GROUP_NAME, null)

    fun saveGroupName(groupName: String) {
        prefs.edit().putString(KEY_GROUP_NAME, groupName).apply()
    }

    fun getCourse(): Int = if (prefs.getInt(KEY_COURSE, 1) == 2) 2 else 1

    fun saveCourse(course: Int) {
        prefs.edit().putInt(KEY_COURSE, if (course == 2) 2 else 1).apply()
    }

    fun getStage(): Int = prefs.getInt(KEY_STAGE, Stages.DEFAULT).let { if (Stages.isValid(it)) it else Stages.DEFAULT }

    fun saveStage(stage: Int) {
        prefs.edit().putInt(KEY_STAGE, if (Stages.isValid(stage)) stage else Stages.DEFAULT).apply()
    }

    fun getCacheStage(): Int = prefs.getInt(KEY_CACHE_STAGE, Stages.DEFAULT).let { if (Stages.isValid(it)) it else Stages.DEFAULT }

    fun saveCacheStage(stage: Int) {
        prefs.edit().putInt(KEY_CACHE_STAGE, if (Stages.isValid(stage)) stage else Stages.DEFAULT).apply()
    }

    fun clearSession() {
        val darkMode = isDarkMode()
        val course = getCourse()
        val stage = getStage()
        val cacheStage = getCacheStage()
        secure.clear()
        prefs.edit().clear().apply()
        setDarkMode(darkMode)
        saveCourse(course)
        saveStage(stage)
        saveCacheStage(cacheStage)
    }
}
