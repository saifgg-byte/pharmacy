package com.saifadnan.pharmacynotes.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlin.math.ceil
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.data.SupabaseClient.WeeklySchedule
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.MedicalEmptyNotificationState
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.components.BrandGlowDot
import com.saifadnan.pharmacynotes.ui.components.PulseDot
import com.saifadnan.pharmacynotes.ui.theme.Accent
import com.saifadnan.pharmacynotes.ui.theme.AccentSoft
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.glass
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Stable
class WeeklyScheduleState(
    private val context: Context,
    private val scope: CoroutineScope
) {
    var data by mutableStateOf<WeeklySchedule?>(null)
    var loading by mutableStateOf(true)
    var failed by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var refreshing by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    val mode: String get() = data?.mode ?: "WEEKLY"
    val isExam: Boolean get() = mode == "EXAM"
    val noun: String get() = if (isExam) "جدول الامتحانات" else "الجدول الأسبوعي"

    private val prefs = context.getSharedPreferences("weekly_schedule", Context.MODE_PRIVATE)
    private var seenAt by mutableLongStateOf(prefs.getLong("seen", 0L))

    val hasUnseen: Boolean
        get() = data?.let { it.imageUrl.isNotBlank() && it.updatedAt > seenAt } ?: false

    private suspend fun load() {
        loading = data == null
        failed = false
        val result = SupabaseClient.getWeeklySchedule()
        if (result != null) data = result else failed = data == null
        loading = false
    }

    fun refresh() {
        if (refreshing) return
        scope.launch {
            refreshing = true
            val t0 = System.currentTimeMillis()
            load()
            val rest = 750L - (System.currentTimeMillis() - t0)
            if (rest > 0) delay(rest)
            refreshing = false
        }
    }

    fun setMode(newMode: String) {
        if (busy || newMode == mode) return
        val old = data
        data = (old ?: WeeklySchedule("", "", 0L)).copy(mode = newMode)
        scope.launch {
            if (!SupabaseClient.setWeeklyScheduleMode(newMode)) {
                data = old
                message = "تعذر تغيير نوع الجدول، حاول مرة ثانية."
            }
        }
    }

    fun markSeen() {
        val updated = data?.updatedAt ?: return
        if (updated > seenAt) {
            seenAt = updated
            prefs.edit().putLong("seen", updated).apply()
        }
    }

    fun upload(uri: Uri) {
        if (busy) return
        scope.launch {
            busy = true
            message = null
            val file = withContext(Dispatchers.IO) { prepareImage(uri) }
            if (file == null) {
                message = "تعذر قراءة الصورة، جرّب صورة ثانية."
                busy = false
                return@launch
            }
            val url = SupabaseClient.uploadImageFile(file, file.name)
            val ok = url != null && SupabaseClient.setWeeklySchedule(url)
            file.delete()
            if (ok) load() else message = "فشل رفع الجدول، تأكد من الاتصال وحاول مرة ثانية."
            busy = false
        }
    }

    fun delete() {
        if (busy) return
        scope.launch {
            busy = true
            message = null
            if (SupabaseClient.deleteWeeklySchedule()) {
                data = WeeklySchedule("", "", 0L, mode)
            } else {
                message = "تعذر حذف الجدول، حاول مرة ثانية."
            }
            busy = false
        }
    }

    private fun prepareImage(uri: Uri): File? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 3200) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        }
        val oriented = if (orientation == ExifInterface.ORIENTATION_NORMAL || orientation == ExifInterface.ORIENTATION_UNDEFINED) {
            decoded
        } else {
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        }

        val flat = if (oriented.hasAlpha()) {
            val canvasBmp = Bitmap.createBitmap(oriented.width, oriented.height, Bitmap.Config.ARGB_8888)
            Canvas(canvasBmp).apply {
                drawColor(AndroidColor.WHITE)
                drawBitmap(oriented, 0f, 0f, null)
            }
            canvasBmp
        } else {
            oriented
        }

        val dir = File(context.cacheDir, "weekly_schedule").apply { mkdirs() }
        val out = File(dir, "schedule_${System.currentTimeMillis()}.jpg")
        out.outputStream().use { flat.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (flat !== oriented) flat.recycle()
        if (oriented !== decoded) oriented.recycle()
        decoded.recycle()
        return out
    }
}

@Composable
fun rememberWeeklyScheduleState(): WeeklyScheduleState {
    val appContext = LocalContext.current.applicationContext
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    return remember { WeeklyScheduleState(appContext, scope) }
}

@Composable
fun NotifTabSwitcher(
    selected: Int,
    onSelect: (Int) -> Unit,
    scheduleBadge: Boolean,
    modifier: Modifier = Modifier,
    scheduleLabel: String = "الجدول الأسبوعي",
    scheduleExam: Boolean = false
) {
    val glass = MaterialTheme.glass
    val direction = LocalLayoutDirection.current
    val fraction by animateFloatAsState(
        targetValue = selected.toFloat(),
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 380f),
        label = "notif_tab_fraction"
    )
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(CircleShape)
            .background(glass.fillBottom)
            .border(1.dp, glass.border, CircleShape)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .width(maxWidth / 2)
                .fillMaxHeight()
                .graphicsLayer {
                    val sign = if (direction == LayoutDirection.Rtl) -1f else 1f
                    translationX = fraction * size.width * sign
                }
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
        )
        Row(modifier = Modifier.fillMaxSize()) {
            NotifTabItem(
                label = "التبليغات",
                selected = selected == 0,
                badge = false,
                onClick = { onSelect(0) }
            ) { tint ->
                Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
            }
            NotifTabItem(
                label = scheduleLabel,
                selected = selected == 1,
                badge = scheduleBadge && selected != 1,
                onClick = { onSelect(1) }
            ) { tint ->
                Crossfade(targetState = scheduleExam, animationSpec = tween(260), label = "schedule_tab_icon") { exam ->
                    Icon(
                        if (exam) Icons.Default.EventAvailable else Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.NotifTabItem(
    label: String,
    selected: Boolean,
    badge: Boolean,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit
) {
    val tint by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        animationSpec = tween(240),
        label = "notif_tab_tint"
    )
    Row(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon(tint)
        Box(modifier = Modifier.width(8.dp))
        AnimatedContent(
            targetState = label,
            transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(140)) },
            label = "notif_tab_label"
        ) { text ->
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = tint,
                maxLines = 1
            )
        }
        AnimatedVisibility(
            visible = badge,
            enter = fadeIn(tween(300)) + expandHorizontally(tween(300)),
            exit = fadeOut(tween(200)) + shrinkHorizontally(tween(200))
        ) {
            BrandGlowDot(visible = true)
        }
    }
}

@Composable
fun WeeklyScheduleTab(
    state: WeeklyScheduleState,
    isAdmin: Boolean,
    onPreview: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) state.upload(uri)
    }
    var confirmDelete by remember { mutableStateOf(false) }
    val data = state.data
    val hasImage = data != null && data.imageUrl.isNotBlank()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (isAdmin) {
            ScheduleModeSwitch(isExam = state.isExam, enabled = !state.busy, onChange = { state.setMode(if (it) "EXAM" else "WEEKLY") })
        }

        if (state.busy) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CircleShape),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.glass.border
            )
        }

        when {
            state.loading && data == null -> ScheduleSkeleton()
            state.failed && data == null -> ScheduleError(onRetry = { state.refresh() })
            hasImage && data != null -> {
                ScheduleInfoCard(title = state.noun, isExam = state.isExam, updatedAt = data.updatedAt, refreshing = state.refreshing, onRefresh = { state.refresh() })
                ScheduleImageCard(url = data.imageUrl, noun = state.noun, dimmed = state.busy, onClick = { onPreview(data.imageUrl) })
                if (isAdmin) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PillButton(
                            text = if (state.busy) "جاري الرفع..." else "تغيير الصورة",
                            onClick = { picker.launch("image/*") },
                            icon = Icons.Default.PhotoLibrary,
                            enabled = !state.busy,
                            modifier = Modifier.weight(1f)
                        )
                        GlassIconButton(onClick = { if (!state.busy) confirmDelete = true }, size = 52.dp) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "حذف " + state.noun,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
            isAdmin -> ScheduleUploadCard(noun = state.noun, busy = state.busy, onPick = { picker.launch("image/*") })
            else -> GlassCard(modifier = Modifier.fillMaxWidth()) {
                MedicalEmptyNotificationState(
                    message = "لم يُنشر " + state.noun + " بعد",
                    subtitle = "راح يظهر هنا فور رفعه من الإدارة"
                )
            }
        }

        state.message?.let { text ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AppShapes.Medium)
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.10f))
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)), AppShapes.Medium)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف " + state.noun + "؟") },
            text = { Text("راح تختفي الصورة من عند كل الطلاب، وتكدر ترفع جدول جديد بأي وقت.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    state.delete()
                }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun ScheduleInfoCard(title: String, isExam: Boolean, updatedAt: Long, refreshing: Boolean, onRefresh: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Crossfade(targetState = isExam, animationSpec = tween(260), label = "info_icon") { exam ->
                IconTile(icon = if (exam) Icons.Default.EventAvailable else Icons.Default.CalendarMonth, size = 48.dp)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                AnimatedContent(
                    targetState = title,
                    transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(140)) },
                    label = "info_title"
                ) { t ->
                    Text(
                        text = t,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                val sub = when {
                    refreshing -> "جاري التحديث…"
                    updatedAt > 0L -> "آخر تحديث · " + formatScheduleDate(updatedAt)
                    else -> ""
                }
                if (sub.isNotEmpty()) {
                    AnimatedContent(
                        targetState = sub,
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                        label = "info_sub"
                    ) { t ->
                        Text(
                            text = t,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            SpinRefreshButton(refreshing = refreshing, onClick = onRefresh)
        }
    }
}

@Composable
internal fun SpinRefreshButton(refreshing: Boolean, onClick: () -> Unit) {
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) {
                rotation.animateTo(rotation.value + 360f, tween(800, easing = LinearEasing))
            }
        } else {
            val target = ceil(rotation.value / 360f) * 360f
            if (target != rotation.value) rotation.animateTo(target, tween(380, easing = FastOutSlowInEasing))
        }
    }
    val tint by animateColorAsState(
        targetValue = if (refreshing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        animationSpec = tween(300),
        label = "refresh_tint"
    )
    GlassIconButton(onClick = onClick, size = 40.dp) {
        Icon(
            Icons.Default.Refresh,
            contentDescription = "تحديث",
            tint = tint,
            modifier = Modifier
                .size(20.dp)
                .graphicsLayer { rotationZ = rotation.value }
        )
    }
}

@Composable
private fun ScheduleModeSwitch(isExam: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    val glass = MaterialTheme.glass
    val direction = LocalLayoutDirection.current
    val fraction by animateFloatAsState(
        targetValue = if (isExam) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 380f),
        label = "mode_switch_fraction"
    )
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "نوع الجدول (يظهر للطلاب)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(CircleShape)
                    .background(glass.fillBottom)
                    .border(1.dp, glass.border, CircleShape)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(maxWidth / 2)
                        .fillMaxHeight()
                        .graphicsLayer {
                            val sign = if (direction == LayoutDirection.Rtl) -1f else 1f
                            translationX = fraction * size.width * sign
                        }
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Row(modifier = Modifier.fillMaxSize()) {
                    ModeOption("أسبوعي", Icons.Default.CalendarMonth, !isExam, enabled) { onChange(false) }
                    ModeOption("امتحاني", Icons.Default.EventAvailable, isExam, enabled) { onChange(true) }
                }
            }
        }
    }
}

@Composable
private fun RowScope.ModeOption(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        animationSpec = tween(240),
        label = "mode_option_tint"
    )
    Row(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(CircleShape)
            .clickable(enabled = enabled, interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Box(modifier = Modifier.width(8.dp))
        Text(text = label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = tint, maxLines = 1)
    }
}

@Composable
private fun ScheduleImageCard(url: String, noun: String, dimmed: Boolean, onClick: () -> Unit) {
    val context = LocalContext.current
    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clip(AppShapes.Medium)
                .background(Color.White)
        ) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(context).data(url).crossfade(250).build(),
                contentDescription = noun,
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp)
                    .graphicsLayer { alpha = if (dimmed) 0.5f else 1f },
                loading = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                    }
                },
                error = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "تعذر تحميل الصورة، اضغط زر التحديث وحاول مرة ثانية.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF59616F),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                }
            )
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.ZoomIn, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Text("اضغط للتكبير", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
    }
}

@Composable
private fun ScheduleUploadCard(noun: String, busy: Boolean, onPick: () -> Unit) {
    val dash = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.22f)
    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { if (!busy) onPick() }) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
                .drawBehind {
                    drawRoundRect(
                        color = dash,
                        cornerRadius = CornerRadius(22.dp.toPx()),
                        style = Stroke(
                            width = 1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))
                        )
                    )
                }
                .padding(horizontal = 20.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconTile(icon = Icons.Default.AddPhotoAlternate, size = 68.dp)
            Text(
                text = "ارفع صورة " + noun,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "اختر صورة واضحة (PNG أو JPG) وتظهر لكل الطلاب فوراً داخل هذا التبويب.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            PillButton(
                text = if (busy) "جاري الرفع..." else "اختيار صورة",
                onClick = onPick,
                icon = Icons.Default.PhotoLibrary,
                enabled = !busy
            )
        }
    }
}

@Composable
private fun ScheduleSkeleton() {
    val transition = rememberInfiniteTransition(label = "schedule_skeleton")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "skeleton_alpha"
    )
    val ink = MaterialTheme.colorScheme.onSurface
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(ink.copy(alpha = 0.08f * alpha * 2)))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.width(140.dp).height(14.dp).clip(CircleShape).background(ink.copy(alpha = 0.08f * alpha * 2)))
                Box(Modifier.width(96.dp).height(10.dp).clip(CircleShape).background(ink.copy(alpha = 0.06f * alpha * 2)))
            }
        }
    }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .height(300.dp)
                .clip(AppShapes.Medium)
                .background(ink.copy(alpha = 0.06f * alpha * 2))
        )
    }
}

@Composable
private fun ScheduleError(onRetry: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconTile(icon = Icons.Default.ErrorOutline, size = 56.dp, tint = MaterialTheme.colorScheme.error)
            Text(
                text = "تعذر تحميل الجدول",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "تأكد من الاتصال بالإنترنت وحاول مرة ثانية.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            PillButton(text = "إعادة المحاولة", onClick = onRetry, icon = Icons.Default.Refresh)
        }
    }
}

private fun formatScheduleDate(millis: Long): String =
    SimpleDateFormat("d MMMM yyyy، h:mm a", Locale.forLanguageTag("ar")).format(Date(millis))
