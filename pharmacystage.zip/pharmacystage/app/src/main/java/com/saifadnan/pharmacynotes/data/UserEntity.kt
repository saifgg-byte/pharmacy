package com.saifadnan.pharmacynotes.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val email: String,
    val fullName: String,
    val studentId: String = "",
    val role: String = "STUDENT",
    val registrationDate: Long = System.currentTimeMillis(),
    val isApproved: Boolean = true,
    val authUid: String = "",
    val idCardUrl: String = "",
    val groupName: String = ""
)
