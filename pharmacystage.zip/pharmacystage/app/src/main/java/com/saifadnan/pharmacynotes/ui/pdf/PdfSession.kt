package com.saifadnan.pharmacynotes.ui.pdf

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

internal object PdfGeometry {

    const val MAX_BASE_PIXELS = 4_000_000f

    fun fitScale(vw: Float, vh: Float, pw: Float, ph: Float, rotated: Boolean): Float =
        if (rotated) min(vw / ph, vh / pw) else min(vw / pw, vh / ph)

    fun baseScale(vw: Float, vh: Float, pw: Float, ph: Float, rotated: Boolean): Float {
        val k = fitScale(vw, vh, pw, ph, rotated)
        val px = pw * k * ph * k
        return if (px > MAX_BASE_PIXELS) k * sqrt(MAX_BASE_PIXELS / px) else k
    }
}

class HiResTile(
    val image: ImageBitmap,
    val left: Int,
    val top: Int,
    val scale: Float,
    val offset: Offset,
    val rotated: Boolean
)

class FullPage(val bitmap: Bitmap, val widthPt: Int, val heightPt: Int)

class PdfSession private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) {
    val pageCount: Int = renderer.pageCount

    val pageSizes = mutableStateMapOf<Int, Size>()

    private val mutex = Mutex()
    @Volatile private var closed = false
    @Volatile private var cacheKey = ""
    @Volatile private var latestKey = ""

    private val cache = object : LruCache<Int, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount
    }

    fun peek(index: Int, vw: Int, rotated: Boolean): Bitmap? =
        if (cacheKey == key(vw, rotated)) cache.get(index) else null

    suspend fun loadPage(index: Int, vw: Int, vh: Int, rotated: Boolean): Bitmap? {
        if (index < 0 || index >= pageCount || vw <= 0 || vh <= 0) return null
        val k = key(vw, rotated)
        latestKey = k
        if (k == cacheKey) cache.get(index)?.let { return it }
        return withContext(Dispatchers.IO) {
            mutex.withLock {
                if (closed || k != latestKey) return@withLock null
                if (k != cacheKey) {
                    cache.evictAll()
                    cacheKey = k
                }
                cache.get(index)?.let { return@withLock it }
                renderBase(index, vw, vh, rotated)?.also { cache.put(index, it) }
            }
        }
    }

    suspend fun renderTile(
        index: Int,
        vw: Int,
        vh: Int,
        rotated: Boolean,
        scale: Float,
        offset: Offset
    ): HiResTile? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (closed || index < 0 || index >= pageCount) return@withLock null
            val page = renderer.openPage(index)
            try {
                val pw = page.width.toFloat().coerceAtLeast(1f)
                val ph = page.height.toFloat().coerceAtLeast(1f)
                val k = PdfGeometry.fitScale(vw.toFloat(), vh.toFloat(), pw, ph, rotated) * scale
                val cx = vw / 2f + offset.x
                val cy = vh / 2f + offset.y
                val m = Matrix()

                if (!rotated) {
                    m.setValues(floatArrayOf(k, 0f, cx - k * pw / 2f, 0f, k, cy - k * ph / 2f, 0f, 0f, 1f))
                } else {
                    m.setValues(floatArrayOf(0f, -k, cx + k * ph / 2f, k, 0f, cy - k * pw / 2f, 0f, 0f, 1f))
                }
                val r = RectF(0f, 0f, pw, ph)
                m.mapRect(r)
                val l = max(0, floor(r.left).toInt())
                val t = max(0, floor(r.top).toInt())
                val rr = min(vw, ceil(r.right).toInt())
                val bb = min(vh, ceil(r.bottom).toInt())
                val w = rr - l
                val h = bb - t
                if (w < 2 || h < 2) return@withLock null
                m.postTranslate(-l.toFloat(), -t.toFloat())
                val bmp = createBitmapSafe(w, h) ?: return@withLock null
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                HiResTile(bmp.asImageBitmap(), l, t, scale, offset, rotated)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            } finally {
                page.close()
            }
        }
    }

    suspend fun renderJpeg(index: Int, maxSide: Int = 1200, quality: Int = 76): ByteArray? =
        withContext(Dispatchers.IO) {
            mutex.withLock {
                if (closed || index < 0 || index >= pageCount) return@withLock null
                val page = renderer.openPage(index)
                try {
                    val pw = page.width.toFloat().coerceAtLeast(1f)
                    val ph = page.height.toFloat().coerceAtLeast(1f)
                    val k = maxSide / max(pw, ph)
                    val w = (pw * k).roundToInt().coerceAtLeast(1)
                    val h = (ph * k).roundToInt().coerceAtLeast(1)
                    val bmp = createBitmapSafe(w, h) ?: return@withLock null
                    try {
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val out = java.io.ByteArrayOutputStream(256 * 1024)
                        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
                        out.toByteArray()
                    } finally {
                        bmp.recycle()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    null
                } finally {
                    page.close()
                }
            }
        }

    suspend fun renderFull(index: Int, maxSide: Int): FullPage? =
        withContext(Dispatchers.IO) {
            mutex.withLock {
                if (closed || index < 0 || index >= pageCount) return@withLock null
                val page = renderer.openPage(index)
                try {
                    val pw = page.width.toFloat().coerceAtLeast(1f)
                    val ph = page.height.toFloat().coerceAtLeast(1f)
                    val k = maxSide / max(pw, ph)
                    val w = (pw * k).roundToInt().coerceAtLeast(1)
                    val h = (ph * k).roundToInt().coerceAtLeast(1)
                    val bmp = createBitmapSafe(w, h) ?: return@withLock null
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    FullPage(bmp, pw.roundToInt(), ph.roundToInt())
                } catch (e: Exception) {
                    e.printStackTrace()
                    null
                } finally {
                    page.close()
                }
            }
        }

    private fun renderBase(index: Int, vw: Int, vh: Int, rotated: Boolean): Bitmap? {
        val page = renderer.openPage(index)
        try {
            val pw = page.width.toFloat().coerceAtLeast(1f)
            val ph = page.height.toFloat().coerceAtLeast(1f)
            pageSizes[index] = Size(pw, ph)
            val k = PdfGeometry.baseScale(vw.toFloat(), vh.toFloat(), pw, ph, rotated)
            val w = (pw * k).roundToInt().coerceAtLeast(1)
            val h = (ph * k).roundToInt().coerceAtLeast(1)
            val bmp = createBitmapSafe(w, h) ?: return null
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        } finally {
            page.close()
        }
    }

    private fun createBitmapSafe(w: Int, h: Int): Bitmap? = try {
        Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    } catch (oom: OutOfMemoryError) {
        cache.evictAll()
        try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (oom2: OutOfMemoryError) {
            null
        }
    }

    private fun key(vw: Int, rotated: Boolean) = "$vw|$rotated"

    fun closeAsync(scope: CoroutineScope = CoroutineScope(Dispatchers.IO)) {
        scope.launch(Dispatchers.IO) {
            mutex.withLock {
                if (closed) return@withLock
                closed = true
                cache.evictAll()
                try { renderer.close() } catch (_: Exception) {}
                try { pfd.close() } catch (_: Exception) {}
            }
        }
    }

    companion object {
        fun open(file: File): PdfSession {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                return PdfSession(pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                try { pfd.close() } catch (_: Exception) {}
                throw e
            }
        }

        private fun cacheBytes(): Int =
            (Runtime.getRuntime().maxMemory() / 6L).toInt().coerceIn(24 * 1024 * 1024, 96 * 1024 * 1024)
    }
}