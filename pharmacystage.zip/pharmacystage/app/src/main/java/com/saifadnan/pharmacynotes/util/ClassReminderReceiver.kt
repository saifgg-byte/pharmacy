package com.saifadnan.pharmacynotes.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.saifadnan.pharmacynotes.data.ScheduleConstants

class ClassReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val scheduleId = intent.getStringExtra("schedule_id") ?: return
        val subject = intent.getStringExtra("subject") ?: ""
        val sessionType = intent.getStringExtra("session_type") ?: ""
        val dayOfWeek = intent.getIntExtra("day_of_week", 1)
        val startHour = intent.getIntExtra("start_hour", 8)
        val startMinute = intent.getIntExtra("start_minute", 0)
        val room = intent.getStringExtra("room") ?: ""
        val triggerAt = intent.getLongExtra("trigger_at", 0L)

        ClassAlarmScheduler.rescheduleFromExtras(
            context = context,
            scheduleId = scheduleId,
            subject = subject,
            sessionType = sessionType,
            dayOfWeek = dayOfWeek,
            startHour = startHour,
            startMinute = startMinute,
            room = room
        )

        if (!ClassReminderSettings.isEnabled(context)) return

        try {

            val now = System.currentTimeMillis()
            val classStart = if (triggerAt > 0) triggerAt + ScheduleConstants.REMINDER_MINUTES_BEFORE * 60_000L else 0L
            val stale = classStart > 0 && now > classStart
            if (!stale && !HolidayStore.isHolidayToday(context)) {
                val minutesLeft = if (classStart > 0) {
                    ((classStart - now + 59_999L) / 60_000L).toInt().coerceIn(1, ScheduleConstants.REMINDER_MINUTES_BEFORE)
                } else ScheduleConstants.REMINDER_MINUTES_BEFORE

                val timeText = String.format(java.util.Locale.US, "%02d:%02d", startHour, startMinute)
                val roomText = if (room.isNotBlank()) " بقاعة $room" else ""
                SystemNotificationHelper.sendSystemNotification(
                    context = context,
                    notificationId = scheduleId.hashCode() and 0x7FFFFFFF,
                    title = "تبدأ محاضرتك ${minutesText(minutesLeft)}",
                    message = "$subject ($sessionType) الساعة $timeText$roomText — جهّز نفسك."
                )
            }
        } catch (e: Exception) {
            Log.e("ClassReminderReceiver", "reminder failed", e)
        }

        if (ClassReminderSettings.isOnline(context)) {
            val pending = goAsync()
            Thread {
                try {
                    HolidayStore.refreshBlocking(context)
                } catch (e: Exception) {
                    Log.w("ClassReminderReceiver", "holiday refresh failed", e)
                } finally {
                    pending?.finish()
                }
            }.start()
        }
    }

    private fun minutesText(m: Int): String = when (m) {
        1 -> "بعد دقيقة"
        2 -> "بعد دقيقتين"
        else -> "بعد $m دقائق"
    }
}
