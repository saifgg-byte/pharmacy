package com.saifadnan.pharmacynotes.ui.theme

import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class WindowClass { Compact, Medium, Expanded }

@Immutable
class Adaptive(
    val widthDp: Int,
    val heightDp: Int,
    val smallestDp: Int,
    val landscape: Boolean
) {
    val windowClass: WindowClass = when {
        widthDp >= 840 -> WindowClass.Expanded
        widthDp >= 600 -> WindowClass.Medium
        else -> WindowClass.Compact
    }

    val isTablet: Boolean = smallestDp >= 600

    val useRail: Boolean = isTablet && landscape && widthDp >= 840

    val contentMaxWidth: Dp = when (windowClass) {
        WindowClass.Compact -> Dp.Unspecified
        WindowClass.Medium -> 720.dp
        WindowClass.Expanded -> 860.dp
    }

    val gridMaxWidth: Dp = when (windowClass) {
        WindowClass.Compact -> Dp.Unspecified
        WindowClass.Medium -> 840.dp
        WindowClass.Expanded -> 1240.dp
    }

    val horizontalPadding: Dp = when (windowClass) {
        WindowClass.Compact -> 20.dp
        WindowClass.Medium -> 28.dp
        WindowClass.Expanded -> 32.dp
    }

    fun columnsFor(availableWidth: Dp): Int = when {
        availableWidth >= 1000.dp -> 3
        availableWidth >= 640.dp -> 2
        else -> 1
    }
}

@Composable
fun rememberAdaptive(): Adaptive {
    val config = LocalConfiguration.current
    return remember(config.screenWidthDp, config.screenHeightDp, config.smallestScreenWidthDp, config.orientation) {
        Adaptive(
            widthDp = config.screenWidthDp,
            heightDp = config.screenHeightDp,
            smallestDp = config.smallestScreenWidthDp,
            landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
        )
    }
}

@Composable
fun AdaptiveContent(
    modifier: Modifier = Modifier,
    maxWidth: Dp = rememberAdaptive().contentMaxWidth,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(modifier = Modifier.widthIn(max = maxWidth).fillMaxSize()) {
            content()
        }
    }
}
