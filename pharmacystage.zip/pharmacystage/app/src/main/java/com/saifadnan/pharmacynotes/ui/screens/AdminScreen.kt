package com.saifadnan.pharmacynotes.ui.screens

import com.saifadnan.pharmacynotes.util.AdminConfig
import android.content.Context
import android.os.ParcelFileDescriptor
import java.io.FileOutputStream
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.School
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.data.Stages
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import androidx.compose.foundation.border
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlin.coroutines.resumeWithException
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.components.bounceClick
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PhonelinkErase
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.ui.components.AdminTabSkeleton
import com.saifadnan.pharmacynotes.ui.components.softGlow
import com.saifadnan.pharmacynotes.data.Category
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.data.NewLectureRequest
import com.saifadnan.pharmacynotes.data.Section
import com.saifadnan.pharmacynotes.data.WorksheetType
import com.saifadnan.pharmacynotes.util.ArabicSearch
import kotlinx.coroutines.delay
import com.saifadnan.pharmacynotes.data.SubjectEntity
import com.saifadnan.pharmacynotes.data.UserEntity
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.AppElevation
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.Spacing
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    subjects: List<SubjectEntity>,
    lectures: List<LectureEntity>,
    students: List<UserEntity> = emptyList(),
    admins: List<UserEntity> = emptyList(),
    currentAdminEmail: String = "",
    banRequests: List<com.saifadnan.pharmacynotes.data.SupabaseClient.BanRequest> = emptyList(),
    onDecideBanRequest: (id: Long, approve: Boolean) -> Unit = { _, _ -> },
    onUploadLecture: (request: NewLectureRequest, onResult: (Boolean) -> Unit) -> Unit,
    onToggleSubjectExamPinned: (subjectName: String, section: String, semester: Int, isPinned: Boolean) -> Unit,
    onPublishAnnouncement: (title: String, message: String, url: String?, imageUrl: String?, style: String) -> Unit,
    exams: List<com.saifadnan.pharmacynotes.data.ExamEntity> = emptyList(),
    onSaveExam: (com.saifadnan.pharmacynotes.data.ExamEntity, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onDeleteExam: (com.saifadnan.pharmacynotes.data.ExamEntity, onResult: (Boolean) -> Unit) -> Unit = { _, r -> r(false) },
    onSetSubjectIcon: (name: String, section: String, semester: Int, icon: String, onResult: (String?) -> Unit) -> Unit = { _, _, _, _, r -> r(null) },
    onDeleteLecture: (LectureEntity) -> Unit,
    onUpdateLecture: (LectureEntity, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onAddSubjectFolder: (name: String, section: String, semester: Int) -> Unit = { _, _, _ -> },
    onDeleteSubjectFolder: (name: String, section: String, semester: Int, onResult: (Boolean) -> Unit) -> Unit = { _, _, _, r -> r(false) },
    onRenameSubjectFolder: (old: String, new: String, section: String, semester: Int, onResult: (String?) -> Unit) -> Unit = { _, _, _, _, r -> r(null) },
    onApproveStudent: (UserEntity) -> Unit = {},
    onRejectStudent: (UserEntity) -> Unit = {},
    onUpdateStudent: (email: String, name: String, studentId: String, newPassword: String, onResult: (String?) -> Unit) -> Unit = { _, _, _, _, r -> r(null) },
    onChangeEmail: (email: String, newEmail: String, onResult: (String?) -> Unit) -> Unit = { _, _, r -> r(null) },
    onDeleteStudent: (email: String, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onResetDevices: (email: String, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onCreateAdmin: (email: String, name: String, password: String, onResult: (String?) -> Unit) -> Unit = { _, _, _, r -> r(null) },
    onDemoteAdmin: (email: String, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onPromoteStudent: (student: UserEntity, newEmail: String, password: String, onResult: (String?) -> Unit) -> Unit = { _, _, _, r -> r(null) },
    onSwitchStage: (stage: Int, onResult: (String?) -> Unit) -> Unit = { _, r -> r(null) },
    onRefreshUsers: () -> Unit = {},
    isTabLoading: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (isTabLoading) {
        AdminTabSkeleton(
            modifier = modifier
                .fillMaxSize()
                .padding(Spacing.Lg)
        )
    } else {
        val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var selectedFileSize by remember { mutableStateOf<String?>(null) }
    var detectedPageCount by remember { mutableIntStateOf(1) }
    var isUploadingToStorage by remember { mutableStateOf(false) }
    var uploadStorageStatus by remember { mutableStateOf("") }

    var adminTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(adminTab) {
        if (adminTab >= 4) {
            onRefreshUsers()
        }
    }

    LaunchedEffect(Unit) {
        onRefreshUsers()
    }

    // تبويب أسئلة اللعبة للأدمن الرئيسي فقط
    LaunchedEffect(adminTab, currentAdminEmail) {
        if (adminTab == 9 && !AdminConfig.isMainAdmin(currentAdminEmail)) adminTab = 0
    }

    BackHandler(enabled = adminTab != 0) {
        adminTab = 0
    }

    var titleInput by remember { mutableStateOf("") }
    var subjectInput by remember { mutableStateOf("") }
    var selectedSemesterInput by remember { mutableIntStateOf(1) }
    var fileUrlInput by remember { mutableStateOf("") }
    var sendNotificationInput by remember { mutableStateOf(true) }
    var selectedLocalFile by remember { mutableStateOf<File?>(null) }
    var uploadSection by remember { mutableStateOf(Section.THEORY) }
    var uploadCategory by remember { mutableStateOf(Category.OFFICIAL) }
    var worksheetUrlInput by remember { mutableStateOf("") }
    var youtubeUrlInput by remember { mutableStateOf("") }
    var worksheetTypeInput by remember { mutableStateOf(WorksheetType.WORKSHEET) }
    var isUploadingWorksheet by remember { mutableStateOf(false) }

    var foldersSection by remember { mutableStateOf(Section.THEORY) }
    var foldersSemester by remember { mutableIntStateOf(1) }
    var lecturesSection by remember { mutableStateOf(Section.THEORY) }
    var studentQuery by remember { mutableStateOf("") }

    var renameTarget by remember { mutableStateOf<SubjectEntity?>(null) }
    var deleteFolderTarget by remember { mutableStateOf<SubjectEntity?>(null) }
    var editLectureTarget by remember { mutableStateOf<LectureEntity?>(null) }
    var deleteLectureTarget by remember { mutableStateOf<LectureEntity?>(null) }
    var editStudentTarget by remember { mutableStateOf<UserEntity?>(null) }
    var deleteStudentTarget by remember { mutableStateOf<UserEntity?>(null) }
    var demoteTarget by remember { mutableStateOf<UserEntity?>(null) }
    var showAddAdmin by remember { mutableStateOf(false) }
    var promoteTarget by remember { mutableStateOf<UserEntity?>(null) }
    var studentGroupFilter by remember { mutableStateOf<String?>(null) }
    var studentSort by remember { mutableIntStateOf(0) }
    var stageSwitching by remember { mutableStateOf(false) }
    var dialogBusy by remember { mutableStateOf(false) }
    var dialogError by remember { mutableStateOf<String?>(null) }

    val pickUploadWorksheet = rememberWorksheetPicker(
        onStart = { isUploadingWorksheet = true },
        onResult = { url ->
            isUploadingWorksheet = false
            if (url != null) worksheetUrlInput = url
        }
    )

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            val (fName, fSize) = getFileNameAndSizeFromUri(context, selectedUri)
            selectedFileName = fName
            if (titleInput.isBlank()) {
                titleInput = fName.removeSuffix(".pdf").removeSuffix(".PDF")
            }

            try {
                val sharedDir = File(context.filesDir, "shared_pdf_lectures").apply { mkdirs() }
                val safeName = "lec_${System.currentTimeMillis()}.pdf"
                val internalFile = File(sharedDir, safeName)

                context.contentResolver.openInputStream(selectedUri)?.use { input ->
                    FileOutputStream(internalFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (internalFile.exists() && internalFile.length() > 0) {
                    selectedLocalFile = internalFile
                    val bytesSize = internalFile.length()
                    val mb = bytesSize / (1024.0 * 1024.0)
                    val realSizeStr = if (mb >= 1.0) String.format(java.util.Locale.US, "%.1f MB", mb) else String.format(java.util.Locale.US, "%d KB", bytesSize / 1024)
                    selectedFileSize = realSizeStr

                    try {
                        val pfd = ParcelFileDescriptor.open(internalFile, ParcelFileDescriptor.MODE_READ_ONLY)
                        val renderer = android.graphics.pdf.PdfRenderer(pfd)
                        detectedPageCount = renderer.pageCount
                        renderer.close()
                        pfd.close()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    fileUrlInput = "file://${internalFile.absolutePath}"

                    isUploadingToStorage = true
                    uploadStorageStatus = "جاري تهيئة رفع الملف..."
                    coroutineScope.launch {
                        try {
                            val uploadResult = com.saifadnan.pharmacynotes.data.SupabaseClient.uploadPdfFile(internalFile, safeName, onStatus = { uploadStorageStatus = it }) { bytes, total ->
                                if (total > 0) {
                                    val percent = (bytes * 100 / total).toInt()
                                    val mbUploaded = bytes / (1024.0 * 1024.0)
                                    val mbTotal = total / (1024.0 * 1024.0)
                                    uploadStorageStatus = String.format(
                                        java.util.Locale.US,
                                        "جاري رفع الملف للسيرفر: %d%% (%.1f MB / %.1f MB)...",
                                        percent,
                                        mbUploaded,
                                        mbTotal
                                    )
                                }
                            }
                            if (uploadResult.isSuccess && uploadResult.url != null) {
                                fileUrlInput = uploadResult.url
                                uploadResult.finalSizeBytes?.let { b ->
                                    selectedFileSize = String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
                                }
                                uploadStorageStatus = "تم الرفع والربط بنجاح مع السيرفر"
                            } else {
                                val err = uploadResult.error ?: "خطأ غير معروف أثناء الرفع"
                                uploadStorageStatus = "فشل الرفع: $err"
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            uploadStorageStatus = "خطأ غير متوقع: ${e.message}"
                        } finally {
                            isUploadingToStorage = false
                        }
                    }
                } else {
                    fileUrlInput = selectedUri.toString()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                fileUrlInput = selectedUri.toString()
            }
        }
    }

    var announceTitleInput by remember { mutableStateOf("") }
    var announceMsgInput by remember { mutableStateOf("") }
    var announceUrlInput by remember { mutableStateOf("") }
    var announceImageUrlInput by remember { mutableStateOf("") }
    var announceStyle by remember { mutableStateOf(com.saifadnan.pharmacynotes.ui.components.NotifStyle()) }
    var iconTarget by remember { mutableStateOf<SubjectEntity?>(null) }
    var isUploadingNotifImage by remember { mutableStateOf(false) }

    val notifImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            coroutineScope.launch {
                try {
                    isUploadingNotifImage = true
                    val sharedDir = File(context.filesDir, "shared_notif_images").apply { mkdirs() }
                    val safeName = "notif_img_${System.currentTimeMillis()}.jpg"
                    val internalFile = File(sharedDir, safeName)
                    context.contentResolver.openInputStream(selectedUri)?.use { input ->
                        internalFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val uploadedUrl = com.saifadnan.pharmacynotes.data.SupabaseClient.uploadImageFile(internalFile, safeName)
                    if (uploadedUrl != null) {
                        announceImageUrlInput = uploadedUrl
                        android.widget.Toast.makeText(context, "تم رفع الصورة بنجاح", android.widget.Toast.LENGTH_SHORT).show()
                    } else {
                        announceImageUrlInput = selectedUri.toString()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    isUploadingNotifImage = false
                }
            }
        }
    }

    var showSuccessMessage by remember { mutableStateOf(false) }
    var successText by remember { mutableStateOf("") }

    LaunchedEffect(showSuccessMessage, successText) {
        if (showSuccessMessage) {
            delay(2600)
            showSuccessMessage = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
    ) {

        fun closeDialogs() { dialogBusy = false; dialogError = null }
        fun toast(msg: String) { successText = msg; showSuccessMessage = true }

        renameTarget?.let { target ->
            RenameFolderDialog(
                initialName = target.name, section = target.section, semester = target.semester, busy = dialogBusy, error = dialogError,
                onConfirm = { newName ->
                    dialogBusy = true; dialogError = null
                    onRenameSubjectFolder(target.name, newName, target.section, target.semester) { err ->
                        dialogBusy = false
                        if (err == null) { renameTarget = null; toast("تم تعديل اسم المجلد إلى ($newName)") } else dialogError = err
                    }
                },
                onDismiss = { renameTarget = null; closeDialogs() }
            )
        }
        iconTarget?.let { target ->
            SubjectIconDialog(
                subject = target, busy = dialogBusy, error = dialogError,
                onSave = { icon ->
                    dialogBusy = true; dialogError = null
                    onSetSubjectIcon(target.name, target.section, target.semester, icon) { err ->
                        dialogBusy = false
                        if (err == null) { iconTarget = null; toast("تم تغيير أيقونة (${target.name})") } else dialogError = err
                    }
                },
                onDismiss = { iconTarget = null; closeDialogs() }
            )
        }
        deleteFolderTarget?.let { target ->
            val n = lectures.count { it.subject == target.name && it.section == target.section && it.semester == target.semester }
            ConfirmDialog(
                title = "حذف المجلد",
                message = "سيتم حذف مجلد (${target.name}) من ${Section.label(target.section)} · ${com.saifadnan.pharmacynotes.data.Course.label(target.semester)} مع $n ملف بداخله نهائياً من السيرفر. ما يمكن التراجع.",
                confirmText = "حذف نهائي",
                onConfirm = {
                    deleteFolderTarget = null
                    onDeleteSubjectFolder(target.name, target.section, target.semester) { ok ->
                        toast(if (ok) "تم حذف مجلد (${target.name})" else "تعذر حذف المجلد، تأكد من الاتصال")
                    }
                },
                onDismiss = { deleteFolderTarget = null }
            )
        }
        editLectureTarget?.let { target ->
            EditLectureDialog(
                lecture = target, subjects = subjects, busy = dialogBusy, error = dialogError,
                onSave = { updated ->
                    dialogBusy = true; dialogError = null
                    onUpdateLecture(updated) { err ->
                        dialogBusy = false
                        if (err == null) { editLectureTarget = null; toast("تم حفظ تعديلات المحاضرة") } else dialogError = err
                    }
                },
                onDismiss = { editLectureTarget = null; closeDialogs() }
            )
        }
        deleteLectureTarget?.let { target ->
            ConfirmDialog(
                title = "حذف المحاضرة",
                message = "هل تريد حذف (${target.title}) نهائياً؟",
                confirmText = "حذف",
                onConfirm = { onDeleteLecture(target); deleteLectureTarget = null; toast("تم حذف المحاضرة") },
                onDismiss = { deleteLectureTarget = null }
            )
        }
        editStudentTarget?.let { target ->
            EditStudentDialog(
                student = target, busy = dialogBusy, error = dialogError,
                onSave = { name, sid, email, newPassword ->
                    dialogBusy = true; dialogError = null
                    fun finish(err: String?) {
                        dialogBusy = false
                        if (err == null) { editStudentTarget = null; toast("تم حفظ بيانات الطالب") } else dialogError = err
                    }
                    val infoChanged = name != target.fullName || sid != target.studentId
                    val passwordChanged = newPassword.isNotBlank()
                    val emailChanged = !email.equals(target.email, ignoreCase = true)
                    fun changeEmailStep() {
                        if (emailChanged) onChangeEmail(target.email, email) { finish(it) } else finish(null)
                    }
                    if (infoChanged || passwordChanged) {
                        onUpdateStudent(target.email, name, sid, newPassword) { err ->
                            if (err != null) finish(err) else changeEmailStep()
                        }
                    } else changeEmailStep()
                },
                onDismiss = { editStudentTarget = null; closeDialogs() }
            )
        }
        deleteStudentTarget?.let { target ->
            ConfirmDialog(
                title = "حذف الطالب",
                message = "سيتم حذف حساب (${target.fullName}) من السيرفر نهائياً. لن يُنشأ حساب جديد بالدخول بالاسم فقط.",
                confirmText = "حذف",
                onConfirm = {
                    deleteStudentTarget = null
                    onDeleteStudent(target.email) { err -> toast(err ?: "تم حذف الطالب") }
                },
                onDismiss = { deleteStudentTarget = null }
            )
        }
        demoteTarget?.let { target ->
            ConfirmDialog(
                title = "إزالة صلاحية الأدمن",
                message = "(${target.fullName}) يرجع طالب عادي وتنتهي جلساته فوراً.",
                confirmText = "إزالة الصلاحية",
                onConfirm = {
                    demoteTarget = null
                    onDemoteAdmin(target.email) { err -> toast(err ?: "تمت إزالة صلاحية الأدمن") }
                },
                onDismiss = { demoteTarget = null }
            )
        }
        promoteTarget?.let { target ->
            PromoteStudentDialog(
                student = target, busy = dialogBusy, error = dialogError,
                onPromote = { email, password ->
                    dialogBusy = true; dialogError = null
                    onPromoteStudent(target, email, password) { err ->
                        dialogBusy = false
                        if (err == null) { promoteTarget = null; toast("تم تعيين (${target.fullName}) أدمن بهذه المرحلة") } else dialogError = err
                    }
                },
                onDismiss = { promoteTarget = null; closeDialogs() }
            )
        }
        if (showAddAdmin) {
            AddAdminDialog(
                busy = dialogBusy, error = dialogError,
                onCreate = { email, name, password ->
                    dialogBusy = true; dialogError = null
                    onCreateAdmin(email, name, password) { err ->
                        dialogBusy = false
                        if (err == null) { showAddAdmin = false; toast("تمت إضافة الأدمن ($name)") } else dialogError = err
                    }
                },
                onDismiss = { showAddAdmin = false; closeDialogs() }
            )
        }

        val isMainAdminUser = AdminConfig.isMainAdmin(currentAdminEmail)
        com.saifadnan.pharmacynotes.ui.components.ScreenHeader(
            title = "لوحة الأدمن",
            subtitle = "إدارة السيرفر · ${Stages.label(Stages.current)}",
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        if (isMainAdminUser) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = Spacing.Xs),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Stages.ALL.forEach { st ->
                    GlassChip(
                        text = Stages.short(st.id),
                        selected = st.id == Stages.current,
                        onClick = {
                            if (!stageSwitching && st.id != Stages.current) {
                                stageSwitching = true
                                onSwitchStage(st.id) { err ->
                                    stageSwitching = false
                                    toast(err ?: "تم الانتقال إلى ${Stages.label(st.id)}")
                                }
                            }
                        },
                        modifier = Modifier.testTag("admin_stage_chip_${st.id}")
                    )
                }
            }
        }
        val allNonAdminStudents = remember(students) { students.filter { !it.email.equals(AdminConfig.ADMIN_EMAIL, ignoreCase = true) } }
        val pendingStudents = remember(students) { students.filter { !it.isApproved && !it.email.equals(AdminConfig.ADMIN_EMAIL, ignoreCase = true) } }
        val approvedStudents = remember(students) { students.filter { it.isApproved && !it.email.equals(AdminConfig.ADMIN_EMAIL, ignoreCase = true) } }

        ScrollableTabRow(
            selectedTabIndex = adminTab,
            containerColor = MaterialTheme.colorScheme.surface,
            edgePadding = Spacing.Md
        ) {
            Tab(
                selected = adminTab == 0,
                onClick = { adminTab = 0 },
                text = { Text("رفع ملازمة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 1,
                onClick = { adminTab = 1 },
                text = { Text("إدارة المجلدات (${subjects.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 2,
                onClick = { adminTab = 2 },
                text = { Text("إرسال تبليغ", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 3,
                onClick = { adminTab = 3 },
                text = { Text("إدارة المحاضرات", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 4,
                onClick = { adminTab = 4 },
                text = { Text("الطلاب (${approvedStudents.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 5,
                onClick = { adminTab = 5 },
                text = { Text("إدارة الحظر (${allNonAdminStudents.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 6,
                onClick = { adminTab = 6 },
                text = { Text("الأدمنية (${admins.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 7,
                onClick = { adminTab = 7 },
                text = { Text("الإحصائيات", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 8,
                onClick = { adminTab = 8 },
                text = { Text("الامتحانات (${exams.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            )
            if (isMainAdminUser) {
                Tab(
                    selected = adminTab == 9,
                    onClick = { adminTab = 9 },
                    text = { Text("أسئلة اللعبة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                )
            }
        }

        AnimatedVisibility(visible = showSuccessMessage) {
            Card(
                shape = AppShapes.Small,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Spacing.Lg, vertical = Spacing.Sm)
            ) {
                Row(
                    modifier = Modifier.padding(Spacing.Md),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Success", tint = MaterialTheme.colorScheme.onPrimary)
                    Text(text = successText, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(Spacing.Lg),
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(Spacing.Md)
        ) {
            when (adminTab) {
                0 -> {
                    item {
                        Card(
                            shape = AppShapes.Medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Column(
                                modifier = Modifier.padding(Spacing.Lg),
                                verticalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Text(
                                    text = "بيانات المحاضرة الجديدة (${com.saifadnan.pharmacynotes.data.Stages.label(com.saifadnan.pharmacynotes.data.Stages.current)})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                OutlinedTextField(
                                    value = titleInput,
                                    onValueChange = { titleInput = it },
                                    label = { Text("عنوان المحاضرة *") },
                                    placeholder = { Text("المحاضرة 3: المركبات الأروماتية") },
                                    modifier = Modifier.fillMaxWidth().testTag("admin_lecture_title_input"),
                                    singleLine = true,
                                    shape = AppShapes.Small
                                )

                                AdminSectionToggle(selected = uploadSection, onSelect = { uploadSection = it })
                                AdminCategoryToggle(section = uploadSection, selected = uploadCategory, onSelect = { uploadCategory = it })
                                AdminSemesterToggle(selected = selectedSemesterInput, onSelect = { selectedSemesterInput = it })

                                OutlinedTextField(
                                    value = subjectInput,
                                    onValueChange = { subjectInput = it },
                                    label = { Text("اسم المادة الصيدلانية *") },
                                    placeholder = { Text("الكيمياء العضوية الصيدلانية") },
                                    modifier = Modifier.fillMaxWidth().testTag("admin_lecture_subject_input"),
                                    singleLine = true,
                                    shape = AppShapes.Small
                                )
                                SubjectChips(subjects.filter { it.section == uploadSection && it.semester == selectedSemesterInput }, subjectInput) { subjectInput = it }

                                YoutubeLinkField(value = youtubeUrlInput, onValueChange = { youtubeUrlInput = it })

                                if (uploadSection == Section.PRACTICAL) {
                                    WorksheetEditor(
                                        url = worksheetUrlInput,
                                        type = worksheetTypeInput,
                                        uploading = isUploadingWorksheet,
                                        onPick = pickUploadWorksheet,
                                        onTypeChange = { worksheetTypeInput = it },
                                        onRemove = { worksheetUrlInput = "" }
                                    )
                                }

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            AppShapes.Medium
                                        )
                                        .border(1.dp, CardBorder, AppShapes.Medium)
                                        .padding(Spacing.Md),
                                    verticalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ملف المحاضرة (PDF):",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )

                                        Button(
                                            onClick = { pdfPickerLauncher.launch("application/pdf") },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary
                                            ),
                                            shape = AppShapes.Small,
                                            modifier = Modifier.testTag("admin_browse_files_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.FolderOpen,
                                                contentDescription = "Browse",
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(Spacing.Sm))
                                            Text("تصفح ملفات النظام", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (selectedFileName != null) {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                            ),
                                            shape = AppShapes.Small
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(Spacing.Md),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PictureAsPdf,
                                                    contentDescription = "PDF",
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = selectedFileName ?: "",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "حجم الملف: ${selectedFileSize ?: "حسب الملف"} • عدد الصفحات: $detectedPageCount صفحة",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                    if (uploadStorageStatus.isNotBlank()) {
                                                        Spacer(modifier = Modifier.height(Spacing.Xs))
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            if (isUploadingToStorage) {
                                                                CircularProgressIndicator(
                                                                    modifier = Modifier.size(Spacing.Md),
                                                                    strokeWidth = Spacing.Xs,
                                                                    color = MaterialTheme.colorScheme.primary
                                                                )
                                                                Spacer(modifier = Modifier.width(Spacing.Xs))
                                                            }
                                                            Text(
                                                                text = uploadStorageStatus,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = if (isUploadingToStorage) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        OutlinedTextField(
                                            value = fileUrlInput,
                                            onValueChange = { fileUrlInput = it },
                                            label = { Text("أو أدخل رابط الملف المباشر (PDF)") },
                                            placeholder = { Text("https://mustansiriyah.edu.iq/docs/lecture.pdf") },
                                            modifier = Modifier.fillMaxWidth().testTag("admin_file_url_input"),
                                            singleLine = true,
                                            shape = AppShapes.Small
                                        )
                                    }
                                }

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                                    ),
                                    shape = AppShapes.Small
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(Spacing.Md),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "Auto",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "تم ربط تخزين المحاضرات مع السيرفر السحابي لضمان وصولها الفوري لجميع الطلاب",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f), AppShapes.Small)
                                        .padding(Spacing.Sm)
                                ) {
                                    Checkbox(
                                        checked = sendNotificationInput,
                                        onCheckedChange = { sendNotificationInput = it },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = "Alert",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(Spacing.Sm))
                                    Text(
                                        text = "إرسال إشعار فوري للجهاز والتطبيق لجميع الطلاب",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                Button(
                                    enabled = !isUploadingToStorage && !isUploadingWorksheet,
                                    onClick = {
                                        if (titleInput.isNotBlank() && subjectInput.isNotBlank()) {
                                            coroutineScope.launch {
                                                if (!com.saifadnan.pharmacynotes.util.YoutubeLinks.isValid(youtubeUrlInput)) {
                                                    Toast.makeText(context, "رابط اليوتيوب غير صالح", Toast.LENGTH_LONG).show()
                                                    return@launch
                                                }
                                                var finalUrl = fileUrlInput
                                                val localF = selectedLocalFile ?: run {
                                                    val filePath = finalUrl.removePrefix("file://").removePrefix("content://")
                                                    File(filePath)
                                                }
                                                if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                                    isUploadingToStorage = true
                                                    uploadStorageStatus = "جاري تهيئة رفع الملف للسيرفر..."
                                                    if (localF != null && localF.exists() && localF.length() > 0) {
                                                        val safeName = "lec_${System.currentTimeMillis()}.pdf"
                                                        val uploadResult = com.saifadnan.pharmacynotes.data.SupabaseClient.uploadPdfFile(localF, safeName, onStatus = { uploadStorageStatus = it }) { bytes, total ->
                                                            if (total > 0) {
                                                                val percent = (bytes * 100 / total).toInt()
                                                                val mbUploaded = bytes / (1024.0 * 1024.0)
                                                                val mbTotal = total / (1024.0 * 1024.0)
                                                                uploadStorageStatus = String.format(
                                                                    java.util.Locale.US,
                                                                    "جاري رفع الملف للسيرفر: %d%% (%.1f MB / %.1f MB)...",
                                                                    percent,
                                                                    mbUploaded,
                                                                    mbTotal
                                                                )
                                                            }
                                                        }

                                                        if (uploadResult.isSuccess && uploadResult.url != null) {
                                                            finalUrl = uploadResult.url
                                                            fileUrlInput = uploadResult.url
                                                            uploadResult.finalSizeBytes?.let { b ->
                                                                selectedFileSize = String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
                                                            }
                                                            uploadStorageStatus = "تم الرفع والربط بنجاح مع السيرفر"
                                                        } else {
                                                            val err = uploadResult.error ?: "تعذر رفع الملف للسيرفر"
                                                            uploadStorageStatus = "فشل الرفع: $err"
                                                            Toast.makeText(context, "فشل الرفع:\n$err", Toast.LENGTH_LONG).show()
                                                            isUploadingToStorage = false
                                                            return@launch
                                                        }
                                                    } else {
                                                        Toast.makeText(context, "تعذر العثور على الملف المحلي لإعادة رفعه. يرجى اختيار الملف مجدداً.", Toast.LENGTH_LONG).show()
                                                        isUploadingToStorage = false
                                                        return@launch
                                                    }
                                                    isUploadingToStorage = false
                                                }

                                                if (finalUrl.startsWith("file://") || finalUrl.startsWith("content://")) {
                                                    Toast.makeText(context, "تعذر رفع الملف إلى السيرفر السحابي. لن يتمكن الطلاب من فتح الملف — يرجى إعادة المحاولة.", Toast.LENGTH_LONG).show()
                                                    isUploadingToStorage = false
                                                    return@launch
                                                }

                                                if (finalUrl.isNotBlank()) {
                                                    val practical = uploadSection == Section.PRACTICAL
                                                    onUploadLecture(
                                                        NewLectureRequest(
                                                            title = titleInput,
                                                            subject = subjectInput,
                                                            semester = selectedSemesterInput,
                                                            fileUrl = finalUrl,
                                                            sendNotification = sendNotificationInput,
                                                            fileSize = selectedFileSize,
                                                            pageCount = detectedPageCount,
                                                            section = uploadSection,
                                                            category = if (practical && uploadCategory == Category.REEYUS) Category.GHRADI else uploadCategory,
                                                            worksheetUrl = if (practical) worksheetUrlInput else "",
                                                            worksheetType = if (practical && worksheetUrlInput.isNotBlank()) worksheetTypeInput else "",
                                                            youtubeUrl = youtubeUrlInput.trim()
                                                        )
                                                    ) { isSupabaseSuccess ->
                                                        if (!isSupabaseSuccess) {
                                                            Toast.makeText(
                                                                context,
                                                                "تنبيه: تعذر رفع بيانات المحاضرة إلى السيرفر. المحاضرة محفوظة محلياً فقط.",
                                                                Toast.LENGTH_LONG
                                                            ).show()
                                                        }
                                                    }
                                                    successText = "تم رفع المحاضرة وعرضها لجميع المستخدمين عبر السيرفر بنجاح."
                                                    showSuccessMessage = true
                                                    titleInput = ""
                                                    subjectInput = ""
                                                    fileUrlInput = ""
                                                    selectedLocalFile = null
                                                    selectedFileName = null
                                                    selectedFileSize = null
                                                    uploadStorageStatus = ""
                                                    worksheetUrlInput = ""
                                                    youtubeUrlInput = ""
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("admin_upload_submit_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = AppShapes.Small
                                ) {
                                    if (isUploadingToStorage) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            color = MaterialTheme.colorScheme.onPrimary,
                                            strokeWidth = Spacing.Xs
                                        )
                                        Spacer(modifier = Modifier.width(Spacing.Sm))
                                        Text("جاري رفع الملف إلى السيرفر...", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    } else {
                                        Icon(Icons.Default.CloudUpload, contentDescription = "Upload")
                                        Spacer(modifier = Modifier.width(Spacing.Sm))
                                        Text("رفع المحاضرة الآن", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(Spacing.Sm)) {
                            AdminSectionToggle(selected = foldersSection, onSelect = { foldersSection = it })
                            AdminSemesterToggle(selected = foldersSemester, onSelect = { foldersSemester = it })
                        }
                    }

                    item {
                        var newFolderNameInput by remember { mutableStateOf("") }

                        Card(
                            shape = AppShapes.Medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Column(
                                modifier = Modifier.padding(Spacing.Lg),
                                verticalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Text(
                                    text = "مجلد جديد في ${Section.label(foldersSection)} · ${com.saifadnan.pharmacynotes.data.Course.label(foldersSemester)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                OutlinedTextField(
                                    value = newFolderNameInput,
                                    onValueChange = { newFolderNameInput = it },
                                    label = { Text("اسم المادة / المجلد") },
                                    leadingIcon = { Icon(Icons.Default.Folder, contentDescription = "Folder") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("admin_add_subject_input"),
                                    singleLine = true,
                                    shape = AppShapes.Small
                                )

                                Button(
                                    onClick = {
                                        if (newFolderNameInput.isNotBlank()) {
                                            val name = newFolderNameInput.trim()
                                            onAddSubjectFolder(name, foldersSection, foldersSemester)
                                            successText = "تمت إضافة مجلد ($name) في ${Section.label(foldersSection)} · ${com.saifadnan.pharmacynotes.data.Course.label(foldersSemester)}"
                                            showSuccessMessage = true
                                            newFolderNameInput = ""
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("admin_add_subject_button"),
                                    shape = AppShapes.Small,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = "Add Folder", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(Spacing.Sm))
                                    Text("إضافة المجلد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }

                    val sectionSubjects = subjects.filter { it.section == foldersSection && it.semester == foldersSemester }

                    item {
                        Text(
                            text = "المجلدات الحالية (${sectionSubjects.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(top = Spacing.Sm)
                        )
                    }

                    if (sectionSubjects.isEmpty()) {
                        item {
                            Text("لا توجد مجلدات بعد", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        itemsIndexed(sectionSubjects, key = { _, it -> it.section + "|" + it.semester + "|" + it.name }) { index, subj ->
                            val inFolder = lectures.filter { it.subject == subj.name && it.section == subj.section && it.semester == subj.semester }
                            val summary = buildList {
                                inFolder.count { it.category == Category.OFFICIAL }.takeIf { it > 0 }?.let { add("$it محاضرة") }
                                inFolder.count { it.category == Category.GHRADI }.takeIf { it > 0 }?.let { add("$it غراضي") }
                                inFolder.count { it.category == Category.REEYUS }.takeIf { it > 0 }?.let { add("$it ريوس") }
                            }.joinToString(" · ").ifBlank { "فارغ" }
                            Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItemEntrance(index = index)
                                    .border(1.dp, CardBorder, AppShapes.Medium)
                                    .testTag("admin_subject_folder_${subj.name}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = Spacing.Md, top = Spacing.Xs, bottom = Spacing.Xs, end = Spacing.Xs),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    com.saifadnan.pharmacynotes.ui.components.SubjectIconTile(
                                        icon = subj.icon,
                                        size = 38.dp,
                                        tint = MaterialTheme.colorScheme.primary,
                                        container = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                                    )
                                    Spacer(Modifier.width(Spacing.Md))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = subj.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2
                                        )
                                        Text(
                                            text = summary,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { dialogError = null; iconTarget = subj },
                                        modifier = Modifier.testTag("icon_subject_button_${subj.name}")
                                    ) {
                                        Icon(Icons.Default.Palette, contentDescription = "أيقونة المادة", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = { renameTarget = subj },
                                        modifier = Modifier.testTag("rename_subject_button_${subj.name}")
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل الاسم", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = {
                                            val newPinnedState = !subj.isExamPinned
                                            onToggleSubjectExamPinned(subj.name, subj.section, subj.semester, newPinnedState)
                                            successText = if (newPinnedState) "تم تثبيت مادة (${subj.name}) للامتحان" else "تم إلغاء تثبيت مادة (${subj.name})"
                                            showSuccessMessage = true
                                        },
                                        modifier = Modifier.testTag("pin_subject_button_${subj.name}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PushPin,
                                            contentDescription = "Pin Subject",
                                            tint = if (subj.isExamPinned) Amber else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                        )
                                    }
                                    IconButton(
                                        onClick = { deleteFolderTarget = subj },
                                        modifier = Modifier.testTag("delete_subject_button_${subj.name}")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Folder", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        Card(
                            shape = AppShapes.Medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Column(
                                modifier = Modifier.padding(Spacing.Lg),
                                verticalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = "Announcement",
                                        tint = Amber,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "إرسال تبليغ رسمي لطلاب المرحلة",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedTextField(
                                    value = announceTitleInput,
                                    onValueChange = { announceTitleInput = it },
                                    label = { Text("عنوان التبليغ *") },
                                    placeholder = { Text("تأجيل موعد القاعة الامتحانية") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = AppShapes.Small
                                )

                                com.saifadnan.pharmacynotes.ui.components.RichMessageEditor(
                                    value = announceMsgInput,
                                    onValueChange = { announceMsgInput = it },
                                    label = "تفاصيل التبليغ *",
                                    placeholder = "يرجى الحضور في تمام الساعة العاشرة صباحاً...",
                                    shape = AppShapes.Small
                                )

                                OutlinedTextField(
                                    value = announceUrlInput,
                                    onValueChange = { announceUrlInput = it },
                                    label = { Text("رابط خارجي قابل للفتح (اختياري)") },
                                    placeholder = { Text("https://example.com أو رابط قناة تيليجرام") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Link, contentDescription = "URL")
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = AppShapes.Small
                                )

                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(Spacing.Xs)
                                ) {
                                    OutlinedTextField(
                                        value = announceImageUrlInput,
                                        onValueChange = { announceImageUrlInput = it },
                                        label = { Text("رابط صورة مرفقة (اختياري)") },
                                        placeholder = { Text("https://example.com/image.jpg") },
                                        leadingIcon = {
                                            Icon(Icons.Default.Image, contentDescription = "Image")
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        shape = AppShapes.Small
                                    )

                                    OutlinedButton(
                                        onClick = { notifImagePickerLauncher.launch("image/*") },
                                        enabled = !isUploadingNotifImage,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = AppShapes.Small
                                    ) {
                                        if (isUploadingNotifImage) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                            Spacer(modifier = Modifier.width(Spacing.Sm))
                                            Text("جاري رفع الصورة...")
                                        } else {
                                            Icon(Icons.Default.Image, contentDescription = "Pick Image")
                                            Spacer(modifier = Modifier.width(Spacing.Sm))
                                            Text("اختر صورة مرفقة من الجهاز")
                                        }
                                    }
                                }

                                com.saifadnan.pharmacynotes.ui.components.NotifStyleEditor(
                                    title = announceTitleInput,
                                    message = announceMsgInput,
                                    style = announceStyle,
                                    onChange = { announceStyle = it }
                                )

                                Button(
                                    onClick = {
                                        if (announceTitleInput.isNotBlank() && announceMsgInput.isNotBlank()) {
                                            onPublishAnnouncement(
                                                announceTitleInput,
                                                announceMsgInput,
                                                announceUrlInput.ifBlank { null },
                                                announceImageUrlInput.ifBlank { null },
                                                announceStyle.toJson()
                                            )
                                            successText = "تم بث التبليغ الرسمي لطلاب المرحلة وإرسال إشعار للنظام بنجاح."
                                            showSuccessMessage = true
                                            announceTitleInput = ""
                                            announceMsgInput = ""
                                            announceUrlInput = ""
                                            announceImageUrlInput = ""
                                            announceStyle = com.saifadnan.pharmacynotes.ui.components.NotifStyle()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp)
                                        .testTag("send_announcement_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Amber),
                                    shape = AppShapes.Small
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(Spacing.Sm))
                                    Text("بث التبليغ للطلاب", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                3 -> {
                    item {
                        AdminSectionToggle(selected = lecturesSection, onSelect = { lecturesSection = it })
                    }

                    val sectionLectures = lectures.filter { it.section == lecturesSection }

                    if (sectionLectures.isEmpty()) {
                        item {
                            Text("لا توجد محاضرات في ${Section.label(lecturesSection)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    itemsIndexed(sectionLectures, key = { _, it -> it.id }) { index, lecture ->
                        Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItemEntrance(index = index)
                                    .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = Spacing.Md, top = Spacing.Xs, bottom = Spacing.Xs, end = Spacing.Xs),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = lecture.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2
                                    )
                                    Text(
                                        text = buildString {
                                            append(lecture.subject)
                                            append(" · ")
                                            append(Category.label(lecture.category))
                                            if (lecture.worksheetUrl.isNotBlank()) {
                                                append(" · ")
                                                append(WorksheetType.label(lecture.worksheetType))
                                            }
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2
                                    )
                                }
                                IconButton(
                                    onClick = { editLectureTarget = lecture },
                                    modifier = Modifier.testTag("edit_lecture_button_${lecture.id}")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(
                                    onClick = { deleteLectureTarget = lecture },
                                    modifier = Modifier.testTag("delete_lecture_button_${lecture.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }

                4 -> {
                    item {
                        OutlinedTextField(
                            value = studentQuery,
                            onValueChange = { studentQuery = it },
                            placeholder = { Text("ابحث بالاسم أو البريد أو الرقم الجامعي") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            shape = AppShapes.Medium,
                            modifier = Modifier.fillMaxWidth().testTag("admin_student_search")
                        )
                    }

                    val searchedStudents = approvedStudents.filter {
                        studentQuery.isBlank() ||
                            ArabicSearch.matches(it.fullName, studentQuery) ||
                            ArabicSearch.matches(it.email, studentQuery) ||
                            ArabicSearch.matches(it.studentId, studentQuery)
                    }
                    val groupCounts = searchedStudents.groupingBy { it.groupName.trim() }.eachCount()
                    val presentGroups = groupCounts.keys.sortedWith(compareBy({ groupRank(it) }, { it }))
                    val activeFilter = studentGroupFilter?.takeIf { it in groupCounts.keys }
                    val shownStudents = searchedStudents.filter { activeFilter == null || it.groupName.trim() == activeFilter }
                    val collator = java.text.Collator.getInstance(Locale.forLanguageTag("ar"))
                    val byName = shownStudents.sortedWith { a, b -> collator.compare(a.fullName.trim(), b.fullName.trim()) }
                    val studentRows: List<StudentRow> = when (studentSort) {
                        1 -> byName.mapIndexed { i, u -> StudentRow.Item(u, i + 1) }
                        2 -> shownStudents.sortedByDescending { it.registrationDate }.mapIndexed { i, u -> StudentRow.Item(u, i + 1) }
                        else -> {
                            val out = ArrayList<StudentRow>()
                            val grouped = byName.groupBy { it.groupName.trim() }
                            grouped.keys.sortedWith(compareBy({ groupRank(it) }, { it })).forEach { g ->
                                val members = grouped.getValue(g)
                                out.add(StudentRow.Header(g, members.size))
                                members.forEachIndexed { i, u -> out.add(StudentRow.Item(u, i + 1)) }
                            }
                            out
                        }
                    }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(Spacing.Sm)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                            ) {
                                GlassChip(
                                    text = "الكل (${searchedStudents.size})",
                                    selected = activeFilter == null,
                                    onClick = { studentGroupFilter = null }
                                )
                                presentGroups.forEach { g ->
                                    GlassChip(
                                        text = "${if (g.isBlank()) "بدون كروب" else g} (${groupCounts[g] ?: 0})",
                                        selected = activeFilter == g,
                                        onClick = { studentGroupFilter = g }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                            ) {
                                listOf("حسب الكروب", "أبجدي", "الأحدث").forEachIndexed { i, label ->
                                    GlassChip(
                                        text = label,
                                        selected = studentSort == i,
                                        onClick = { studentSort = i }
                                    )
                                }
                            }
                        }
                    }

                    if (shownStudents.isEmpty()) {
                        item {
                            Text(
                                text = if (studentQuery.isBlank()) "لا يوجد طلاب مسجلون حالياً" else "لا توجد نتائج",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(Spacing.Lg)
                            )
                        }
                    } else {
                        itemsIndexed(studentRows, key = { _, r -> r.key }) { index, row ->
                            if (row is StudentRow.Header) {
                                StudentGroupHeader(
                                    title = if (row.group.isBlank()) "بدون كروب" else "الكروب ${row.group}",
                                    count = row.count,
                                    color = groupColor(row.group),
                                    modifier = Modifier.animateItemEntrance(index = index)
                                )
                                return@itemsIndexed
                            }
                            val student = (row as StudentRow.Item).user
                            val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale.getDefault()) }
                            val dateStr = dateFormat.format(Date(student.registrationDate))

                            Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItemEntrance(index = index)
                                    .border(1.dp, CardBorder, AppShapes.Medium)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(Spacing.Md),
                                    verticalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
                                    ) {
                                        val avatarColor = groupColor(student.groupName)
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .background(avatarColor.copy(alpha = 0.18f), CircleShape)
                                                .border(1.dp, avatarColor.copy(alpha = 0.45f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = student.fullName.trim().take(1),
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = avatarColor
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                            ) {
                                                Text(
                                                    text = "${row.number}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = student.fullName,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 2,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                if (student.groupName.isNotBlank()) {
                                                    Text(
                                                        text = student.groupName,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = groupColor(student.groupName),
                                                        modifier = Modifier
                                                            .background(groupColor(student.groupName).copy(alpha = 0.14f), CircleShape)
                                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Text(
                                                text = buildString {
                                                    if (student.studentId.isNotBlank()) append(student.studentId).append(" · ")
                                                    append(dateStr)
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = student.email,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                    ) {
                                        OutlinedButton(
                                            onClick = { editStudentTarget = student },
                                            shape = AppShapes.Small,
                                            contentPadding = PaddingValues(horizontal = Spacing.Sm),
                                            modifier = Modifier.weight(1f).testTag("edit_student_${student.email}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(Spacing.Xs))
                                            Text("تعديل", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                onResetDevices(student.email) { err ->
                                                    successText = err ?: "تم فك ربط أجهزة (${student.fullName})"
                                                    showSuccessMessage = true
                                                }
                                            },
                                            shape = AppShapes.Small,
                                            contentPadding = PaddingValues(horizontal = Spacing.Sm),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.PhonelinkErase, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(Spacing.Xs))
                                            Text("الأجهزة", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                        }
                                        OutlinedButton(
                                            onClick = { deleteStudentTarget = student },
                                            shape = AppShapes.Small,
                                            contentPadding = PaddingValues(horizontal = Spacing.Sm),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(Spacing.Xs))
                                            Text("حذف", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error, maxLines = 1)
                                        }
                                    }

                                    if (isMainAdminUser) {
                                        OutlinedButton(
                                            onClick = { dialogError = null; promoteTarget = student },
                                            shape = AppShapes.Small,
                                            modifier = Modifier.fillMaxWidth().testTag("promote_student_${student.email}")
                                        ) {
                                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Amber, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(Spacing.Xs))
                                            Text("تعيين كأدمن بهذه المرحلة", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                5 -> {
                    item {
                        Card(
                            shape = AppShapes.Medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(Spacing.Lg),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Badge,
                                    contentDescription = "Students Ban Management",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Column {
                                    Text(
                                        text = "إدارة وحظر الطلاب",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = "عرض كافة الطلاب المسجلين بالسيرفر مع إمكانية حظر أو إلغاء حظر أي طالب فوراً",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }

                    if (banRequests.isNotEmpty()) {
                        item(key = "ban_requests_header") {
                            Text(
                                text = if (isMainAdminUser) "طلبات حظر بانتظار قرارك (${banRequests.count { it.status == "PENDING" }})"
                                else "طلبات الحظر التي أرسلتها",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = Spacing.Xs)
                            )
                        }
                        items(banRequests, key = { "ban_${it.id}" }) { req ->
                            BanRequestCard(
                                req = req,
                                isMainAdmin = isMainAdminUser,
                                onDecide = { approve -> onDecideBanRequest(req.id, approve) },
                                modifier = Modifier.animateItem()
                            )
                        }
                    }

                    if (allNonAdminStudents.isEmpty()) {
                        item {
                            Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = Spacing.Lg)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "لا يوجد طلاب مسجلون حالياً",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    } else {
                        itemsIndexed(allNonAdminStudents, key = { _, it -> it.email }) { index, student ->
                            val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale.getDefault()) }
                            val dateStr = dateFormat.format(Date(student.registrationDate))

                            Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItemEntrance(index = index)
                                    .border(1.dp, CardBorder, AppShapes.Medium)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(Spacing.Lg),
                                    verticalArrangement = Arrangement.spacedBy(Spacing.Md)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .background(
                                                    if (student.isApproved) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = "Student",
                                                tint = if (student.isApproved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.fullName,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (student.studentId.isNotBlank()) {
                                                Text(
                                                    text = "الرقم الجامعي: ${student.studentId}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            Text(
                                                text = "تاريخ التسجيل: $dateStr",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Column(
                                            horizontalAlignment = Alignment.End,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Card(
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (student.isApproved) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                                                ),
                                                shape = AppShapes.Small
                                            ) {
                                                Text(
                                                    text = if (student.isApproved) "نشط" else "محظور",
                                                    modifier = Modifier.padding(horizontal = Spacing.Sm, vertical = Spacing.Xs),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (student.isApproved) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                                                )
                                            }

                                            if (student.groupName.isNotBlank()) {
                                                Card(
                                                    colors = CardDefaults.cardColors(
                                                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                                                    ),
                                                    shape = AppShapes.Small
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                                                        modifier = Modifier.padding(horizontal = Spacing.Sm, vertical = Spacing.Xs)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Groups,
                                                            contentDescription = "Group",
                                                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Text(
                                                            text = student.groupName,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                    ) {
                                        if (student.isApproved) {
                                            val banPending = banRequests.any {
                                                it.status == "PENDING" && it.targetEmail.equals(student.email, ignoreCase = true)
                                            }
                                            Button(
                                                onClick = { onRejectStudent(student) },
                                                enabled = !banPending,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .bounceClick(),
                                                shape = AppShapes.Small,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.error,
                                                    disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                                    disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Ban", modifier = Modifier.size(Spacing.Lg))
                                                Spacer(modifier = Modifier.width(Spacing.Xs))
                                                Text(
                                                    text = when {
                                                        banPending -> "بانتظار موافقة الأدمن الرئيسي"
                                                        isMainAdminUser -> "حظر الطالب"
                                                        else -> "طلب حظر الطالب"
                                                    },
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        } else {
                                            Button(
                                                onClick = { onApproveStudent(student) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .bounceClick(),
                                                shape = AppShapes.Small,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.primary
                                                )
                                            ) {
                                                Icon(Icons.Default.Check, contentDescription = "Unban", modifier = Modifier.size(Spacing.Lg))
                                                Spacer(modifier = Modifier.width(Spacing.Xs))
                                                Text("إلغاء الحظر (تفعيل)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                6 -> {
                    item {
                        Card(
                            shape = AppShapes.Medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(Spacing.Lg),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("الأدمنية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        if (isMainAdminUser) "الأدمنية خاصة بهذه المرحلة فقط. لتعيين أدمن من الطلاب: افتح تبويب (الطلاب) واضغط (تعيين كأدمن)."
                                        else "كل أدمن يدخل ببريده وكلمة مروره وله صلاحيات إدارة هذه المرحلة.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (isMainAdminUser) {
                                    Button(
                                        onClick = { dialogError = null; showAddAdmin = true },
                                        shape = AppShapes.Small,
                                        modifier = Modifier.testTag("admin_add_admin_button")
                                    ) {
                                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(Spacing.Xs))
                                        Text("إضافة", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    itemsIndexed(admins, key = { _, it -> it.email }) { index, admin ->
                        val isMain = AdminConfig.isMainAdmin(admin.email)
                        val isSelf = admin.email.equals(currentAdminEmail, ignoreCase = true)
                        Card(
                                shape = AppShapes.Medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateItemEntrance(index = index)
                                    .border(1.dp, CardBorder, AppShapes.Medium)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = Spacing.Md, top = Spacing.Xs, bottom = Spacing.Xs, end = Spacing.Xs),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Amber.copy(alpha = 0.16f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Amber)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
                                    ) {
                                        Text(
                                            text = admin.fullName.ifBlank { admin.email },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (isMain) AdminBadge("الرئيسي")
                                        if (isSelf) AdminBadge("أنت")
                                    }
                                    Text(
                                        text = admin.email,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                                if (!isMain && !isSelf) {
                                    IconButton(
                                        onClick = { demoteTarget = admin },
                                        modifier = Modifier.testTag("demote_admin_${admin.email}")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "إزالة الصلاحية", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }

                7 -> {
                    item { AdminStatsContent() }
                }

                9 -> {
                    item {
                        if (isMainAdminUser) AdminGamePanel(onToast = { msg -> successText = msg; showSuccessMessage = true })
                    }
                }

                8 -> {
                    item {
                        AdminExamsPanel(
                            exams = exams,
                            onSave = onSaveExam,
                            onDelete = onDeleteExam,
                            onToast = { msg -> successText = msg; showSuccessMessage = true }
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
private fun AdminBadge(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onPrimaryContainer,
        modifier = Modifier
            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

private fun getFileNameAndSizeFromUri(context: Context, uri: Uri): Pair<String, String> {
    var name = "lecture.pdf"
    var sizeStr = "3.2 MB"
    try {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) {
                        name = cursor.getString(nameIndex) ?: name
                    }
                    if (sizeIndex != -1) {
                        val sizeBytes = cursor.getLong(sizeIndex)
                        if (sizeBytes > 0) {
                            val mb = sizeBytes / (1024.0 * 1024.0)
                            sizeStr = String.format(Locale.US, "%.1f MB", mb)
                        }
                    }
                }
            }
        } else {
            uri.path?.let { p ->
                val f = File(p)
                if (f.exists()) {
                    name = f.name
                    val mb = f.length() / (1024.0 * 1024.0)
                    sizeStr = String.format(Locale.US, "%.1f MB", mb)
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return Pair(name, sizeStr)
}


private sealed class StudentRow(val key: String) {
    class Header(val group: String, val count: Int) : StudentRow("hdr_$group")
    class Item(val user: UserEntity, val number: Int) : StudentRow(user.email)
}

private val GROUP_COLORS = listOf(
    Color(0xFF5B8DEF), Color(0xFF3FB68B), Color(0xFFE8A33D), Color(0xFFE5677B),
    Color(0xFF9B7BE8), Color(0xFF3CB4D0), Color(0xFFD9822B), Color(0xFF7BA33B)
)
private val NO_GROUP_COLOR = Color(0xFF8A94A6)

private fun groupColor(group: String): Color {
    val i = ScheduleConstants.GROUPS.indexOf(group.trim())
    return if (i >= 0) GROUP_COLORS[i % GROUP_COLORS.size] else NO_GROUP_COLOR
}

private fun groupRank(group: String): Int {
    val g = group.trim()
    val i = ScheduleConstants.GROUPS.indexOf(g)
    return when {
        i >= 0 -> i
        g.isBlank() -> Int.MAX_VALUE
        else -> 1000
    }
}

@Composable
private fun StudentGroupHeader(
    title: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = Spacing.Sm),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "$count طالب",
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier
                .background(color.copy(alpha = 0.14f), CircleShape)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(CardBorder)
        )
    }
}


@Composable
private fun BanRequestCard(
    req: com.saifadnan.pharmacynotes.data.SupabaseClient.BanRequest,
    isMainAdmin: Boolean,
    onDecide: (approve: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val pending = req.status == "PENDING"
    val statusColor by androidx.compose.animation.animateColorAsState(
        targetValue = when (req.status) {
            "APPROVED" -> scheme.primary
            "REJECTED" -> scheme.error
            else -> scheme.tertiary
        },
        animationSpec = androidx.compose.animation.core.tween(300),
        label = "banStatusColor"
    )
    Card(
        shape = AppShapes.Medium,
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceContainerHigh),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, AppShapes.Medium)
    ) {
        Column(
            modifier = Modifier.padding(Spacing.Lg),
            verticalArrangement = Arrangement.spacedBy(Spacing.Sm)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)) {
                Icon(Icons.Default.Badge, contentDescription = null, tint = statusColor, modifier = Modifier.size(22.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(req.targetName.ifBlank { req.targetEmail }, style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = scheme.onSurface)
                    Text(
                        text = if (isMainAdmin) "طلب من: ${req.requestedByName.ifBlank { req.requestedBy }}"
                        else req.targetEmail,
                        style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant
                    )
                }
                Text(
                    text = when (req.status) {
                        "APPROVED" -> "تمت الموافقة"
                        "REJECTED" -> "مرفوض"
                        else -> "بانتظار القرار"
                    },
                    style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = statusColor
                )
            }
            if (isMainAdmin && pending) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Spacing.Sm)) {
                    Button(
                        onClick = { onDecide(true) },
                        modifier = Modifier.weight(1f).bounceClick(),
                        shape = AppShapes.Small,
                        colors = ButtonDefaults.buttonColors(containerColor = scheme.error)
                    ) { Text("قبول الحظر", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = { onDecide(false) },
                        modifier = Modifier.weight(1f).bounceClick(),
                        shape = AppShapes.Small
                    ) { Text("رفض", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
