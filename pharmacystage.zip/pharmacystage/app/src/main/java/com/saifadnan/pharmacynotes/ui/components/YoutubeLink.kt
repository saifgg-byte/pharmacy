package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.YoutubeRed
import com.saifadnan.pharmacynotes.util.YoutubeLinks
import com.saifadnan.pharmacynotes.util.YoutubeVideo
import kotlinx.coroutines.delay

@Composable
fun YoutubeLinkButton(
    url: String,
    modifier: Modifier = Modifier
) {
    val videos = remember(url) { YoutubeLinks.parse(url) }
    when {
        videos.isEmpty() -> Unit
        videos.size == 1 -> YoutubeSingleButton(videos[0].url, modifier)
        else -> YoutubePlaylistCard(videos, modifier)
    }
}

@Composable
private fun YoutubeSingleButton(
    url: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .iconInteractiveClick(
                behavior = IconClickBehavior.SPRING_BOUNCE,
                scaleDown = 0.97f,
                onClick = { YoutubeLinks.openUrl(context, url) }
            )
            .clip(CircleShape)
            .background(YoutubeRed.copy(alpha = 0.10f))
            .border(1.dp, YoutubeRed.copy(alpha = 0.28f), CircleShape)
            .testTag("youtube_link_button"),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_youtube),
            contentDescription = null,
            tint = Color.Unspecified,
            modifier = Modifier.size(28.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "شرح المحاضرة على يوتيوب",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = YoutubeRed
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            imageVector = Icons.Default.OpenInNew,
            contentDescription = null,
            tint = YoutubeRed.copy(alpha = 0.7f),
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
fun YoutubePlaylistCard(
    videos: List<YoutubeVideo>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf(setOf<Int>()) }
    val shape = RoundedCornerShape(22.dp)
    val chevron by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "yt_chevron"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(YoutubeRed.copy(alpha = 0.10f))
            .border(1.dp, YoutubeRed.copy(alpha = 0.28f), shape)
            .testTag("youtube_playlist_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .iconInteractiveClick(
                    behavior = IconClickBehavior.SPRING_BOUNCE,
                    scaleDown = 0.98f,
                    onClick = { expanded = !expanded }
                )
                .padding(horizontal = 14.dp)
                .testTag("youtube_playlist_header"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_youtube),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "شرح المحاضرة على يوتيوب",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = YoutubeRed,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            YoutubeCountPill(videos.size)
            Spacer(Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ExpandMore,
                contentDescription = if (expanded) "إخفاء القائمة" else "عرض القائمة",
                tint = YoutubeRed.copy(alpha = 0.85f),
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer { rotationZ = chevron }
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)) +
                fadeIn(tween(MotionSpecs.DurationMedium)),
            exit = shrinkVertically(tween(MotionSpecs.ScreenOut, easing = MotionSpecs.StandardEasing)) +
                fadeOut(tween(MotionSpecs.DurationQuick))
        ) {
            Column(
                modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                videos.forEachIndexed { index, video ->
                    YoutubeVideoRow(
                        index = index,
                        video = video,
                        opened = index in opened,
                        onClick = {
                            opened = opened + index
                            YoutubeLinks.openUrl(context, video.url)
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YoutubeVideosSheet(
    videos: List<YoutubeVideo>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var opened by remember { mutableStateOf(setOf<Int>()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 0.dp,
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_youtube),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(30.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "شرح المحاضرة على يوتيوب",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            YoutubeCountPill(videos.size)
        }
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 460.dp)
                .testTag("youtube_videos_sheet"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(videos) { index, video ->
                YoutubeVideoRow(
                    index = index,
                    video = video,
                    opened = index in opened,
                    onClick = {
                        opened = opened + index
                        YoutubeLinks.openUrl(context, video.url)
                    }
                )
            }
        }
    }
}

@Composable
private fun YoutubeCountPill(count: Int) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(YoutubeRed.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = YoutubeLinks.countLabel(count),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = YoutubeRed,
            maxLines = 1
        )
    }
}

@Composable
private fun YoutubeVideoRow(
    index: Int,
    video: YoutubeVideo,
    opened: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // ظهور متتابع: كل صف يتأخر قليلًا عن الذي قبله ثم ينزلق لمكانه بنعومة
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((index * 45L).coerceAtMost(360L))
        reveal.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow))
    }
    val badgeColor by animateColorAsState(
        targetValue = if (opened) SuccessGreen.copy(alpha = 0.16f) else YoutubeRed.copy(alpha = 0.14f),
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "yt_badge_bg"
    )
    val shape = RoundedCornerShape(16.dp)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = reveal.value.coerceIn(0f, 1f)
                translationY = (1f - reveal.value) * 14.dp.toPx()
            }
            .bounceClick(scaleDown = 0.98f, onClick = onClick)
            .clip(shape)
            .background(YoutubeRed.copy(alpha = 0.06f))
            .border(1.dp, YoutubeRed.copy(alpha = 0.16f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("youtube_video_row_$index"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(badgeColor),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = opened,
                transitionSpec = {
                    (fadeIn(tween(200)) + scaleIn(tween(240), initialScale = 0.6f)) togetherWith
                        (fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.6f))
                },
                label = "yt_badge_content"
            ) { done ->
                if (done) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "تمت المشاهدة",
                        tint = SuccessGreen,
                        modifier = Modifier.size(17.dp)
                    )
                } else {
                    Text(
                        text = "${index + 1}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = YoutubeRed
                    )
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = YoutubeLinks.displayTitle(video, index),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            tint = YoutubeRed,
            modifier = Modifier.size(22.dp)
        )
    }
}
