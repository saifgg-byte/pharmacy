package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.panelTokens

private enum class PinState { Idle, Loading, Done }

@Composable
fun DownloadPinButton(
    isDownloaded: Boolean,
    progress: Int?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 46.dp
) {
    val state = when {
        progress != null -> PinState.Loading
        isDownloaded -> PinState.Done
        else -> PinState.Idle
    }
    val accent = panelTokens().accent
    val idleFill = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
    val fill by animateColorAsState(
        targetValue = when (state) {
            PinState.Done -> SuccessGreen.copy(alpha = 0.14f)
            PinState.Loading -> accent.copy(alpha = 0.14f)
            PinState.Idle -> idleFill
        },
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "pin_fill"
    )
    val fraction by animateFloatAsState(
        targetValue = ((progress ?: 0).coerceIn(0, 100)) / 100f,
        animationSpec = tween(260),
        label = "pin_fraction"
    )

    Box(
        modifier = modifier
            .size(size)
            .iconInteractiveClick(
                behavior = IconClickBehavior.SPRING_BOUNCE,
                onClick = { if (state != PinState.Loading) onClick() }
            )
            .clip(CircleShape)
            .background(fill),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = state,
            transitionSpec = {
                (fadeIn(tween(180)) + scaleIn(spring(Spring.DampingRatioMediumBouncy, 380f), initialScale = 0.4f)) togetherWith
                    (fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.6f))
            },
            contentAlignment = Alignment.Center,
            label = "pin_content"
        ) { st ->
            when (st) {
                PinState.Idle -> Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "تنزيل",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(22.dp)
                )
                PinState.Done -> Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "مثبّتة على الجهاز",
                    tint = SuccessGreen,
                    modifier = Modifier.size(22.dp)
                )
                PinState.Loading -> Box(contentAlignment = Alignment.Center) {
                    val p = progress ?: -1
                    if (p <= 0) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(30.dp),
                            strokeWidth = 2.5.dp,
                            color = accent,
                            trackColor = accent.copy(alpha = 0.18f)
                        )
                    } else {
                        CircularProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier.size(30.dp),
                            strokeWidth = 2.5.dp,
                            color = accent,
                            trackColor = accent.copy(alpha = 0.18f)
                        )
                        Text(
                            text = "$p",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
