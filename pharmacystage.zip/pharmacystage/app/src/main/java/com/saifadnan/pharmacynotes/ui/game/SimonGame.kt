package com.saifadnan.pharmacynotes.ui.game

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.rememberAdaptive
import kotlinx.coroutines.delay
import kotlin.random.Random

private const val SimonSeconds = 10
private val SimonColors = listOf(
    Color(0xFF22C55E),
    Color(0xFFEF4444),
    Color(0xFFEAB308),
    Color(0xFF3B82F6)
)

internal enum class SimonPhase { Idle, Showing, Input, Success, Over }
internal enum class SimonEnd { None, Wrong, TimeUp }

@Stable
internal class SimonState {
    private val sequence = ArrayList<Int>()
    private var progress = 0

    var phase by mutableStateOf(SimonPhase.Idle)
        private set
    var end by mutableStateOf(SimonEnd.None)
        private set
    var level by mutableIntStateOf(0)
        private set
    var best by mutableIntStateOf(0)
        private set
    var lit by mutableIntStateOf(-1)
        private set
    var flash by mutableIntStateOf(-1)
        private set
    var flashTick by mutableIntStateOf(0)
        private set
    var timeLeft by mutableIntStateOf(SimonSeconds)
        private set
    var token by mutableIntStateOf(0)
        private set

    fun start() {
        sequence.clear()
        level = 0
        end = SimonEnd.None
        lit = -1
        addStep()
        phase = SimonPhase.Showing
        token += 1
    }

    fun tap(index: Int) {
        if (phase != SimonPhase.Input || progress >= sequence.size) return
        flash = index
        flashTick += 1
        if (sequence[progress] != index) {
            finish(SimonEnd.Wrong)
            return
        }
        progress += 1
        if (progress == sequence.size) {
            phase = SimonPhase.Success
            token += 1
        }
    }

    fun clearFlash() {
        flash = -1
    }

    fun abort() {
        if (phase == SimonPhase.Showing || phase == SimonPhase.Input || phase == SimonPhase.Success) {
            phase = SimonPhase.Idle
            end = SimonEnd.None
            lit = -1
            token += 1
        }
    }

    suspend fun run() {
        when (phase) {
            SimonPhase.Success -> {
                delay(800)
                addStep()
                phase = SimonPhase.Showing
                play()
            }
            SimonPhase.Showing -> play()
            else -> Unit
        }
    }

    private suspend fun play() {
        delay(450)
        for (idx in sequence.toList()) {
            lit = idx
            delay(420)
            lit = -1
            delay(240)
        }
        phase = SimonPhase.Input
        timeLeft = SimonSeconds
        while (timeLeft > 0) {
            delay(1000)
            timeLeft -= 1
        }
        finish(SimonEnd.TimeUp)
    }

    private fun addStep() {
        level += 1
        progress = 0
        sequence.add(Random.nextInt(SimonColors.size))
        if (level > best) best = level
    }

    private fun finish(reason: SimonEnd) {
        end = reason
        phase = SimonPhase.Over
        lit = -1
        token += 1
    }
}

@Composable
internal fun SimonGame(state: SimonState, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    val adaptive = rememberAdaptive()

    LaunchedEffect(state.token) { state.run() }
    LaunchedEffect(state.flashTick) {
        if (state.flash >= 0) {
            delay(220)
            state.clearFlash()
        }
    }
    DisposableEffect(state) {
        onDispose { state.abort() }
    }

    val phase = state.phase
    val message = when (phase) {
        SimonPhase.Idle -> "احفظ التسلسل ثم كرره بنفس الترتيب"
        SimonPhase.Showing -> "المستوى ${state.level} - احفظ التسلسل"
        SimonPhase.Input -> "المستوى ${state.level} - دورك الآن"
        SimonPhase.Success -> "أحسنت"
        SimonPhase.Over -> if (state.end == SimonEnd.TimeUp) {
            "انتهى الوقت - وصلت إلى المستوى ${state.level}"
        } else {
            "أخطأت - وصلت إلى المستوى ${state.level}"
        }
    }
    val messageColor = when (phase) {
        SimonPhase.Over -> MaterialTheme.colorScheme.error
        SimonPhase.Success -> SuccessGreen
        else -> MaterialTheme.colorScheme.onSurface
    }
    val canStart = phase == SimonPhase.Idle || phase == SimonPhase.Over

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        val sideBySide = adaptive.landscape && maxWidth >= 560.dp
        val heightCap = (adaptive.heightDp - 230).coerceAtLeast(200).dp
        val boardWidth = if (sideBySide) {
            minOf(maxWidth * 0.46f, minOf(320.dp, heightCap))
        } else {
            minOf(maxWidth, 280.dp)
        }

        val messageBlock: @Composable () -> Unit = {
            AnimatedContent(
                targetState = message,
                transitionSpec = {
                    fadeIn(tween(MotionSpecs.DurationMedium, delayMillis = 60)) togetherWith fadeOut(tween(MotionSpecs.DurationQuick))
                },
                label = "simon_message"
            ) { text ->
                Text(
                    text = text,
                    color = messageColor,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 40.dp)
                )
            }
        }

        val startButton: @Composable () -> Unit = {
            PillButton(
                text = when {
                    phase == SimonPhase.Idle -> "ابدأ"
                    phase == SimonPhase.Over -> "إعادة المحاولة"
                    else -> "جارٍ اللعب"
                },
                onClick = { state.start() },
                enabled = canStart,
                height = 48.dp
            )
        }

        val board: @Composable () -> Unit = {
            Column(
                modifier = Modifier
                    .width(boardWidth)
                    .clip(AppShapes.Medium)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .border(1.dp, CardBorder, AppShapes.Medium)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (row in 0..1) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (col in 0..1) {
                            val index = row * 2 + col
                            SimonPad(
                                color = SimonColors[index],
                                lit = state.lit == index || state.flash == index,
                                enabled = phase == SimonPhase.Input,
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    state.tap(index)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        if (sideBySide) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                board()
                Column(
                    modifier = Modifier.weight(1f).widthIn(max = 320.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    messageBlock()
                    SimonTimer(state)
                    startButton()
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                messageBlock()
                SimonTimer(state)
                board()
                startButton()
            }
        }
    }
}

@Composable
private fun SimonTimer(state: SimonState) {
    val active = state.phase == SimonPhase.Input
    val fraction by animateFloatAsState(
        targetValue = if (active) state.timeLeft / SimonSeconds.toFloat() else 1f,
        animationSpec = tween(if (active) 900 else MotionSpecs.DurationMedium, easing = LinearEasing),
        label = "simon_timer"
    )
    Box(
        modifier = Modifier
            .widthIn(max = 280.dp)
            .fillMaxWidth()
            .height(22.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = active,
            enter = fadeIn(tween(MotionSpecs.DurationMedium)),
            exit = fadeOut(tween(MotionSpecs.DurationQuick))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .weight(1f)
                        .height(4.dp)
                        .clip(CircleShape),
                    color = if (state.timeLeft <= 3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
                )
                Text(
                    text = state.timeLeft.toString(),
                    color = if (state.timeLeft <= 3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SimonPad(
    color: Color,
    lit: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glow by animateFloatAsState(
        targetValue = if (lit) 1f else 0f,
        animationSpec = tween(if (lit) 90 else 240),
        label = "simon_pad_glow"
    )
    val source = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .graphicsLayer {
                val s = 1f + 0.04f * glow
                scaleX = s
                scaleY = s
            }
            .clip(AppShapes.Small)
            .background(color.copy(alpha = 0.40f + 0.60f * glow))
            .border(1.dp, color.copy(alpha = 0.55f + 0.45f * glow), AppShapes.Small)
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
    )
}
