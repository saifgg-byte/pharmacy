package com.saifadnan.pharmacynotes.util

import com.saifadnan.pharmacynotes.data.LectureEntity

object LectureOrder {

    private const val MAX_LECTURE_NUMBER = 1000L

    fun subjectPriorityGroup(name: String): Int {
        val firstLetter = name.trim().firstOrNull { it.isLetter() }?.lowercaseChar()
        return when (firstLetter) {
            'p' -> 0
            'o' -> 1
            'm' -> 2
            else -> 3
        }
    }

    val inFolder: Comparator<LectureEntity> = Comparator { a, b -> compareLectures(a, b) }

    val inSearchResults: Comparator<LectureEntity> = Comparator { a, b ->
        val bySubject = a.subject.compareTo(b.subject, ignoreCase = true)
        if (bySubject != 0) bySubject else compareLectures(a, b)
    }

    private fun compareLectures(a: LectureEntity, b: LectureEntity): Int {
        val bySemester = a.semester.compareTo(b.semester)
        if (bySemester != 0) return bySemester

        val numA = lectureNumber(a.title)
        val numB = lectureNumber(b.title)
        if (numA != null && numB != null) {
            if (numA != numB) return numA.compareTo(numB)
        } else if (numA != null) {
            return -1
        } else if (numB != null) {
            return 1
        } else {

            val byTime = a.uploadTimestamp.compareTo(b.uploadTimestamp)
            if (byTime != 0) return byTime
        }

        val byTitle = compareNatural(a.title, b.title)
        if (byTitle != 0) return byTitle

        val byTime = a.uploadTimestamp.compareTo(b.uploadTimestamp)
        if (byTime != 0) return byTime
        return a.id.compareTo(b.id)
    }

    fun lectureNumber(title: String): Long? {
        var i = 0
        while (i < title.length) {
            if (title[i].isDigit()) {
                var value = 0L
                var digits = 0
                while (i < title.length && title[i].isDigit()) {
                    if (digits < 18) {
                        value = value * 10 + (title[i].digitToIntOrNull() ?: 0)
                        digits++
                    }
                    i++
                }
                if (value < MAX_LECTURE_NUMBER) return value
            } else {
                i++
            }
        }
        return null
    }

    fun compareNatural(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var endA = i
                while (endA < a.length && a[endA].isDigit()) endA++
                var endB = j
                while (endB < b.length && b[endB].isDigit()) endB++
                val runA = digitsToString(a, i, endA)
                val runB = digitsToString(b, j, endB)
                val trimmedA = runA.trimStart('0')
                val trimmedB = runB.trimStart('0')

                if (trimmedA.length != trimmedB.length) return trimmedA.length.compareTo(trimmedB.length)
                val cmp = trimmedA.compareTo(trimmedB)
                if (cmp != 0) return cmp
                i = endA
                j = endB
            } else if (ca.isDigit()) {
                return -1
            } else if (cb.isDigit()) {
                return 1
            } else {
                val cmp = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (cmp != 0) return cmp
                i++
                j++
            }
        }
        return (a.length - i).compareTo(b.length - j)
    }

    private fun digitsToString(s: String, start: Int, end: Int): String {
        val sb = StringBuilder(end - start)
        for (k in start until end) {
            sb.append(s[k].digitToIntOrNull() ?: 0)
        }
        return sb.toString()
    }
}
