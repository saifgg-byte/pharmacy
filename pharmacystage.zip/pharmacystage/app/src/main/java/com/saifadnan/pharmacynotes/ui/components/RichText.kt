package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.unit.em
import com.saifadnan.pharmacynotes.util.ScriptSeg
import com.saifadnan.pharmacynotes.util.normalizeMath
import com.saifadnan.pharmacynotes.util.scriptSegments
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

private val HEADER = Regex("^\\s{0,3}(#{1,3})\\s+(.*)$")
private val ANY_INLINE = Regex("\\*\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*\\*|\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*|\\*(?!\\s)(.+?)(?<!\\s)\\*")

fun buildRichAnnotated(text: String, headerColor: Color = Color.Unspecified): AnnotatedString =
    buildAnnotatedString {
        val lines = normalizeMath(text).lines()
        lines.forEachIndexed { i, raw ->
            val h = HEADER.matchEntire(raw)
            if (h != null) {
                val level = h.groupValues[1].length
                val size = when (level) { 1 -> 20.sp; 2 -> 17.5.sp; else -> 16.sp }
                withStyle(
                    SpanStyle(fontSize = size, fontWeight = FontWeight.Bold, color = headerColor)
                ) { appendInline(h.groupValues[2], boldBase = true) }
            } else {
                appendInline(raw, boldBase = false)
            }
            if (i < lines.lastIndex) append('\n')
        }
    }

private val SubStyle = SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = 0.74.em)
private val SupStyle = SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 0.74.em)

private fun AnnotatedString.Builder.appendScripted(text: String) {
    if (text.isEmpty()) return
    for (seg in scriptSegments(text)) {
        when (seg.kind) {
            ScriptSeg.SUB -> withStyle(SubStyle) { append(seg.text) }
            ScriptSeg.SUP -> withStyle(SupStyle) { append(seg.text) }
            else -> append(seg.text)
        }
    }
}

private fun AnnotatedString.Builder.appendInline(line: String, boldBase: Boolean) {
    var last = 0
    for (m in ANY_INLINE.findAll(line)) {
        if (m.range.first > last) appendScripted(line.substring(last, m.range.first))
        val bi = m.groups[1]?.value
        val b = m.groups[2]?.value
        val ital = m.groups[3]?.value
        when {
            bi != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)) { appendScripted(bi) }
            b != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendScripted(b) }
            ital != null -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendScripted(ital) }
        }
        last = m.range.last + 1
    }
    if (last < line.length) appendScripted(line.substring(last))
}

@Composable
fun RichText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle,
    color: Color = Color.Unspecified,
    headerColor: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    selectable: Boolean = false,
    onOverflow: ((Boolean) -> Unit)? = null
) {
    val annotated = remember(text, headerColor) { buildRichAnnotated(text, headerColor) }
    val content: @Composable () -> Unit = {
        Text(
            text = annotated,
            style = style,
            color = color,
            maxLines = maxLines,
            overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis,
            onTextLayout = { r -> onOverflow?.invoke(r.hasVisualOverflow) },
            modifier = modifier
        )
    }
    if (selectable) SelectionContainer { content() } else content()
}
