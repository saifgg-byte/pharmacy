package com.saifadnan.pharmacynotes.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFF2F5FA),
    onPrimary = Color(0xFF0B1020),
    primaryContainer = Color(0x2EFFFFFF),
    onPrimaryContainer = Color(0xFFF2F5FA),
    secondary = AccentSoft,
    onSecondary = Color(0xFF0B1020),
    secondaryContainer = Color(0x338FB0FF),
    onSecondaryContainer = Color(0xFFD5E1FF),
    tertiary = Color(0xFFE0B458),
    onTertiary = Color(0xFF241800),
    tertiaryContainer = Color(0x33E0B458),
    onTertiaryContainer = Color(0xFFF5DFA6),
    background = DarkBackground,
    onBackground = Color(0xFFEEF1F8),
    surface = Color(0x14FFFFFF),
    onSurface = Color(0xFFEEF1F8),
    surfaceVariant = Color(0x1FFFFFFF),
    onSurfaceVariant = Color(0xFF9BA7BF),
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color(0xFF0A0F1F),
    surfaceContainerLow = Color(0xFF0E1428),
    surfaceContainer = Color(0xFF121A33),
    surfaceContainerHigh = Color(0xFF172040),
    surfaceContainerHighest = Color(0xFF1D284D),
    outline = Color(0xFF3A4566),
    outlineVariant = Color(0x24FFFFFF),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF370B08),
    errorContainer = Color(0x33FF8A80),
    onErrorContainer = Color(0xFFFFC9C4)
)

private val LightColorScheme = lightColorScheme(
    primary = Ink,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE5EBF0),
    onPrimaryContainer = Ink,
    secondary = Accent,
    onSecondary = Color.White,
    secondaryContainer = SkyContainer,
    onSecondaryContainer = Color(0xFF1F3F5C),
    tertiary = Amber,
    onTertiary = Color.White,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = Color(0xFF6B4A0F),
    background = LightBackground,
    onBackground = Ink,
    surface = Color(0xCCFFFFFF),
    onSurface = Ink,
    surfaceVariant = Color(0x99E6ECF1),
    onSurfaceVariant = Color(0xFF5A6673),
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF7F9FB),
    surfaceContainer = Color(0xFFF1F4F7),
    surfaceContainerHigh = Color(0xFFF7F9FB),
    surfaceContainerHighest = Color(0xFFEAEFF3),
    outline = Color(0xFFB9C4CE),
    outlineVariant = Color(0xFFCBD5DD),
    error = Color(0xFFD14343),
    onError = Color.White,
    errorContainer = Color(0xFFFBE3E1),
    onErrorContainer = Color(0xFF7A1F1B)
)

@Composable
fun MustansiriyahTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val glass = if (darkTheme) DarkGlass else LightGlass

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !darkTheme
                controller.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalGlass provides glass
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
