package com.saifadnan.pharmacynotes.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.ui.theme.glass
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    onSplashFinished: (logoBounds: Rect?) -> Unit,
    modifier: Modifier = Modifier
) {
    val logoCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val pulse = rememberInfiniteTransition(label = "splash_logo_pulse")
    val ring by pulse.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearOutSlowInEasing), RepeatMode.Restart),
        label = "splash_ring"
    )
    val entranceAlpha = remember { Animatable(0f) }
    val entranceScale = remember { Animatable(0.92f) }
    val logoScale = remember { Animatable(0.3f) }
    val logoAlpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val textOffsetY = remember { Animatable(20f) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch {
            entranceAlpha.animateTo(1f, tween(350, easing = LinearOutSlowInEasing))
        }
        launch {
            entranceScale.animateTo(1f, spring(dampingRatio = 0.75f, stiffness = 250f))
        }

        launch {
            logoAlpha.animateTo(1f, tween(350))
        }
        launch {
            logoScale.animateTo(
                targetValue = 1.0f,
                animationSpec = spring(
                    dampingRatio = 0.65f,
                    stiffness = 300f
                )
            )
        }

        delay(250)

        launch {
            textAlpha.animateTo(1f, tween(400, easing = LinearOutSlowInEasing))
        }
        launch {
            textOffsetY.animateTo(0f, tween(400, easing = LinearOutSlowInEasing))
        }

        progress.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1100, easing = FastOutSlowInEasing)
        )

        delay(120)
        val bounds = logoCoords[0]?.takeIf { it.isAttached }?.boundsInRoot()
        onSplashFinished(bounds)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = entranceAlpha.value
                scaleX = entranceScale.value
                scaleY = entranceScale.value
            }
            .testTag("app_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
        ) {
            val ringColor = MaterialTheme.colorScheme.onBackground
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .onGloballyPositioned { logoCoords[0] = it }
                    .drawBehind {
                        val t = ring
                        val a = (1f - t) * 0.16f * logoAlpha.value
                        if (a > 0.004f) {
                            drawCircle(
                                color = ringColor.copy(alpha = a),
                                radius = size.minDimension / 2f * (1f + 0.55f * t),
                                center = Offset(size.width / 2f, size.height / 2f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = logoScale.value
                            scaleY = logoScale.value
                            alpha = logoAlpha.value
                        }
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.glass.fillBottom)
                        .border(1.dp, MaterialTheme.glass.border, CircleShape)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.pharmacy_icon_1784744273743),
                        contentDescription = "App Emblem",
                        modifier = Modifier
                            .size(104.dp)
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer {
                    alpha = textAlpha.value
                    translationY = textOffsetY.value
                }
            ) {
                Text(
                    text = "ملازم الصيدلة",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "صيدلة · الجامعة المستنصرية",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.glass.headerSubtitle,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            Box(
                modifier = Modifier
                    .width(140.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.10f))
                    .graphicsLayer { alpha = textAlpha.value }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.value)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onBackground)
                )
            }
        }
    }
}