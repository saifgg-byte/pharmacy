package com.saifadnan.pharmacynotes.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.material.icons.filled.Flare
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Share
import com.saifadnan.pharmacynotes.ui.pdf.InkTool
import com.saifadnan.pharmacynotes.ui.pdf.InkToolbar
import com.saifadnan.pharmacynotes.ui.pdf.TextEditDialog
import com.saifadnan.pharmacynotes.ui.pdf.ReaderExport
import com.saifadnan.pharmacynotes.ui.pdf.ExportDialog
import com.saifadnan.pharmacynotes.ui.pdf.ExportProgressDialog
import com.saifadnan.pharmacynotes.ui.pdf.ExportDoneDialog
import com.saifadnan.pharmacynotes.ui.pdf.ExportResult
import kotlinx.coroutines.Job
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.LineHeightStyle
import com.saifadnan.pharmacynotes.data.LectureEntity
import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.PdfViewerSkeleton
import com.saifadnan.pharmacynotes.ui.game.DownloadLoadingState
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick
import com.saifadnan.pharmacynotes.ui.pdf.PageScrubber
import com.saifadnan.pharmacynotes.ui.components.AI_PREFILL
import com.saifadnan.pharmacynotes.ui.components.AiInitial
import com.saifadnan.pharmacynotes.ui.components.SlideAiSheet
import com.saifadnan.pharmacynotes.ui.components.YoutubeVideosSheet
import com.saifadnan.pharmacynotes.ui.components.SlideAiState
import androidx.compose.material.icons.filled.AutoAwesome
import com.saifadnan.pharmacynotes.ui.pdf.PdfReader
import com.saifadnan.pharmacynotes.ui.pdf.PdfSession
import com.saifadnan.pharmacynotes.ui.pdf.ReaderZoomState
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.Spacing
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.PillButton
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.ui.components.GlassSortChip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Bookmarks
import com.saifadnan.pharmacynotes.ui.pdf.SelectionActionBar
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.saifadnan.pharmacynotes.ui.pdf.LectureSearchDialog
import com.saifadnan.pharmacynotes.ui.pdf.MarkedItem
import com.saifadnan.pharmacynotes.ui.pdf.MarkedPagesDialog
import com.saifadnan.pharmacynotes.ui.pdf.PageNoteDialog
import com.saifadnan.pharmacynotes.ui.pdf.ReaderAnnotations
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import com.saifadnan.pharmacynotes.ui.pdf.ReaderTheme
import com.saifadnan.pharmacynotes.util.ReaderPrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.TextButton
import android.content.res.Configuration
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.draw.clipToBounds
import com.saifadnan.pharmacynotes.ui.components.SlideAiSidePanel
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import androidx.compose.ui.text.style.TextOverflow
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.YoutubeRed
import com.saifadnan.pharmacynotes.util.YoutubeLinks
import com.saifadnan.pharmacynotes.util.PdfHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.File
import kotlin.math.roundToInt

private val BookmarkYellow = Color(0xFFF5B83D)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LectureDetailScreen(
    lecture: LectureEntity,
    onBack: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleDownload: (LectureEntity) -> Unit,
    onAvailableOffline: (LectureEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfFile by remember { mutableStateOf<File?>(null) }
    var session by remember { mutableStateOf<PdfSession?>(null) }
    var totalPages by remember { mutableIntStateOf(lecture.pageCount) }
    var isLoadingPdf by remember { mutableStateOf(true) }
    var statusText by remember { mutableStateOf("جاري فتح ملف المحاضرة...") }
    var loadError by remember { mutableStateOf<String?>(null) }
    var controlsVisible by remember { mutableStateOf(true) }

    var rotated by remember { mutableStateOf(false) }
    val rotateFade = remember { Animatable(1f) }

    val pagerState = rememberPagerState(pageCount = { totalPages.coerceAtLeast(1) })
    val zoom = remember { ReaderZoomState() }

    val isWorksheet = lecture.id < 0
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    DisposableEffect(context) {
        var host: Context = context
        while (host is ContextWrapper && host !is Activity) host = host.baseContext
        val window = (host as? Activity)?.window
        val previous = window?.attributes?.softInputMode
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        onDispose {
            if (window != null && previous != null) window.setSoftInputMode(previous)
        }
    }

    val docKey = remember(lecture.id, lecture.worksheetUrl) { ReaderPrefs.keyFor(lecture) }
    var theme by remember { mutableIntStateOf(ReaderPrefs.getTheme(context)) }
    var markedPage by remember(docKey) { mutableIntStateOf(ReaderPrefs.getMark(context, docKey)) }
    val annotations = remember(docKey) { ReaderAnnotations(context, docKey, lecture.id, lecture.fileUrl.substringAfterLast('/')) }
    val clipboard = LocalClipboardManager.current
    var aiInitial by remember { mutableStateOf<AiInitial?>(null) }
    var showNote by remember { mutableStateOf(false) }
    var showMarked by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    val aiState = remember(docKey) { SlideAiState() }
    var showExport by remember { mutableStateOf(false) }
    var exportJob by remember { mutableStateOf<Job?>(null) }
    var exportProgress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var exportResult by remember { mutableStateOf<ExportResult?>(null) }

    val config = LocalConfiguration.current
    val tabletDrawingLayout = config.smallestScreenWidthDp >= 600
    var inkPanelPx by remember { mutableIntStateOf(0) }
    var inkToolbarPx by remember { mutableIntStateOf(0) }
    var inkPad by remember { mutableStateOf(0.dp) }
    var inkTopPad by remember { mutableStateOf(0.dp) }
    val inkOpen = annotations.drawMode && !isLoadingPdf && session != null
    val inkDensity = LocalDensity.current
    LaunchedEffect(inkOpen, inkPanelPx, inkToolbarPx, tabletDrawingLayout, controlsVisible) {
        if (!inkOpen) {
            inkPad = 0.dp
            inkTopPad = 0.dp
        } else {
            delay(260)
            val measuredHeight = if (tabletDrawingLayout) inkToolbarPx else inkPanelPx
            val panelHeight = with(inkDensity) { measuredHeight.toDp() }
            if (tabletDrawingLayout) {
                inkPad = 0.dp
                inkTopPad = panelHeight + if (controlsVisible) 0.dp else 32.dp
            } else {
                inkPad = panelHeight
                inkTopPad = 0.dp
            }
        }
    }
    val inkPadAnim by animateDpAsState(inkPad, tween(320, easing = MotionSpecs.EmphasizedEasing), label = "ink_pad")
    val inkTopPadAnim by animateDpAsState(inkTopPad, tween(320, easing = MotionSpecs.EmphasizedEasing), label = "ink_top_pad")
    val inkPadAnimating = inkPadAnim != inkPad || inkTopPadAnim != inkTopPad

    val splitCapable = config.smallestScreenWidthDp >= 600 &&
        config.orientation == Configuration.ORIENTATION_LANDSCAPE &&
        config.screenWidthDp >= 720
    val panelWidth = (config.screenWidthDp * 0.38f).coerceIn(380f, 520f).dp
    val panelOpen = showAi && splitCapable && session != null
    val panelProgress = remember { Animatable(if (panelOpen) 1f else 0f) }
    val panelVisible by remember { derivedStateOf { panelProgress.value > 0.001f } }
    val panelAnimating = panelProgress.isRunning
    val appDirection = LocalLayoutDirection.current

    LaunchedEffect(panelOpen) {
        val target = if (panelOpen) 1f else 0f
        if (panelProgress.value != target) {
            zoom.reset()
            panelProgress.animateTo(
                target,
                tween(if (panelOpen) 460 else 340, easing = MotionSpecs.EmphasizedEasing)
            )
        }
    }

    BackHandler(enabled = true) {
        if (showAi) showAi = false else if (annotations.drawMode) annotations.closeTools() else onBack()
    }

    fun jumpToPage(target: Int) {
        val dest = target.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
        if (dest == pagerState.currentPage) return
        coroutineScope.launch { pagerState.scrollToPage(dest) }
    }

    val currentPage by remember { derivedStateOf { pagerState.currentPage + 1 } }
    val zoomPercent by remember { derivedStateOf { ((zoom.scale * 100f) / 5f).roundToInt() * 5 } }

    fun toggleRotate() {
        if (rotateFade.isRunning) return
        coroutineScope.launch {
            rotateFade.animateTo(0f, tween(110))
            zoom.reset()
            rotated = !rotated
            rotateFade.animateTo(1f, tween(260))
        }
    }

    fun toggleMark() {
        val idx = pagerState.currentPage
        markedPage = if (markedPage == idx) -1 else idx
        ReaderPrefs.setMark(context, docKey, markedPage)
    }

    fun applyTheme(value: Int) {
        theme = value
        ReaderPrefs.setTheme(context, value)
    }

    suspend fun openPdf() {
        isLoadingPdf = true
        loadError = null
        try {
            var opened: PdfSession? = null
            var attempt = 0
            while (opened == null) {
                val file = try {
                    if (isWorksheet) {
                        PdfHelper.getWorksheetFile(context, lecture) { msg -> statusText = msg }
                    } else {
                        PdfHelper.getOrDownloadPdfFile(context, lecture) { msg -> statusText = msg }
                    }
                } catch (e: PdfHelper.LectureFileException) {
                    if (!PdfHelper.isConnectionIssue(context, e)) throw e
                    statusText = "بانتظار الاتصال بالسيرفر..."
                    PdfHelper.awaitConnection(context)
                    continue
                }
                pdfFile = file
                if (!isWorksheet) onAvailableOffline(lecture)
                try {
                    opened = withContext(Dispatchers.IO) { PdfSession.open(file) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: SecurityException) {
                    throw PdfHelper.LectureFileException("الملف محمي بكلمة مرور ولا يمكن عرضه داخل التطبيق.")
                } catch (e: Exception) {
                    if (attempt >= 1) {
                        throw PdfHelper.LectureFileException("الملف تالف أو غير صالح للعرض. جرّب إعادة التحميل أو فتحه بقارئ خارجي.")
                    }
                    attempt++
                    statusText = "إصلاح الملف وإعادة تحميله..."
                    withContext(Dispatchers.IO) {
                        if (isWorksheet) PdfHelper.deleteWorksheetCopy(context, lecture)
                        else PdfHelper.deleteOfflineCopy(context, lecture.id)
                    }
                }
            }
            val ready = checkNotNull(opened)
            session?.closeAsync()
            session = ready
            totalPages = ready.pageCount
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            e.printStackTrace()
            loadError = (e as? PdfHelper.LectureFileException)?.message ?: "تعذر فتح ملف المحاضرة"
        } finally {
            isLoadingPdf = false
        }
    }

    LaunchedEffect(lecture.id, lecture.fileUrl, lecture.worksheetUrl) {
        statusText = "جاري تهيئة عارض الملفات..."
        openPdf()
    }

    DisposableEffect(Unit) {
        onDispose { session?.closeAsync() }
    }

    LaunchedEffect(session) {
        val ready = session ?: return@LaunchedEffect
        val saved = ReaderPrefs.getLastPage(context, docKey)
        if (saved in 1 until ready.pageCount) {
            pagerState.scrollToPage(saved)
            Toast.makeText(context, "تكملة من الصفحة ${saved + 1}", Toast.LENGTH_SHORT).show()
        }
        snapshotFlow { pagerState.settledPage }.collectLatest { page ->
            delay(400)
            ReaderPrefs.setLastPage(context, docKey, page)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Row(modifier = modifier.fillMaxSize()) {
    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
    CompositionLocalProvider(LocalLayoutDirection provides appDirection) {
    Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {

        AnimatedVisibility(
            visible = controlsVisible,
            enter = slideInVertically(initialOffsetY = { -it }, animationSpec = tween(280)) + fadeIn(animationSpec = tween(280)),
            exit = slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(220)) + fadeOut(animationSpec = tween(220))
        ) {
            Box(
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                GlassCard(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ReaderIconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("pdf_reader_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
                            Text(
                                text = lecture.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${lecture.subject} · ${lecture.doctorName.ifBlank { "كلية الصيدلة" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (session != null && !isLoadingPdf) {
                            ReaderIconButton(
                                onClick = { showAi = if (splitCapable) !showAi else true },
                                modifier = Modifier.testTag("pdf_reader_ai_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "مساعد الفارما",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                        }

                        Box {
                            ReaderIconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.testTag("pdf_reader_more_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "المزيد",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false },
                                shape = RoundedCornerShape(20.dp),
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                tonalElevation = 0.dp,
                                shadowElevation = 14.dp,
                                border = BorderStroke(1.dp, CardBorder)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .widthIn(min = 250.dp)
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = "وضع القراءة",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                        GlassSortChip(
                                            text = readerThemeLabel(theme),
                                            onClick = { applyTheme((theme + 1) % 3) },
                                            icon = Icons.Default.Palette,
                                            modifier = Modifier.testTag("pdf_reader_theme_chip")
                                        )
                                    }
                                    HorizontalDivider(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = CardBorder
                                    )
                                    val currentIsMarked = markedPage == currentPage - 1
                                    ReaderMenuItem(
                                        icon = if (currentIsMarked) Icons.Default.Star else Icons.Default.StarBorder,
                                        tint = Amber,
                                        label = when {
                                            currentIsMarked -> "إزالة تعليم الصفحة"
                                            markedPage >= 0 -> "نقل التعليم لهذه الصفحة"
                                            else -> "تعليم هذه الصفحة"
                                        },
                                        onClick = {
                                            showMenu = false
                                            toggleMark()
                                        }
                                    )
                                    if (markedPage >= 0 && !currentIsMarked) {
                                        ReaderMenuItem(
                                            icon = Icons.Default.Bookmark,
                                            tint = Amber,
                                            label = "الانتقال للصفحة المعلّمة (${markedPage + 1})",
                                            onClick = {
                                                showMenu = false
                                                jumpToPage(markedPage)
                                            }
                                        )
                                    }
                                    HorizontalDivider(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = CardBorder
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.Brush,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = if (annotations.drawMode) "إنهاء أدوات الرسم" else "ادوات الرسم",
                                        onClick = {
                                            showMenu = false
                                            if (annotations.drawMode) annotations.closeTools()
                                            else {
                                                annotations.openTools(annotations.tool)
                                                controlsVisible = false
                                            }
                                        }
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.Flare,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = "قلم الليزر",
                                        onClick = {
                                            showMenu = false
                                            annotations.openTools(InkTool.LASER)
                                            annotations.selectTool(InkTool.LASER)
                                            controlsVisible = false
                                        }
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.TextFields,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = "إضافة نص على السلايد",
                                        onClick = {
                                            showMenu = false
                                            annotations.openTools(InkTool.TEXT)
                                            annotations.selectTool(InkTool.TEXT)
                                            controlsVisible = false
                                        }
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.EditNote,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = if (annotations.notes.containsKey(currentPage - 1)) "ملاحظتي على هذه الصفحة" else "إضافة ملاحظة للصفحة",
                                        onClick = {
                                            showMenu = false
                                            showNote = true
                                        }
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.Bookmarks,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = "الصفحات المميّزة",
                                        onClick = {
                                            showMenu = false
                                            showMarked = true
                                        }
                                    )
                                    if (lecture.id > 0) {
                                        ReaderMenuItem(
                                            icon = Icons.Default.Search,
                                            tint = MaterialTheme.colorScheme.primary,
                                            label = "بحث في المحاضرة",
                                            onClick = {
                                                showMenu = false
                                                showSearch = true
                                            }
                                        )
                                    }
                                    HorizontalDivider(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = CardBorder
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.Share,
                                        tint = MaterialTheme.colorScheme.primary,
                                        label = "تصدير نسخة",
                                        onClick = {
                                            showMenu = false
                                            if (session != null) showExport = true
                                            else Toast.makeText(context, "انتظر حتى تُفتح المحاضرة", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                    ReaderMenuItem(
                                        icon = Icons.Default.OpenInNew,
                                        label = "فتح بقارئ خارجي",
                                        onClick = {
                                            showMenu = false
                                            pdfFile?.let { file ->
                                                PdfHelper.openPdfInExternalApp(context, file)
                                            } ?: run {
                                                Toast.makeText(context, "جاري تحضير الملف...", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        if (lecture.youtubeUrl.isNotBlank()) {
                            val ytVideos = remember(lecture.youtubeUrl) { YoutubeLinks.parse(lecture.youtubeUrl) }
                            var showYoutubeSheet by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.size(40.dp)) {
                                ReaderIconButton(
                                    onClick = {
                                        if (ytVideos.size > 1) showYoutubeSheet = true
                                        else YoutubeLinks.open(context, lecture.youtubeUrl)
                                    },
                                    modifier = Modifier.testTag("pdf_reader_youtube_button")
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_youtube),
                                        contentDescription = "شرح على يوتيوب",
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                if (ytVideos.size > 1) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .height(17.dp)
                                            .widthIn(min = 17.dp)
                                            .clip(CircleShape)
                                            .background(YoutubeRed)
                                            .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                            .padding(horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${ytVideos.size}",
                                            style = TextStyle(
                                                fontSize = 9.sp,
                                                lineHeight = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                textAlign = TextAlign.Center,
                                                platformStyle = PlatformTextStyle(includeFontPadding = false),
                                                lineHeightStyle = LineHeightStyle(
                                                    alignment = LineHeightStyle.Alignment.Center,
                                                    trim = LineHeightStyle.Trim.Both
                                                )
                                            ),
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                            if (showYoutubeSheet) {
                                YoutubeVideosSheet(
                                    videos = ytVideos,
                                    onDismiss = { showYoutubeSheet = false }
                                )
                            }
                        }

                        if (!isWorksheet) {
                            val bookmarked = lecture.isBookmarked
                            val bookmarkTint by animateColorAsState(
                                targetValue = if (bookmarked) BookmarkYellow else MaterialTheme.colorScheme.onSurface,
                                animationSpec = tween(320),
                                label = "bookmark_tint"
                            )
                            val bookmarkPop = remember { Animatable(1f) }
                            var bookmarkSeen by remember { mutableStateOf(false) }
                            LaunchedEffect(bookmarked) {
                                if (bookmarkSeen && bookmarked) {
                                    bookmarkPop.snapTo(0.72f)
                                    bookmarkPop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 380f))
                                }
                                bookmarkSeen = true
                            }
                            ReaderIconButton(onClick = onToggleBookmark) {
                                Crossfade(
                                    targetState = bookmarked,
                                    animationSpec = tween(220),
                                    label = "bookmark_icon"
                                ) { on ->
                                    Icon(
                                        imageVector = if (on) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "حفظ في المفضلة",
                                        tint = bookmarkTint,
                                        modifier = Modifier
                                            .size(21.dp)
                                            .graphicsLayer {
                                                scaleX = bookmarkPop.value
                                                scaleY = bookmarkPop.value
                                            }
                                    )
                                }
                            }
                        }

                        ReaderIconButton(
                            onClick = { onToggleDownload(lecture) },
                            modifier = Modifier.testTag("pdf_reader_download_button")
                        ) {
                            Icon(
                                imageVector = if (lecture.isDownloaded) Icons.Default.CheckCircle else Icons.Default.Download,
                                contentDescription = if (lecture.isDownloaded) "محملة" else "تنزيل",
                                tint = if (lecture.isDownloaded) SuccessGreen else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                    if (!isLoadingPdf && totalPages > 0) {
                        LinearProgressIndicator(
                            progress = { (currentPage.toFloat() / totalPages.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 6.dp)
                                .height(2.dp),
                            color = MaterialTheme.colorScheme.onSurface,
                            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .clip(AppShapes.Card)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                .border(1.dp, CardBorder, AppShapes.Card),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = isLoadingPdf, label = "pdf_content_state", animationSpec = tween(220)) { loading ->
                val readySession = session
                if (loading) {
                    DownloadLoadingState(statusText = statusText)
                } else if (readySession != null && totalPages > 0) {
                    PdfReader(
                        session = readySession,
                        pagerState = pagerState,
                        zoom = zoom,
                        rotated = rotated,
                        annotations = annotations,
                        onTap = {
                            if (annotations.drawMode) Unit
                            else if (annotations.hasSelection) annotations.clearSelection()
                            else controlsVisible = !controlsVisible
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = inkPadAnim)
                            .graphicsLayer { alpha = rotateFade.value },
                        theme = theme,
                        freezeRender = panelAnimating || inkPadAnimating
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = loadError ?: "اضغط لتحميل المحاضرة وقراءتها",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        PillButton(
                            text = "تحميل المحاضرة",
                            icon = Icons.Default.Download,
                            height = 46.dp,
                            onClick = {
                                coroutineScope.launch {
                                    statusText = "جاري الاتصال بالسيرفر وتنزيل المحاضرة..."
                                    openPdf()
                                    loadError?.let {
                                        Toast.makeText(context, "خطأ في التنزيل: $it", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        )
                        pdfFile?.let { file ->
                            TextButton(onClick = { PdfHelper.openPdfInExternalApp(context, file) }) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح بقارئ خارجي", color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = controlsVisible,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(280)) + fadeIn(animationSpec = tween(280)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(220)) + fadeOut(animationSpec = tween(220))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!isLoadingPdf) {
                    PageScrubber(
                        currentPage = currentPage,
                        totalPages = totalPages,
                        onJump = { jumpToPage(it) }
                    )
                }
                GlassCard(shape = CircleShape) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    pagerState.animateScrollToPage((currentPage - 2).coerceAtLeast(0))
                                }
                            },
                            enabled = currentPage > 1,
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("pdf_prev_page_button")
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "الصفحة السابقة", modifier = Modifier.size(22.dp))
                        }

                        Row(
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("pdf_page_counter"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (markedPage == currentPage - 1) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "صفحة معلّمة",
                                    tint = Amber,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            if (annotations.notes.containsKey(currentPage - 1)) {
                                Icon(
                                    imageVector = Icons.Default.EditNote,
                                    contentDescription = "عليها ملاحظة",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "$currentPage / $totalPages",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    pagerState.animateScrollToPage(currentPage.coerceAtMost(totalPages - 1))
                                }
                            },
                            enabled = currentPage < totalPages,
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("pdf_next_page_button")
                        ) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "الصفحة التالية", modifier = Modifier.size(22.dp))
                        }

                        Box(
                            modifier = Modifier
                                .padding(horizontal = 6.dp)
                                .size(1.dp, 20.dp)
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
                        )

                        IconButton(
                            onClick = { zoom.zoomStep(coroutineScope, -0.5f) },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "تصغير", modifier = Modifier.size(20.dp))
                        }
                        Text(
                            text = "$zoomPercent%",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        IconButton(
                            onClick = { zoom.zoomStep(coroutineScope, 0.5f) },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "تكبير", modifier = Modifier.size(20.dp))
                        }

                        Box(
                            modifier = Modifier
                                .padding(horizontal = 6.dp)
                                .size(1.dp, 20.dp)
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
                        )

                        IconButton(
                            onClick = { toggleRotate() },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("pdf_rotate_button")
                        ) {
                            Icon(
                                Icons.Default.RotateRight,
                                contentDescription = "تدوير العرض",
                                tint = if (rotated) MaterialTheme.colorScheme.secondary else LocalContentColor.current,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(pagerState.settledPage) {
        annotations.clearSelection()
        annotations.onPageChanged()
    }

    if (annotations.hasSelection && !annotations.drawMode) {
        SelectionActionBar(
            onCopy = {
                clipboard.setText(AnnotatedString(annotations.selectedText()))
                Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show()
                annotations.clearSelection()
            },
            onHighlight = {
                annotations.highlightSelection()
                annotations.clearSelection()
            },
            showRemoveHighlight = annotations.selectionHasHighlight(),
            onRemoveHighlight = {
                if (annotations.removeHighlightInSelection()) {
                    Toast.makeText(context, "تمت إزالة التظليل", Toast.LENGTH_SHORT).show()
                }
                annotations.clearSelection()
            },
            onAsk = {
                val t = annotations.selectedText()
                if (t.isNotBlank()) {
                    aiInitial = AiInitial(AI_PREFILL, "اشرح: " + t.take(900), "")
                    annotations.clearSelection()
                    showAi = true
                }
            },
            onTranslate = {
                val t = annotations.selectedText()
                if (t.isNotBlank()) {
                    aiInitial = AiInitial("sel_translate", t.take(700), "ترجمة: " + t.take(700))
                    annotations.clearSelection()
                    showAi = true
                }
            },
            onClose = { annotations.clearSelection() },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (controlsVisible) 150.dp else 18.dp)
        )
    }

    Box(
        modifier = Modifier
            .align(if (tabletDrawingLayout) Alignment.TopCenter else Alignment.BottomCenter)
            .onSizeChanged { inkPanelPx = it.height }
            .then(
                if (tabletDrawingLayout) {
                    Modifier.statusBarsPadding().padding(top = if (controlsVisible) 78.dp else 8.dp)
                } else {
                    Modifier.navigationBarsPadding().padding(bottom = 10.dp)
                }
            )
    ) {
        InkPanelSlide(
            visible = annotations.drawMode && !isLoadingPdf && session != null,
            fromTop = tabletDrawingLayout
        ) {
            InkToolbar(
                annotations = annotations,
                page = pagerState.currentPage,
                pageLabel = "$currentPage/$totalPages",
                onPrev = {
                    val t = pagerState.currentPage - 1
                    if (t >= 0) coroutineScope.launch { pagerState.animateScrollToPage(t) }
                },
                onNext = {
                    val t = pagerState.currentPage + 1
                    if (t < totalPages) coroutineScope.launch { pagerState.animateScrollToPage(t) }
                },
                onDone = { annotations.closeTools() },
                aiOpen = showAi,
                onAi = { showAi = if (splitCapable) !showAi else true },
                modifier = Modifier.onSizeChanged { inkToolbarPx = it.height }
            )
        }
    }

    annotations.textRequest?.let { req ->
        TextEditDialog(
            request = req,
            look = annotations.textLook,
            onSubmit = { annotations.submitText(it) },
            onDismiss = { annotations.cancelTextRequest() }
        )
    }

    if (showExport && session != null) {
        val exportSession = session!!
        ExportDialog(
            currentPage = pagerState.currentPage,
            totalPages = totalPages,
            annotatedCount = annotations.annotatedPages().size,
            onDismiss = { showExport = false },
            onStart = { scope, quality ->
                showExport = false
                val pages = ReaderExport.pagesFor(scope, pagerState.currentPage, totalPages, annotations)
                if (pages.isEmpty()) {
                    Toast.makeText(context, "لا توجد صفحات للتصدير", Toast.LENGTH_SHORT).show()
                } else {
                    exportProgress = 0 to pages.size
                    exportJob = coroutineScope.launch {
                        try {
                            exportResult = ReaderExport.export(
                                context, exportSession, annotations, pages, quality, lecture.title
                            ) { d, t -> exportProgress = d to t }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "تعذر تصدير النسخة: ${e.message ?: ""}", Toast.LENGTH_LONG).show()
                        } finally {
                            exportProgress = null
                            exportJob = null
                        }
                    }
                }
            }
        )
    }

    exportProgress?.let { (d, t) ->
        ExportProgressDialog(done = d, total = t, onCancel = { exportJob?.cancel() })
    }

    exportResult?.let { res ->
        ExportDoneDialog(
            result = res,
            onOpen = { res.uri?.let { ReaderExport.open(context, it) } },
            onShare = { res.uri?.let { ReaderExport.share(context, it) } },
            onDismiss = { exportResult = null }
        )
    }

    if (showNote) {
        val notePage = pagerState.currentPage
        PageNoteDialog(
            pageNumber = notePage + 1,
            initial = annotations.notes[notePage].orEmpty(),
            onSave = {
                annotations.setNote(notePage, it)
                showNote = false
            },
            onDismiss = { showNote = false }
        )
    }

    if (showMarked) {
        val marked = annotations.markedPages()
        val items = (marked + listOfNotNull(markedPage.takeIf { it >= 0 })).distinct().sorted().map { p ->
            MarkedItem(
                page = p,
                starred = p == markedPage,
                hasHighlight = annotations.strokes.containsKey(p) || annotations.texts.any { it.page == p },
                note = annotations.notes[p]
            )
        }
        MarkedPagesDialog(
            items = items,
            onJump = { p ->
                showMarked = false
                jumpToPage(p)
            },
            onDismiss = { showMarked = false }
        )
    }

    if (showSearch) {
        LectureSearchDialog(
            lectureId = lecture.id,
            onJump = { p ->
                showSearch = false
                jumpToPage(p)
            },
            onDismiss = { showSearch = false }
        )
    }

    val aiSession = session
    if (showAi && aiSession != null && !splitCapable) {
        SlideAiSheet(
            state = aiState,
            session = aiSession,
            pageIndex = pagerState.currentPage,
            subject = lecture.subject,
            title = lecture.title,
            fileUrl = if (isWorksheet) lecture.worksheetUrl else lecture.fileUrl,
            initial = aiInitial,
            onInitialConsumed = { aiInitial = null },
            onDismiss = {
                showAi = false
                aiInitial = null
            }
        )
    }
    }
    }
    }

    val panelSession = session
    if (panelSession != null && (panelOpen || panelVisible)) {
        val panelWidthPx = with(LocalDensity.current) { panelWidth.roundToPx() }
        Box(
            modifier = Modifier
                .layout { measurable, constraints ->
                    val w = (panelWidthPx * panelProgress.value).roundToInt()
                    val placeable = measurable.measure(Constraints.fixed(w, constraints.maxHeight))
                    layout(w, constraints.maxHeight) { placeable.place(0, 0) }
                }
                .clipToBounds()
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides appDirection) {
                SlideAiSidePanel(
                    state = aiState,
                    session = panelSession,
                    pageIndex = pagerState.currentPage,
                    subject = lecture.subject,
                    title = lecture.title,
                    fileUrl = if (isWorksheet) lecture.worksheetUrl else lecture.fileUrl,
                    initial = aiInitial,
                    onInitialConsumed = { aiInitial = null },
                    onDismiss = {
                        showAi = false
                        aiInitial = null
                    },
                    modifier = Modifier
                        .requiredWidth(panelWidth)
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .padding(top = 8.dp, bottom = 4.dp, end = 12.dp)
                        .graphicsLayer {
                            val p = panelProgress.value
                            translationX = (1f - p) * size.width * 0.18f
                            alpha = (p * 1.4f).coerceIn(0f, 1f)
                        }
                )
            }
        }
    }
    }
    }
}

private fun readerThemeLabel(theme: Int): String = when (theme) {
    ReaderTheme.NIGHT -> "ليلي"
    ReaderTheme.SEPIA -> "دافئ"
    else -> "عادي"
}

@Composable
private fun ReaderMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ReaderIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .size(40.dp)
            .iconInteractiveClick(behavior = IconClickBehavior.SPRING_BOUNCE, scaleDown = 0.88f, onClick = onClick)
            .clip(CircleShape),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun InkPanelSlide(
    visible: Boolean,
    fromTop: Boolean = false,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            initialOffsetY = { if (fromTop) -it else it },
            animationSpec = tween(320, easing = MotionSpecs.EmphasizedEasing)
        ) + fadeIn(tween(240)),
        exit = slideOutVertically(
            targetOffsetY = { if (fromTop) -it else it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180))
    ) {
        content()
    }
}