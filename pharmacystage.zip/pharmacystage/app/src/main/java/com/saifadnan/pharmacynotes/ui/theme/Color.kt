package com.saifadnan.pharmacynotes.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0E1116)
val Accent = Color(0xFF4A7BA6)
val AccentSoft = Color(0xFF8FB0FF)

val SkyContainer = Color(0xFFDCE8F1)

val Amber = Color(0xFFB9852B)
val GoldAccent = Color(0xFFD9A566)
val AmberContainer = Color(0xFFF6EBD3)

val SuccessGreen = Color(0xFF2F9E6E)

val LightBackground = Color(0xFFEEF2F5)
val DarkBackground = Color(0xFF070A15)

val LightGradient = listOf(
    0.00f to Color(0xFF7FA6BE),
    0.30f to Color(0xFFB4CBD9),
    0.60f to Color(0xFFE3EAF0),
    1.00f to Color(0xFFF3F5F8)
)
val DarkGradient = listOf(
    0.00f to Color(0xFF070A15),
    0.30f to Color(0xFF0B1337),
    0.49f to Color(0xFF142158),
    0.62f to Color(0xFF1A2B6E),
    0.78f to Color(0xFF14204F),
    1.00f to Color(0xFF0B1024)
)

val CardBorder: Color
    @Composable
    get() = MaterialTheme.glass.border

private val TelegramLight = Color(0xFF229ED9)
private val TelegramDark = Color(0xFF7DD3FC)

val TelegramAccent: Color
    @Composable get() = if (isSystemInDarkTheme()) TelegramDark else TelegramLight

val YoutubeRed = Color(0xFFE23B3B)
