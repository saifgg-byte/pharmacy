package com.saifadnan.pharmacynotes.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.saifadnan.pharmacynotes.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action !in RESCHEDULE_ACTIONS) return
        if (!ClassReminderSettings.isEnabled(context)) return

        val appContext = context.applicationContext
        val pendingResult = goAsync()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val db = AppDatabase.getDatabase(appContext, scope)
                val session = SessionManager(appContext)
                val group = session.getSavedGroupName()
                if (!group.isNullOrBlank()) {
                    val entries = db.scheduleDao().getScheduleForGroup(group).first()
                    ClassAlarmScheduler.scheduleAll(appContext, entries)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pendingResult.finish()
            }
        }
    }

    private companion object {
        val RESCHEDULE_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"
        )
    }
}
