package com.saifadnan.pharmacynotes.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.unit.dp

object MotionSpecs {
    const val DurationQuick = 150
    const val DurationMedium = 300
    const val DurationLong = 450

    const val ScreenIn = 260
    const val ScreenOut = 120
    const val ScreenInDelay = 40

    val EmphasizedEasing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val LogoTravelEasing = CubicBezierEasing(0.22f, 1.0f, 0.36f, 1.0f)
    val StandardEasing = FastOutSlowInEasing
    val BounceEasing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1.0f)

    val IconSpring = spring<Float>(
        dampingRatio = 0.55f,
        stiffness = Spring.StiffnessMedium * 1.5f
    )

    val SoftSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessMediumLow
    )

    val CardBounceSpring = spring<Float>(
        dampingRatio = 0.62f,
        stiffness = Spring.StiffnessMediumLow * 1.6f
    )

    val BouncyPopSpring = spring<Float>(
        dampingRatio = 0.55f,
        stiffness = Spring.StiffnessMediumLow
    )

    val PaddingXs = 4.dp
    val PaddingSm = 8.dp
    val PaddingMd = 12.dp
    val PaddingLg = 16.dp
    val PaddingXl = 24.dp
}