package com.saifadnan.pharmacynotes.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exam_schedule")
data class ExamEntity(
    @PrimaryKey
    val id: String,
    val subject: String,
    val examDate: String,
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val durationMin: Int = 60,
    val examType: String = ExamTypes.FINAL,
    val groupName: String = "",
    val hall: String = "",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

object ExamTypes {
    const val FINAL = "FINAL"
    const val MIDTERM = "MIDTERM"
    const val PRACTICAL = "PRACTICAL"
    const val QUIZ = "QUIZ"
    val ALL = listOf(FINAL, MIDTERM, PRACTICAL, QUIZ)
    fun label(t: String) = when (t) {
        FINAL -> "نهائي"
        MIDTERM -> "فصلي"
        PRACTICAL -> "عملي"
        QUIZ -> "كوز"
        else -> t
    }
}
