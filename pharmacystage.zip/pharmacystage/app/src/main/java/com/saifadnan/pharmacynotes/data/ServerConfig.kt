package com.saifadnan.pharmacynotes.data

object ServerConfig {
    // ضع رابط السيرفر حقك هنا (لازم https وبدون "/" بالنهاية)
    const val BASE_URL = "https://YOUR-SERVER-URL"
}
