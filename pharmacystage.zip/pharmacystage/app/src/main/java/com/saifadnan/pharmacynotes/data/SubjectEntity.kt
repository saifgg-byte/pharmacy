package com.saifadnan.pharmacynotes.data

import androidx.room.Entity

@Entity(tableName = "subjects", primaryKeys = ["name", "section", "semester"])
data class SubjectEntity(
    val name: String,
    val section: String = Section.THEORY,
    val semester: Int = 1,
    val isExamPinned: Boolean = false,
    val addedAt: Long = 0L,
    val icon: String = ""
)
