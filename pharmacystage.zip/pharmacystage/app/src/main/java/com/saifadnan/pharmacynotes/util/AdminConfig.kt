package com.saifadnan.pharmacynotes.util

object AdminConfig {
    const val ADMIN_EMAIL = "saifgames.2006.2020@gmail.com"

    fun isAdminEmail(email: String?): Boolean =
        email != null && email.trim().equals(ADMIN_EMAIL, ignoreCase = true)

    fun isMainAdmin(email: String?): Boolean = isAdminEmail(email)

    fun isAdminRole(role: String?): Boolean = role.equals("ADMIN", ignoreCase = true)

    fun looksLikeEmail(input: String): Boolean {
        val s = input.trim()
        return s.isNotEmpty() && !s.contains(' ') && s.contains('@') && s.substringAfter('@').contains('.')
    }
}
