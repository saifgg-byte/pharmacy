package com.saifadnan.pharmacynotes.ui.game

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.components.PdfViewerSkeleton
import com.saifadnan.pharmacynotes.ui.components.bounceClick
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.SuccessGreen
import com.saifadnan.pharmacynotes.ui.theme.rememberAdaptive
import com.saifadnan.pharmacynotes.util.ReaderPrefs
import kotlinx.coroutines.delay

private val PercentRegex = Regex("""\((\d{1,3})%\)""")
private const val GameStartDelayMs = 1100L
private val OptionLetters = listOf("A", "B", "C", "D")
private val GameTabTitles = listOf("أسئلة صيدلة", "تذكّر التسلسل")

private enum class OptionState { Idle, Correct, Wrong, Dim }

@Composable
fun DownloadLoadingState(
    statusText: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ReaderPrefs.isGameEnabled(context)) }
    var ready by remember { mutableStateOf(false) }
    var lastPercent by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        GameRemote.refresh(context)
    }
    LaunchedEffect(Unit) {
        delay(GameStartDelayMs)
        ready = true
    }
    LaunchedEffect(statusText) {
        val parsed = PercentRegex.find(statusText)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (parsed != null) lastPercent = parsed.coerceIn(0, 100)
    }

    val showGame = ready && enabled

    Crossfade(
        targetState = showGame,
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "download_state",
        modifier = modifier.fillMaxSize()
    ) { game ->
        if (game) {
            GameScreen(
                statusText = statusText,
                percent = lastPercent,
                onDisable = {
                    ReaderPrefs.setGameEnabled(context, false)
                    enabled = false
                }
            )
        } else {
            PlainLoading(
                statusText = statusText,
                offerGame = !enabled,
                onEnable = {
                    ReaderPrefs.setGameEnabled(context, true)
                    enabled = true
                }
            )
        }
    }
}

@Composable
private fun PlainLoading(
    statusText: String,
    offerGame: Boolean,
    onEnable: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        PdfViewerSkeleton()
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.onSurface,
                strokeWidth = 3.dp,
                modifier = Modifier.size(32.dp)
            )
            Text(
                text = statusText,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            if (offerGame) {
                TextButton(onClick = onEnable) {
                    Text(
                        text = "العب أثناء الانتظار",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun GameScreen(
    statusText: String,
    percent: Int,
    onDisable: () -> Unit
) {
    val quiz = remember { GameSession() }
    val simon = remember { SimonState() }
    val adaptive = rememberAdaptive()
    val maxContentWidth = when {
        adaptive.isTablet && adaptive.landscape -> 880.dp
        adaptive.isTablet -> 640.dp
        else -> 520.dp
    }
    var tab by remember { mutableIntStateOf(0) }
    val progress by animateFloatAsState(
        targetValue = (percent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(320, easing = MotionSpecs.StandardEasing),
        label = "download_progress"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .wrapContentWidth(Alignment.CenterHorizontally)
            .widthIn(max = maxContentWidth)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ProgressHeader(statusText = statusText, percent = percent, progress = progress)

        GameTabs(selected = tab, onSelect = { tab = it })

        AnimatedContent(
            targetState = tab,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
            transitionSpec = {
                (fadeIn(tween(MotionSpecs.DurationMedium, delayMillis = 60, easing = MotionSpecs.EmphasizedEasing)) +
                    slideInVertically(tween(MotionSpecs.ScreenIn, easing = MotionSpecs.EmphasizedEasing)) { it / 14 }) togetherWith
                    fadeOut(tween(MotionSpecs.DurationQuick))
            },
            label = "game_tab"
        ) { t ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (t == 0) {
                    GameCard(session = quiz)
                } else {
                    SimonGame(state = simon)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Crossfade(
                targetState = tab,
                animationSpec = tween(MotionSpecs.DurationMedium),
                label = "game_stats"
            ) { t ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (t == 0) {
                        StatPill(label = "النقاط", value = quiz.score)
                        StatPill(label = "السلسلة", value = quiz.streak)
                    } else {
                        StatPill(label = "المستوى", value = simon.level)
                        StatPill(label = "الأفضل", value = simon.best)
                    }
                }
            }
            TextButton(onClick = onDisable) {
                Text(
                    text = "إيقاف اللعبة",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun GameTabs(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(AppShapes.Pill)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
            .border(1.dp, CardBorder, AppShapes.Pill)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        GameTabTitles.forEachIndexed { index, title ->
            TabSegment(
                text = title,
                selected = index == selected,
                onClick = { onSelect(index) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun TabSegment(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val fill by animateColorAsState(
        targetValue = if (selected) scheme.onSurface.copy(alpha = 0.14f) else Color.Transparent,
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "tab_fill"
    )
    val tint by animateColorAsState(
        targetValue = if (selected) scheme.onSurface else scheme.onSurfaceVariant,
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "tab_tint"
    )
    Box(
        modifier = modifier
            .clip(AppShapes.Pill)
            .background(fill)
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = tint,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
private fun ProgressHeader(statusText: String, percent: Int, progress: Float) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = statusText,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            if (percent > 0) {
                Text(
                    text = "$percent%",
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        if (percent > 0) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape),
                color = MaterialTheme.colorScheme.onSurface,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
            )
        } else {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape),
                color = MaterialTheme.colorScheme.onSurface,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
            )
        }
    }
}

@Composable
private fun StatPill(label: String, value: Int) {
    Row(
        modifier = Modifier
            .clip(AppShapes.Pill)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .border(1.dp, CardBorder, AppShapes.Pill)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelMedium
        )
        AnimatedContent(
            targetState = value,
            transitionSpec = {
                (slideInVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)) { -it / 2 } +
                    fadeIn(tween(MotionSpecs.DurationMedium))) togetherWith
                    (slideOutVertically(tween(MotionSpecs.DurationQuick)) { it / 2 } +
                        fadeOut(tween(MotionSpecs.DurationQuick)))
            },
            label = "stat_value"
        ) { v ->
            Text(
                text = v.toString(),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun GameCard(session: GameSession) {
    val round = session.round
    val picked = round.picked

    LaunchedEffect(round, picked) {
        if (picked != null) {
            delay(if (picked == round.correct) 1500L else 2600L)
            session.advance()
        }
    }

    AnimatedContent(
        targetState = round,
        transitionSpec = {
            (fadeIn(tween(MotionSpecs.DurationMedium, delayMillis = 60, easing = MotionSpecs.EmphasizedEasing)) +
                slideInVertically(tween(MotionSpecs.ScreenIn, easing = MotionSpecs.EmphasizedEasing)) { it / 10 }) togetherWith
                fadeOut(tween(MotionSpecs.DurationQuick))
        },
        label = "game_round"
    ) { r ->
        RoundContent(round = r, onPick = { session.pick(it) }, onNext = { session.advance() })
    }
}

@Composable
private fun RoundContent(
    round: LiveRound,
    onPick: (Int) -> Unit,
    onNext: () -> Unit
) {
    val picked = round.picked
    val answered = picked != null
    val isMatch = round.item.kind == GameKind.Match
    val right = picked != null && picked == round.correct

    val shake = remember { Animatable(0f) }
    LaunchedEffect(picked) {
        if (picked != null && picked != round.correct) {
            for (v in listOf(-14f, 12f, -8f, 5f, 0f)) {
                shake.animateTo(v, tween(55, easing = LinearEasing))
            }
        }
    }

    val autoMs = if (right) 1500 else 2600
    val countdown = remember { Animatable(1f) }
    LaunchedEffect(picked) {
        if (picked != null) {
            countdown.snapTo(1f)
            countdown.animateTo(0f, tween(autoMs, easing = LinearEasing))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { translationX = shake.value }
            .clip(AppShapes.Medium)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(1.dp, CardBorder, AppShapes.Medium)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isMatch) "اختر الإجابة الصحيحة" else "صح أم غلط",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(AppShapes.Pill)
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
            Text(
                text = "سؤال ${round.number}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelMedium
            )
        }

        Text(
            text = round.item.prompt,
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 60.dp)
                .padding(vertical = 4.dp)
        )

        if (isMatch) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                round.options.forEachIndexed { index, text ->
                    OptionButton(
                        text = text,
                        badge = OptionLetters.getOrElse(index) { "" },
                        state = optionState(index, picked, round.correct),
                        enabled = !answered,
                        onClick = { onPick(index) }
                    )
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                round.options.forEachIndexed { index, text ->
                    OptionButton(
                        text = text,
                        badge = "",
                        icon = if (index == 0) Icons.Default.Check else Icons.Default.Close,
                        state = optionState(index, picked, round.correct),
                        enabled = !answered,
                        onClick = { onPick(index) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = answered,
            enter = fadeIn(tween(MotionSpecs.DurationMedium)) + slideInVertically(tween(MotionSpecs.DurationMedium)) { it / 4 },
            exit = fadeOut(tween(MotionSpecs.DurationQuick))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (right) "إجابة صحيحة" else "إجابة غير صحيحة",
                    color = if (right) SuccessGreen else MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = round.item.why,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(countdown.value)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f))
                    )
                }
                TextButton(onClick = onNext) {
                    Text(
                        text = "التالي",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

private fun optionState(index: Int, picked: Int?, correct: Int): OptionState = when {
    picked == null -> OptionState.Idle
    index == correct -> OptionState.Correct
    index == picked -> OptionState.Wrong
    else -> OptionState.Dim
}

@Composable
private fun OptionButton(
    text: String,
    badge: String,
    state: OptionState,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    val scheme = MaterialTheme.colorScheme
    val idleFill = scheme.onSurface.copy(alpha = 0.06f)
    val container by animateColorAsState(
        targetValue = when (state) {
            OptionState.Idle -> idleFill
            OptionState.Correct -> SuccessGreen.copy(alpha = 0.18f)
            OptionState.Wrong -> scheme.error.copy(alpha = 0.16f)
            OptionState.Dim -> idleFill
        },
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "option_fill"
    )
    val stroke by animateColorAsState(
        targetValue = when (state) {
            OptionState.Idle -> CardBorder
            OptionState.Correct -> SuccessGreen
            OptionState.Wrong -> scheme.error
            OptionState.Dim -> CardBorder
        },
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "option_border"
    )
    val badgeFill by animateColorAsState(
        targetValue = when (state) {
            OptionState.Correct -> SuccessGreen
            OptionState.Wrong -> scheme.error
            else -> scheme.onSurface.copy(alpha = 0.09f)
        },
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "option_badge"
    )
    val fade by animateFloatAsState(
        targetValue = if (state == OptionState.Dim) 0.45f else 1f,
        animationSpec = tween(MotionSpecs.DurationMedium),
        label = "option_alpha"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (enabled) Modifier.bounceClick(scaleDown = 0.97f, onClick = onClick) else Modifier)
            .graphicsLayer { alpha = fade }
            .clip(AppShapes.Small)
            .background(container)
            .border(1.dp, stroke, AppShapes.Small)
            .heightIn(min = 54.dp)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(badgeFill),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(
                targetState = state,
                animationSpec = tween(MotionSpecs.DurationMedium),
                label = "option_badge_content"
            ) { st ->
                when {
                    st == OptionState.Correct -> Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    st == OptionState.Wrong -> Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    icon != null -> Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = scheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    else -> Text(
                        text = badge,
                        color = scheme.onSurface,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        Text(
            text = text,
            color = scheme.onSurface,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.size(28.dp))
    }
}
