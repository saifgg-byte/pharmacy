package com.saifadnan.pharmacynotes.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.saifadnan.pharmacynotes.util.ClassReminderSettings
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.data.ScheduleEntity
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassChip
import com.saifadnan.pharmacynotes.ui.components.GlassDivider
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick
import com.saifadnan.pharmacynotes.ui.theme.glass
import java.util.Calendar

@Composable
fun StudentScheduleScreen(
    myGroup: String,
    schedule: List<ScheduleEntity>,
    onGroupSelected: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    remindersEnabled: Boolean = true,
    onRemindersToggle: (Boolean) -> Unit = {}
) {
    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "الجدول",
            subtitle = if (myGroup.isBlank()) "اختار كروبك" else "الأسبوعي · كروب $myGroup",
            modifier = Modifier.padding(horizontal = 20.dp),
            leading = {
                GlassIconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("schedule_back_button")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }
            },
            trailing = if (myGroup.isNotBlank()) {
                {
                    GlassChip(
                        text = "تغيير الكروب",
                        selected = false,
                        onClick = { onGroupSelected("") },
                        modifier = Modifier.testTag("change_group_button")
                    )
                }
            } else null
        )

        if (myGroup.isBlank()) {
            GroupPicker(
                selected = null,
                onSelect = onGroupSelected,
                title = "اختار كروبك",
                subtitle = "حدد كروبك حتى يوصلك الجدول والتذكيرات"
            )
        } else {
            ReminderToggleCard(
                enabled = remindersEnabled,
                onToggle = onRemindersToggle,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp)
            )

            val today = remember { Calendar.getInstance().get(Calendar.DAY_OF_WEEK) }
            val groupedByDay = ScheduleConstants.WEEK_DAYS.mapNotNull { day ->
                val entries = schedule
                    .filter { it.dayOfWeek == day.calendarDayOfWeek }
                    .sortedBy { it.startHour * 60 + it.startMinute }
                if (entries.isEmpty()) null else day to entries
            }

            if (groupedByDay.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(44.dp)
                        )
                        Text(
                            text = "ماكو محاضرات مجدولة لكروبك لحد الآن",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("student_schedule_list")
                ) {
                    itemsIndexed(groupedByDay, key = { _, pair -> pair.first.calendarDayOfWeek }) { index, (day, entries) ->
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateItemEntrance(index = index)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = day.arabicName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (day.calendarDayOfWeek == today) {
                                        Box(
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary)
                                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = "اليوم",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onPrimary
                                            )
                                        }
                                    }
                                }
                                entries.forEachIndexed { i, entry ->
                                    if (i > 0) GlassDivider()
                                    ScheduleEntryRow(entry)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScheduleEntryRow(entry: ScheduleEntity) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(52.dp)) {
            Text(
                text = String.format("%02d:%02d", entry.startHour, entry.startMinute),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = String.format("%02d:%02d", entry.endHour, entry.endMinute),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = entry.subject,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            val details = buildString {
                append(entry.sessionType)
                if (entry.room.isNotBlank()) append("  ·  قاعة ${entry.room}")
                if (entry.doctorName.isNotBlank()) append("  ·  د. ${entry.doctorName}")
            }
            Text(
                text = details,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun GroupPicker(
    selected: String?,
    onSelect: (String) -> Unit,
    title: String,
    subtitle: String
) {
    val glass = MaterialTheme.glass
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("group_picker_grid")
        ) {
            items(ScheduleConstants.GROUPS) { group ->
                val isSelected = group == selected
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .iconInteractiveClick(
                            behavior = IconClickBehavior.SPRING_BOUNCE,
                            scaleDown = 0.94f,
                            onClick = { onSelect(group) }
                        )
                        .clip(CircleShape)
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else glass.fillBottom)
                        .border(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else glass.border, CircleShape)
                        .testTag("group_option_$group"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = group,
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Center,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun ReminderToggleCard(
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var notificationsOk by remember { mutableStateOf(true) }
    var exactOk by remember { mutableStateOf(true) }

    LifecycleResumeEffect(Unit) {
        notificationsOk = ClassReminderSettings.areNotificationsAllowed(context)
        exactOk = ClassReminderSettings.canScheduleExactAlarms(context)
        onPauseOrDispose { }
    }

    GlassCard(modifier = modifier.fillMaxWidth().testTag("class_reminder_card")) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (enabled) Icons.Default.Notifications else Icons.Default.NotificationsOff,
                        contentDescription = null,
                        tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تذكير قبل المحاضرة",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (enabled) "ينبهك قبل كل محاضرة بـ ${ScheduleConstants.REMINDER_MINUTES_BEFORE} دقائق، حتى بدون إنترنت"
                        else "التذكير متوقف",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        checkedTrackColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("class_reminder_switch")
                )
            }

            if (enabled && !notificationsOk) {
                ReminderFixRow(
                    text = "إشعارات التطبيق مقفولة من إعدادات الهاتف، فما يوصلك التذكير.",
                    action = "فتح الإعدادات",
                    onClick = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { context.startActivity(intent) } catch (_: Exception) { }
                    }
                )
            } else if (enabled && !exactOk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ReminderFixRow(
                    text = "اسمح للتطبيق بارسال لك اشعارات حتى ينبهك بوقت المحاضرات",
                    action = "السماح",
                    onClick = {
                        val intent = Intent(
                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:${context.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { context.startActivity(intent) } catch (_: Exception) { }
                    }
                )
            }
        }
    }
}

@Composable
private fun ReminderFixRow(text: String, action: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.weight(1f)
        )
        GlassChip(text = action, selected = false, onClick = onClick)
    }
}
