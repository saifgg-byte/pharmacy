@file:OptIn(kotlinx.coroutines.FlowPreview::class)

package com.saifadnan.pharmacynotes.ui.pdf

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FloatExponentialDecaySpec
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import android.graphics.Bitmap
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.PagerSnapDistance
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.ui.components.shimmerEffect
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

object ReaderTheme {
    const val NORMAL = 0
    const val NIGHT = 1
    const val SEPIA = 2

    private val night = ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                -0.9f, 0f, 0f, 0f, 230f,
                0f, -0.9f, 0f, 0f, 230f,
                0f, 0f, -0.9f, 0f, 230f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    private val sepia = ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                0.366f, 0.715f, 0.176f, 0f, 0f,
                0.325f, 0.638f, 0.156f, 0f, 0f,
                0.253f, 0.497f, 0.122f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    fun filter(theme: Int): ColorFilter? = when (theme) {
        NIGHT -> night
        SEPIA -> sepia
        else -> null
    }

    fun paper(theme: Int): Color = when (theme) {
        NIGHT -> Color(0xFF111111)
        SEPIA -> Color(0xFFF4ECD8)
        else -> Color.White
    }
}

class ReaderGeo(val cw: Float, val ch: Float, val vw: Float, val vh: Float) {
    companion object {
        val Empty = ReaderGeo(0f, 0f, 0f, 0f)
    }
}

@Stable
class ReaderZoomState {
    var ownerPage by mutableIntStateOf(-1)
    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    var geo: ReaderGeo = ReaderGeo.Empty

    private var animJob: Job? = null

    fun cancelAnimation() {
        animJob?.cancel()
        animJob = null
    }

    fun reset(owner: Int = ownerPage) {
        cancelAnimation()
        scale = 1f
        offset = Offset.Zero
        ownerPage = owner
    }

    fun clamp(o: Offset, s: Float): Offset {
        val maxX = max(0f, (geo.cw * s - geo.vw) / 2f)
        val maxY = max(0f, (geo.ch * s - geo.vh) / 2f)
        return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
    }

    fun blockedHorizontally(dx: Float): Boolean {
        val maxX = max(0f, (geo.cw * scale - geo.vw) / 2f)
        return if (dx > 0f) offset.x >= maxX - EDGE_EPS else offset.x <= -maxX + EDGE_EPS
    }

    fun blockedVertically(dy: Float): Boolean {
        val maxY = max(0f, (geo.ch * scale - geo.vh) / 2f)
        return if (dy > 0f) offset.y >= maxY - EDGE_EPS else offset.y <= -maxY + EDGE_EPS
    }

    fun animateTo(scope: CoroutineScope, targetScale: Float, targetOffset: Offset, durationMs: Int = 240) {
        cancelAnimation()
        animJob = scope.launch {
            val s0 = scale
            val o0 = offset
            animate(0f, 1f, animationSpec = tween(durationMs, easing = FastOutSlowInEasing)) { t, _ ->
                val s = s0 + (targetScale - s0) * t
                scale = s
                offset = if (s <= 1f) Offset.Zero else clamp(
                    Offset(o0.x + (targetOffset.x - o0.x) * t, o0.y + (targetOffset.y - o0.y) * t),
                    s
                )
            }
        }
    }

    fun zoomAt(scope: CoroutineScope, focal: Offset, target: Float) {
        val ns = target.coerceIn(1f, MAX_SCALE)
        val c = Offset(geo.vw / 2f, geo.vh / 2f)
        val p = focal - c
        val no = if (ns <= 1f) Offset.Zero else clamp(p - (p - offset) * (ns / scale), ns)
        animateTo(scope, ns, no)
    }

    fun zoomStep(scope: CoroutineScope, delta: Float) {
        zoomAt(scope, Offset(geo.vw / 2f, geo.vh / 2f), scale + delta)
    }

    fun toggleDoubleTap(scope: CoroutineScope, focal: Offset) {
        if (scale > 1.05f) animateTo(scope, 1f, Offset.Zero) else zoomAt(scope, focal, DOUBLE_TAP_SCALE)
    }

    fun fling(scope: CoroutineScope, velocity: Offset) {
        cancelAnimation()
        animJob = scope.launch {
            coroutineScope {
                launch {
                    animateDecay(offset.x, velocity.x, FloatExponentialDecaySpec(frictionMultiplier = 1.6f)) { v, _ ->
                        offset = clamp(Offset(v, offset.y), scale)
                    }
                }
                launch {
                    animateDecay(offset.y, velocity.y, FloatExponentialDecaySpec(frictionMultiplier = 1.6f)) { v, _ ->
                        offset = clamp(Offset(offset.x, v), scale)
                    }
                }
            }
        }
    }

    companion object {
        const val MAX_SCALE = 5f
        const val DOUBLE_TAP_SCALE = 2.5f

        const val SWIPE_ALWAYS_TURNS_PAGE = false
        private const val EDGE_EPS = 1.5f
    }
}

@Composable
fun PdfReader(
    session: PdfSession,
    pagerState: PagerState,
    zoom: ReaderZoomState,
    rotated: Boolean,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    theme: Int = ReaderTheme.NORMAL,
    annotations: ReaderAnnotations? = null,
    freezeRender: Boolean = false
) {
    BoxWithConstraints(modifier = modifier) {
        val viewport = IntSize(constraints.maxWidth, constraints.maxHeight)
        val landscape = viewport.width > viewport.height

        val heightRef = remember(landscape) { IntArray(1) }
        if (viewport.height > heightRef[0]) heightRef[0] = viewport.height
        val baseVh = heightRef[0]

        val renderWRef = remember { IntArray(1) }
        if (!freezeRender || renderWRef[0] == 0) renderWRef[0] = viewport.width
        val renderW = renderWRef[0]

        LaunchedEffect(pagerState.settledPage) {
            zoom.reset(pagerState.settledPage)
        }

        LaunchedEffect(session, renderW, baseVh, rotated, pagerState.settledPage) {
            val c = pagerState.settledPage
            for (d in intArrayOf(1, -1, 2, -2)) {
                session.loadPage(c + d, renderW, baseVh, rotated)
            }
        }

        val fling = PagerDefaults.flingBehavior(
            state = pagerState,
            pagerSnapDistance = PagerSnapDistance.atMost(1),
            snapAnimationSpec = spring(stiffness = Spring.StiffnessMediumLow)
        )
        val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
        val scrollEnabled = annotations?.capturing != true

        val pageContent: @Composable (Int) -> Unit = { pageIndex ->
            ReaderPage(
                pageIndex = pageIndex,
                session = session,
                zoom = zoom,
                rotated = rotated,
                viewport = viewport,
                renderW = renderW,
                baseVh = baseVh,
                onTap = onTap,
                theme = theme,
                annotations = annotations
            )
        }

        if (rotated) {
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1,
                userScrollEnabled = scrollEnabled,
                reverseLayout = rtl,
                flingBehavior = fling,
                pageSpacing = 12.dp,
                key = { it }
            ) { pageIndex -> pageContent(pageIndex) }
        } else {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1,
                userScrollEnabled = scrollEnabled,
                flingBehavior = fling,
                pageSpacing = 12.dp,
                key = { it }
            ) { pageIndex -> pageContent(pageIndex) }
        }
    }
}

@Composable
private fun ReaderPage(
    pageIndex: Int,
    session: PdfSession,
    zoom: ReaderZoomState,
    rotated: Boolean,
    viewport: IntSize,
    renderW: Int,
    baseVh: Int,
    onTap: () -> Unit,
    theme: Int,
    annotations: ReaderAnnotations?
) {
    if (viewport.width <= 0 || viewport.height <= 0) return

    val themeFilter = remember(theme) { ReaderTheme.filter(theme) }
    val paperColor = remember(theme) { ReaderTheme.paper(theme) }

    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val pageSize = session.pageSizes[pageIndex] ?: session.pageSizes[0] ?: Size(595f, 842f)
    val vw = viewport.width.toFloat()
    val vh = viewport.height.toFloat()
    val fit = PdfGeometry.fitScale(vw, vh, pageSize.width, pageSize.height, rotated)

    val dispW = (if (rotated) pageSize.height else pageSize.width) * fit
    val dispH = (if (rotated) pageSize.width else pageSize.height) * fit
    val isOwner = zoom.ownerPage == pageIndex

    SideEffect {
        if (isOwner) {
            zoom.geo = ReaderGeo(dispW, dispH, vw, vh)
            if (annotations != null) {
                annotations.unitW = if (rotated) dispH else dispW
                annotations.unitH = if (rotated) dispW else dispH
            }
        }
    }

    var bitmap by remember(pageIndex, session) {
        mutableStateOf(session.peek(pageIndex, renderW, rotated))
    }
    var failed by remember(pageIndex, session) { mutableStateOf(false) }
    var retryKey by remember(pageIndex, session) { mutableIntStateOf(0) }
    LaunchedEffect(pageIndex, session, renderW, baseVh, rotated, retryKey) {
        failed = false
        var attempt = 0
        var loaded: Bitmap? = null
        while (loaded == null && attempt < 3) {
            loaded = session.loadPage(pageIndex, renderW, baseVh, rotated)
            if (loaded == null) {
                attempt++
                delay(300L * attempt)
            }
        }
        if (loaded != null) {
            bitmap = loaded
        } else if (bitmap == null) {
            failed = true
        }
    }
    val image = remember(bitmap) { bitmap?.asImageBitmap() }

    var tile by remember(pageIndex, session) { mutableStateOf<HiResTile?>(null) }
    LaunchedEffect(isOwner) { if (!isOwner) tile = null }
    if (isOwner) {
        LaunchedEffect(session, viewport, baseVh, rotated, pageSize) {
            snapshotFlow { zoom.scale to zoom.offset }
                .debounce(140)
                .collectLatest { (s, o) ->
                    val kBase = PdfGeometry.baseScale(vw, baseVh.toFloat(), pageSize.width, pageSize.height, rotated)
                    if (s * fit <= kBase * 1.08f) {
                        tile = null
                    } else {
                        tile = session.renderTile(pageIndex, viewport.width, viewport.height, rotated, s, o)
                    }
                }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(pageIndex) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { pos -> if (zoom.ownerPage == pageIndex) zoom.toggleDoubleTap(scope, pos) }
                )
            }
            .readerTransformGestures(pageIndex, zoom, scope, rotated)
            .then(
                if (annotations != null && annotations.capturing) {
                    Modifier.inkGestures(pageIndex, annotations, zoom, rotated, dispW, dispH)
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .requiredSize(with(density) { dispW.toDp() }, with(density) { dispH.toDp() })
                .graphicsLayer {
                    if (zoom.ownerPage == pageIndex) {
                        scaleX = zoom.scale
                        scaleY = zoom.scale
                        translationX = zoom.offset.x
                        translationY = zoom.offset.y
                    }
                }
                .background(paperColor),
            contentAlignment = Alignment.Center
        ) {
            val img = image
            if (img != null) {
                Image(
                    bitmap = img,
                    contentDescription = "صفحة ${pageIndex + 1}",
                    contentScale = ContentScale.FillBounds,
                    colorFilter = themeFilter,
                    modifier = Modifier
                        .requiredSize(
                            with(density) { (if (rotated) dispH else dispW).toDp() },
                            with(density) { (if (rotated) dispW else dispH).toDp() }
                        )
                        .graphicsLayer { rotationZ = if (rotated) 90f else 0f }
                )
            } else if (failed) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { retryKey++ },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = "تعذر عرض الصفحة، اضغط للمحاولة",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                Box(modifier = Modifier.fillMaxSize().shimmerEffect())
            }
        }

        Spacer(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val t = tile
                    if (t != null && zoom.ownerPage == pageIndex && t.rotated == rotated &&
                        t.scale == zoom.scale && t.offset == zoom.offset
                    ) {
                        drawImage(t.image, topLeft = Offset(t.left.toFloat(), t.top.toFloat()), colorFilter = themeFilter)
                    }
                }
        )

        if (annotations != null) {
            HighlightLayer(
                pageIndex = pageIndex,
                annotations = annotations,
                rotated = rotated,
                dispW = dispW,
                dispH = dispH,
                zoom = zoom
            )
            if (annotations.lectureId > 0) {
                SelectionLayer(
                    pageIndex = pageIndex,
                    annotations = annotations,
                    rotated = rotated,
                    dispW = dispW,
                    dispH = dispH,
                    zoom = zoom
                )
            }
        }
    }
}

private fun Modifier.readerTransformGestures(
    pageIndex: Int,
    zoom: ReaderZoomState,
    scope: CoroutineScope,
    rotated: Boolean
): Modifier = pointerInput(pageIndex, zoom, rotated) {
    val touchSlop = viewConfiguration.touchSlop
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        if (zoom.ownerPage != pageIndex) return@awaitEachGesture
        zoom.cancelAnimation()

        val center = Offset(size.width / 2f, size.height / 2f)
        val tracker = VelocityTracker()
        var pastSlop = false
        var handedOff = false
        var pinched = false
        var accZoom = 1f
        var accPan = Offset.Zero

        do {
            val event = awaitPointerEvent()
            if (handedOff) continue
            if (event.changes.any { it.isConsumed }) break

            val pressedCount = event.changes.count { it.pressed }
            val zoomChange = event.calculateZoom()
            val panChange = event.calculatePan()

            if (!pastSlop) {
                accZoom *= zoomChange
                accPan += panChange
                val centroidSize = event.calculateCentroidSize(useCurrent = false)
                val zoomMotion = abs(1f - accZoom) * centroidSize
                val panMotion = accPan.getDistance()
                if (zoomMotion > touchSlop || panMotion > touchSlop) {
                    pastSlop = true
                    if (pressedCount < 2) {
                        val atRest = zoom.scale <= 1.01f
                        val turnsPageAtEdge = if (rotated) {
                            abs(accPan.y) > abs(accPan.x) &&
                                (ReaderZoomState.SWIPE_ALWAYS_TURNS_PAGE || zoom.blockedVertically(accPan.y))
                        } else {
                            abs(accPan.x) > abs(accPan.y) &&
                                (ReaderZoomState.SWIPE_ALWAYS_TURNS_PAGE || zoom.blockedHorizontally(accPan.x))
                        }
                        if (atRest || turnsPageAtEdge) handedOff = true
                    }
                }
                if (!pastSlop || handedOff) continue
            }

            if (zoomChange != 1f || panChange != Offset.Zero) {
                if (pressedCount >= 2) pinched = true
                val old = zoom.scale
                val ns = (old * zoomChange).coerceIn(1f, ReaderZoomState.MAX_SCALE)
                val p = event.calculateCentroid(useCurrent = false) - center
                val raw = p - (p - zoom.offset) * (ns / old) + panChange
                zoom.scale = ns
                zoom.offset = if (ns <= 1f) Offset.Zero else zoom.clamp(raw, ns)

                if (pressedCount == 1) {
                    event.changes.firstOrNull { it.pressed }?.let { tracker.addPointerInputChange(it) }
                }
                event.changes.forEach { if (it.positionChanged()) it.consume() }
            }
        } while (event.changes.any { it.pressed })

        if (!handedOff && pastSlop) {
            if (zoom.scale > 1f && zoom.scale < 1.03f) {
                zoom.animateTo(scope, 1f, Offset.Zero)
            } else if (!pinched && zoom.scale > 1f) {
                val v = tracker.calculateVelocity()
                zoom.fling(scope, Offset(v.x, v.y))
            }
        }
    }
}