package com.saifadnan.pharmacynotes.data

import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

object ResilientDns : Dns {
    private class Entry(val time: Long, val addresses: List<InetAddress>)

    private val cache = ConcurrentHashMap<String, Entry>()
    private const val FRESH_MS = 10 * 60 * 1000L

    private val bootstrap by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private val resolvers = listOf(
        "https://1.1.1.1/dns-query?type=A&name=",
        "https://8.8.8.8/resolve?type=A&name=",
        "https://1.0.0.1/dns-query?type=A&name="
    )

    override fun lookup(hostname: String): List<InetAddress> {
        val cached = cache[hostname]
        if (cached != null && System.currentTimeMillis() - cached.time < FRESH_MS) return cached.addresses

        try {
            val system = Dns.SYSTEM.lookup(hostname)
            if (system.isNotEmpty()) {
                cache[hostname] = Entry(System.currentTimeMillis(), system)
                return system
            }
        } catch (_: UnknownHostException) {

        }

        val viaDoh = dohLookup(hostname)
        if (viaDoh.isNotEmpty()) {
            cache[hostname] = Entry(System.currentTimeMillis(), viaDoh)
            return viaDoh
        }

        cached?.let { return it.addresses }
        throw UnknownHostException("unable to resolve host \"$hostname\"")
    }

    private fun dohLookup(hostname: String): List<InetAddress> {
        for (base in resolvers) {
            try {
                val req = Request.Builder()
                    .url(base + hostname)
                    .header("accept", "application/dns-json")
                    .build()
                bootstrap.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val body = resp.body?.string() ?: return@use
                    val answers = JSONObject(body).optJSONArray("Answer") ?: return@use
                    val out = mutableListOf<InetAddress>()
                    for (i in 0 until answers.length()) {
                        val a = answers.getJSONObject(i)
                        if (a.optInt("type") == 1) {
                            val ip = a.optString("data")
                            if (ip.isNotBlank()) out.add(InetAddress.getByName(ip))
                        }
                    }
                    if (out.isNotEmpty()) return out
                }
            } catch (_: Exception) {

            }
        }
        return emptyList()
    }
}
