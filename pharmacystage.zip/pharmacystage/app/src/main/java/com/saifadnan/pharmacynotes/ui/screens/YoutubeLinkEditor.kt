package com.saifadnan.pharmacynotes.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.ui.components.GlassSegmented
import com.saifadnan.pharmacynotes.ui.components.IconClickBehavior
import com.saifadnan.pharmacynotes.ui.components.SegmentOption
import com.saifadnan.pharmacynotes.ui.components.iconInteractiveClick
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import com.saifadnan.pharmacynotes.ui.theme.YoutubeRed
import com.saifadnan.pharmacynotes.ui.theme.glass
import com.saifadnan.pharmacynotes.util.YoutubeLinks
import com.saifadnan.pharmacynotes.util.YoutubeVideo
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private class EditableVideo(val key: Long, title: String, url: String) {
    var title by mutableStateOf(title)
    var url by mutableStateOf(url)
}

@Composable
fun YoutubeLinkField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val keys = remember { AtomicLong(0L) }
    fun newRow(title: String = "", url: String = "") = EditableVideo(keys.incrementAndGet(), title, url)

    fun rowsFor(raw: String, asPlaylist: Boolean): List<EditableVideo> {
        val parsed = YoutubeLinks.parse(raw)
        val rows = parsed.map { newRow(it.title, it.url) }.toMutableList()
        if (rows.isEmpty()) rows.add(newRow())
        if (asPlaylist && rows.size == 1) rows.add(newRow())
        return rows
    }

    var playlist by remember { mutableStateOf(YoutubeLinks.isPlaylist(value)) }
    val rows = remember { mutableStateListOf<EditableVideo>().apply { addAll(rowsFor(value, playlist)) } }
    var lastEmitted by remember { mutableStateOf(value) }

    fun emit() {
        val encoded = YoutubeLinks.encode(rows.map { YoutubeVideo(it.title, it.url) }, playlist)
        lastEmitted = encoded
        onValueChange(encoded)
    }

    // تغيير خارجي (مثل تفريغ الحقل بعد رفع المحاضرة) → نعيد بناء الصفوف
    LaunchedEffect(value) {
        if (value != lastEmitted) {
            lastEmitted = value
            playlist = YoutubeLinks.isPlaylist(value)
            rows.clear()
            rows.addAll(rowsFor(value, playlist))
        }
    }

    fun switchTo(toPlaylist: Boolean) {
        if (toPlaylist == playlist) return
        if (toPlaylist) {
            val first = rows.firstOrNull() ?: newRow()
            rows.clear()
            rows.add(first)
            rows.add(newRow())
        } else {
            // فيديو واحد: نُبقي أول رابط مكتوب
            val first = rows.firstOrNull { it.url.isNotBlank() } ?: rows.firstOrNull() ?: newRow()
            rows.clear()
            rows.add(first)
        }
        playlist = toPlaylist
        emit()
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        GlassSegmented(
            options = listOf(
                SegmentOption("single", "فيديو واحد", Icons.Default.SmartDisplay),
                SegmentOption("playlist", "قائمة تشغيل", Icons.Default.PlaylistPlay)
            ),
            selectedKey = if (playlist) "playlist" else "single",
            onSelect = { switchTo(it == "playlist") },
            height = 44.dp,
            tagPrefix = "admin_youtube_mode_"
        )

        AnimatedContent(
            targetState = playlist,
            transitionSpec = {
                (
                    (fadeIn(tween(260, delayMillis = 80)) +
                        slideInVertically(tween(300, easing = MotionSpecs.EmphasizedEasing)) { it / 12 }) togetherWith
                        fadeOut(tween(120))
                    ) using SizeTransform(clip = false)
            },
            label = "yt_editor_mode"
        ) { isPlaylist ->
            if (!isPlaylist) {
                SingleVideoField(row = rows.firstOrNull(), onChanged = { emit() })
            } else {
                PlaylistEditor(
                    rows = rows,
                    onChanged = { emit() },
                    newRow = { newRow() }
                )
            }
        }
    }
}

@Composable
private fun YoutubeBrandIcon() {
    Icon(
        painter = painterResource(id = R.drawable.ic_youtube),
        contentDescription = null,
        tint = Color.Unspecified,
        modifier = Modifier.size(26.dp)
    )
}

@Composable
private fun SingleVideoField(row: EditableVideo?, onChanged: () -> Unit) {
    if (row == null) return
    OutlinedTextField(
        value = row.url,
        onValueChange = {
            row.url = it
            onChanged()
        },
        label = { Text("رابط يوتيوب (اختياري)") },
        placeholder = { Text("https://youtu.be/...") },
        supportingText = { Text("يقبل رابط فيديو أو قائمة تشغيل جاهزة من يوتيوب") },
        leadingIcon = { YoutubeBrandIcon() },
        isError = !YoutubeLinks.isValidUrl(row.url),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
        shape = AppShapes.Small,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_youtube_single_field")
    )
}

@Composable
private fun PlaylistEditor(
    rows: SnapshotStateList<EditableVideo>,
    onChanged: () -> Unit,
    newRow: () -> EditableVideo
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEachIndexed { index, row ->
            key(row.key) {
                PlaylistRowEditor(
                    index = index,
                    count = rows.size,
                    row = row,
                    onChanged = onChanged,
                    onMoveUp = {
                        val i = rows.indexOf(row)
                        if (i > 0) {
                            rows.removeAt(i)
                            rows.add(i - 1, row)
                            onChanged()
                        }
                    },
                    onMoveDown = {
                        val i = rows.indexOf(row)
                        if (i in 0 until rows.size - 1) {
                            rows.removeAt(i)
                            rows.add(i + 1, row)
                            onChanged()
                        }
                    },
                    onRemove = {
                        rows.remove(row)
                        onChanged()
                    }
                )
            }
        }
        OutlinedButton(
            onClick = { rows.add(newRow()) },
            shape = AppShapes.Pill,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_youtube_add_video")
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("إضافة فيديو", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PlaylistRowEditor(
    index: Int,
    count: Int,
    row: EditableVideo,
    onChanged: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onRemove: () -> Unit
) {
    val glass = MaterialTheme.glass
    val scope = rememberCoroutineScope()
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }

    AnimatedVisibility(
        visible = shown,
        enter = expandVertically(tween(MotionSpecs.DurationMedium, easing = MotionSpecs.EmphasizedEasing)) +
            fadeIn(tween(MotionSpecs.DurationMedium)),
        exit = shrinkVertically(tween(MotionSpecs.ScreenOut, easing = MotionSpecs.StandardEasing)) +
            fadeOut(tween(MotionSpecs.DurationQuick))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(AppShapes.Medium)
                .background(glass.fillBottom)
                .border(1.dp, glass.border, AppShapes.Medium)
                .padding(10.dp)
                .testTag("admin_youtube_row_$index"),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(YoutubeRed.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = YoutubeRed
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "الفيديو ${index + 1}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                MiniAction(Icons.Default.KeyboardArrowUp, "نقل للأعلى", enabled = index > 0, onClick = onMoveUp)
                MiniAction(Icons.Default.KeyboardArrowDown, "نقل للأسفل", enabled = index < count - 1, onClick = onMoveDown)
                if (count > 1) {
                    MiniAction(
                        icon = Icons.Default.Close,
                        description = "حذف الفيديو",
                        enabled = true,
                        tint = MaterialTheme.colorScheme.error,
                        onClick = {
                            scope.launch {
                                shown = false
                                delay(MotionSpecs.ScreenOut.toLong() + 40L)
                                onRemove()
                            }
                        }
                    )
                }
            }
            OutlinedTextField(
                value = row.title,
                onValueChange = {
                    row.title = it
                    onChanged()
                },
                label = { Text("عنوان الفيديو (اختياري)") },
                singleLine = true,
                shape = AppShapes.Small,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = row.url,
                onValueChange = {
                    row.url = it
                    onChanged()
                },
                label = { Text("رابط الفيديو") },
                placeholder = { Text("https://youtu.be/...") },
                leadingIcon = { YoutubeBrandIcon() },
                isError = !YoutubeLinks.isValidUrl(row.url),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                shape = AppShapes.Small,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun MiniAction(
    icon: ImageVector,
    description: String,
    enabled: Boolean,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onSurface
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .then(
                if (enabled) Modifier.iconInteractiveClick(
                    behavior = IconClickBehavior.SPRING_BOUNCE,
                    scaleDown = 0.85f,
                    onClick = onClick
                ) else Modifier
            )
            .clip(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = tint.copy(alpha = if (enabled) 1f else 0.28f),
            modifier = Modifier.size(20.dp)
        )
    }
}
