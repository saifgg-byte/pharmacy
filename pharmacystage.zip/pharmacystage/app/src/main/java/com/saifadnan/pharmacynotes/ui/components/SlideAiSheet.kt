@file:OptIn(ExperimentalMaterial3Api::class)

package com.saifadnan.pharmacynotes.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.activity.compose.BackHandler
import android.widget.Toast
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.produceState
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.runtime.RememberObserver
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.saifadnan.pharmacynotes.ui.theme.MotionSpecs
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.ui.pdf.PdfSession
import com.saifadnan.pharmacynotes.ui.theme.glass
import com.saifadnan.pharmacynotes.util.cleanAiMarkup
import com.saifadnan.pharmacynotes.util.stripRich
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val ASSISTANT_NAME = "مساعد الفارما"

private val saveScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

@Immutable
private class AiColors(
    val dark: Boolean,
    val sheetTop: Color,
    val sheetBottom: Color,
    val panel: Color,
    val panelRaised: Color,
    val border: Color,
    val userFill: Color,
    val userText: Color,
    val text: Color,
    val muted: Color,
    val errorFill: Color,
    val errorText: Color,
    val brandA: Color,
    val brandB: Color,
    val onBrand: Color
)

@Composable
private fun aiColors(): AiColors =
    if (MaterialTheme.glass.isDark) AiColors(
        dark = true,
        sheetTop = Color(0xFF0E1428),
        sheetBottom = Color(0xFF0A0F1F),
        panel = Color(0xFF141C38),
        panelRaised = Color(0xFF1D284D),
        border = Color(0x26FFFFFF),
        userFill = Color(0xFFF2F5FA),
        userText = Color(0xFF0E1116),
        text = Color(0xFFEEF1F8),
        muted = Color(0xFF9BA7BF),
        errorFill = Color(0xFF3A1F24),
        errorText = Color(0xFFFFC2CB),
        brandA = Color(0xFF8FB0FF),
        brandB = Color(0xFF5B83D6),
        onBrand = Color(0xFF0B1020)
    ) else AiColors(
        dark = false,
        sheetTop = Color(0xFFEEF2F5),
        sheetBottom = Color(0xFFF5F7F9),
        panel = Color(0xFFFFFFFF),
        panelRaised = Color(0xFFE5EBF0),
        border = Color(0xFFD6DEE5),
        userFill = Color(0xFF0E1116),
        userText = Color(0xFFFFFFFF),
        text = Color(0xFF0E1116),
        muted = Color(0xFF5A6673),
        errorFill = Color(0xFFFBE3E1),
        errorText = Color(0xFF7A1F1B),
        brandA = Color(0xFF5B8DB8),
        brandB = Color(0xFF3F6E99),
        onBrand = Color(0xFFFFFFFF)
    )

private enum class AiQuick(
    val action: String,
    val label: String,
    val icon: ImageVector
) {
    EXPLAIN("explain", "شرح مفصل", Icons.Default.School),
    SIMPLIFY("simplify", "تبسيط مختصر", Icons.Default.AutoFixHigh),
    TRANSLATE("translate", "ترجمة السلايد", Icons.Default.Translate),
    KEYWORDS("keywords", "Key words", Icons.Default.Key),
    MCQ("mcq", "MCQ", Icons.Default.Quiz),
    MEMORIZE("memorize", "طريقة حفظ", Icons.Default.Psychology)
}

private class FollowUp(val label: String, val question: String, val action: String = "ask")

private val FU_MORE = FollowUp("اشرح أكثر", "اشرح الفكرة السابقة بتفصيل أكبر وبأسلوب أبسط.")
private val FU_EXAMPLE = FollowUp("أعطني مثالاً", "أعطني مثالاً عملياً أو سريرياً يوضح الفكرة.")
private val FU_QUIZ = FollowUp(
    "اختبرني بسؤال",
    "اسألني سؤالاً واحداً من هذا السلايد بدون ذكر جوابه، وبعد أن أجيب صحّح لي إجابتي."
)
private val FU_SHORT = FollowUp("لخّصها بنقاط", "لخّص ما سبق في 4 نقاط قصيرة.")
private val FU_HARDER = FollowUp(
    "أسئلة أصعب",
    "اكتب 3 أسئلة MCQ أصعب من هذا السلايد بنفس الصيغة السابقة، وضع الأجوبة تحت العنوان ## Answers."
)
private val FU_WHY_WRONG = FollowUp("لماذا الخيارات الأخرى خاطئة؟", "اشرح لماذا الخيارات الأخرى خاطئة في الأسئلة السابقة.")
private val FU_MCQ = FollowUp("حوّلها لأسئلة MCQ", "", "mcq")
private val FU_MEMO = FollowUp("كيف أحفظها؟", "", "memorize")
private val FU_EXPLAIN = FollowUp("اشرحها لي", "", "explain")
private val FU_EXAM = FollowUp("ما المهم للامتحان؟", "", "exam")
private val FU_STRUCT = FollowUp("ارسم التراكيب", "", "structure")

private fun followUpsFor(action: String): List<FollowUp> = when (action) {
    "mcq" -> listOf(FU_HARDER, FU_WHY_WRONG, FU_MEMO)
    "translate" -> listOf(FU_EXPLAIN, FU_EXAM, FU_MCQ)
    "explain" -> listOf(FU_STRUCT, FU_SHORT, FU_EXAMPLE, FU_QUIZ)
    "simplify" -> listOf(FU_STRUCT, FU_MORE, FU_EXAMPLE, FU_QUIZ)
    "keywords" -> listOf(FU_STRUCT, FU_MEMO, FU_QUIZ, FU_MCQ)
    "exam" -> listOf(FU_MCQ, FU_STRUCT, FU_MEMO, FU_MORE)
    "memorize" -> listOf(FU_QUIZ, FU_MCQ, FU_EXAM)
    "example" -> listOf(FU_MORE, FU_QUIZ, FU_MCQ)
    "structure" -> listOf(FU_MORE, FU_MEMO, FU_QUIZ)
    else -> listOf(FU_MORE, FU_EXAMPLE, FU_QUIZ)
}

private val REMOVED_SUGGESTION_MARKERS = listOf("مهمة للصيدلاني", "أنتبه له قبل الامتحان", "انتبه له قبل الامتحان")

private fun List<String>.cleanSuggestions(): List<String> =
    filter { q -> REMOVED_SUGGESTION_MARKERS.none { q.contains(it) } }.distinct()

private val ANSWERS_HEADING = Regex("(?im)^\\s{0,3}#{1,3}\\s*(answers?|الأجوبة|الاجوبة|الإجابات|الاجابات).*$")

private class SplitAnswer(val body: String, val answers: String?)

private fun splitAnswers(text: String): SplitAnswer {
    val m = ANSWERS_HEADING.find(text) ?: return SplitAnswer(text, null)
    val body = text.substring(0, m.range.first).trim()
    val answers = text.substring(m.range.first).trim()
    if (body.isEmpty() || answers.isEmpty()) return SplitAnswer(text, null)
    return SplitAnswer(body, answers)
}

data class AiMsg(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val page: Int = 0,
    val isError: Boolean = false,
    val loading: Boolean = false,
    val action: String = "",
    val qid: String = "",
    val providerName: String = "",
    val switchedFrom: String = "",
    val retryAfter: Int = 0
)

class AiInitial(val action: String, val question: String, val label: String)

const val AI_PREFILL = "prefill"


@Stable
class SlideAiState : RememberObserver {
    private val ownScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onRemembered() {}
    override fun onForgotten() { ownScope.cancel() }
    override fun onAbandoned() { ownScope.cancel() }

    internal val progress = HashMap<Long, Int>()
    internal val thumbs = HashMap<Int, ImageBitmap>()

    var pickedPages by mutableStateOf<Set<Int>>(emptySet())
        private set

    fun resetScope() {
        pickedPages = emptySet()
    }

    fun togglePage(p: Int): Boolean {
        return when {
            p in pickedPages -> { pickedPages = pickedPages - p; true }
            pickedPages.size >= MAX_PICK -> false
            else -> { pickedPages = pickedPages + p; true }
        }
    }

    val messages = mutableStateListOf<AiMsg>()

    var chatId by mutableStateOf("")
        private set
    var history by mutableStateOf<List<SupabaseClient.AiChatInfo>>(emptyList())
        private set
    var historyLoading by mutableStateOf(false)
        private set
    var historyError by mutableStateOf(false)
        private set
    var openingId by mutableStateOf("")
        private set
    private var historyJob: Job? = null

    fun loadHistory(fileUrl: String, silent: Boolean = false) {
        if (fileUrl.isBlank()) return
        historyJob?.cancel()
        historyJob = ownScope.launch {
            if (!silent) {
                historyLoading = true
                historyError = false
            }
            val list = SupabaseClient.aiChatList(fileUrl)
            if (list != null) {
                history = list
                historyError = false
            } else if (!silent) {
                historyError = true
            }
            historyLoading = false
        }
    }

    fun newChat() {
        job?.cancel()
        messages.clear()
        chatId = ""
        lastArgs = null
        busy = false
        resetScope()
    }

    fun openChat(id: String, onResult: (Boolean) -> Unit) {
        if (openingId.isNotEmpty()) return
        if (id == chatId && messages.isNotEmpty()) {
            onResult(true)
            return
        }
        openingId = id
        ownScope.launch {
            val items = SupabaseClient.aiChatLoad(id)
            if (items == null || items.isEmpty()) {
                openingId = ""
                onResult(false)
                return@launch
            }
            job?.cancel()
            busy = false
            lastArgs = null
            resetScope()
            val restored = items.map {
                val mid = nextId++
                revealed.add(mid)
                appeared.add(mid)
                AiMsg(
                    id = mid,
                    fromUser = it.role == "user",
                    text = it.text,
                    page = it.page,
                    action = it.action,
                    qid = it.qid,
                    providerName = it.prov
                )
            }
            messages.clear()
            messages.addAll(restored)
            chatId = id
            revealTick++
            openingId = ""
            onResult(true)
        }
    }

    fun deleteChat(id: String, fileUrl: String) {
        history = history.filterNot { it.id == id }
        if (id == chatId) newChat()
        saveScope.launch {
            if (!SupabaseClient.aiChatDelete(id)) loadHistory(fileUrl, silent = true)
        }
    }

    fun clearAllChats(fileUrl: String) {
        history = emptyList()
        newChat()
        saveScope.launch {
            if (!SupabaseClient.aiChatClear(fileUrl)) loadHistory(fileUrl, silent = true)
        }
    }

    private fun persist(cid: String, a: AskArgs, reply: AiMsg) {
        saveScope.launch {
            val ok = SupabaseClient.aiChatAppend(
                chatId = cid,
                fileUrl = a.fileUrl,
                subject = a.subject,
                title = a.title,
                items = listOf(
                    SupabaseClient.AiChatItem("user", a.userLabel, a.pageIndex + 1, a.action),
                    SupabaseClient.AiChatItem("assistant", reply.text, 0, a.action, reply.qid, reply.providerName)
                )
            )
            if (ok) loadHistory(a.fileUrl, silent = true)
        }
    }

    var busy by mutableStateOf(false)
        private set
    var cooling by mutableStateOf(false)
        private set
    val locked: Boolean get() = busy || cooling
    private var coolJob: Job? = null

    private fun startCooldown() {
        cooling = true
        coolJob?.cancel()
        coolJob = ownScope.launch {
            delay(COOLDOWN_MS)
            cooling = false
        }
    }
    var remaining by mutableIntStateOf(-1)
        private set
    var provider by mutableStateOf("auto")
        private set
    var providers by mutableStateOf<List<SupabaseClient.AiProvider>>(emptyList())
        private set

    fun pickProvider(id: String) {
        provider = id
    }

    fun refreshStatus() {
        ownScope.launch {
            SupabaseClient.aiStatus()?.let { st ->
                providers = st.providers
                if (st.remaining >= 0) remaining = st.remaining
                if (provider != "auto" && st.providers.none { it.id == provider }) provider = "auto"
            }
        }
    }
    var revealTick by mutableIntStateOf(0)
        private set

    private class AskArgs(
        val pageIndex: Int,
        val action: String,
        val question: String,
        val userLabel: String,
        val subject: String,
        val title: String,
        val fileUrl: String
    )

    private var job: Job? = null
    private var nextId = 0L
    private var lastArgs: AskArgs? = null
    private val revealed = HashSet<Long>()
    private val appeared = HashSet<Long>()

    internal fun isRevealed(id: Long) = id in revealed
    internal fun markRevealed(id: Long) {
        if (revealed.add(id)) revealTick++
    }

    internal fun consumeAppear(id: Long): Boolean = appeared.add(id)

    fun ask(
        scope: CoroutineScope,
        session: PdfSession,
        pageIndex: Int,
        action: String,
        question: String,
        userLabel: String,
        subject: String,
        title: String,
        fileUrl: String
    ) {
        if (busy || cooling) return
        val args = AskArgs(pageIndex, action, question, userLabel, subject, title, fileUrl)
        lastArgs = args
        if (chatId.isBlank()) chatId = UUID.randomUUID().toString().replace("-", "")
        val cid = chatId
        val picked = pickedPages.sorted().take(MAX_PICK)
        val multi = picked.size > 1
        val targetPage = if (!multi && picked.size == 1) picked[0] else pageIndex
        val history = messages
            .filter { !it.isError && !it.loading && it.text.isNotBlank() }
            .takeLast(6)
            .map { (if (it.fromUser) "user" else "assistant") to it.text }

        messages += AiMsg(nextId++, fromUser = true, text = userLabel, page = pageIndex + 1)
        messages += AiMsg(nextId++, fromUser = false, text = "", loading = true)
        busy = true

        job = ownScope.launch {
            try {
                val jpeg = if (multi) null else session.renderJpeg(targetPage)
                val extra: List<ByteArray> = if (multi && picked.size <= 3) {
                    picked.mapNotNull { session.renderJpeg(it) }
                } else {
                    emptyList()
                }
                val res = if (!multi && jpeg == null) {
                    SupabaseClient.AiAnswer(false, message = "تعذر تجهيز صورة الصفحة. حاول مرة ثانية.")
                } else {
                    SupabaseClient.askSlideAi(
                        action = action,
                        question = question,
                        jpeg = jpeg,
                        page = targetPage + 1,
                        subject = subject,
                        title = title,
                        fileUrl = fileUrl,
                        history = history,
                        pages = if (multi) picked.map { it + 1 } else emptyList(),
                        allPages = false,
                        extraImages = extra,
                        provider = provider
                    )
                }
                val idx = messages.indexOfLast { it.loading }
                val id = if (idx >= 0) messages[idx].id else nextId++
                val reply = if (res.ok && res.text.isNotBlank()) {
                    AiMsg(
                        id, fromUser = false, text = cleanAiMarkup(res.text), action = action, qid = res.qid,
                        providerName = res.providerName, switchedFrom = res.switchedFrom
                    )
                } else {
                    revealed += id
                    AiMsg(
                        id, fromUser = false, text = res.message ?: "لم يصل رد. حاول مرة ثانية.",
                        isError = true, action = action, retryAfter = res.retryAfter
                    )
                }
                if (idx >= 0) messages[idx] = reply else messages += reply
                if (!reply.isError) persist(cid, args, reply)
                if (res.remaining >= 0) remaining = res.remaining
                refreshStatus()
            } finally {
                val idx = messages.indexOfLast { it.loading }
                if (idx >= 0) messages.removeAt(idx)
                busy = false
                startCooldown()
            }
        }
    }

    fun retry(scope: CoroutineScope, session: PdfSession) {
        val a = lastArgs ?: return
        if (busy || cooling) return
        if (messages.isNotEmpty() && messages.last().isError) messages.removeAt(messages.lastIndex)
        if (messages.isNotEmpty() && messages.last().fromUser) messages.removeAt(messages.lastIndex)
        ask(scope, session, a.pageIndex, a.action, a.question, a.userLabel, a.subject, a.title, a.fileUrl)
    }

    fun cancel() {
        job?.cancel()
    }

    fun clear() = newChat()
}

@Stable
private class ListFollower(private val ls: LazyListState) {
    private var programmatic = false
    fun atBottom(): Boolean = !ls.canScrollForward
    fun userScrolling(): Boolean = ls.isScrollInProgress && !programmatic
    suspend fun toEnd() {
        programmatic = true
        try { ls.scrollBy(100_000f) } finally { programmatic = false }
    }
}

@Composable
fun SlideAiSheet(
    state: SlideAiState,
    session: PdfSession,
    pageIndex: Int,
    subject: String,
    title: String,
    fileUrl: String,
    initial: AiInitial? = null,
    onInitialConsumed: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val c = aiColors()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var showPicker by remember { mutableStateOf(false) }

    BackHandler(enabled = true) {
        if (showPicker) {
            showPicker = false
        } else {
            scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.sheetTop,
        contentColor = c.text,
        tonalElevation = 0.dp,
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 10.dp, bottom = 6.dp)
                    .width(42.dp)
                    .height(4.dp)
                    .background(c.muted.copy(alpha = 0.45f), CircleShape)
            )
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .background(Brush.verticalGradient(listOf(c.sheetTop, c.sheetBottom)))
        ) {
            AiConversation(
                c = c,
                state = state,
                session = session,
                pageIndex = pageIndex,
                subject = subject,
                title = title,
                fileUrl = fileUrl,
                initial = initial,
                onInitialConsumed = onInitialConsumed,
                showPicker = showPicker,
                onShowPicker = { showPicker = it },
                onClose = null,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun SlideAiSidePanel(
    state: SlideAiState,
    session: PdfSession,
    pageIndex: Int,
    subject: String,
    title: String,
    fileUrl: String,
    initial: AiInitial? = null,
    onInitialConsumed: () -> Unit = {},
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = aiColors()
    var showPicker by remember { mutableStateOf(false) }
    val shape = AppShapesPanel

    BackHandler(enabled = showPicker) { showPicker = false }

    Box(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.sheetTop, c.sheetBottom)))
            .border(BorderStroke(1.dp, c.border), shape)
    ) {
        AiConversation(
            c = c,
            state = state,
            session = session,
            pageIndex = pageIndex,
            subject = subject,
            title = title,
            fileUrl = fileUrl,
            initial = initial,
            onInitialConsumed = onInitialConsumed,
            showPicker = showPicker,
            onShowPicker = { showPicker = it },
            onClose = onDismiss,
            modifier = Modifier.fillMaxSize()
        )
    }
}

private val AppShapesPanel = RoundedCornerShape(28.dp)

@Composable
private fun AiConversation(
    c: AiColors,
    state: SlideAiState,
    session: PdfSession,
    pageIndex: Int,
    subject: String,
    title: String,
    fileUrl: String,
    initial: AiInitial?,
    onInitialConsumed: () -> Unit,
    showPicker: Boolean,
    onShowPicker: (Boolean) -> Unit,
    onClose: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val follower = remember(listState) { ListFollower(listState) }
    var input by remember { mutableStateOf("") }
    val inputFocus = remember { FocusRequester() }
    var tab by remember { mutableIntStateOf(0) }
    val pageNumber = pageIndex + 1
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    var learned by remember { mutableStateOf<List<String>>(emptyList()) }
    val pickedCount = state.pickedPages.size
    val suggestPage = if (pickedCount == 1) state.pickedPages.first() else pageIndex
    LaunchedEffect(fileUrl, suggestPage, pickedCount) {
        learned = if (pickedCount > 1 || fileUrl.isBlank()) emptyList()
        else SupabaseClient.slideAiSuggestions(fileUrl, suggestPage + 1)
    }
    val compact = onClose != null && imeOpen
    var cachedActions by remember { mutableStateOf<Set<String>>(emptySet()) }
    var cachedQs by remember { mutableStateOf<Set<String>>(emptySet()) }
    var typedCached by remember { mutableStateOf(false) }
    val canCache = state.messages.isEmpty() && pickedCount <= 1 && fileUrl.isNotBlank()
    val starters = remember(learned) { learned.cleanSuggestions().take(8) }
    LaunchedEffect(canCache, fileUrl, suggestPage, starters) {
        if (!canCache) {
            cachedActions = emptySet()
            cachedQs = emptySet()
        } else {
            val status = SupabaseClient.aiCacheStatus(fileUrl, suggestPage + 1, starters)
            if (status != null) {
                cachedActions = status.actions
                cachedQs = starters.filterIndexed { i, _ -> status.questions.getOrNull(i) == true }.toSet()
            }
        }
    }
    LaunchedEffect(input, canCache, fileUrl, suggestPage) {
        typedCached = false
        val q = input.trim()
        if (canCache && q.length >= 4) {
            delay(500)
            typedCached = SupabaseClient.aiCacheStatus(fileUrl, suggestPage + 1, listOf(q))?.questions?.firstOrNull() == true
        }
    }

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }
    LaunchedEffect(tab, state.chatId) {
        if (tab == 0 && state.messages.isNotEmpty()) {
            delay(120)
            listState.scrollToItem(state.messages.lastIndex)
        }
    }

    fun scopeSuffix(): String = when {
        state.pickedPages.size > 1 -> " · سلايدات " + pageRanges(state.pickedPages)
        state.pickedPages.size == 1 && state.pickedPages.first() != pageIndex -> " · سلايد " + (state.pickedPages.first() + 1)
        else -> ""
    }

    fun send(action: String, question: String, label: String) {
        state.ask(scope, session, pageIndex, action, question, label + scopeSuffix(), subject, title, fileUrl)
    }

    LaunchedEffect(Unit) {
        state.resetScope()
        state.refreshStatus()
        state.loadHistory(fileUrl, silent = state.history.isNotEmpty())
    }

    val openChat: (String) -> Unit = { id ->
        state.openChat(id) { ok ->
            if (ok) {
                tab = 0
            } else {
                Toast.makeText(context, "تعذر فتح المحادثة. تأكد من الاتصال وحاول مرة ثانية.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val startNew: () -> Unit = {
        state.newChat()
        tab = 0
    }

    LaunchedEffect(initial) {
        initial?.let {
            tab = 0
            if (it.action == AI_PREFILL) {
                input = it.question.take(1000)
                onInitialConsumed()
                delay(380)
                runCatching { inputFocus.requestFocus() }
            } else {
                send(it.action, it.question, it.label)
                onInitialConsumed()
            }
        }
    }

    val onRetry: () -> Unit = { state.retry(scope, session) }

    val lastMsg = state.messages.lastOrNull()
    val showFollowUps = state.revealTick >= 0 && !state.busy && lastMsg != null &&
        !lastMsg.fromUser && !lastMsg.isError && !lastMsg.loading && state.isRevealed(lastMsg.id)

    LaunchedEffect(showFollowUps, lastMsg?.id) {
        if (showFollowUps) {
            delay(60)
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            if (lastVisible >= state.messages.lastIndex) follower.toEnd()
        }
    }

    fun sendFollowUp(f: FollowUp) {
        send(f.action, f.question, f.label)
    }

    fun sendTyped() {
        val q = input.trim()
        if (q.isEmpty() || state.locked) return
        input = ""
        send("ask", q, q)
    }

    val insetModifier = if (onClose != null) {
        Modifier
            .consumeWindowInsets(WindowInsets.navigationBars)
            .imePadding()
            .padding(bottom = 10.dp)
    } else {
        Modifier
            .navigationBarsPadding()
            .imePadding()
    }

    Box(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(insetModifier)
                .padding(horizontal = 18.dp)
        ) {
            AiHeader(
                c = c,
                pageNumber = pageNumber,
                pageCount = session.pageCount,
                remaining = state.remaining,
                busy = state.busy,
                hasMessages = state.messages.isNotEmpty(),
                onClear = startNew,
                onClose = onClose,
                modifier = if (onClose != null) Modifier.padding(top = 14.dp) else Modifier
            )

            AiTabs(c = c, selected = tab) { tab = it }

            AnimatedVisibility(
                visible = state.providers.size > 1 && !compact && tab == 0,
                enter = fadeIn(tween(250)) + expandVertically(tween(300, easing = FastOutSlowInEasing)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(200))
            ) {
                ModelBar(c, state)
            }

            AnimatedVisibility(
                visible = state.messages.isNotEmpty() && !compact && tab == 0,
                enter = fadeIn(tween(250)) + expandVertically(tween(300, easing = FastOutSlowInEasing)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(200))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScopePill(c, scopeSummary(state, pageIndex)) { onShowPicker(true) }
                    AiQuick.entries.forEach { q ->
                        QuickChip(c, q, enabled = !state.locked) { send(q.action, "", q.label) }
                    }
                }
            }

            val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
              AnimatedContent(
                targetState = tab,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    val toHistory = targetState > initialState
                    val dir = (if (toHistory) 1 else -1) * (if (rtl) -1 else 1)
                    (fadeIn(tween(260, delayMillis = 60)) +
                        slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { dir * it / 5 }) togetherWith
                        (fadeOut(tween(140)) +
                            slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { -dir * it / 6 })
                },
                label = "ai_tab_body"
              ) { t ->
               if (t == 1) {
                AiHistoryPane(
                    c = c,
                    state = state,
                    fileUrl = fileUrl,
                    onOpen = openChat,
                    onNew = startNew
                )
               } else {
                AnimatedContent(
                    targetState = state.messages.isEmpty(),
                    modifier = Modifier.fillMaxSize(),
                    transitionSpec = {
                        (fadeIn(tween(280, delayMillis = 80)) + slideInVertically(tween(320)) { it / 12 }) togetherWith
                            fadeOut(tween(160))
                    },
                    label = "ai_body"
                ) { empty ->
                    if (empty) {
                        AiHero(
                            c = c,
                            session = session,
                            pageIndex = pageIndex,
                            enabled = !state.locked,
                            state = state,
                            onChangeScope = { onShowPicker(true) },
                            learned = learned,
                            cachedActions = cachedActions,
                            cachedQs = cachedQs,
                            lastChat = state.history.firstOrNull(),
                            resuming = state.openingId.isNotEmpty(),
                            onResume = { state.history.firstOrNull()?.let { openChat(it.id) } },
                            onSuggest = { q -> send("ask", q, q) }
                        ) { q -> send(q.action, "", q.label) }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.messages, key = { it.id }) { m ->
                                val canRetry = m.isError && m.id == lastMsg?.id && !state.locked
                                Appear(id = m.id, state = state) {
                                    AiBubble(c, m, state, follower, if (canRetry) onRetry else null)
                                }
                            }
                            if (showFollowUps && lastMsg != null) {
                                item(key = "follow_ups") {
                                    AppearStatic(delayMs = 0) {
                                        FollowUpRow(c, followUpsFor(lastMsg.action), enabled = !state.locked) { f -> sendFollowUp(f) }
                                    }
                                }
                            }
                            item { Spacer(Modifier.height(6.dp)) }
                        }
                    }
                }
               }
              }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = typedCached && input.isNotBlank(),
                enter = fadeIn(tween(220)) + expandVertically(tween(240, easing = FastOutSlowInEasing)),
                exit = fadeOut(tween(120)) + shrinkVertically(tween(160))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp, start = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PulseDot(colorA = c.brandA, colorB = c.brandB, size = 8.dp)
                    Text(
                        text = "سؤال مطروح سابقاً · جوابه فوري وبدون توكنات",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (c.dark) c.brandA else c.brandB
                    )
                }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = tab == 0,
                enter = fadeIn(tween(220)) + expandVertically(tween(260, easing = FastOutSlowInEasing)),
                exit = fadeOut(tween(120)) + shrinkVertically(tween(180))
            ) {
                AiInputBar(
                    c = c,
                    value = input,
                    onValueChange = { if (it.length <= 1000) input = it },
                    busy = state.busy,
                    cooling = state.cooling,
                    onSend = { sendTyped() },
                    onStop = { state.cancel() },
                    focusRequester = inputFocus
                )
            }
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = showPicker,
            enter = fadeIn(tween(220)) + slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it / 8 },
            exit = fadeOut(tween(160)) + slideOutVertically(tween(220)) { it / 10 }
        ) {
            ScopePicker(c, state, session, pageIndex) { onShowPicker(false) }
        }
    }
}

private val CHEM_TAG = Regex("\\{\\{chem\\|([^|}]*)\\|([^}]*)\\}\\}")

private class ChemRef(val name: String, val smiles: String)

private val DIAGRAM_TAG = Regex("\\{\\{diagram\\|([^}]*)\\}\\}\\s*(<svg[\\s\\S]*?</svg>)", RegexOption.IGNORE_CASE)

private class DiagramRef(val title: String, val svg: String)

private fun parseDiagram(text: String): DiagramRef? =
    DIAGRAM_TAG.find(text)?.let { DiagramRef(it.groupValues[1].trim(), it.groupValues[2]) }

private fun stripChem(text: String): String =
    DIAGRAM_TAG.replace(CHEM_TAG.replace(stripVizTags(text), ""), "").replace(Regex("\\n{3,}"), "\n\n").trim()

private fun parseChem(text: String): List<ChemRef> =
    CHEM_TAG.findAll(text)
        .map { ChemRef(it.groupValues[1].trim(), it.groupValues[2].trim()) }
        .filter { it.smiles.isNotEmpty() }
        .distinctBy { it.smiles }
        .take(5)
        .toList()

private fun AiColors.viz(): VizTheme = VizTheme(
    dark = dark,
    panel = panel,
    raised = panelRaised,
    border = border,
    text = text,
    muted = muted,
    brandA = brandA,
    brandB = brandB
)

private fun formatFormula(f: String): AnnotatedString = buildAnnotatedString {
    var sub = false
    var prev = ' '
    for (ch in f) {
        val isSub = ch.isDigit() && (sub || prev.isLetter() || prev == ')')
        if (isSub) {
            withStyle(SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = 11.sp)) { append(ch) }
        } else {
            append(ch)
        }
        sub = isSub
        prev = ch
    }
}

private fun chemFailText(reason: String?): String = when (reason) {
    "no_rdkit" -> "رسم التراكيب غير مفعّل على السيرفر"
    "invalid" -> "تعذر رسم هذا التركيب (صيغة غير صالحة)"
    "network", "http" -> "تعذر الاتصال برسم التراكيب"
    else -> "تعذر رسم التركيب"
}

private object ChemCache {
    val map = HashMap<String, SupabaseClient.ChemDepict>()
}

@Composable
private fun DiagramCard(c: AiColors, ref: DiagramRef) {
    val shape = RoundedCornerShape(18.dp)
    val ink = Color(0xFF1F2933)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (ref.title.isNotBlank()) {
            Text(
                text = ref.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = c.text
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            SvgIcon(svg = ref.svg, tint = ink, diagram = true, modifier = Modifier.fillMaxWidth().aspectRatio(1.25f))
        }
    }
}

@Composable
private fun ChemSection(c: AiColors, items: List<ChemRef>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { ChemCard(c, it) }
    }
}

@Composable
private fun ChemCard(c: AiColors, ref: ChemRef) {
    val result by produceState<SupabaseClient.ChemDepict?>(ChemCache.map[ref.smiles], ref.smiles) {
        if (value == null) {
            val r = SupabaseClient.depictChem(ref.smiles)
            if (r.ok) ChemCache.map[ref.smiles] = r
            value = r
        }
    }
    val bmp = remember(result) {
        result?.png?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
    }
    var show3d by remember(ref.smiles) { mutableStateOf(false) }
    val shape = RoundedCornerShape(18.dp)
    val ink = Color(0xFF5A6673)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Science,
                contentDescription = null,
                tint = if (c.dark) c.brandA else c.brandB,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = ref.name.ifBlank { "Structure" },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            val pressSrc = remember { MutableInteractionSource() }
            val pressed by pressSrc.collectIsPressedAsState()
            val pressScale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.55f), label = "3d")
            Row(
                modifier = Modifier
                    .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (show3d) c.brandB else c.panelRaised)
                    .clickable(interactionSource = pressSrc, indication = null) { show3d = !show3d }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ViewInAr,
                    contentDescription = null,
                    tint = if (show3d) c.onBrand else c.text,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "3D",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (show3d) c.onBrand else c.text
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val r = result
            when {
                r == null -> CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = ink
                )
                bmp != null -> Image(
                    bitmap = bmp,
                    contentDescription = ref.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(6.dp)
                )
                else -> Text(
                    text = chemFailText(r.reason),
                    style = MaterialTheme.typography.bodySmall,
                    color = ink,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
        val r = result
        if (r != null && r.ok) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = formatFormula(r.formula),
                    style = MaterialTheme.typography.titleSmall,
                    color = c.text
                )
                if (r.mw.isNotBlank()) {
                    Text(
                        text = "${r.mw} g/mol",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.muted
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = show3d,
            enter = fadeIn(tween(300, easing = MotionSpecs.EmphasizedEasing)) + expandVertically(tween(300, easing = MotionSpecs.EmphasizedEasing)),
            exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
        ) {
            VizCard(molRef(ref.name.ifBlank { "Structure" }, ref.smiles), c.viz(), framed = false)
        }
    }
}

private const val MAX_PICK = 12

private const val COOLDOWN_MS = 5000L

private fun pageRanges(pages: Set<Int>): String {
    val s = pages.sorted().map { it + 1 }
    if (s.isEmpty()) return ""
    val out = ArrayList<String>()
    var a = s[0]
    var b = a
    for (i in 1 until s.size) {
        if (s[i] == b + 1) {
            b = s[i]
        } else {
            out.add(if (a == b) "$a" else "$a–$b")
            a = s[i]
            b = a
        }
    }
    out.add(if (a == b) "$a" else "$a–$b")
    return out.joinToString("، ")
}

private fun scopeSummary(state: SlideAiState, pageIndex: Int): String = when {
    state.pickedPages.size > 1 -> "${state.pickedPages.size} سلايدات"
    state.pickedPages.size == 1 -> "سلايد ${state.pickedPages.first() + 1}"
    else -> "سلايد ${pageIndex + 1}"
}

@Composable
private fun ScopePill(c: AiColors, text: String, onClick: () -> Unit) {
    val shape = CircleShape
    Row(
        modifier = Modifier
            .clip(shape)
            .background(c.brandA.copy(alpha = 0.14f))
            .border(BorderStroke(1.dp, c.brandA.copy(alpha = 0.45f)), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Layers,
            contentDescription = null,
            tint = if (c.dark) c.brandA else c.brandB,
            modifier = Modifier.size(18.dp)
        )
        Text(text = text, style = MaterialTheme.typography.labelLarge, color = c.text)
        Icon(
            imageVector = Icons.Default.ExpandMore,
            contentDescription = null,
            tint = c.muted,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun ScopeCard(c: AiColors, state: SlideAiState, session: PdfSession, pageIndex: Int, onChange: () -> Unit) {
    val picked = state.pickedPages
    val single: Int? = when {
        picked.isEmpty() -> pageIndex
        picked.size == 1 -> picked.first()
        else -> null
    }
    var thumb by remember(session, single) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(session, single) {
        val p = single
        thumb = if (p == null) null else withContext(Dispatchers.Default) {
            session.renderJpeg(p, 420, 70)?.let {
                BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap()
            }
        }
    }
    val title = when {
        picked.size > 1 -> "${picked.size} سلايدات"
        picked.size == 1 && picked.first() != pageIndex -> "سلايد محدد"
        else -> "السلايد الحالي"
    }
    val sub = when {
        picked.size > 1 -> pageRanges(picked)
        else -> "الصفحة ${(single ?: pageIndex) + 1} من ${session.pageCount}"
    }
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable(onClick = onChange)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        val tShape = RoundedCornerShape(12.dp)
        Box(
            modifier = Modifier
                .height(66.dp)
                .width(108.dp)
                .clip(tShape)
                .background(c.panelRaised)
                .border(BorderStroke(1.dp, c.border), tShape),
            contentAlignment = Alignment.Center
        ) {
            val img = thumb
            if (single == null) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = null,
                    tint = if (c.dark) c.brandA else c.brandB,
                    modifier = Modifier.size(30.dp)
                )
            } else {
                Crossfade(targetState = img, animationSpec = tween(300), label = "scope_thumb") { b ->
                    if (b != null) {
                        Image(
                            bitmap = b,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = c.muted)
            Text(
                text = sub,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                maxLines = 2
            )
        }
        Text(
            text = "تغيير",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = if (c.dark) c.brandA else c.brandB,
            modifier = Modifier
                .clip(CircleShape)
                .background(c.brandA.copy(alpha = 0.14f))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun RowScope.SegItem(c: AiColors, label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        targetValue = if (selected) c.brandA.copy(alpha = if (c.dark) 0.30f else 0.22f) else Color.Transparent,
        animationSpec = tween(200),
        label = "seg_bg"
    )
    Box(
        modifier = Modifier
            .weight(1f)
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) c.text else c.muted
        )
    }
}

@Composable
private fun SlideThumb(
    c: AiColors,
    state: SlideAiState,
    session: PdfSession,
    index: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    var img by remember(session, index) { mutableStateOf(state.thumbs[index]) }
    LaunchedEffect(session, index) {
        if (img == null) {
            val bmp = withContext(Dispatchers.Default) {
                session.renderJpeg(index, 280, 62)?.let {
                    BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap()
                }
            }
            if (bmp != null) {
                state.thumbs[index] = bmp
                img = bmp
            }
        }
    }
    val shape = RoundedCornerShape(14.dp)
    val borderColor by animateColorAsState(
        targetValue = if (selected) c.brandA else c.border,
        animationSpec = tween(180),
        label = "thumb_border"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.35f)
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(if (selected) 2.dp else 1.dp, borderColor), shape)
            .clickable(onClick = onClick)
    ) {
        Crossfade(targetState = img, animationSpec = tween(250), label = "thumb_img") { b ->
            if (b != null) {
                Image(
                    bitmap = b,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(4.dp)
                )
            }
        }
        Text(
            text = "${index + 1}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = c.text,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp)
                .background(c.sheetBottom.copy(alpha = 0.82f), CircleShape)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        )
        if (selected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(20.dp)
                    .background(c.brandA, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = c.onBrand,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun ScopePicker(
    c: AiColors,
    state: SlideAiState,
    session: PdfSession,
    pageIndex: Int,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val picked = state.pickedPages
    val mode = if (picked.isEmpty()) 0 else 1
    val summary = when {
        picked.size > 1 -> "${picked.size} من $MAX_PICK سلايد · ${pageRanges(picked)}"
        picked.size == 1 -> "سلايد ${picked.first() + 1}"
        else -> "السلايد الحالي · ${pageIndex + 1}"
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.sheetTop, c.sheetBottom)))
            .navigationBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "اختر السلايدات",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = c.text
                )
                Text(text = summary, style = MaterialTheme.typography.bodySmall, color = c.muted)
            }
            Text(
                text = "تم",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = c.onBrand,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(c.brandA, c.brandB)))
                    .clickable(onClick = onClose)
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(c.panel, CircleShape)
                .border(BorderStroke(1.dp, c.border), CircleShape)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SegItem(c, "الحالي", mode == 0) { state.resetScope() }
            SegItem(c, "محدد", mode == 1) {
                if (mode != 1) {
                    state.resetScope()
                    state.togglePage(pageIndex)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(session.pageCount) { idx ->
                SlideThumb(
                    c = c,
                    state = state,
                    session = session,
                    index = idx,
                    selected = idx in picked || (mode == 0 && idx == pageIndex)
                ) {
                    if (!state.togglePage(idx)) {
                        Toast.makeText(context, "الحد الأقصى $MAX_PICK سلايد", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

@Composable
private fun AiHeader(
    c: AiColors,
    pageNumber: Int,
    pageCount: Int,
    remaining: Int,
    busy: Boolean,
    hasMessages: Boolean,
    onClear: () -> Unit,
    onClose: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(top = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .background(Brush.linearGradient(listOf(c.brandA, c.brandB)), RoundedCornerShape(16.dp))
                .border(BorderStroke(1.dp, c.border), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            val breathe = rememberInfiniteTransition(label = "breathe")
            val pulse by breathe.animateFloat(
                initialValue = 1f,
                targetValue = if (busy) 0.55f else 1f,
                animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "breathe_alpha"
            )
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = c.onBrand,
                modifier = Modifier.size(24.dp).graphicsLayer { alpha = pulse }
            )
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                text = ASSISTANT_NAME,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = c.text
            )
            AnimatedContent(
                targetState = pageNumber to remaining,
                transitionSpec = {
                    (slideInVertically(tween(260)) { it / 2 } + fadeIn(tween(260))) togetherWith
                        (slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(160)))
                },
                label = "ai_sub"
            ) { (p, r) ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "الصفحة $p من $pageCount",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.muted
                    )
                    if (r in 0..998) {
                        Text(
                            text = "المتبقي اليوم $r",
                            style = MaterialTheme.typography.labelSmall,
                            color = c.text.copy(alpha = 0.85f),
                            modifier = Modifier
                                .background(c.panelRaised, CircleShape)
                                .border(BorderStroke(1.dp, c.border), CircleShape)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = hasMessages,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut()
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(c.panel, CircleShape)
                    .border(BorderStroke(1.dp, c.border), CircleShape)
                    .clip(CircleShape)
                    .clickable(onClick = onClear),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "محادثة جديدة",
                    tint = if (c.dark) c.brandA else c.brandB,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        if (onClose != null) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(c.panel, CircleShape)
                    .border(BorderStroke(1.dp, c.border), CircleShape)
                    .clip(CircleShape)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق المساعد",
                    tint = c.muted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

private val StateReady = Color(0xFF3FB26B)
private val StateBusy = Color(0xFFE8A93A)

@Composable
private fun stateColor(c: AiColors, state: String): Color = when (state) {
    "ready" -> StateReady
    "busy" -> StateBusy
    else -> c.errorText
}

@Composable
private fun StatusDot(c: AiColors, state: String) {
    val color by animateColorAsState(stateColor(c, state), tween(300), label = "dot_color")
    Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
}

private fun stateLabel(p: SupabaseClient.AiProvider): String = when (p.state) {
    "ready" -> "جاهز"
    "busy" -> if (p.retryIn > 0) "مشغول ${p.retryIn} ث" else "مشغول"
    else -> "انتهت الحصة"
}

@Composable
private fun ModelBar(c: AiColors, state: SlideAiState) {
    val list = state.providers
    var open by remember { mutableStateOf(false) }
    val current = list.firstOrNull { it.id == state.provider }
    val autoState = if (list.any { it.state == "ready" }) "ready" else if (list.any { it.state == "busy" }) "busy" else "limit"
    val rot by animateFloatAsState(if (open) 180f else 0f, tween(240, easing = FastOutSlowInEasing), label = "model_chevron")
    Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(c.panel)
                .border(BorderStroke(1.dp, c.border), CircleShape)
                .clickable {
                    open = !open
                    if (open) state.refreshStatus()
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusDot(c, current?.state ?: autoState)
            Text(
                text = "النموذج: " + (current?.name ?: "تلقائي"),
                style = MaterialTheme.typography.labelLarge,
                color = c.text
            )
            Icon(
                imageVector = Icons.Default.ExpandMore,
                contentDescription = null,
                tint = c.muted,
                modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = rot }
            )
        }
        AnimatedVisibility(
            visible = open,
            enter = fadeIn(tween(220)) + expandVertically(tween(280, easing = FastOutSlowInEasing)),
            exit = fadeOut(tween(140)) + shrinkVertically(tween(200))
        ) {
            Column(
                modifier = Modifier
                    .padding(top = 8.dp)
                    .fillMaxWidth()
                    .background(c.panel, RoundedCornerShape(18.dp))
                    .border(BorderStroke(1.dp, c.border), RoundedCornerShape(18.dp))
                    .padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                ModelRow(
                    c = c,
                    selected = state.provider == "auto",
                    title = "تلقائي",
                    hint = "يختار الأنسب ويتحوّل عند انتهاء الحد",
                    stateKey = autoState,
                    status = if (autoState == "limit") "انتهت الحصة" else "ذكي"
                ) {
                    state.pickProvider("auto")
                    open = false
                }
                list.forEach { p ->
                    ModelRow(
                        c = c,
                        selected = state.provider == p.id,
                        title = p.name,
                        hint = p.hint,
                        stateKey = p.state,
                        status = stateLabel(p)
                    ) {
                        state.pickProvider(p.id)
                        open = false
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelRow(
    c: AiColors,
    selected: Boolean,
    title: String,
    hint: String,
    stateKey: String,
    status: String,
    onClick: () -> Unit
) {
    val bg by animateColorAsState(
        if (selected) c.brandA.copy(alpha = if (c.dark) 0.22f else 0.16f) else Color.Transparent,
        tween(200),
        label = "model_row_bg"
    )
    val ring by animateColorAsState(if (selected) c.brandA else c.border, tween(200), label = "model_row_ring")
    val dotScale by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.65f, stiffness = 500f), label = "model_row_dot")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier.size(20.dp).border(BorderStroke(2.dp, ring), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .graphicsLayer {
                        scaleX = dotScale
                        scaleY = dotScale
                    }
                    .background(c.brandA, CircleShape)
            )
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = c.text
            )
            Text(text = hint, style = MaterialTheme.typography.labelSmall, color = c.muted)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StatusDot(c, stateKey)
            Text(text = status, style = MaterialTheme.typography.labelSmall, color = c.muted)
        }
    }
}

@Composable
private fun AiHero(
    c: AiColors,
    session: PdfSession,
    pageIndex: Int,
    enabled: Boolean,
    state: SlideAiState,
    onChangeScope: () -> Unit,
    learned: List<String>,
    cachedActions: Set<String>,
    cachedQs: Set<String>,
    lastChat: SupabaseClient.AiChatInfo?,
    resuming: Boolean,
    onResume: () -> Unit,
    onSuggest: (String) -> Unit,
    onPick: (AiQuick) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = 14.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        ScopeCard(c, state, session, pageIndex, onChangeScope)

        if (lastChat != null) {
            AppearStatic(delayMs = 40) {
                ResumeCard(c, lastChat, resuming, onResume)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "كيف أساعدك بهذا السلايد؟",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = c.text
            )
            if (cachedActions.isNotEmpty() || cachedQs.isNotEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PulseDot(colorA = c.brandA, colorB = c.brandB, size = 7.dp)
                    Text(
                        text = "النقطة الزرقاء = جواب جاهز، يظهر فوراً وبدون توكنات",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.muted
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AiQuick.entries.chunked(2).forEachIndexed { row, pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEachIndexed { col, q ->
                        Box(modifier = Modifier.weight(1f)) {
                            AppearStatic(delayMs = 70 + (row * 2 + col) * 70) {
                                ActionCard(c, q, enabled) { onPick(q) }
                            }
                            CachedDot(
                                c = c,
                                visible = q.action in cachedActions,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 6.dp, end = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (learned.isNotEmpty()) {
                Text(
                    text = "أسئلة سألها زملاؤك عن هذا السلايد",
                    style = MaterialTheme.typography.labelLarge,
                    color = c.muted
                )
            }
            learned.cleanSuggestions().forEachIndexed { i, q ->
                AppearStatic(delayMs = 330 + i * 80) {
                    SuggestionRow(c, q, enabled, cached = q in cachedQs) { onSuggest(q) }
                }
            }
        }
    }
}

@Composable
private fun SlideContextCard(c: AiColors, session: PdfSession, pageIndex: Int) {
    var thumb by remember(session, pageIndex) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(session, pageIndex) {
        thumb = withContext(Dispatchers.Default) {
            session.renderJpeg(pageIndex, 420, 70)?.let {
                BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap()
            }
        }
    }
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.panel, shape)
            .border(BorderStroke(1.dp, c.border), shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        val tShape = RoundedCornerShape(12.dp)
        Box(
            modifier = Modifier
                .height(66.dp)
                .width(108.dp)
                .clip(tShape)
                .background(c.panelRaised)
                .border(BorderStroke(1.dp, c.border), tShape),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = thumb, animationSpec = tween(300), label = "thumb") { img ->
                if (img != null) {
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                text = "السلايد الحالي",
                style = MaterialTheme.typography.labelMedium,
                color = c.muted
            )
            Text(
                text = "الصفحة ${pageIndex + 1} من ${session.pageCount}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = c.text
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(7.dp).background(Color(0xFF2F9E6E), CircleShape))
                Text(
                    text = "جاهز للقراءة",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.muted
                )
            }
        }
    }
}

@Composable
private fun ActionCard(c: AiColors, q: AiQuick, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 420f),
        label = "card_press"
    )
    val iconScale by animateFloatAsState(
        targetValue = if (pressed) 1.12f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 380f),
        label = "card_icon"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(104.dp)
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                alpha = if (enabled) 1f else 0.5f
            }
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        val iShape = RoundedCornerShape(14.dp)
        Box(
            modifier = Modifier
                .size(44.dp)
                .graphicsLayer { scaleX = iconScale; scaleY = iconScale }
                .background(
                    Brush.linearGradient(listOf(c.brandA.copy(alpha = 0.26f), c.brandB.copy(alpha = 0.14f))),
                    iShape
                )
                .border(BorderStroke(1.dp, c.brandA.copy(alpha = 0.30f)), iShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = q.icon,
                contentDescription = null,
                tint = if (c.dark) c.brandA else c.brandB,
                modifier = Modifier.size(24.dp)
            )
        }
        Text(
            text = q.label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = c.text,
            maxLines = 1
        )
    }
}

@Composable
private fun SuggestionRow(c: AiColors, text: String, enabled: Boolean, cached: Boolean = false, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 420f),
        label = "suggest_press"
    )
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                alpha = if (enabled) 1f else 0.5f
            }
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        val iShape = RoundedCornerShape(12.dp)
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(c.panelRaised, iShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.QuestionAnswer,
                contentDescription = null,
                tint = if (c.dark) c.brandA else c.brandB,
                modifier = Modifier.size(20.dp)
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Medium,
            color = c.text,
            modifier = Modifier.weight(1f)
        )
        CachedDot(c = c, visible = cached)
    }
}

@Composable
private fun CachedDot(c: AiColors, visible: Boolean, modifier: Modifier = Modifier) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(300), label = "cached_dot_alpha")
    if (a > 0.01f) {
        PulseDot(
            colorA = c.brandA,
            colorB = c.brandB,
            size = 9.dp,
            modifier = modifier.graphicsLayer { alpha = a }
        )
    }
}

@Composable
private fun FollowUpRow(c: AiColors, items: List<FollowUp>, enabled: Boolean, onPick: (FollowUp) -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items.forEach { f ->
                val interaction = remember { MutableInteractionSource() }
                val pressed by interaction.collectIsPressedAsState()
                val scale by animateFloatAsState(
                    targetValue = if (pressed) 0.94f else 1f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                    label = "follow_press"
                )
                Text(
                    text = f.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = c.text,
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = scale; scaleY = scale
                            alpha = if (enabled) 1f else 0.45f
                        }
                        .clip(CircleShape)
                        .background(c.panel)
                        .border(BorderStroke(1.dp, c.border), CircleShape)
                        .clickable(interactionSource = interaction, indication = null, enabled = enabled) { onPick(f) }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickChip(c: AiColors, q: AiQuick, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "chip_press"
    )
    Row(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                alpha = if (enabled) 1f else 0.45f
            }
            .background(c.panel, CircleShape)
            .border(BorderStroke(1.dp, c.border), CircleShape)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(imageVector = q.icon, contentDescription = null, tint = c.muted, modifier = Modifier.size(18.dp))
        Text(text = q.label, style = MaterialTheme.typography.labelLarge, color = c.text)
    }
}

@Composable
private fun AiBubble(c: AiColors, m: AiMsg, state: SlideAiState, follower: ListFollower, onRetry: (() -> Unit)?) {
    if (m.fromUser) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .background(
                        c.userFill,
                        RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 6.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                if (m.page > 0) {
                    Text(
                        text = "الصفحة ${m.page}",
                        style = MaterialTheme.typography.labelSmall,
                        color = c.userText.copy(alpha = 0.6f)
                    )
                }
                Text(
                    text = m.text,
                    style = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, textDirection = TextDirection.Content),
                    color = c.userText
                )
            }
        }
        return
    }

    val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 6.dp, bottomStart = 20.dp)
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .background(if (m.isError) c.errorFill else c.panel, shape)
                .border(BorderStroke(1.dp, c.border), shape)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (m.loading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MiniBadge(c, active = true)
                    TypingDots(c.text)
                    Text(
                        text = "أقرأ السلايد...",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
            } else {
                AnswerBody(c, m, state, follower, onRetry)
            }
        }
    }
}

@Composable
private fun MiniBadge(c: AiColors, active: Boolean) {
    val breathe = rememberInfiniteTransition(label = "mini_breathe")
    val a by breathe.animateFloat(
        initialValue = 1f,
        targetValue = if (active) 0.5f else 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "mini_alpha"
    )
    Box(
        modifier = Modifier
            .size(24.dp)
            .background(Brush.linearGradient(listOf(c.brandA, c.brandB)), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = c.onBrand,
            modifier = Modifier.size(13.dp).graphicsLayer { alpha = a }
        )
    }
}

@Composable
private fun AnswerBody(c: AiColors, m: AiMsg, state: SlideAiState, follower: ListFollower, onRetry: (() -> Unit)?) {
    val already = remember(m.id) { state.isRevealed(m.id) }
    val parts = remember(m.id, m.text, m.isError) {
        if (m.isError) SplitAnswer(m.text, null) else splitAnswers(stripChem(m.text))
    }
    val chems = remember(m.id, m.text, m.isError) {
        if (m.isError) emptyList() else parseChem(m.text)
    }
    val diagram = remember(m.id, m.text, m.isError) {
        if (m.isError || chems.isNotEmpty()) null else parseDiagram(m.text)
    }
    val viz = remember(m.id, m.text, m.isError) {
        if (m.isError) emptyList() else parseViz(m.text)
    }
    val rich = remember(m.id, parts, c.text) {
        if (m.isError) AnnotatedString(parts.body) else buildRichAnnotated(parts.body, c.text)
    }
    val total = rich.length
    var shown by remember(m.id) {
        mutableIntStateOf(if (already) total else (state.progress[m.id] ?: 0).coerceIn(0, total))
    }
    var typing by remember(m.id) { mutableStateOf(!already) }

    LaunchedEffect(m.id) {
        if (!already) {
            val step = max(2, total / 130)
            var following = true
            while (shown < total) {
                if (follower.userScrolling()) following = false
                else if (follower.atBottom()) following = true
                shown = min(total, shown + step)
                state.progress[m.id] = shown
                delay(16)
                if (following) follower.toEnd()
            }
            delay(320)
            if (following) follower.toEnd()
        }
        typing = false
        state.markRevealed(m.id)
    }

    if (!m.isError) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MiniBadge(c, active = typing)
            Text(
                text = ASSISTANT_NAME,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = c.muted
            )
            if (m.providerName.isNotBlank()) {
                Text(
                    text = "· ${m.providerName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.muted.copy(alpha = 0.75f)
                )
            }
        }
        if (m.switchedFrom.isNotBlank() && m.providerName.isNotBlank()) {
            SwitchNotice(c, m.id, "انتقل تلقائياً من ${m.switchedFrom} إلى ${m.providerName}")
        }
    }

    SelectionContainer {
        Text(
            text = if (shown >= total) rich else rich.subSequence(0, shown),
            style = TextStyle(fontSize = 15.sp, lineHeight = 25.sp, textDirection = TextDirection.Content),
            color = if (m.isError) c.errorText else c.text,
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { shown = total }
        )
    }

    if (chems.isNotEmpty()) {
        AnimatedVisibility(
            visible = !typing,
            enter = fadeIn(tween(250)) + expandVertically(tween(250))
        ) {
            ChemSection(c, chems)
        }
    }

    if (diagram != null) {
        AnimatedVisibility(
            visible = !typing,
            enter = fadeIn(tween(250)) + expandVertically(tween(250))
        ) {
            DiagramCard(c, diagram)
        }
    }

    if (viz.isNotEmpty()) {
        AnimatedVisibility(
            visible = !typing,
            enter = fadeIn(tween(250)) + expandVertically(tween(250))
        ) {
            VizSection(viz, c.viz())
        }
    }

    val hiddenAnswers = parts.answers
    if (hiddenAnswers != null) {
        AnimatedVisibility(
            visible = !typing,
            enter = fadeIn(tween(250)) + expandVertically(tween(250))
        ) {
            AnswersReveal(c, hiddenAnswers)
        }
    }

    if (m.isError && onRetry != null) {
        RetryButton(c, m.retryAfter, onRetry)
    }

    AnimatedVisibility(
        visible = !m.isError && !typing,
        enter = fadeIn(tween(250)) + expandVertically(tween(250))
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CopyButton(c, stripRich(stripChem(m.text)))
            if (m.qid.isNotBlank()) ReportButton(c, m.qid)
        }
    }
}

@Composable
private fun ReportButton(c: AiColors, qid: String) {
    val scope = rememberCoroutineScope()
    var phase by remember(qid) { mutableStateOf(0) }
    val tint by animateColorAsState(if (phase == 2) c.text else c.muted, label = "report_tint")
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .clickable(enabled = phase == 0) {
                phase = 1
                scope.launch {
                    val ok = SupabaseClient.reportAiAnswer(qid)
                    phase = if (ok) 2 else 0
                }
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = if (phase == 2) Icons.Default.Check else Icons.Default.Flag,
            contentDescription = "الإبلاغ عن جواب غير صحيح",
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = when (phase) {
                2 -> "تم التبليغ"
                1 -> "جارٍ التبليغ"
                else -> "غير صحيح"
            },
            style = MaterialTheme.typography.labelMedium,
            color = tint
        )
    }
}

@Composable
private fun AnswersReveal(c: AiColors, answers: String) {
    var open by remember { mutableStateOf(false) }
    val rich = remember(answers, c.text) { buildRichAnnotated(answers, c.text) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(c.panelRaised)
                .border(BorderStroke(1.dp, c.border), CircleShape)
                .clickable { open = !open }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = if (open) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = null,
                tint = c.text,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = if (open) "إخفاء الأجوبة" else "إظهار الأجوبة",
                style = MaterialTheme.typography.labelLarge,
                color = c.text
            )
        }
        AnimatedVisibility(
            visible = open,
            enter = fadeIn(tween(200)) + expandVertically(tween(260)),
            exit = fadeOut(tween(120)) + shrinkVertically(tween(180))
        ) {
            SelectionContainer {
                Text(
                    text = rich,
                    style = TextStyle(fontSize = 15.sp, lineHeight = 25.sp, textDirection = TextDirection.Content),
                    color = c.text
                )
            }
        }
    }
}

@Composable
private fun RetryButton(c: AiColors, wait: Int, onClick: () -> Unit) {
    var left by remember(wait) { mutableIntStateOf(wait) }
    LaunchedEffect(wait) {
        while (left > 0) {
            delay(1000)
            left -= 1
        }
    }
    val ready = left <= 0
    val alpha by animateFloatAsState(if (ready) 1f else 0.55f, tween(250), label = "retry_alpha")
    Row(
        modifier = Modifier
            .graphicsLayer { this.alpha = alpha }
            .clip(CircleShape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), CircleShape)
            .clickable(enabled = ready, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = null,
            tint = c.errorText,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = if (ready) "إعادة المحاولة" else "إعادة المحاولة بعد $left ث",
            style = MaterialTheme.typography.labelLarge,
            color = c.errorText
        )
    }
}

@Composable
private fun SwitchNotice(c: AiColors, id: Long, text: String) {
    var shown by remember(id) { mutableStateOf(false) }
    LaunchedEffect(id) {
        delay(300)
        shown = true
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(260)) + expandVertically(tween(260, easing = FastOutSlowInEasing)),
        exit = fadeOut(tween(120))
    ) {
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(c.brandA.copy(alpha = 0.14f))
                .border(BorderStroke(1.dp, c.brandA.copy(alpha = 0.35f)), CircleShape)
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.SwapHoriz,
                contentDescription = null,
                tint = if (c.dark) c.brandA else c.brandB,
                modifier = Modifier.size(14.dp)
            )
            Text(text = text, style = MaterialTheme.typography.labelSmall, color = c.text.copy(alpha = 0.85f))
        }
    }
}

@Composable
private fun CopyButton(c: AiColors, text: String) {
    val ctx = LocalContext.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }
    val tint by animateColorAsState(if (copied) c.text else c.muted, label = "copy_tint")
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .clickable {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("pharma-ai", text))
                copied = true
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AnimatedContent(
            targetState = copied,
            transitionSpec = { (fadeIn(tween(150)) + scaleIn()) togetherWith (fadeOut(tween(100)) + scaleOut()) },
            label = "copy_icon"
        ) { done ->
            Icon(
                imageVector = if (done) Icons.Default.Check else Icons.Default.ContentCopy,
                contentDescription = "نسخ",
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
        }
        Text(
            text = if (copied) "تم النسخ" else "نسخ",
            style = MaterialTheme.typography.labelMedium,
            color = tint
        )
    }
}

@Composable
private fun TypingDots(color: Color) {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(550, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 160)
                ),
                label = "dot$i"
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        alpha = a
                        scaleX = 0.7f + 0.3f * a
                        scaleY = 0.7f + 0.3f * a
                    }
                    .background(color, CircleShape)
            )
        }
    }
}

@Composable
private fun Appear(id: Long, state: SlideAiState, content: @Composable () -> Unit) {
    val animate = remember(id) { state.consumeAppear(id) }
    var on by remember(id) { mutableStateOf(!animate) }
    LaunchedEffect(id) { on = true }
    AnimatedVisibility(
        visible = on,
        enter = fadeIn(tween(260)) + slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it / 6 }
    ) { content() }
}

@Composable
private fun AppearStatic(delayMs: Int, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        on = true
    }
    AnimatedVisibility(
        visible = on,
        enter = fadeIn(tween(300)) + slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it / 5 }
    ) { content() }
}

@Composable
private fun AiInputBar(
    c: AiColors,
    value: String,
    onValueChange: (String) -> Unit,
    busy: Boolean,
    cooling: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
    focusRequester: FocusRequester? = null
) {
    val canSend = value.isNotBlank() && !busy && !cooling
    val active = canSend || busy
    val btnAlpha by animateFloatAsState(if (active) 1f else 0.0f, tween(200), label = "send_alpha")
    val shape = RoundedCornerShape(30.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 14.dp)
            .background(c.panel, shape)
            .border(BorderStroke(1.dp, c.border), shape)
            .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 32.dp)
                .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
            textStyle = TextStyle(
                fontSize = 15.sp,
                lineHeight = 22.sp,
                color = c.text,
                textDirection = TextDirection.Content
            ),
            cursorBrush = SolidColor(c.text),
            maxLines = 6,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(
                            text = "اسأل $ASSISTANT_NAME...",
                            style = TextStyle(fontSize = 15.sp),
                            color = c.muted
                        )
                    }
                    inner()
                }
            }
        )
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(c.panelRaised, CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(c.brandA.copy(alpha = btnAlpha), c.brandB.copy(alpha = btnAlpha))
                    ),
                    CircleShape
                )
                .clip(CircleShape)
                .clickable(enabled = active) { if (busy) onStop() else onSend() },
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = busy,
                transitionSpec = { (fadeIn(tween(150)) + scaleIn()) togetherWith (fadeOut(tween(100)) + scaleOut()) },
                label = "send_icon"
            ) { isBusy ->
                Icon(
                    imageVector = if (isBusy) Icons.Default.Stop else Icons.AutoMirrored.Filled.Send,
                    contentDescription = if (isBusy) "إيقاف" else "إرسال",
                    tint = if (active) c.onBrand else c.muted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}


private fun agoText(ms: Long): String {
    val d = System.currentTimeMillis() - ms
    val min = d / 60_000
    return when {
        ms <= 0 -> ""
        min < 1 -> "الآن"
        min < 60 -> "قبل $min د"
        min < 60 * 24 -> "قبل ${min / 60} س"
        min < 60 * 48 -> "أمس"
        min < 60 * 24 * 7 -> "قبل ${min / (60 * 24)} أيام"
        else -> SimpleDateFormat("d/M/yyyy", Locale.US).format(Date(ms))
    }
}

private fun questionsOf(count: Int): Int = ((count + 1) / 2).coerceAtLeast(1)

@Composable
private fun AiTabs(c: AiColors, selected: Int, onSelect: (Int) -> Unit) {
    val bias by animateFloatAsState(
        targetValue = if (selected == 0) -1f else 1f,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 420f),
        label = "ai_tab_bias"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .background(c.panel, CircleShape)
            .border(BorderStroke(1.dp, c.border), CircleShape)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.5f)
                .height(40.dp)
                .align(BiasAlignment(bias, 0f))
                .background(
                    Brush.linearGradient(
                        listOf(
                            c.brandA.copy(alpha = if (c.dark) 0.34f else 0.28f),
                            c.brandB.copy(alpha = if (c.dark) 0.26f else 0.20f)
                        )
                    ),
                    CircleShape
                )
        )
        Row(modifier = Modifier.fillMaxWidth()) {
            AiTabLabel(c, "المحادثة", Icons.Default.AutoAwesome, selected == 0) { onSelect(0) }
            AiTabLabel(c, "السجل", Icons.Default.History, selected == 1) { onSelect(1) }
        }
    }
}

@Composable
private fun RowScope.AiTabLabel(
    c: AiColors,
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    val tint by animateColorAsState(
        targetValue = if (selected) c.text else c.muted,
        animationSpec = tween(220),
        label = "ai_tab_tint"
    )
    Row(
        modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(7.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = tint
        )
    }
}

@Composable
private fun ResumeCard(c: AiColors, chat: SupabaseClient.AiChatInfo, loading: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val accent = if (c.dark) c.brandA else c.brandB
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.panel)
            .border(BorderStroke(1.dp, c.border), shape)
            .clickable(enabled = !loading, onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(c.brandA.copy(alpha = 0.16f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(color = accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            } else {
                Icon(Icons.Default.History, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = "تابع آخر محادثة · ${agoText(chat.updated)}",
                style = MaterialTheme.typography.labelMedium,
                color = c.muted,
                maxLines = 1
            )
            Text(
                text = chat.head.ifBlank { "محادثة سابقة" },
                style = TextStyle(fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold, textDirection = TextDirection.Content),
                color = c.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = "متابعة",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = accent,
            modifier = Modifier
                .clip(CircleShape)
                .background(c.brandA.copy(alpha = 0.14f))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun AiHistoryPane(
    c: AiColors,
    state: SlideAiState,
    fileUrl: String,
    onOpen: (String) -> Unit,
    onNew: () -> Unit
) {
    val items = state.history
    var confirmAll by remember { mutableStateOf(false) }
    LaunchedEffect(confirmAll) {
        if (confirmAll) {
            delay(3500)
            confirmAll = false
        }
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "محادثاتك مع المساعد",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = c.text
                )
            }
            AnimatedVisibility(
                visible = items.isNotEmpty(),
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                val bg by animateColorAsState(if (confirmAll) c.errorFill else c.panel, tween(200), label = "clear_all_bg")
                val fg by animateColorAsState(if (confirmAll) c.errorText else c.muted, tween(200), label = "clear_all_fg")
                Text(
                    text = if (confirmAll) "تأكيد مسح الكل" else "مسح الكل",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = fg,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(bg)
                        .border(BorderStroke(1.dp, c.border), CircleShape)
                        .clickable {
                            if (confirmAll) {
                                confirmAll = false
                                state.clearAllChats(fileUrl)
                            } else {
                                confirmAll = true
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                state.historyLoading && items.isEmpty() -> HistorySkeleton(c)
                state.historyError && items.isEmpty() -> HistoryMessage(
                    c = c,
                    title = "تعذر تحميل السجل",
                    body = "تأكد من الاتصال بالإنترنت ثم حاول مرة ثانية",
                    action = "إعادة المحاولة"
                ) { state.loadHistory(fileUrl) }
                items.isEmpty() -> HistoryMessage(
                    c = c,
                    title = "لا توجد محادثات بعد",
                    action = "ابدأ محادثة",
                    body = "اسال المساعد سؤال حتى ينضاف هنا",
                    onAction = onNew
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 18.dp)
                ) {
                    itemsIndexed(items, key = { _, it -> it.id }) { i, chat ->
                        Box(modifier = Modifier.animateItem()) {
                            AppearStatic(delayMs = min(i, 6) * 55) {
                                HistoryCard(
                                    c = c,
                                    chat = chat,
                                    current = chat.id == state.chatId,
                                    opening = chat.id == state.openingId,
                                    onOpen = { onOpen(chat.id) },
                                    onDelete = { state.deleteChat(chat.id, fileUrl) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(
    c: AiColors,
    chat: SupabaseClient.AiChatInfo,
    current: Boolean,
    opening: Boolean,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    var confirm by remember(chat.id) { mutableStateOf(false) }
    LaunchedEffect(confirm) {
        if (confirm) {
            delay(3500)
            confirm = false
        }
    }
    val accent = if (c.dark) c.brandA else c.brandB
    val shape = RoundedCornerShape(22.dp)
    val bg by animateColorAsState(if (confirm) c.errorFill else c.panel, tween(220), label = "hist_bg")
    val borderColor by animateColorAsState(
        if (current) c.brandA.copy(alpha = 0.75f) else c.border, tween(250), label = "hist_border"
    )
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.98f else 1f, spring(stiffness = 600f), label = "hist_press")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(bg)
            .border(BorderStroke(if (current) 1.5.dp else 1.dp, borderColor), shape)
            .clickable(interactionSource = source, indication = null, enabled = !opening) {
                if (confirm) confirm = false else onOpen()
            }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(
                    if (current) Brush.linearGradient(listOf(c.brandA, c.brandB))
                    else Brush.linearGradient(listOf(c.panelRaised, c.panelRaised)),
                    RoundedCornerShape(15.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (opening) {
                CircularProgressIndicator(color = accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            } else {
                Icon(
                    imageVector = Icons.Default.ChatBubbleOutline,
                    contentDescription = null,
                    tint = if (current) c.onBrand else accent,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = chat.head.ifBlank { "محادثة" },
                style = TextStyle(fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold, textDirection = TextDirection.Content),
                color = if (confirm) c.errorText else c.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (chat.preview.isNotBlank()) {
                Text(
                    text = chat.preview,
                    style = TextStyle(fontSize = 13.sp, lineHeight = 19.sp, textDirection = TextDirection.Content),
                    color = c.muted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = agoText(chat.updated),
                    style = MaterialTheme.typography.labelSmall,
                    color = c.muted
                )
                Text(text = "·", style = MaterialTheme.typography.labelSmall, color = c.muted)
                Text(
                    text = "${questionsOf(chat.count)} سؤال",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.muted
                )
                if (current) {
                    Text(
                        text = "مفتوحة",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = accent,
                        modifier = Modifier
                            .background(c.brandA.copy(alpha = 0.16f), CircleShape)
                            .padding(horizontal = 8.dp, vertical = 1.dp)
                    )
                }
            }
        }
        AnimatedContent(
            targetState = confirm,
            transitionSpec = { (fadeIn(tween(160)) + scaleIn(tween(200), 0.85f)) togetherWith (fadeOut(tween(100)) + scaleOut(tween(120), 0.85f)) },
            label = "hist_del"
        ) { asking ->
            if (asking) {
                Text(
                    text = "حذف",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = c.errorText,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(c.errorText.copy(alpha = 0.16f))
                        .border(BorderStroke(1.dp, c.errorText.copy(alpha = 0.4f)), CircleShape)
                        .clickable {
                            confirm = false
                            onDelete()
                        }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(c.panelRaised.copy(alpha = 0.6f))
                        .clickable { confirm = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف المحادثة",
                        tint = c.muted,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HistorySkeleton(c: AiColors) {
    val t = rememberInfiniteTransition(label = "hist_sk")
    val a by t.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "hist_sk_a"
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(4) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(88.dp)
                    .graphicsLayer { alpha = a }
                    .background(c.panel, RoundedCornerShape(22.dp))
                    .border(BorderStroke(1.dp, c.border), RoundedCornerShape(22.dp))
            )
        }
    }
}

@Composable
private fun HistoryMessage(
    c: AiColors,
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AppearStatic(delayMs = 0) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .background(Brush.linearGradient(listOf(c.brandA, c.brandB)), RoundedCornerShape(24.dp))
                        .border(BorderStroke(1.dp, c.border), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = c.onBrand, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = c.text,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = action,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = c.onBrand,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(c.brandA, c.brandB)))
                        .clickable(onClick = onAction)
                        .padding(horizontal = 26.dp, vertical = 11.dp)
                )
            }
        }
    }
}