package com.saifadnan.pharmacynotes.util

import android.content.Context
import com.saifadnan.pharmacynotes.data.LectureEntity

object ReaderPrefs {

    private const val FILE = "reader_prefs"
    private const val KEY_THEME = "reader_theme"
    private const val KEY_GAME = "download_game_enabled"

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun keyFor(lecture: LectureEntity): String =
        if (lecture.id < 0) "w${-lecture.id}_${PdfHelper.worksheetTag(lecture.worksheetUrl)}" else "l${lecture.id}"

    fun getLastPage(context: Context, key: String): Int = prefs(context).getInt("last_$key", 0)

    fun setLastPage(context: Context, key: String, page: Int) {
        prefs(context).edit().putInt("last_$key", page).apply()
    }

    fun getTheme(context: Context): Int = prefs(context).getInt(KEY_THEME, 0).coerceIn(0, 2)

    fun setTheme(context: Context, theme: Int) {
        prefs(context).edit().putInt(KEY_THEME, theme.coerceIn(0, 2)).apply()
    }

    fun isGameEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_GAME, true)

    fun setGameEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_GAME, enabled).apply()
    }

    fun getMark(context: Context, key: String): Int = prefs(context).getInt("mark_$key", -1)

    fun setMark(context: Context, key: String, page: Int) {
        prefs(context).edit().putInt("mark_$key", page).apply()
    }
}
