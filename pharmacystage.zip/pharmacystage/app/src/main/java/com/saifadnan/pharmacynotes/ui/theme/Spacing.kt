package com.saifadnan.pharmacynotes.ui.theme

import androidx.compose.ui.unit.dp

object Spacing {
    val Xs = 4.dp
    val Sm = 8.dp
    val Md = 12.dp
    val Lg = 16.dp
    val Xl = 24.dp
    val Xxl = 32.dp

    val MinTouchTarget = 48.dp
}
