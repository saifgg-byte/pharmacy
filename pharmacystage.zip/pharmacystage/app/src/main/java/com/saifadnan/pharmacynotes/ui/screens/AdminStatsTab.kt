package com.saifadnan.pharmacynotes.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.SupabaseClient
import com.saifadnan.pharmacynotes.ui.theme.AppShapes
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.Spacing

private fun actionLabel(a: String): String = when (a) {
    "explain" -> "شرح مفصل"
    "simplify" -> "تبسيط مختصر"
    "translate" -> "ترجمة السلايد"
    "keywords" -> "Key words"
    "mcq" -> "MCQ"
    "memorize" -> "طريقة حفظ"
    "exam" -> "نقاط الامتحان"
    "example" -> "مثال تطبيقي"
    "ask" -> "سؤال مباشر"
    else -> a
}

@Composable
fun AdminStatsContent() {
    var days by remember { mutableIntStateOf(30) }
    var stats by remember { mutableStateOf<SupabaseClient.AdminStats?>(null) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(days, reload) {
        loading = true
        failed = false
        val r = SupabaseClient.getAdminStats(days)
        if (r == null) failed = true else stats = r
        loading = false
    }

    Column(verticalArrangement = Arrangement.spacedBy(Spacing.Md)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7 to "آخر أسبوع", 30 to "آخر شهر", 90 to "آخر 3 أشهر").forEach { (d, label) ->
                FilterChip(
                    selected = days == d,
                    onClick = { days = d },
                    label = { Text(label) }
                )
            }
        }

        val data = stats
        when {
            loading && data == null -> {
                Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                }
            }
            failed && data == null -> {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "تعذر تحميل الإحصائيات",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = { reload++ }, shape = AppShapes.Small) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("إعادة المحاولة")
                    }
                }
            }
            data != null -> {
                StatsSummary(data)
                StatCard(
                    title = "أكثر المحاضرات قراءة",
                    note = "حسب عدد مرات فتح المحاضرة",
                    icon = Icons.Default.Visibility,
                    rows = data.topViewed,
                    unit = "فتح"
                )
                StatCard(
                    title = "صفحات يسأل عنها الطلاب كثيراً",
                    note = "قد تحتاج شرحاً إضافياً في المحاضرة",
                    icon = Icons.Default.AutoAwesome,
                    rows = data.topAiPages,
                    unit = "سؤال"
                )
                StatCard(
                    title = "محاضرات يستعين فيها الطلاب بالمساعد",
                    note = "عدد طلبات الذكاء الاصطناعي لكل محاضرة",
                    icon = Icons.Default.Description,
                    rows = data.topAiLectures,
                    unit = "طلب"
                )
                StatCard(
                    title = "أكثر الأسئلة المكتوبة للمساعد",
                    note = "الأسئلة المتشابهة تُجمع معاً",
                    icon = Icons.Default.Forum,
                    rows = data.topQuestions,
                    unit = "مرة"
                )
                StatCard(
                    title = "الأدوات الأكثر استخداماً",
                    note = "",
                    icon = Icons.Default.AutoAwesome,
                    rows = data.actions.map { it.copy(label = actionLabel(it.label)) },
                    unit = "مرة"
                )
            }
        }
    }
}

@Composable
private fun StatsSummary(data: SupabaseClient.AdminStats) {
    Card(
        shape = AppShapes.Medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, AppShapes.Medium)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(Spacing.Lg),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Spacing.Md)
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("طلبات المساعد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "خلال آخر ${data.days} يوم",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "${data.totalAi}",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    note: String,
    icon: ImageVector,
    rows: List<SupabaseClient.StatRow>,
    unit: String
) {
    Card(
        shape = AppShapes.Medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, AppShapes.Medium)
    ) {
        Column(
            modifier = Modifier.padding(Spacing.Lg),
            verticalArrangement = Arrangement.spacedBy(Spacing.Md)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (note.isNotBlank()) {
                        Text(
                            note,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (rows.isEmpty()) {
                Text(
                    "لا توجد بيانات بعد",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )
            } else {
                val max = rows.maxOf { it.n }.coerceAtLeast(1)
                rows.forEachIndexed { i, row ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                "${i + 1}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp),
                                textAlign = TextAlign.Center
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    row.label.ifBlank { "—" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (row.sub.isNotBlank()) {
                                    Text(
                                        row.sub,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Text(
                                "${row.n} $unit",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        LinearProgressIndicator(
                            progress = { row.n.toFloat() / max },
                            modifier = Modifier.fillMaxWidth().height(4.dp),
                            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                        )
                    }
                }
            }
        }
    }
}
