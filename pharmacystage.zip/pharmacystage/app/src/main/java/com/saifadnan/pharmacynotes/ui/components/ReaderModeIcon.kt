package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ReaderModeIcon(
    theme: Int,
    modifier: Modifier = Modifier,
    size: Dp = 20.dp
) {
    val spec = tween<Float>(durationMillis = 650, easing = FastOutSlowInEasing)
    val night by animateFloatAsState(if (theme == 1) 1f else 0f, spec, label = "ReaderIconNight")
    val warm by animateFloatAsState(if (theme == 2) 1f else 0f, spec, label = "ReaderIconWarm")

    val base = MaterialTheme.colorScheme.onSurface
    val color by animateColorAsState(
        targetValue = if (theme == 2) Color(0xFFD9791F) else base,
        animationSpec = tween(500),
        label = "ReaderIconColor"
    )

    Canvas(modifier = modifier.size(size)) {
        val u = this.size.minDimension / 24f          // وحدة الرسم (شبكة 24×24)
        val cx = 12f * u
        val stroke = Stroke(width = 1.8f * u, cap = StrokeCap.Round)

        // ---- الأشعة (تدور قليلاً، والسفلية تختفي بالغروب، وكلها بالليل) ----
        val spin = 20f * warm - 40f * night
        rotate(degrees = spin, pivot = Offset(cx, cx)) {
            for (k in 0 until 8) {
                val deg = k * 45f                      // 0 = للأعلى
                val isLow = k in 3..5                  // الأشعة السفلية
                val vis = (1f - night) * (if (isLow) 1f - warm else 1f)
                if (vis <= 0.01f) continue
                val rad = Math.toRadians(deg.toDouble())
                val dx = sin(rad).toFloat()
                val dy = -cos(rad).toFloat()
                val r1 = (if (k % 2 == 0) 10.5f else 10.2f) * u * (0.4f + 0.6f * vis)
                val r2 = 8.2f * u * (0.4f + 0.6f * vis)
                drawLine(
                    color = color.copy(alpha = vis),
                    start = Offset(cx + dx * r1, cx + dy * r1),
                    end = Offset(cx + dx * r2, cx + dy * r2),
                    strokeWidth = stroke.width,
                    cap = StrokeCap.Round
                )
            }
        }

        // ---- القرص: شمس تتحول إلى هلال ----
        val coreY = (12f + 2f * warm) * u
        val coreR = 5f * (1f + 0.35f * night) * u
        val sun = Path().apply {
            addOval(androidx.compose.ui.geometry.Rect(Offset(cx, coreY), coreR))
        }
        val biteX = (30f - 14f * night) * u
        val biteY = (-5.5f + 14f * night) * u
        val bite = Path().apply {
            addOval(androidx.compose.ui.geometry.Rect(Offset(biteX, biteY), 6f * u))
        }
        val shape = Path.combine(PathOperation.Difference, sun, bite)
        drawPath(shape, color)

        // ---- خط الأفق (ينمو من الوسط بالغروب) ----
        if (warm > 0.01f) {
            val half = 10f * u * warm
            drawLine(
                color = color.copy(alpha = warm),
                start = Offset(cx - half, 20f * u),
                end = Offset(cx + half, 20f * u),
                strokeWidth = stroke.width,
                cap = StrokeCap.Round
            )
        }

        // ---- نجوم الليل (تظهر بالتتابع) ----
        sparkle(Offset(19f * u, 5f * u), 2.4f * u * night.coerceIn(0f, 1f), color)
        sparkle(Offset(5f * u, 14f * u), 1.8f * u * ((night - 0.3f) / 0.7f).coerceIn(0f, 1f), color)
        val dot = ((night - 0.5f) / 0.5f).coerceIn(0f, 1f)
        if (dot > 0f) drawCircle(color, radius = 0.9f * u * dot, center = Offset(21f * u, 14f * u))
    }
}

private fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    if (r <= 0.05f) return
    val k = r * 0.28f
    val p = Path().apply {
        moveTo(c.x, c.y - r)
        quadraticTo(c.x + k, c.y - k, c.x + r, c.y)
        quadraticTo(c.x + k, c.y + k, c.x, c.y + r)
        quadraticTo(c.x - k, c.y + k, c.x - r, c.y)
        quadraticTo(c.x - k, c.y - k, c.x, c.y - r)
        close()
    }
    drawPath(p, color)
}
