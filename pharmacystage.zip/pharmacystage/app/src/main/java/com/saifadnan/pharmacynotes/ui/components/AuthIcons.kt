package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp


object AuthIcons {

    private fun build(name: String, evenOdd: Boolean, vararg paths: String): ImageVector {
        val builder = ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        )
        val data = paths.joinToString(" ")
        builder.addPath(
            pathData = PathParser().parsePathString(data).toNodes(),
            pathFillType = if (evenOdd) PathFillType.EvenOdd else PathFillType.NonZero,
            fill = SolidColor(Color.Black)
        )
        return builder.build()
    }

    val PersonName: ImageVector by lazy {
        build(
            "AuthPersonName",
            false,
            "M12 2.8a4.6 4.6 0 1 1 0 9.2a4.6 4.6 0 0 1 0-9.2Z",
            "M4 19.3c0-3.4 3.7-5.5 8-5.5s8 2.1 8 5.5c0 .95-.75 1.7-1.7 1.7H5.7C4.75 21 4 20.25 4 19.3Z"
        )
    }

    val StudentId: ImageVector by lazy {
        build(
            "AuthStudentId",
            true,
            "M5 4h14a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z",
            "M9 8.1a2.1 2.1 0 1 1 0 4.2a2.1 2.1 0 0 1 0-4.2Z",
            "M5.7 16.4c.35-1.6 1.8-2.5 3.3-2.5s2.95.9 3.3 2.5Z",
            "M14.6 9.1h4a.8.8 0 0 1 0 1.6h-4a.8.8 0 0 1 0-1.6Z",
            "M14.6 13.3h4a.8.8 0 0 1 0 1.6h-4a.8.8 0 0 1 0-1.6Z"
        )
    }
}
