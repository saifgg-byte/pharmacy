package com.saifadnan.pharmacynotes.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

data class YoutubeVideo(val title: String, val url: String)

object YoutubeLinks {

    private val hosts = setOf("youtube.com", "youtu.be", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com")

    private fun withScheme(value: String): String =
        if (value.startsWith("http://", true) || value.startsWith("https://", true)) value else "https://$value"

    fun isValidUrl(raw: String): Boolean {
        val value = raw.trim()
        if (value.isEmpty()) return true
        val host = try {
            Uri.parse(withScheme(value)).host?.lowercase()?.removePrefix("www.")
        } catch (_: Exception) {
            null
        }
        return host != null && host in hosts
    }

    fun isPlaylist(raw: String): Boolean = raw.trimStart().startsWith("[")

    fun parse(raw: String): List<YoutubeVideo> {
        val value = raw.trim()
        if (value.isEmpty()) return emptyList()
        if (!value.startsWith("[")) return listOf(YoutubeVideo("", value))
        return try {
            val arr = JSONArray(value)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = o.optString("url").trim()
                if (url.isEmpty()) null else YoutubeVideo(o.optString("title").trim(), url)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encode(videos: List<YoutubeVideo>, asPlaylist: Boolean): String {
        val clean = videos
            .map { YoutubeVideo(it.title.trim(), it.url.trim()) }
            .filter { it.url.isNotEmpty() }
        if (clean.isEmpty()) return ""
        if (!asPlaylist) return clean.first().url
        val arr = JSONArray()
        clean.forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url)) }
        return arr.toString()
    }

    fun isValid(raw: String): Boolean {
        val value = raw.trim()
        if (value.isEmpty()) return true
        if (!value.startsWith("[")) return isValidUrl(value)
        return try {
            JSONArray(value)
            parse(value).all { isValidUrl(it.url) }
        } catch (_: Exception) {
            false
        }
    }

    fun displayTitle(video: YoutubeVideo, index: Int): String =
        video.title.ifBlank { "الفيديو ${index + 1}" }

    fun countLabel(n: Int): String = when {
        n == 1 -> "فيديو واحد"
        n == 2 -> "فيديوان"
        n in 3..10 -> "$n فيديوهات"
        else -> "$n فيديو"
    }

    fun open(context: Context, raw: String) {
        val first = if (isPlaylist(raw)) parse(raw).firstOrNull()?.url.orEmpty() else raw
        openUrl(context, first)
    }

    fun openUrl(context: Context, url: String) {
        val value = url.trim()
        if (value.isEmpty()) return
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(withScheme(value))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "تعذر فتح رابط اليوتيوب", Toast.LENGTH_SHORT).show()
        }
    }
}
