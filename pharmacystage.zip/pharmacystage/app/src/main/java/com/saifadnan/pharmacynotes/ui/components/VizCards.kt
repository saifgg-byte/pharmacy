package com.saifadnan.pharmacynotes.ui.components

import android.annotation.SuppressLint
import android.graphics.Color as AColor
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.saifadnan.pharmacynotes.data.SupabaseClient
import org.json.JSONObject

class VizTheme(
    val dark: Boolean,
    val panel: Color,
    val raised: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val brandA: Color,
    val brandB: Color
)

class VizRef(val kind: String, val title: String, val path: String, val body: String) {
    val key: String get() = "$path|$body"
}

private val VIZ_TAG = Regex("\\{\\{(chart|plot|seq|mol3d)\\|([^}]*)\\}\\}")

fun stripVizTags(text: String): String = VIZ_TAG.replace(text, "")

fun parseViz(text: String): List<VizRef> =
    VIZ_TAG.findAll(text).mapNotNull { m ->
        val kind = m.groupValues[1]
        val payload = m.groupValues[2]
        val parts = payload.split("|")
        when (kind) {
            "chart", "plot" -> {
                val title = parts.getOrNull(1)?.trim().orEmpty()
                VizRef(kind, title, "chart", JSONObject().put("spec", "$kind|$payload").toString())
            }
            "seq" -> {
                if (parts.size < 3) null
                else VizRef(
                    kind, parts[0].trim(), "seq",
                    JSONObject().put("name", parts[0].trim()).put("type", parts[1].trim()).put("seq", parts[2].trim()).toString()
                )
            }
            else -> {
                if (parts.size < 2) null
                else VizRef(kind, parts[0].trim(), "mol3d", JSONObject().put("spec", payload).toString())
            }
        }
    }.distinctBy { it.key }.take(2).toList()

fun molRef(name: String, smiles: String): VizRef =
    VizRef("mol3d", name, "mol3d", JSONObject().put("spec", "$name|smiles:$smiles").toString())

private object VizCache {
    val map = HashMap<String, String>()
}

private fun Color.css(): String {
    val a = (alpha * 100).toInt() / 100.0
    return "rgba(${(red * 255).toInt()},${(green * 255).toInt()},${(blue * 255).toInt()},$a)"
}

private fun VizTheme.json(): JSONObject = JSONObject()
    .put("dark", dark)
    .put("panel", panel.css())
    .put("raised", raised.css())
    .put("border", border.css())
    .put("text", text.css())
    .put("muted", muted.css())
    .put("brandA", brandA.css())
    .put("brandB", brandB.css())

private fun heightFor(kind: String): Dp = when (kind) {
    "mol3d" -> 440.dp
    "seq" -> 470.dp
    else -> 350.dp
}

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
private fun VizWebView(payload: String, theme: VizTheme, interactive: Boolean, background: Int, modifier: Modifier) {
    var loaded by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf<WebView?>(null) }
    val themeJson = remember(theme) { theme.json().toString() }

    LaunchedEffect(loaded, themeJson) {
        val w = view
        if (loaded && w != null) w.evaluateJavascript("window.pvTheme(${JSONObject.quote(themeJson)})", null)
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(background)
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                overScrollMode = WebView.OVER_SCROLL_NEVER
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                settings.allowContentAccess = false
                settings.allowFileAccessFromFileURLs = false
                settings.allowUniversalAccessFromFileURLs = false
                settings.setSupportZoom(false)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean = true
                    override fun onPageFinished(v: WebView, url: String?) {
                        val msg = JSONObject().put("payload", JSONObject(payload)).put("theme", theme.json())
                        v.evaluateJavascript("window.pvMount(${JSONObject.quote(msg.toString())})", null)
                        loaded = true
                    }
                }
                if (interactive) {
                    setOnTouchListener { v, e ->
                        when (e.actionMasked) {
                            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> v.parent?.requestDisallowInterceptTouchEvent(true)
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.parent?.requestDisallowInterceptTouchEvent(false)
                        }
                        false
                    }
                }
                addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
                    if (r - l > 0 && b - t > 0) {
                        (v as WebView).evaluateJavascript("window.PharmacyViz&&window.PharmacyViz.resize()", null)
                    }
                }
                loadUrl("file:///android_asset/viz/frame.html")
                view = this
            }
        },
        update = { it.setBackgroundColor(background) },
        onRelease = {
            it.stopLoading()
            it.destroy()
            view = null
        }
    )
}

@Composable
fun VizCard(ref: VizRef, theme: VizTheme, framed: Boolean = true, modifier: Modifier = Modifier) {
    val payload by produceState<String?>(VizCache.map[ref.key], ref.key) {
        if (value == null) {
            val r = SupabaseClient.vizFetch(ref.path, ref.body)
            if (r.contains("\"ok\": true") || r.contains("\"ok\":true")) VizCache.map[ref.key] = r
            value = r
        }
    }
    val shape = RoundedCornerShape(18.dp)
    val box = if (framed) {
        modifier
            .fillMaxWidth()
            .background(theme.panel, shape)
            .border(BorderStroke(1.dp, theme.border), shape)
            .padding(12.dp)
    } else {
        modifier.fillMaxWidth()
    }
    Column(modifier = box, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (framed) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = when (ref.kind) {
                        "mol3d" -> Icons.Default.ViewInAr
                        "seq" -> Icons.Default.Science
                        else -> Icons.Default.AutoGraph
                    },
                    contentDescription = null,
                    tint = if (theme.dark) theme.brandA else theme.brandB,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = ref.title.ifBlank { if (ref.kind == "mol3d") "3D" else "Chart" },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = theme.text,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(heightFor(ref.kind)),
            contentAlignment = Alignment.Center
        ) {
            val p = payload
            if (p == null) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = theme.muted
                )
            } else {
                VizWebView(
                    p,
                    theme,
                    ref.kind == "mol3d",
                    if (framed) theme.panel.toArgb() else AColor.TRANSPARENT,
                    Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun VizSection(refs: List<VizRef>, theme: VizTheme) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        refs.forEach { VizCard(it, theme) }
    }
}
