package com.saifadnan.pharmacynotes.data

object DefaultPharmacyData {
    val defaultSubjects: List<SubjectEntity> = emptyList()
    val defaultLectures: List<LectureEntity> = emptyList()
    val defaultNotifications: List<BroadcastNotificationEntity> = emptyList()
}
