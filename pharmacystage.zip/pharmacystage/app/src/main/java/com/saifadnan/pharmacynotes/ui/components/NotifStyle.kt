package com.saifadnan.pharmacynotes.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONObject

data class NotifStyle(
    val accent: Int = 0,
    val icon: String = "campaign",
    val level: Int = 0,
    val focus: Boolean = false
) {
    val isDefault: Boolean get() = accent == 0 && icon == "campaign" && level == 0 && !focus

    fun toJson(): String =
        if (isDefault) "" else JSONObject().put("a", accent).put("i", icon).put("l", level).put("f", focus).toString()

    companion object {
        fun parse(s: String?): NotifStyle {
            if (s.isNullOrBlank()) return NotifStyle()
            return try {
                val o = JSONObject(s)
                NotifStyle(
                    accent = o.optInt("a", 0).coerceIn(0, NotifPalette.size - 1),
                    icon = o.optString("i", "campaign").takeIf { it in NotifIcons } ?: "campaign",
                    level = o.optInt("l", 0).coerceIn(0, 2),
                    focus = o.optBoolean("f", false)
                )
            } catch (e: Exception) {
                NotifStyle()
            }
        }
    }
}

private val Accents = listOf(
    "افتراضي" to Color.Unspecified,
    "أزرق" to Color(0xFF3B82F6),
    "أخضر" to Color(0xFF22C55E),
    "ذهبي" to Color(0xFFF59E0B),
    "أحمر" to Color(0xFFEF4444),
    "بنفسجي" to Color(0xFF8B5CF6),
    "وردي" to Color(0xFFEC4899),
    "تركوازي" to Color(0xFF14B8A6)
)

object NotifPalette {
    val size: Int get() = Accents.size
    fun name(i: Int) = Accents[i.coerceIn(0, Accents.size - 1)].first
    fun color(i: Int): Color? = Accents[i.coerceIn(0, Accents.size - 1)].second.takeIf { it != Color.Unspecified }
}

val NotifIcons: LinkedHashMap<String, ImageVector> = linkedMapOf(
    "campaign" to Icons.Default.Campaign,
    "alarm" to Icons.Default.NotificationsActive,
    "event" to Icons.Default.Event,
    "warning" to Icons.Default.Warning,
    "star" to Icons.Default.Star,
    "book" to Icons.Default.MenuBook,
    "school" to Icons.Default.School,
    "celebration" to Icons.Default.Celebration,
    "info" to Icons.Default.Info
)

private val LevelNames = listOf("عادي", "مهم", "عاجل")

@Composable
fun NotifStyle.accentColor(): Color = NotifPalette.color(accent) ?: MaterialTheme.colorScheme.primary

@Composable
fun NotifLevelBadge(style: NotifStyle, modifier: Modifier = Modifier) {
    if (style.level == 0) return
    val color = if (style.level == 2) Color(0xFFEF4444) else Color(0xFFF59E0B)
    val pulse = if (style.level == 2) {
        val t = rememberInfiniteTransition(label = "urgent")
        val v by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "urgentAlpha")
        v
    } else 1f
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f * pulse + 0.06f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(Modifier.size(7.dp).graphicsLayer { alpha = pulse }.clip(CircleShape).background(color))
        Text(LevelNames[style.level], style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NotifStyleEditor(
    title: String,
    message: String,
    style: NotifStyle,
    onChange: (NotifStyle) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        NotifPreviewCard(title, message, style)

        Text("لون التنبيه", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items((0 until NotifPalette.size).toList()) { i ->
                val c = NotifPalette.color(i) ?: MaterialTheme.colorScheme.primary
                val selected = style.accent == i
                val ring by animateColorAsState(if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent, tween(200), label = "ring")
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .border(2.dp, ring, CircleShape)
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(c)
                        .clickable { onChange(style.copy(accent = i)) },
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                }
            }
        }

        Text("الأيقونة", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(NotifIcons.entries.toList()) { (key, vec) ->
                val selected = style.icon == key
                val accent = style.accentColor()
                val bg by animateColorAsState(if (selected) accent.copy(alpha = 0.18f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f), tween(200), label = "iconBg")
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(bg)
                        .border(if (selected) BorderStroke(1.5.dp, accent) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(14.dp))
                        .clickable { onChange(style.copy(icon = key)) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(vec, null, tint = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                }
            }
        }

        Text("درجة الأهمية", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LevelNames.forEachIndexed { i, name ->
                val selected = style.level == i
                val c = when (i) { 2 -> Color(0xFFEF4444); 1 -> Color(0xFFF59E0B); else -> MaterialTheme.colorScheme.primary }
                val bg by animateColorAsState(if (selected) c.copy(alpha = 0.18f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f), tween(200), label = "lvBg")
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(bg)
                        .clickable { onChange(style.copy(level = i)) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(name, color = if (selected) c else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("وضع التركيز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    "يظهر للطالب كنافذة وحدها فوق التطبيق مرة واحدة، ولا تختفي حتى يضغط (فهمت).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = style.focus, onCheckedChange = { onChange(style.copy(focus = it)) })
        }
    }
}

@Composable
fun NotifPreviewCard(title: String, message: String, style: NotifStyle, modifier: Modifier = Modifier) {
    val accent = style.accentColor()
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = accent.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                Icon(NotifIcons[style.icon] ?: Icons.Default.Campaign, null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(title.ifBlank { "عنوان التبليغ" }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                    NotifLevelBadge(style)
                }
                Text(message.ifBlank { "نص التبليغ يظهر هنا..." }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
            }
        }
    }
}

@Composable
fun FocusNoticeDialog(title: String, message: String, style: NotifStyle, onAck: () -> Unit) {
    val accent = style.accentColor()
    val t = rememberInfiniteTransition(label = "focus")
    val ring by t.animateFloat(1f, 1.35f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "ring")
    val ringAlpha by t.animateFloat(0.35f, 0f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "ringA")
    val enter by androidx.compose.animation.core.animateFloatAsState(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "enter")
    Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth().scale(0.88f + 0.12f * enter).graphicsLayer { alpha = enter.coerceIn(0f, 1f) },
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
        ) {
            Column(
                Modifier.padding(horizontal = 22.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(92.dp)) {
                    Box(Modifier.size(66.dp).scale(ring).graphicsLayer { alpha = ringAlpha }.clip(CircleShape).background(accent))
                    Box(Modifier.size(66.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                        Icon(NotifIcons[style.icon] ?: Icons.Default.Campaign, null, tint = accent, modifier = Modifier.size(34.dp))
                    }
                }
                NotifLevelBadge(style)
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Column(Modifier.fillMaxWidth().height(1.dp).background(accent.copy(alpha = 0.25f))) {}
                Column(Modifier.fillMaxWidth().weightedMax().verticalScroll(rememberScrollState())) {
                    RichText(
                        text = message,
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Spacer(Modifier.height(4.dp))
                Button(onClick = onAck, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                    Text("فهمت", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun Modifier.weightedMax(): Modifier = this.then(Modifier.heightIn(max = 320.dp))