package com.saifadnan.pharmacynotes.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.saifadnan.pharmacynotes.data.ScheduleConstants
import com.saifadnan.pharmacynotes.data.ScheduleEntity
import java.util.Calendar

object ClassAlarmScheduler {
    private const val TAG = "ClassAlarmScheduler"
    private const val ACTION_CLASS_REMINDER = "com.saifadnan.pharmacynotes.CLASS_REMINDER"

    private fun requestCodeFor(entryId: String): Int =
        entryId.hashCode() and 0x7FFFFFFF

    private fun buildPendingIntent(context: Context, entry: ScheduleEntity, triggerAt: Long = 0L): PendingIntent {
        val intent = Intent(context, ClassReminderReceiver::class.java).apply {
            action = ACTION_CLASS_REMINDER
            putExtra("schedule_id", entry.id)
            putExtra("subject", entry.subject)
            putExtra("session_type", entry.sessionType)
            putExtra("day_of_week", entry.dayOfWeek)
            putExtra("start_hour", entry.startHour)
            putExtra("start_minute", entry.startMinute)
            putExtra("room", entry.room)

            putExtra("trigger_at", triggerAt)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCodeFor(entry.id),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTriggerMillis(dayOfWeek: Int, startHour: Int, startMinute: Int): Long {
        val now = Calendar.getInstance()
        val candidate = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, dayOfWeek)
            set(Calendar.HOUR_OF_DAY, startHour)
            set(Calendar.MINUTE, startMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, -ScheduleConstants.REMINDER_MINUTES_BEFORE)
        }

        if (candidate.timeInMillis <= now.timeInMillis) {
            candidate.add(Calendar.DAY_OF_YEAR, 7)
        }
        return candidate.timeInMillis
    }

    fun schedule(context: Context, entry: ScheduleEntity) {

        if (!ClassReminderSettings.isEnabled(context)) {
            cancel(context, entry)
            return
        }
        try {
            val triggerAt = nextTriggerMillis(entry.dayOfWeek, entry.startHour, entry.startMinute)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = buildPendingIntent(context, entry, triggerAt)
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } catch (security: SecurityException) {

                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scheduling class reminder for ${entry.id}", e)
        }
    }

    fun cancel(context: Context, entry: ScheduleEntity) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(buildPendingIntent(context, entry))
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling class reminder for ${entry.id}", e)
        }
    }

    fun rescheduleFromExtras(
        context: Context,
        scheduleId: String,
        subject: String,
        sessionType: String,
        dayOfWeek: Int,
        startHour: Int,
        startMinute: Int,
        room: String
    ) {
        val entry = ScheduleEntity(
            id = scheduleId,
            groupName = "",
            subject = subject,
            sessionType = sessionType,
            dayOfWeek = dayOfWeek,
            startHour = startHour,
            startMinute = startMinute,
            endHour = startHour,
            endMinute = startMinute,
            room = room
        )
        schedule(context, entry)
    }

    fun rescheduleAll(context: Context, previousEntries: List<ScheduleEntity>, newEntries: List<ScheduleEntity>) {
        previousEntries.forEach { cancel(context, it) }
        newEntries.forEach { schedule(context, it) }
    }

    fun cancelAll(context: Context, entries: List<ScheduleEntity>) {
        entries.forEach { cancel(context, it) }
    }

    fun scheduleAll(context: Context, entries: List<ScheduleEntity>) {
        entries.forEach { schedule(context, it) }
    }
}
