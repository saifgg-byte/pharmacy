package com.saifadnan.pharmacynotes.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {

    @Query("SELECT * FROM class_schedule ORDER BY dayOfWeek ASC, startHour ASC, startMinute ASC")
    fun getAllSchedule(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM class_schedule")
    suspend fun getAllScheduleList(): List<ScheduleEntity>

    @Query("SELECT * FROM class_schedule WHERE groupName = :groupName ORDER BY dayOfWeek ASC, startHour ASC, startMinute ASC")
    fun getScheduleForGroup(groupName: String): Flow<List<ScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: ScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<ScheduleEntity>)

    @Query("DELETE FROM class_schedule WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM class_schedule WHERE id NOT IN (:ids)")
    suspend fun deleteScheduleNotIn(ids: List<String>)

    @Query("DELETE FROM class_schedule")
    suspend fun clearAll()
}
