package com.saifadnan.pharmacynotes.data

import com.saifadnan.pharmacynotes.util.AdminConfig
import android.util.Log
import com.saifadnan.pharmacynotes.util.PdfHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class PharmacyRepository(
    private val db: AppDatabase,
    private val context: android.content.Context? = null,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val lectureDao = db.lectureDao()
    private val subjectDao = db.subjectDao()
    private val notificationDao = db.broadcastNotificationDao()
    private val userDao = db.userDao()
    private val scheduleDao = db.scheduleDao()
    private val examDao = db.examDao()

    private val _banRequests = MutableStateFlow<List<SupabaseClient.BanRequest>>(emptyList())
    val banRequests: StateFlow<List<SupabaseClient.BanRequest>> = _banRequests.asStateFlow()

    suspend fun refreshBanRequests() {
        if (!SupabaseClient.isAdminSession()) {
            if (_banRequests.value.isNotEmpty()) _banRequests.value = emptyList()
            return
        }
        SupabaseClient.getBanRequests()?.let { _banRequests.value = it }
    }

    suspend fun decideBanRequest(id: Long, approve: Boolean): SupabaseClient.ApiResult {
        val r = SupabaseClient.decideBanRequest(id, approve)
        refreshBanRequests()
        refreshUsers()
        return r
    }

    private val prefs = context?.getSharedPreferences("pharmacy_dismissed_notifs", android.content.Context.MODE_PRIVATE)
    private val dismissedNotifIds = java.util.Collections.synchronizedSet(
        prefs?.getStringSet("dismissed_ids", emptySet())?.mapNotNull { it.toLongOrNull() }?.toMutableSet() ?: mutableSetOf()
    )

    private val readNotifPrefs = context?.getSharedPreferences("pharmacy_read_notifs", android.content.Context.MODE_PRIVATE)
    private val readNotifIds = java.util.Collections.synchronizedSet(
        readNotifPrefs?.getStringSet("read_ids", emptySet())?.mapNotNull { it.toLongOrNull() }?.toMutableSet() ?: mutableSetOf()
    )

    init {
        startSupabaseSync()
    }

    private fun startSupabaseSync() {
        externalScope.launch {
            while (isActive) {
                try {
                    syncWithSupabase()
                } catch (e: Exception) {
                    Log.e("PharmacyRepository", "Error during Supabase background sync", e)
                }
                delay(4000)
            }
        }
    }

    private suspend fun syncWithSupabase() {
        val remoteSubjects = SupabaseClient.getSubjects()
        if (remoteSubjects != null) {
            if (remoteSubjects.isNotEmpty()) {
                val localSubjects = subjectDao.getAllSubjectsList().associateBy { Triple(it.name, it.section, it.semester) }
                val now = System.currentTimeMillis()
                val mergedSubjects = remoteSubjects.map { remote ->
                    val local = localSubjects[Triple(remote.name, remote.section, remote.semester)]
                    remote.copy(
                        addedAt = when {
                            local != null -> local.addedAt
                            localSubjects.isNotEmpty() -> now
                            else -> 0L
                        }
                    )
                }
                subjectDao.insertSubjects(mergedSubjects)
                val keep = remoteSubjects.map { Triple(it.name, it.section, it.semester) }.toSet()
                localSubjects.values
                    .filter { Triple(it.name, it.section, it.semester) !in keep }
                    .forEach { subjectDao.deleteSubject(it.name, it.section, it.semester) }
            } else {
                subjectDao.deleteAllSubjects()
            }
        }

        val remoteLectures = SupabaseClient.getLectures()
        if (remoteLectures != null) {
            if (remoteLectures.isNotEmpty()) {
                val localLectures = lectureDao.getAllLecturesList().associateBy { it.id }
                val mergedLectures = remoteLectures.map { remote ->
                    val local = localLectures[remote.id]
                    if (local != null) {
                        remote.copy(
                            isDownloaded = local.isDownloaded,
                            downloadPath = local.downloadPath,
                            isBookmarked = local.isBookmarked,
                            isRead = local.isRead
                        )
                    } else remote
                }
                val remoteIds = remoteLectures.map { it.id }
                val removedIds = localLectures.keys - remoteIds.toSet()
                lectureDao.insertLectures(mergedLectures)
                lectureDao.deleteLecturesNotIn(remoteIds)
                removedIds.forEach { deleteOfflineCopy(it) }
            } else {
                lectureDao.deleteAllLectures()
            }
        }

        val remoteNotifsAll = SupabaseClient.getNotifications()
        if (remoteNotifsAll != null) {
            if (remoteNotifsAll.isNotEmpty()) {
                notificationDao.deleteNotificationsNotIn(remoteNotifsAll.map { it.id })
                val remoteNotifs = remoteNotifsAll.filter { !dismissedNotifIds.contains(it.id) }
                if (remoteNotifs.isNotEmpty()) {
                    val localNotifsMap = notificationDao.getAllNotificationsList().associateBy { it.id }
                    val mergedNotifs = remoteNotifs.map { remote ->
                        val local = localNotifsMap[remote.id]
                        val isReadLocally = (local?.isRead == true) || readNotifIds.contains(remote.id)
                        remote.copy(isRead = isReadLocally)
                    }
                    notificationDao.insertNotifications(mergedNotifs)
                }
            } else {
                notificationDao.deleteAllNotifications()
            }
        }

        refreshUsers()
        refreshBanRequests()

        context?.let { ctx ->
            try {
                com.saifadnan.pharmacynotes.util.HolidayStore.refreshIfStale(ctx)
            } catch (e: Exception) {
                Log.w("PharmacyRepository", "holiday refresh failed", e)
            }
        }

        val remoteSchedule = SupabaseClient.getSchedule()
        if (remoteSchedule != null) {
            if (remoteSchedule.isNotEmpty()) {
                scheduleDao.insertAll(remoteSchedule)
                scheduleDao.deleteScheduleNotIn(remoteSchedule.map { it.id })
            } else {
                scheduleDao.clearAll()
            }
        }

        val remoteExams = SupabaseClient.getExams()
        if (remoteExams != null) {
            if (remoteExams.isNotEmpty()) {
                examDao.insertAll(remoteExams)
                examDao.deleteNotIn(remoteExams.map { it.id })
            } else {
                examDao.clearAll()
            }
        }
    }

    suspend fun cacheUser(user: UserEntity) {
        userDao.insertUser(user)
    }

    suspend fun replaceCachedUser(oldEmail: String, user: UserEntity) {
        if (oldEmail.isNotBlank() && !oldEmail.equals(user.email, ignoreCase = true)) {
            userDao.deleteUser(oldEmail)
        }
        userDao.insertUser(user)
    }

    suspend fun refreshUsers() {
        val remoteUsers = SupabaseClient.getUsers()

        if (remoteUsers.isEmpty()) return
        val localMap = userDao.getAllUsersList().associateBy { it.email.lowercase().trim() }
        val merged = remoteUsers.map { remote ->
            val local = localMap[remote.email.lowercase().trim()]
            if (local != null) {
                remote.copy(
                    fullName = if (remote.fullName.isNotBlank()) remote.fullName else local.fullName,
                    studentId = if (remote.studentId.isNotBlank()) remote.studentId else local.studentId
                )
            } else remote
        }
        userDao.insertUsers(merged)

        userDao.deleteUsersNotIn(remoteUsers.map { it.email })
    }

    val allLectures: Flow<List<LectureEntity>> = lectureDao.getAllLectures()
    val allSubjects: Flow<List<SubjectEntity>> = subjectDao.getAllSubjects()
    val examPinnedSubjects: Flow<List<SubjectEntity>> = subjectDao.getExamPinnedSubjects()
    val bookmarkedLectures: Flow<List<LectureEntity>> = lectureDao.getBookmarkedLectures()
    val downloadedLectures: Flow<List<LectureEntity>> = lectureDao.getDownloadedLectures()
    val allSchedule: Flow<List<ScheduleEntity>> = scheduleDao.getAllSchedule()

    val allExams: Flow<List<ExamEntity>> = examDao.getAll()

    suspend fun upsertExam(e: ExamEntity): String? {
        val r = SupabaseClient.upsertExam(e)
        if (r.ok) examDao.insert(e)
        return if (r.ok) null else (r.message ?: "تعذر حفظ الامتحان")
    }

    suspend fun deleteExam(e: ExamEntity): Boolean {
        val ok = SupabaseClient.deleteExam(e.id)
        if (ok) examDao.deleteById(e.id)
        return ok
    }

    suspend fun setSubjectIcon(name: String, section: String, semester: Int, icon: String): String? {
        val r = SupabaseClient.setSubjectIcon(name, section, semester, icon)
        if (r.ok) subjectDao.setIconByName(name, icon)
        return if (r.ok) null else (r.message ?: "تعذر حفظ الأيقونة")
    }

    fun scheduleForGroup(groupName: String): Flow<List<ScheduleEntity>> =
        scheduleDao.getScheduleForGroup(groupName)

    suspend fun upsertScheduleEntry(entry: ScheduleEntity): Boolean {
        val success = SupabaseClient.upsertScheduleEntry(entry)
        if (success) {
            scheduleDao.insertEntry(entry)
        }
        return success
    }

    suspend fun deleteScheduleEntry(entry: ScheduleEntity): Boolean {
        val success = SupabaseClient.deleteScheduleEntry(entry.id)
        if (success) {
            scheduleDao.deleteById(entry.id)
        }
        return success
    }

    suspend fun setUserGroup(user: UserEntity, groupName: String): UserEntity {
        val updated = user.copy(groupName = groupName)
        userDao.insertUser(updated)
        try {
            SupabaseClient.upsertUser(updated)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error syncing group selection to Supabase", e)
        }
        return updated
    }
    val allNotifications: Flow<List<BroadcastNotificationEntity>> = notificationDao.getAllNotifications()
    val unreadNotificationsCount: Flow<Int> = notificationDao.getUnreadCount()
    val lecturesCount: Flow<Int> = lectureDao.getLecturesCount()
    val allStudents: Flow<List<UserEntity>> = userDao.getAllStudents()
    val allAdmins: Flow<List<UserEntity>> = userDao.getAllAdmins()

    fun getLecturesBySubject(subjectName: String, section: String, semester: Int): Flow<List<LectureEntity>> {
        return lectureDao.getLecturesBySubject(subjectName, section, semester)
    }

    fun getLectureById(id: Long): Flow<LectureEntity?> {
        return lectureDao.getLectureById(id)
    }

    suspend fun toggleBookmark(id: Long, currentStatus: Boolean) {
        lectureDao.updateBookmarkStatus(id, !currentStatus)
    }

    suspend fun toggleDownload(id: Long, currentStatus: Boolean, downloadPath: String? = null) {
        lectureDao.updateDownloadStatus(id, !currentStatus)
        if (!currentStatus) {
            lectureDao.incrementDownloadCount(id)
            SupabaseClient.trackLecture(id, "download")
        }
    }

    suspend fun updateDownloadPath(id: Long, path: String) {
        lectureDao.updateDownloadStatus(id, true)
        lectureDao.incrementDownloadCount(id)
        SupabaseClient.trackLecture(id, "download")
    }

    suspend fun markAvailableOffline(id: Long) {
        lectureDao.markDownloadedIfNeeded(id)
    }

    private fun deleteOfflineCopy(lectureId: Long) {
        val ctx = context ?: return
        try {
            PdfHelper.deleteOfflineCopy(ctx, lectureId)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error deleting offline copy", e)
        }
    }

    suspend fun incrementViewCount(id: Long) {
        lectureDao.incrementViewCount(id)
        SupabaseClient.trackLecture(id, "view")
    }

    suspend fun toggleSubjectExamPinned(subjectName: String, section: String, semester: Int, isPinned: Boolean) {
        subjectDao.setSubjectExamPinned(subjectName, section, semester, isPinned)
        try {
            SupabaseClient.updateSubjectExamPinned(subjectName, section, semester, isPinned)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error updating subject on server", e)
        }
    }

    suspend fun addSubjectFolder(subjectName: String, section: String, semester: Int) {
        if (subjectName.isNotBlank()) {
            val cleanName = subjectName.trim()
            val subject = SubjectEntity(
                name = cleanName, section = section, semester = semester, isExamPinned = false, addedAt = System.currentTimeMillis()
            )
            subjectDao.insertSubjectIfAbsent(subject)
            try {
                SupabaseClient.upsertSubject(subject)
            } catch (e: Exception) {
                Log.e("PharmacyRepository", "Error pushing subject to server", e)
            }
        }
    }

    suspend fun deleteSubjectFolder(subjectName: String, section: String, semester: Int): Boolean {
        val cleanName = subjectName.trim()
        val ok = try {
            SupabaseClient.deleteSubject(cleanName, section, semester)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error deleting subject on server", e)
            false
        }
        if (ok) {
            lectureDao.getAllLecturesList()
                .filter { it.subject == cleanName && it.section == section && it.semester == semester }
                .forEach { deleteOfflineCopy(it.id) }
            lectureDao.deleteLecturesBySubject(cleanName, section, semester)
            subjectDao.deleteSubject(cleanName, section, semester)
        }
        return ok
    }

    suspend fun renameSubjectFolder(oldName: String, newName: String, section: String, semester: Int): String? {
        val res = SupabaseClient.renameSubject(oldName.trim(), newName.trim(), section, semester)
        if (!res.ok) return res.message ?: "تعذر تغيير الاسم"
        subjectDao.renameSubject(oldName.trim(), newName.trim(), section, semester)
        lectureDao.renameLectureSubject(oldName.trim(), newName.trim(), section, semester)
        return null
    }

    suspend fun updateStudent(email: String, fullName: String, studentId: String, newPassword: String = ""): String? {
        val res = SupabaseClient.adminUpdateUser(email, fullName, studentId, newPassword = newPassword.takeIf { it.isNotBlank() })
        if (!res.ok) return res.message
        refreshUsers()
        return null
    }

    suspend fun changeUserEmail(email: String, newEmail: String): String? {
        val res = SupabaseClient.changeUserEmail(email, newEmail)
        if (!res.ok) return res.message
        refreshUsers()
        return null
    }

    suspend fun createAdmin(email: String, password: String, fullName: String): String? {
        val res = SupabaseClient.createAdmin(email, password, fullName)
        if (!res.ok) return res.message
        refreshUsers()
        return null
    }

    suspend fun promoteStudent(studentEmail: String, newEmail: String, password: String, fullName: String): String? {
        val res = SupabaseClient.promoteStudent(studentEmail, newEmail, password, fullName)
        if (!res.ok) return res.message
        userDao.deleteUser(studentEmail)
        refreshUsers()
        return null
    }

    suspend fun resetForStageChange() = kotlinx.coroutines.withContext(Dispatchers.IO) {
        try {
            lectureDao.getAllLecturesList().forEach { deleteOfflineCopy(it.id) }
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error clearing offline copies", e)
        }
        try {
            db.clearAllTables()
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error clearing local cache", e)
        }
        dismissedNotifIds.clear()
        readNotifIds.clear()
        prefs?.edit()?.clear()?.apply()
        readNotifPrefs?.edit()?.clear()?.apply()
        context?.getSharedPreferences("holidays_cache", android.content.Context.MODE_PRIVATE)?.edit()?.clear()?.apply()
    }

    suspend fun demoteAdmin(email: String): String? {
        val res = SupabaseClient.demoteAdmin(email)
        if (!res.ok) return res.message
        refreshUsers()
        return null
    }

    suspend fun deleteUserOnServer(email: String): String? {
        val res = SupabaseClient.deleteUserResult(email)
        if (!res.ok) return res.message
        userDao.deleteUser(email)
        return null
    }

    suspend fun resetUserDevices(email: String): String? = SupabaseClient.resetUserDevices(email).let { if (it.ok) null else it.message }

    suspend fun updateLecture(lecture: LectureEntity): String? {
        val res = SupabaseClient.upsertLectureResult(lecture)
        if (!res.ok) return res.message ?: "تعذر حفظ التعديل"
        lectureDao.insertLecture(lecture)

        subjectDao.insertSubjectIfAbsent(
            SubjectEntity(name = lecture.subject, section = lecture.section, semester = lecture.semester, addedAt = System.currentTimeMillis())
        )
        return null
    }

    suspend fun registerUser(
        email: String,
        fullName: String,
        studentId: String,
        role: String = "STUDENT",
        authUid: String = "",
        isApproved: Boolean = true,
        idCardUrl: String = ""
    ): Boolean {
        val isRealAdmin = email.trim().equals(AdminConfig.ADMIN_EMAIL, ignoreCase = true)
        val finalRole = if (isRealAdmin) "ADMIN" else role
        val finalApproved = if (isRealAdmin) true else isApproved
        val user = UserEntity(
            email = email.trim(),
            fullName = fullName.trim(),
            studentId = studentId.trim(),
            role = finalRole,
            registrationDate = System.currentTimeMillis(),
            isApproved = finalApproved,
            authUid = authUid,
            idCardUrl = idCardUrl
        )
        userDao.insertUser(user)
        return try {
            SupabaseClient.upsertUser(user)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error pushing user to Supabase", e)
            false
        }
    }

    suspend fun approveUser(user: UserEntity) {
        val updated = user.copy(isApproved = true)
        userDao.insertUser(updated)
        try {
            SupabaseClient.upsertUser(updated)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error approving user on Supabase", e)
        }
    }

    suspend fun blockUser(user: UserEntity): SupabaseClient.BlockOutcome {
        val outcome = try {
            SupabaseClient.blockStudent(user.email)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error blocking user on Supabase", e)
            SupabaseClient.BlockOutcome(false, message = "تعذر الاتصال بالخادم.")
        }
        if (outcome.ok && !outcome.pending) userDao.insertUser(user.copy(isApproved = false))
        refreshBanRequests()
        return outcome
    }

    suspend fun deleteUser(user: UserEntity) {
        userDao.deleteUser(user.email)
        try {
            SupabaseClient.deleteUser(user.email)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error deleting user on Supabase", e)
        }
    }

    suspend fun getUserByEmail(email: String): UserEntity? {
        return userDao.getUserByEmail(email.trim())
    }

    suspend fun getUserByFullName(fullName: String): UserEntity? {
        return userDao.getUserByFullName(fullName.trim())
    }

    suspend fun getUserByStudentId(studentId: String): UserEntity? {
        return userDao.getUserByStudentId(studentId.trim())
    }

    private fun autoCalculateFileSizeAndPages(title: String, fileUrl: String): Pair<String, Int> {
        val seed = abs((title + fileUrl).hashCode())
        val pages = 16 + (seed % 28)
        val sizeMb = 2.5 + ((seed % 45).toDouble() / 10.0)
        val formattedSize = String.format("%.1f MB", sizeMb)
        return Pair(formattedSize, pages)
    }

    suspend fun uploadLectureByAdmin(req: NewLectureRequest): Pair<Long, Boolean> {
        val cleanSubject = req.subject.trim()
        val cleanTitle = req.title.trim()
        val section = req.section

        val category = if (section == Section.PRACTICAL && req.category == Category.REEYUS) Category.GHRADI else req.category

        val subjectEntity = SubjectEntity(
            name = cleanSubject, section = section, semester = req.semester, isExamPinned = false, addedAt = System.currentTimeMillis()
        )
        subjectDao.insertSubjectIfAbsent(subjectEntity)
        try {
            SupabaseClient.upsertSubject(subjectEntity)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val (autoSize, autoPages) = autoCalculateFileSizeAndPages(cleanTitle, req.fileUrl)
        val finalSize = if (!req.fileSize.isNullOrBlank()) req.fileSize else autoSize
        val finalPages = if (req.pageCount != null && req.pageCount > 0) req.pageCount else autoPages

        val lectureId = System.currentTimeMillis()
        val hasWorksheet = section == Section.PRACTICAL && req.worksheetUrl.isNotBlank()

        val newLecture = LectureEntity(
            id = lectureId,
            title = cleanTitle,
            subject = cleanSubject,
            stage = Stages.current,
            stageName = Stages.label(Stages.current),
            semester = req.semester,
            fileUrl = if (req.fileUrl.isBlank()) "https://mustansiriyah.edu.iq/pharmacy/lectures/file.pdf" else req.fileUrl,
            fileSize = finalSize,
            pageCount = finalPages,
            uploadTimestamp = System.currentTimeMillis(),
            section = section,
            category = category,
            worksheetUrl = if (hasWorksheet) req.worksheetUrl else "",
            worksheetType = if (hasWorksheet) req.worksheetType.ifBlank { WorksheetType.WORKSHEET } else "",
            youtubeUrl = req.youtubeUrl.trim()
        )

        lectureDao.insertLecture(newLecture)

        var isServerSuccess = false
        try {
            isServerSuccess = SupabaseClient.upsertLecture(newLecture)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error pushing lecture to server", e)
        }

        if (req.sendNotification) {
            val notifId = System.currentTimeMillis() + 1
            val where = if (section == Section.PRACTICAL) "العملي" else "النظري"
            val notification = BroadcastNotificationEntity(
                id = notifId,
                title = "تم رفع ${if (category == Category.OFFICIAL) "محاضرة" else "ملزمة " + Category.label(category)} جديدة ($where): $cleanTitle",
                message = "",
                lectureId = lectureId,
                stage = Stages.current,
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "LECTURE"
            )
            notificationDao.insertNotification(notification)
            try {
                SupabaseClient.upsertNotification(notification)
            } catch (e: Exception) {
                Log.e("PharmacyRepository", "Error pushing notification to server", e)
            }
        }

        return Pair(lectureId, isServerSuccess)
    }

    suspend fun publishAnnouncementByAdmin(
        title: String,
        message: String,
        url: String? = null,
        imageUrl: String? = null,
        style: String = ""
    ): Long {
        val notifId = System.currentTimeMillis()
        val cleanUrl = url?.trim()?.takeIf { it.isNotBlank() }
        val cleanImageUrl = imageUrl?.trim()?.takeIf { it.isNotBlank() }
        val notification = BroadcastNotificationEntity(
            id = notifId,
            title = title,
            message = message,
            timestamp = System.currentTimeMillis(),
            isRead = false,
            type = "ANNOUNCEMENT",
            url = cleanUrl,
            imageUrl = cleanImageUrl,
            style = style
        )
        notificationDao.insertNotification(notification)
        try {
            SupabaseClient.upsertNotification(notification)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error pushing announcement to Supabase", e)
        }
        return notifId
    }

    suspend fun deleteLecture(lecture: LectureEntity) {
        lectureDao.deleteLecture(lecture)
        deleteOfflineCopy(lecture.id)
        try {
            SupabaseClient.deleteLecture(lecture.id)
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error deleting lecture from Supabase", e)
        }
    }

    suspend fun markAllNotificationsAsRead() {
        notificationDao.markAllAsRead()
        val currentNotifs = notificationDao.getAllNotificationsList()
        currentNotifs.forEach { readNotifIds.add(it.id) }
        readNotifPrefs?.edit()?.putStringSet("read_ids", readNotifIds.map { it.toString() }.toSet())?.commit()
    }

    suspend fun markNotificationAsRead(id: Long) {
        notificationDao.markAsRead(id)
        readNotifIds.add(id)
        readNotifPrefs?.edit()?.putStringSet("read_ids", readNotifIds.map { it.toString() }.toSet())?.commit()
    }

    suspend fun dismissNotification(id: Long) {
        dismissedNotifIds.add(id)
        readNotifIds.add(id)
        prefs?.edit()?.putStringSet("dismissed_ids", dismissedNotifIds.map { it.toString() }.toSet())?.commit()
        readNotifPrefs?.edit()?.putStringSet("read_ids", readNotifIds.map { it.toString() }.toSet())?.commit()
        notificationDao.deleteNotification(id)
    }

    suspend fun dismissAllNotifications() {
        val current = notificationDao.getAllNotificationsList()
        val unpinned = current.filter { !it.isPinned }
        unpinned.forEach {
            dismissedNotifIds.add(it.id)
            readNotifIds.add(it.id)
            notificationDao.deleteNotification(it.id)
        }
        prefs?.edit()?.putStringSet("dismissed_ids", dismissedNotifIds.map { it.toString() }.toSet())?.commit()
        readNotifPrefs?.edit()?.putStringSet("read_ids", readNotifIds.map { it.toString() }.toSet())?.commit()
    }

    suspend fun updateNotification(notification: BroadcastNotificationEntity): String? {
        val ok = try {
            SupabaseClient.upsertNotification(notification)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
        if (!ok) return "تعذر حفظ تعديل التبليغ، تأكد من الاتصال"
        notificationDao.insertNotification(notification)
        return null
    }

    suspend fun toggleNotificationPinned(id: Long, isPinned: Boolean) {
        val current = notificationDao.getAllNotificationsList().find { it.id == id }
        if (current != null) {
            val updated = current.copy(isPinned = isPinned)
            notificationDao.insertNotification(updated)
            try {
                SupabaseClient.toggleNotificationPinned(id, isPinned)
            } catch (e: Exception) {
                Log.e("PharmacyRepository", "Error toggling notification pinned status on Supabase", e)
            }
        }
    }

    suspend fun forceSyncWithServer() {
        try {
            syncWithSupabase()
        } catch (e: Exception) {
            Log.e("PharmacyRepository", "Error force syncing with Supabase", e)
        }
    }
}