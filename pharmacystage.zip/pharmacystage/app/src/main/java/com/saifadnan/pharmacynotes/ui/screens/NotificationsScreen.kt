package com.saifadnan.pharmacynotes.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.saifadnan.pharmacynotes.R
import com.saifadnan.pharmacynotes.data.BroadcastNotificationEntity
import com.saifadnan.pharmacynotes.ui.components.GlassCard
import com.saifadnan.pharmacynotes.ui.components.GlassIconButton
import com.saifadnan.pharmacynotes.ui.components.IconTile
import com.saifadnan.pharmacynotes.ui.components.accentColor
import com.saifadnan.pharmacynotes.ui.components.MedicalEmptyNotificationState
import com.saifadnan.pharmacynotes.ui.components.NotificationsTabSkeleton
import com.saifadnan.pharmacynotes.ui.components.PillButton
import com.saifadnan.pharmacynotes.ui.components.ScreenHeader
import com.saifadnan.pharmacynotes.ui.components.animateItemEntrance
import com.saifadnan.pharmacynotes.ui.theme.Amber
import com.saifadnan.pharmacynotes.ui.theme.CardBorder
import com.saifadnan.pharmacynotes.ui.theme.TelegramAccent

@Composable
fun NotificationsScreen(
    notifications: List<BroadcastNotificationEntity>,
    onMarkAllRead: () -> Unit,
    onDismissNotification: (Long) -> Unit = {},
    onDismissAll: () -> Unit = {},
    onNotificationClick: (BroadcastNotificationEntity) -> Unit,
    isAdmin: Boolean = false,
    onTogglePin: ((Long, Boolean) -> Unit)? = null,
    onEditNotification: ((BroadcastNotificationEntity, (String?) -> Unit) -> Unit)? = null,
    isTabLoading: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var previewImageUrl by remember { mutableStateOf<String?>(null) }
    var previewTitle by remember { mutableStateOf("الصورة المرفقة") }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val schedule = rememberWeeklyScheduleState()
    var editTarget by remember { mutableStateOf<BroadcastNotificationEntity?>(null) }
    var editBusy by remember { mutableStateOf(false) }
    var editError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        onMarkAllRead()
    }
    LaunchedEffect(notifications) {
        if (notifications.any { !it.isRead }) {
            onMarkAllRead()
        }
    }
    LaunchedEffect(Unit) { schedule.refresh() }
    LaunchedEffect(tab, schedule.data) { if (tab == 1) schedule.markSeen() }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "تبليغات",
            subtitle = if (tab == 1) schedule.noun else if (notifications.isEmpty()) com.saifadnan.pharmacynotes.data.Stages.label(com.saifadnan.pharmacynotes.data.Stages.current) else "${notifications.size} تبليغ",
            modifier = Modifier.padding(horizontal = 20.dp),
            trailing = if (tab == 0 && notifications.isNotEmpty() && !isTabLoading) {
                {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassIconButton(
                            onClick = onMarkAllRead,
                            modifier = Modifier.testTag("mark_all_read_button")
                        ) {
                            Icon(
                                Icons.Default.DoneAll,
                                contentDescription = "تحديد الكل كمقروء",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        GlassIconButton(
                            onClick = {
                                onDismissAll()
                                Toast.makeText(context, "تم تجاهل جميع التبليغات", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("dismiss_all_button")
                        ) {
                            Icon(
                                Icons.Default.DeleteSweep,
                                contentDescription = "تجاهل الكل",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else null
        )

        NotifTabSwitcher(
            selected = tab,
            onSelect = { tab = it },
            scheduleBadge = schedule.hasUnseen,
            scheduleLabel = schedule.noun,
            scheduleExam = schedule.isExam,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )

        AnimatedContent(
            targetState = tab,
            modifier = Modifier.weight(1f),
            transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(160)) },
            label = "notif_tabs"
        ) { currentTab ->
        if (currentTab == 1) {
            WeeklyScheduleTab(
                state = schedule,
                isAdmin = isAdmin,
                onPreview = { url ->
                    previewTitle = schedule.noun
                    previewImageUrl = url
                }
            )
        } else if (isTabLoading) {
            NotificationsTabSkeleton(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        } else if (notifications.isEmpty()) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                MedicalEmptyNotificationState(
                    message = "لا توجد تبليغات",
                    subtitle = "أي تبليغ أو محاضرة جديدة راح تظهر هنا"
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(notifications, key = { _, item -> item.id }) { index, notif ->
                    NotificationCard(
                        notif = notif,
                        index = index,
                        isAdmin = isAdmin,
                        onClick = { onNotificationClick(notif) },
                        onImageClick = {
                            previewTitle = "الصورة المرفقة"
                            previewImageUrl = notif.imageUrl
                        },
                        onTogglePin = onTogglePin,
                        onEdit = if (isAdmin && onEditNotification != null) { { editTarget = notif; editError = null } } else null,
                        onDismiss = {
                            onDismissNotification(notif.id)
                            Toast.makeText(context, "تم تجاهل التبليغ", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                item(key = "notifications_footer") {
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                        com.saifadnan.pharmacynotes.ui.components.TelegramSupportButton(modifier = Modifier.testTag("telegram_notifications_footer_button"))
                    }
                }
            }
        }
        }
    }

    if (previewImageUrl != null) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }

        Dialog(
            onDismissRequest = { previewImageUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 24.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = previewTitle,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                scale = (scale - 0.5f).coerceAtLeast(1f)
                                if (scale == 1f) offset = Offset.Zero
                            },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "تصغير", tint = Color.White)
                        }

                        IconButton(
                            onClick = {
                                scale = (scale + 0.5f).coerceAtMost(5f)
                            },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "تكبير", tint = Color.White)
                        }

                        IconButton(
                            onClick = { previewImageUrl = null },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 80.dp, bottom = 40.dp)
                        .clipToBounds()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offset = if (scale > 1f) {
                                    Offset(offset.x + pan.x, offset.y + pan.y)
                                } else {
                                    Offset.Zero
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    if (scale > 1f) {
                                        scale = 1f
                                        offset = Offset.Zero
                                    } else {
                                        scale = 2.5f
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    coil.compose.AsyncImage(
                        model = previewImageUrl,
                        contentDescription = "Preview Image",
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y
                            )
                    )
                }
            }
        }
    }

    editTarget?.let { target ->
        EditNotificationDialog(
            notif = target,
            busy = editBusy,
            error = editError,
            onSave = { updated ->
                editBusy = true
                editError = null
                onEditNotification?.invoke(updated) { err ->
                    editBusy = false
                    if (err == null) {
                        editTarget = null
                        Toast.makeText(context, "تم حفظ تعديل التبليغ", Toast.LENGTH_SHORT).show()
                    } else {
                        editError = err
                    }
                }
            },
            onDismiss = { if (!editBusy) { editTarget = null; editError = null } }
        )
    }
}

@Composable
private fun NotificationCard(
    notif: BroadcastNotificationEntity,
    index: Int,
    isAdmin: Boolean,
    onClick: () -> Unit,
    onImageClick: () -> Unit,
    onTogglePin: ((Long, Boolean) -> Unit)?,
    onEdit: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isAnnouncement = notif.type == "ANNOUNCEMENT"
    var expanded by remember(notif.id) { mutableStateOf(false) }
    var overflows by remember(notif.id, notif.message) { mutableStateOf(false) }
    val nStyle = remember(notif.style) { com.saifadnan.pharmacynotes.ui.components.NotifStyle.parse(notif.style) }
    val styled = !nStyle.isDefault
    val nAccent = nStyle.accentColor()

    GlassCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .animateItemEntrance(index = index)
            .then(
                if (styled) Modifier.border(1.2.dp, nAccent.copy(alpha = if (nStyle.level == 2) 0.75f else 0.45f), com.saifadnan.pharmacynotes.ui.theme.AppShapes.Card)
                else Modifier
            )
            .testTag("notification_item_${notif.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                IconTile(
                    icon = if (styled) (com.saifadnan.pharmacynotes.ui.components.NotifIcons[nStyle.icon] ?: Icons.Default.Campaign)
                    else if (isAnnouncement) Icons.Default.Campaign else Icons.Default.NotificationsNone,
                    size = 44.dp,
                    tint = if (styled) nAccent else if (isAnnouncement) Amber else MaterialTheme.colorScheme.onSurface,
                    container = if (styled) nAccent.copy(alpha = 0.16f) else if (isAnnouncement) Amber.copy(alpha = 0.14f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = notif.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Text(
                            text = formatNotificationTime(notif.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                    if (nStyle.level > 0) {
                        com.saifadnan.pharmacynotes.ui.components.NotifLevelBadge(nStyle)
                    }
                    if (notif.isPinned) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = null,
                                tint = Amber,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "مثبّت",
                                style = MaterialTheme.typography.labelSmall,
                                color = Amber
                            )
                        }
                    }
                    if (notif.message.isNotBlank()) {
                        Column(modifier = Modifier.fillMaxWidth().animateContentSize(tween(260))) {
                            com.saifadnan.pharmacynotes.ui.components.RichText(
                                text = notif.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                headerColor = MaterialTheme.colorScheme.onSurface,
                                maxLines = if (expanded) Int.MAX_VALUE else 5,
                                onOverflow = { if (!expanded) overflows = it }
                            )
                            if (overflows || expanded) {
                                Text(
                                    text = if (expanded) "عرض أقل" else "عرض المزيد",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .padding(top = 6.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { expanded = !expanded }
                                        .padding(horizontal = 4.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (!notif.imageUrl.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(20.dp))
                        .clickable { onImageClick() }
                ) {
                    coil.compose.AsyncImage(
                        model = notif.imageUrl,
                        contentDescription = "الصورة المرفقة",
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.45f))
                            .padding(7.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ZoomIn,
                            contentDescription = "تكبير الصورة",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            if (!notif.url.isNullOrBlank()) {
                PillButton(
                    text = "فتح الرابط المرفق",
                    icon = Icons.Default.OpenInNew,
                    height = 44.dp,
                    onClick = {
                        try {
                            val rawUrl = notif.url.trim()
                            val finalUrl = if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) "https://$rawUrl" else rawUrl
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl)))
                        } catch (e: Exception) {
                            Toast.makeText(context, "تعذر فتح الرابط المرفق", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_notif_url_button_${notif.id}")
                )
            }

            if ((isAdmin && onTogglePin != null) || !notif.isPinned) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isAdmin && onTogglePin != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                val newPinnedState = !notif.isPinned
                                onTogglePin.invoke(notif.id, newPinnedState)
                                val msg = if (newPinnedState) "تم تثبيت التبليغ لدى الجميع" else "تم إلغاء تثبيت التبليغ"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("pin_notif_button_${notif.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = null,
                                tint = if (notif.isPinned) Amber else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (notif.isPinned) "إلغاء التثبيت" else "تثبيت",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (notif.isPinned) Amber else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (onEdit != null) {
                            TextButton(
                                onClick = onEdit,
                                modifier = Modifier.testTag("edit_notif_button_${notif.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تعديل",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    if (!notif.isPinned) {
                        TextButton(
                            onClick = onDismiss,
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                            modifier = Modifier.testTag("ignore_notif_button_${notif.id}")
                        ) {
                            Text("تجاهل", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

private fun formatNotificationTime(timestampMillis: Long): String {
    val diffMillis = System.currentTimeMillis() - timestampMillis
    if (diffMillis < 0) return ""
    val minutes = diffMillis / 60000
    val hours = minutes / 60
    val days = hours / 24
    return when {
        minutes < 1 -> "الآن"
        minutes < 60 -> "قبل $minutes د"
        hours < 24 -> "قبل $hours س"
        days < 7 -> "قبل $days يوم"
        else -> {
            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale("ar"))
            sdf.format(java.util.Date(timestampMillis))
        }
    }
}