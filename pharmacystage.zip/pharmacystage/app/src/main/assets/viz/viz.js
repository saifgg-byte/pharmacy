(function () {
  var script = document.currentScript;
  var BASE = script && script.src ? script.src.replace(/[^\/]*$/, "") : "./";
  var loaders = {};

  function loadScript(src) {
    if (loaders[src]) return loaders[src];
    loaders[src] = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src;
      s.async = true;
      s.onload = resolve;
      s.onerror = function () {
        delete loaders[src];
        reject(new Error("load"));
      };
      document.head.appendChild(s);
    });
    return loaders[src];
  }

  function loadCss() {
    if (document.getElementById("pv-css")) return;
    var l = document.createElement("link");
    l.id = "pv-css";
    l.rel = "stylesheet";
    l.href = BASE + "viz.css";
    document.head.appendChild(l);
  }

  function ensure(kind) {
    loadCss();
    if (kind === "mol3d") {
      return window.$3Dmol ? Promise.resolve() : loadScript(BASE + "vendor/3Dmol-min.js");
    }
    return window.Plotly ? Promise.resolve() : loadScript(BASE + "vendor/plotly-cartesian.min.js");
  }

  var REASONS = {
    no_rdkit: "رسم البنية ثلاثية الأبعاد غير مفعّل على السيرفر",
    no_biopython: "تحليل البروتين غير مفعّل على السيرفر",
    no_plotly: "الرسوم البيانية غير مفعّلة على السيرفر",
    no_py3dmol: "التصدير غير مفعّل على السيرفر",
    disabled: "هذه الميزة متوقفة حالياً",
    invalid: "تعذر قراءة البيانات لهذا الرسم",
    not_found: "رمز البروتين غير موجود",
    too_big: "البنية كبيرة جداً للعرض على الجهاز",
    embed: "تعذر توليد الشكل ثلاثي الأبعاد لهذا الجزيء",
    network: "تعذر الاتصال، حاول مرة ثانية",
    http: "تعذر الاتصال، حاول مرة ثانية",
    error: "تعذر إنشاء العرض"
  };

  var PALETTE = ["#5B83D6", "#E07A5F", "#3DA58A", "#E9B44C", "#9B72CF", "#4FB0C6"];
  var PALETTE_DARK = ["#8FB0FF", "#F4A28C", "#6FD1B5", "#F2CB78", "#C4A3F0", "#82D3E6"];

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function cssVars(card, theme) {
    var map = { panel: "--pv-panel", text: "--pv-text", muted: "--pv-muted", border: "--pv-border", brandA: "--pv-a", brandB: "--pv-b", raised: "--pv-raised" };
    card.classList.toggle("pv-dark", !!theme.dark);
    Object.keys(map).forEach(function (k) {
      if (theme[k]) card.style.setProperty(map[k], theme[k]);
    });
  }

  function themeOf(card) {
    var cs = getComputedStyle(card);
    return {
      dark: card.classList.contains("pv-dark"),
      text: cs.getPropertyValue("--pv-text").trim(),
      muted: cs.getPropertyValue("--pv-muted").trim(),
      border: cs.getPropertyValue("--pv-border").trim(),
      a: cs.getPropertyValue("--pv-a").trim(),
      b: cs.getPropertyValue("--pv-b").trim(),
      raised: cs.getPropertyValue("--pv-raised").trim()
    };
  }

  function plotLayout(fig, t) {
    var lay = JSON.parse(JSON.stringify(fig.layout || {}));
    var grid = t.dark ? "rgba(255,255,255,.1)" : "rgba(14,17,22,.08)";
    lay.paper_bgcolor = "rgba(0,0,0,0)";
    lay.plot_bgcolor = "rgba(0,0,0,0)";
    lay.colorway = t.dark ? PALETTE_DARK : PALETTE;
    lay.font = { color: t.text, size: 12, family: "system-ui,-apple-system,Segoe UI,Roboto,Tahoma,sans-serif" };
    lay.dragmode = false;
    lay.hoverlabel = { bgcolor: t.raised, bordercolor: t.border, font: { color: t.text } };
    ["xaxis", "yaxis"].forEach(function (a) {
      var ax = lay[a] || {};
      ax.gridcolor = grid;
      ax.linecolor = t.border;
      ax.tickfont = { color: t.muted, size: 11 };
      ax.fixedrange = true;
      ax.automargin = true;
      if (ax.title) ax.title.font = { color: t.muted, size: 11 };
      lay[a] = ax;
    });
    if (lay.title && lay.title.text) lay.title.font = { color: t.text, size: 14 };
    lay.margin = lay.margin || { l: 46, r: 14, t: 30, b: 44 };
    lay.legend = Object.assign({ orientation: "h", yanchor: "bottom", y: 1.02, xanchor: "right", x: 1, font: { color: t.muted, size: 11 } }, lay.legend || {});
    return lay;
  }

  function reveal(div, fig, t, token) {
    var data = JSON.parse(JSON.stringify(fig.data));
    var lay = plotLayout(fig, t);
    var cfg = { displayModeBar: false, responsive: true, scrollZoom: false, doubleClick: false };
    return Plotly.newPlot(div, data, lay, cfg);
  }

  function chip(label, value, delay) {
    var c = el("span", "pv-chip");
    c.style.animationDelay = delay + "ms";
    c.appendChild(el("small", null, label));
    c.appendChild(el("b", null, String(value)));
    return c;
  }

  function addChips(host, pairs) {
    var box = el("div", "pv-chips");
    pairs.forEach(function (p, i) {
      if (p[1] === null || p[1] === undefined || p[1] === "") return;
      box.appendChild(chip(p[0], p[1], 120 + i * 50));
    });
    if (box.childNodes.length) host.appendChild(box);
  }

  function addSeq(host, label, text) {
    if (!text) return;
    var d = el("div", "pv-seq");
    d.appendChild(el("b", null, label));
    d.appendChild(document.createTextNode(text));
    host.appendChild(d);
  }

  function infoChips(host, p) {
    var i = p.info || {};
    if (p.kind === "plot") {
      var order = { pk_iv: [["C₀", "C0"], ["t½ (h)", "t_half"], ["AUC", "AUC"], ["CL (L/h)", "CL"]], pk_oral: [["Cmax", "Cmax"], ["Tmax (h)", "Tmax"], ["t½ (h)", "t_half"], ["AUC", "AUC"]], emax: [["Emax", "Emax"], ["EC₅₀", "EC50"], ["Hill", "Hill"]], mm: [["Vmax", "Vmax"], ["Kₘ", "Km"]], hh: [["pKₐ", "pKa"]] };
      addChips(host, (order[p.model] || []).map(function (r) { return [r[0], i[r[1]]]; }));
    } else if (p.kind === "seq") {
      addChips(host, [["Length", i.length], ["GC %", i.gc], ["MW", i.mw], ["pI", i.pI], ["Charge pH7", i.charge7], ["Aromaticity", i.aromaticity], ["Instability", i.instability], ["GRAVY", i.gravy], ["Helix", i.helix], ["Sheet", i.sheet]]);
      addSeq(host, "Reverse complement", i.revcomp);
      addSeq(host, "mRNA", i.mrna);
      addSeq(host, "Protein", i.protein);
    } else if (p.kind === "mol3d") {
      var ch = (i.chains || []).map(function (c) { return c.id + ":" + c.residues; }).join("  ");
      addChips(host, [["PDB", i.pdb], ["Formula", i.formula], ["MW", i.mw], ["Resolution", i.resolution ? i.resolution + " Å" : null], ["Chains", ch], ["Ligands", (i.ligands || []).join(", ")], ["Atoms", i.atoms]]);
    }
  }

  function buildMol(body, p, t, token, host) {
    var viewer = $3Dmol.createViewer(body, { backgroundAlpha: 0, antialias: true });
    viewer.addModel(p.data, p.format);
    var protein = p.format === "pdb";
    var modes = protein ? ["cartoon", "sticks", "surface"] : ["sticks", "spheres"];
    var state = { mode: modes[0], spin: true, surface: null };

    function paint() {
      viewer.removeAllSurfaces();
      state.surface = null;
      if (protein) {
        if (state.mode === "cartoon") {
          viewer.setStyle({}, { cartoon: { color: "spectrum", opacity: 0.95 } });
        } else if (state.mode === "sticks") {
          viewer.setStyle({}, { stick: { radius: 0.12, colorscheme: "Jmol" } });
        } else {
          viewer.setStyle({}, { cartoon: { color: "spectrum", opacity: 0.6 } });
          viewer.addSurface($3Dmol.SurfaceType.VDW, { opacity: 0.55, color: t.dark ? "#8fb0ff" : "#5b8db8" }, { hetflag: false });
        }
        viewer.addStyle({ hetflag: true, not: { resn: ["HOH", "WAT"] } }, { stick: { radius: 0.22, colorscheme: "greenCarbon" } });
      } else if (state.mode === "sticks") {
        viewer.setStyle({}, { stick: { radius: 0.14 }, sphere: { scale: 0.26 } });
      } else {
        viewer.setStyle({}, { sphere: { scale: 0.42 }, stick: { radius: 0.1 } });
      }
      viewer.render();
    }

    paint();
    viewer.zoomTo();
    viewer.zoom(0.35, 0);
    viewer.render();
    viewer.zoom(2.85, 900);
    if (state.spin) viewer.spin("y", 0.5);

    var bar = el("div", "pv-bar");
    var btnMode = el("button", "pv-btn", protein ? "كرتون" : "عصي");
    var btnSpin = el("button", "pv-btn pv-on", "تدوير");
    var btnReset = el("button", "pv-btn", "إعادة");
    btnMode.onclick = function () {
      var k = (modes.indexOf(state.mode) + 1) % modes.length;
      state.mode = modes[k];
      btnMode.textContent = { cartoon: "كرتون", sticks: "عصي", surface: "سطح", spheres: "كرات" }[state.mode];
      paint();
    };
    btnSpin.onclick = function () {
      state.spin = !state.spin;
      btnSpin.classList.toggle("pv-on", state.spin);
      if (state.spin) viewer.spin("y", 0.5);
      else viewer.spin(false);
    };
    btnReset.onclick = function () {
      viewer.zoomTo({}, 600);
    };
    body.addEventListener("pointerdown", function () {
      if (state.spin) {
        state.spin = false;
        btnSpin.classList.remove("pv-on");
        viewer.spin(false);
      }
    });
    bar.appendChild(btnMode);
    bar.appendChild(btnSpin);
    bar.appendChild(btnReset);
    host.appendChild(bar);
    token.cleanup = function () {
      try {
        viewer.spin(false);
        viewer.clear();
      } catch (e) {}
    };
    token.resize = function () {
      viewer.resize();
      viewer.render();
    };
    token.setTheme = function () {};
  }

  function mount(host, payload, opts) {
    opts = opts || {};
    var token = { dead: false };
    host.textContent = "";
    var card = el("div", "pv-card" + (opts.chrome === false ? "" : " pv-framed") + (opts.fill ? " pv-fill" : ""));
    cssVars(card, opts.theme || {});
    host.appendChild(card);
    token.card = card;

    if (!payload || !payload.ok) {
      var body0 = el("div", "pv-body pv-plot");
      body0.appendChild(el("div", "pv-msg", REASONS[payload && payload.reason] || REASONS.error));
      card.appendChild(body0);
      return token;
    }

    if (opts.chrome !== false) {
      var head = el("div", "pv-head");
      head.appendChild(el("span", "pv-ic"));
      var title = payload.title || (payload.info && (payload.info.name || payload.info.title)) || payload.name || "";
      head.appendChild(el("div", "pv-title", title));
      card.appendChild(head);
    }

    var isMol = payload.kind === "mol3d";
    var body = el("div", "pv-body " + (isMol ? "pv-mol" : "pv-plot"));
    var wait = el("div", "pv-msg");
    wait.appendChild(el("div", "pv-spin"));
    body.appendChild(wait);
    card.appendChild(body);

    ensure(isMol ? "mol3d" : "plot").then(function () {
      if (token.dead) return;
      body.removeChild(wait);
      var t = themeOf(card);
      if (isMol) {
        buildMol(body, payload, t, token, card);
        infoChips(card, payload);
      } else {
        token.cleanup = function () {
          try { Plotly.purge(body); } catch (e) {}
        };
        token.resize = function () {
          try { Plotly.Plots.resize(body); } catch (e) {}
        };
        token.setTheme = function (th) {
          cssVars(card, th);
          var nt = themeOf(card);
          try { Plotly.relayout(body, plotLayout(payload.figure, nt)); } catch (e) {}
        };
        reveal(body, payload.figure, t, token);
        infoChips(card, payload);
      }
    }).catch(function (err) {
      if (token.dead) return;
      body.textContent = "";
      var loadFail = err && err.message === "load";
      body.appendChild(el("div", "pv-msg", loadFail ? REASONS.network : REASONS.error));
    });
    return token;
  }

  function dispose(token) {
    if (!token) return;
    token.dead = true;
    if (token.cleanup) token.cleanup();
  }

  var current = null;

  window.PharmacyViz = {
    mount: mount,
    dispose: dispose,
    ensure: ensure,
    reasons: REASONS,
    show: function (payload, opts) {
      dispose(current);
      var host = document.getElementById("pv-root") || document.body;
      current = mount(host, payload, opts || { chrome: false, fill: true });
      return current;
    },
    setTheme: function (theme) {
      if (current && current.setTheme) current.setTheme(theme);
    },
    resize: function () {
      if (current && current.resize) current.resize();
    }
  };

  window.addEventListener("resize", function () {
    window.PharmacyViz.resize();
  });
})();
